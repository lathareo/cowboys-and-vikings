# Changelog

## 1.1.0
- **Creation choices vs. granted bonuses.** Ability scores are now points spent + genetic modifier + granted bonuses. Skill ranks are purchased ranks + granted ranks. Origins, the ability Training talents and any Active Effect add to the new `granted` fields, so they never count toward ability points (8) or skill points. The sheet shows granted bonuses as green chips, with a tooltip naming their sources.
- **Origins apply themselves.** Each origin carries a prebuilt Active Effect for its fixed +1 ability and +2 skill ranks. When you drop an origin on a character, it asks for any choices (Soldier's weapon skill, Monastic's ability, talent options), records them as a second effect, and adds the origin talent for free (it doesn't count toward talent picks). Replacing or deleting the origin removes the talent it granted.
- **Genetics buttons.** Roll the genetic ability modifiers (2d8 + 1d4, with the Extreme option). Roll or choose Genetic Talents, Drawbacks and Cosmetic Features straight onto the sheet.
- **Bio tab.** There are now fields for Specialty, Quirk, Ideal, Pledge and Flaw, each paired with a Virtue or Vice, with a 2 + 2 counter. The nine personality prompts (Social, Decisions, Dire Straits) are also on the tab. Every field has roll (dice) and choose (list) buttons tied to its Roll Table.
- **Crew Training upgrade reworked.** Members may spend 2 Strain to roll the chosen skill with Fortune (no AP or RP), instead of gaining 2 ranks. Set the skill on the upgrade, and members get a clover button beside it.
- **Dice Bag** tool in the Token controls, for impromptu rolls.
- **Show Token Art** for any user: a hover button over tokens (client setting), a Token HUD button, a scene tool and a keybinding (Shift+I). It opens only for the user who clicks.
- Darker inactive tab labels for contrast.
- Migration: existing effects that targeted ability `value` or skill `ranks` are rewritten to target `granted`.

## 1.0.0 — Initial release
- Character, Adversary, Hazard and Crew actors with ApplicationV2 sheets.
- 20 item types with dedicated detail sheets.
- CNVRoll dice engine (Advantage, Fortune, critical margins, Fate and Chaos automation).
- Attack and defense cards, damage pipeline, Wounds, death and dying, exhaustion, rests and supply checks.
- 44 conditions with automatic modifiers.
- Spellcasting dialog with Wild Surges.
- Bump initiative, combat upkeep and AP/RP tracking.
- GM Toolkit, the Fate & Chaos tracker, journal enrichers and macros.
- 21 compendium packs covering the full rulebook content, with condensed rules text.
