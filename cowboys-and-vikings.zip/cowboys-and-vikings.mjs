/**
 * Cowboys & Vikings — Foundry VTT game system.
 */
import { CNV } from "./module/config.mjs";
import { actorModels, itemModels } from "./module/data/_module.mjs";
import { CNVActor } from "./module/documents/actor.mjs";
import { CNVItem, rollWildSurge } from "./module/documents/item.mjs";
import { CNVCombat, CNVCombatant } from "./module/documents/combat.mjs";
import { CNVRoll, performCheck, flatCheck } from "./module/dice/cnv-roll.mjs";
import { CharacterSheet, AdversarySheet, HazardSheet, CrewSheet } from "./module/sheets/actor-sheets.mjs";
import { CNVItemSheet } from "./module/sheets/item-sheet.mjs";
import { registerSettings } from "./module/helpers/settings.mjs";
import { registerConditions, setCondition } from "./module/helpers/conditions.mjs";
import { registerChatListeners } from "./module/helpers/chat.mjs";
import { registerSocket, asGM } from "./module/helpers/socket.mjs";
import { registerHandlebars, preloadTemplates } from "./module/helpers/handlebars.mjs";
import { PoolsApp, GMToolkit } from "./module/apps/toolkit.mjs";
import * as macros from "./module/helpers/macros.mjs";
import { migrateWorld } from "./module/helpers/migration.mjs";
import { DiceBag } from "./module/apps/dice-bag.mjs";
import * as builder from "./module/helpers/character-builder.mjs";

const SYS = "cowboys-and-vikings";

Hooks.once("init", () => {
  console.log("Cowboys & Vikings | Initializing the Wild Wastes");

  CONFIG.CNV = CNV;
  game.cnv = { CNVRoll, performCheck, flatCheck, rollWildSurge, setCondition, macros, asGM, apps: { PoolsApp, GMToolkit, DiceBag }, builder,
    showTokenArt: builder.showTokenArt };

  // Documents & data models
  CONFIG.Actor.documentClass = CNVActor;
  CONFIG.Item.documentClass = CNVItem;
  CONFIG.Combat.documentClass = CNVCombat;
  CONFIG.Combatant.documentClass = CNVCombatant;
  Object.assign(CONFIG.Actor.dataModels, actorModels);
  Object.assign(CONFIG.Item.dataModels, itemModels);
  CONFIG.Dice.rolls.unshift(CNVRoll);
  CONFIG.Dice.CNVRoll = CNVRoll;

  // Trackable token attributes
  CONFIG.Actor.trackableAttributes = {
    character: { bar: ["hp", "strain", "sup"], value: ["fate.value", "exhaustion", "hp.temp"] },
    adversary: { bar: ["hp", "strain"], value: ["morale.value", "hp.temp"] },
    hazard: { bar: ["hp"], value: [] },
    crew: { bar: [], value: ["level", "xp"] }
  };

  CONFIG.Combat.initiative = { formula: "1d20 + @initiative.mod", decimals: 2 };
  CONFIG.ActiveEffect.legacyTransferral = false;

  registerSettings();
  registerConditions();
  registerHandlebars();

  // Keybinding: show the art of the hovered (or targeted/controlled) token to yourself
  game.keybindings.register(SYS, "showTokenArt", {
    name: "CNV.TokenArt.Keybind", hint: "CNV.TokenArt.KeybindHint",
    editable: [{ key: "KeyI", modifiers: ["Shift"] }],
    onDown: () => { const t = tokenForArt(); if ( t ) builder.showTokenArt(t); return !!t; }
  });

  // Sheets
  const Actors = foundry.documents.collections.Actors;
  const Items = foundry.documents.collections.Items;
  try { Actors.unregisterSheet("core", foundry.appv1.sheets.ActorSheet); } catch(err) { /* core sheet not registered */ }
  Actors.registerSheet(SYS, CharacterSheet, { types: ["character"], makeDefault: true, label: "CNV.Sheet.Character" });
  Actors.registerSheet(SYS, AdversarySheet, { types: ["adversary"], makeDefault: true, label: "CNV.Sheet.Adversary" });
  Actors.registerSheet(SYS, HazardSheet, { types: ["hazard"], makeDefault: true, label: "CNV.Sheet.Hazard" });
  Actors.registerSheet(SYS, CrewSheet, { types: ["crew"], makeDefault: true, label: "CNV.Sheet.Crew" });
  try { Items.unregisterSheet("core", foundry.appv1.sheets.ItemSheet); } catch(err) { /* core sheet not registered */ }
  Items.registerSheet(SYS, CNVItemSheet, { makeDefault: true, label: "CNV.Sheet.Item" });

  return preloadTemplates();
});

Hooks.once("i18nInit", () => {
  // Localize condition names for token HUD
  for ( const e of CONFIG.statusEffects ) {
    const key = `CNV.Cond.${e.id}`;
    if ( game.i18n.has(key) ) e.name = game.i18n.localize(key);
  }
});

Hooks.once("setup", () => {
  registerChatListeners();
});

Hooks.once("ready", async () => {
  registerSocket();
  game.cnv.pools = new PoolsApp();
  game.cnv.toolkit = new GMToolkit();
  game.cnv.diceBag = new DiceBag();
  builder.registerTokenArtButton();
  if ( game.settings.get(SYS, "showPoolsHud") ) game.cnv.pools.render(true);
  if ( game.user.isGM ) await migrateWorld();
  // Hotbar drop of items creates a use macro
  Hooks.on("hotbarDrop", (bar, data, slot) => {
    if ( data.type !== "Item" ) return;
    macros.createItemMacro(data, slot);
    return false;
  });
});

/** Scene control buttons for the pools and GM toolkit. */
Hooks.on("getSceneControlButtons", controls => {
  const tokens = controls.tokens ?? controls.token;
  if ( !tokens?.tools ) return;
  tokens.tools.cnvPools = {
    name: "cnvPools", title: "CNV.Pools.Title", icon: "fa-solid fa-clover", order: 90, button: true, visible: true,
    onChange: () => game.cnv.pools?.render(true)
  };
  tokens.tools.cnvDiceBag = {
    name: "cnvDiceBag", title: "CNV.DiceBag.Title", icon: "fa-solid fa-dice", order: 92, button: true, visible: true,
    onChange: () => game.cnv.diceBag?.render(true)
  };
  tokens.tools.cnvTokenArt = {
    name: "cnvTokenArt", title: "CNV.TokenArt.Tool", icon: "fa-solid fa-image-portrait", order: 93, button: true, visible: true,
    onChange: () => {
      const t = tokenForArt();
      if ( t ) builder.showTokenArt(t);
      else ui.notifications.info(game.i18n.localize("CNV.TokenArt.NoToken"));
    }
  };
  tokens.tools.cnvToolkit = {
    name: "cnvToolkit", title: "CNV.Toolkit.Title", icon: "fa-solid fa-hat-cowboy", order: 91, button: true, visible: game.user.isGM,
    onChange: () => game.cnv.toolkit?.render(true)
  };
});

/** Show AP/RP pips in the combat tracker. */
Hooks.on("renderCombatTracker", (app, html) => {
  const combat = app.viewed;
  if ( !combat ) return;
  html.querySelectorAll("[data-combatant-id]").forEach(li => {
    const c = combat.combatants.get(li.dataset.combatantId);
    if ( !c ) return;
    const ap = c.getFlag(SYS, "ap"), apMax = c.getFlag(SYS, "apMax"), rp = c.getFlag(SYS, "rp"), rpMax = c.getFlag(SYS, "rpMax");
    if ( apMax === undefined ) return;
    const acted = c.getFlag(SYS, "acted");
    const el = document.createElement("div");
    el.className = "cnv-economy";
    const pips = (n, max, cls, label) => Array.from({ length: max }, (_, i) =>
      `<i class="${i < n ? "fa-solid" : "fa-regular"} fa-circle ${cls}" data-econ="${cls}" data-index="${i}" data-tooltip="${label}"></i>`).join("");
    el.innerHTML = `${pips(ap, apMax, "ap", "AP")}<span class="sep"></span>${pips(rp, rpMax, "rp", "RP")}${acted ? `<i class="fa-solid fa-check acted" data-tooltip="${game.i18n.localize("CNV.Combat.Acted")}"></i>` : ""}`;
    el.querySelectorAll("[data-econ]").forEach(pip => pip.addEventListener("click", async ev => {
      ev.stopPropagation();
      if ( !c.isOwner ) return;
      const key = pip.dataset.econ;
      const idx = Number(pip.dataset.index);
      const cur = c.getFlag(SYS, key);
      await c.setFlag(SYS, key, idx < cur ? idx : idx + 1);
    }));
    (li.querySelector(".token-name") ?? li.querySelector(".combatant-name") ?? li).append(el);
  });
});

/** The token to show art for: hovered, else targeted, else controlled. */
function tokenForArt() {
  return canvas.tokens?.hover ?? game.user.targets.first() ?? canvas.tokens?.controlled[0] ?? null;
}

/** Keep origin grants in step with the origin item. */
Hooks.on("createItem", (item, options, userId) => {
  if ( userId !== game.user.id || item.type !== "origin" || item.parent?.type !== "character" ) return;
  if ( options.cnvSkipOrigin ) return;
  builder.applyOrigin(item.parent, item);
});
Hooks.on("deleteItem", (item, options, userId) => {
  if ( userId !== game.user.id || item.type !== "origin" || item.parent?.type !== "character" ) return;
  builder.removeOriginGrants(item.parent, item);
});
/** Crew membership changes alter members' training buttons. */
Hooks.on("updateActor", actor => {
  if ( actor.type !== "crew" ) return;
  for ( const uuid of actor.system.members ?? [] ) fromUuidSync(uuid)?.sheet?.rendered && fromUuidSync(uuid).sheet.render();
});
for ( const h of ["createItem", "updateItem", "deleteItem"] ) Hooks.on(h, item => {
  if ( item.type !== "crewUpgrade" || item.parent?.type !== "crew" ) return;
  for ( const uuid of item.parent.system.members ?? [] ) { const a = fromUuidSync(uuid); if ( a?.sheet?.rendered ) a.sheet.render(); }
});

/** Right-click token HUD: show-art button, and valued conditions step up/down with wheel. */
Hooks.on("renderTokenHUD", (hud, html) => {
  const col = html.querySelector(".col.left") ?? html.querySelector(".left");
  if ( col && hud.object?.document?.texture?.src ) {
    const b = document.createElement("button");
    b.type = "button";
    b.className = "control-icon cnv-show-art";
    b.dataset.tooltip = game.i18n.localize("CNV.TokenArt.Show");
    b.innerHTML = '<i class="fa-solid fa-image"></i>';
    b.addEventListener("click", ev => { ev.preventDefault(); builder.showTokenArt(hud.object); });
    col.append(b);
  }
  const actor = hud.object?.actor;
  if ( !actor ) return;
  html.querySelectorAll(".effect-control[data-status-id]").forEach(el => {
    const id = el.dataset.statusId;
    const c = CONFIG.CNV.conditions?.[id];
    if ( !c?.valued ) return;
    const eff = actor.effects.find(e => e.statuses.has(id));
    if ( eff ) {
      const badge = document.createElement("span");
      badge.className = "cnv-hud-value";
      badge.textContent = eff.getFlag(SYS, "value") ?? 1;
      el.after(badge);
    }
    el.addEventListener("contextmenu", async ev => {
      if ( !eff ) return;
      ev.preventDefault(); ev.stopPropagation();
      const v = (eff.getFlag(SYS, "value") ?? 1) - 1;
      await setCondition(actor, id, Math.max(0, v));
      hud.render();
    }, { capture: true });
    el.addEventListener("wheel", async ev => {
      ev.preventDefault();
      const v = (eff?.getFlag(SYS, "value") ?? 0) + (ev.deltaY < 0 ? 1 : -1);
      await setCondition(actor, id, Math.max(0, v));
      hud.render();
    });
  });
});

/** Valued condition number overlay on tokens. */
Hooks.on("drawToken", token => token.document?.actor && token.renderFlags?.set({ refreshEffects: true }));

/** Keep a PC's valued conditions from stacking: Lingering uses the higher value. */
Hooks.on("preCreateActiveEffect", (effect, data, options) => {
  const parent = effect.parent;
  if ( !(parent instanceof Actor) ) return;
  for ( const s of effect.statuses ?? [] ) {
    const existing = parent.effects.find(e => e.statuses.has(s));
    if ( existing && CONFIG.CNV.conditions[s]?.valued ) {
      const nv = effect.getFlag(SYS, "value") ?? 1;
      if ( nv > (existing.getFlag(SYS, "value") ?? 1) ) existing.update({ [`flags.${SYS}.value`]: nv, name: `${CONFIG.CNV.conditions[s].name} ${nv}` });
      return false;
    }
  }
});

/** Journal/chat enrichers: [[/check skill dc]] style inline buttons via @Check[...] */
Hooks.once("init", () => {
  CONFIG.TextEditor.enrichers.push({
    pattern: /@(Check|Save)\[([^\]]+)\](?:\{([^}]+)\})?/gi,
    enricher: (match) => {
      const [, kind, args, label] = match;
      const parts = Object.fromEntries(args.split("|").map(p => p.split(":").map(x => x.trim())));
      const a = document.createElement("a");
      a.classList.add("cnv-inline-roll");
      const key = parts.skill ?? parts.ability ?? parts.save ?? Object.keys(parts)[0];
      a.dataset.kind = kind.toLowerCase();
      a.dataset.key = key;
      if ( parts.dc ) a.dataset.dc = parts.dc;
      const name = kind.toLowerCase() === "save" ? game.i18n.localize(CONFIG.CNV.abilities[key]?.label ?? key) : game.i18n.localize(CONFIG.CNV.skills[key]?.label ?? CONFIG.CNV.abilities[key]?.label ?? key);
      a.innerHTML = `<i class="fa-solid fa-dice-d20"></i> ${label ?? `${parts.dc ? `DC ${parts.dc} ` : ""}${name}${kind.toLowerCase() === "save" ? ` ${game.i18n.localize("CNV.Save")}` : ""}`}`;
      return a;
    }
  });
  document.addEventListener("click", ev => {
    const a = ev.target.closest?.(".cnv-inline-roll");
    if ( !a ) return;
    ev.preventDefault();
    const actors = canvas.tokens?.controlled.map(t => t.actor).filter(Boolean) ?? [];
    if ( !actors.length && game.user.character ) actors.push(game.user.character);
    if ( !actors.length ) return ui.notifications.warn(game.i18n.localize("CNV.Chat.SelectToken"));
    const dc = a.dataset.dc ? Number(a.dataset.dc) : null;
    for ( const actor of actors ) {
      if ( a.dataset.kind === "save" ) actor.rollSave(a.dataset.key, { dc, event: ev });
      else if ( CONFIG.CNV.skills[a.dataset.key] ) actor.rollSkill(a.dataset.key, { dc, event: ev });
      else if ( CONFIG.CNV.abilities[a.dataset.key] ) actor.rollAbility(a.dataset.key, { dc, event: ev });
      else if ( a.dataset.key === "flat" ) actor.rollFlat(dc ?? 15);
    }
  });
});
