# Cowboys & Vikings — Foundry VTT System

A complete game system for **Cowboys & Vikings** on Foundry Virtual Tabletop (v13 minimum, v14 verified).

## Installation
1. Copy the `cowboys-and-vikings` folder into your Foundry `Data/systems/` directory (or install from the zip with the manifest URL once hosted).
2. Restart Foundry and create a world using **Cowboys & Vikings**.

## Features
- **Actors:** Character, Adversary (auto-calculated from Rank / Role / Level tracks), Hazard, Crew.
- **Items:** 20 types, including weapons, armor, shields, gear, concoctions, talents, techniques, spells, metamagic, origins, genetics, bonds, maneuvers, afflictions, runes, materials, essences, ingredients, crew abilities and crew upgrades.
- **Dice engine:** d20 + modifiers, Advantage/Disadvantage (±2 per level), Fortune/Misfortune, critical margins (±15, ±10 for defenses), and automatic Fate and Chaos dice.
- **Combat:** targeted attack cards with Parry/Dodge/Take the Hit defense buttons.
  - **Damage:** a full pipeline covering Soak, armor piercing, resistance, vulnerability and immunity, Fortified/Heavy, temp HP and minions.
  - **Injury and death:** Wounds by hit location, Strain overflow into exhaustion, and death options with a Death Timer.
  - **Turn flow:** initiative "bump" mode, AP/RP pips and end-of-turn upkeep cards.
- **Conditions:** 44 status effects with valued badges and automatic roll modifiers.
- **Magic:** a live Strain calculator for deliveries, casting times, components, modifiers, metamagic and push, with automatic Wild Surge tables.
- **GM tools:**
  - Fate & Chaos tracker.
  - Skill Challenge, Negotiation, Encounter Budget and Reaction Roll toolkit.
  - Morale checks, supply checks, rests and group checks.
- **Compendiums:** 21 packs with about 1,400 entries:
  - Rules reference journals.
  - Every talent, spell, weapon, armor, gear item, concoction, rune, material, maneuver, crew option, origin, genetic trait and bond.
  - Wild Surge and GM roll tables.
  - Example adversaries and hazards.
  - Macros.

## Journal Enrichers
`@Check[athletics|dc:15]` and `@Save[reflex|dc:18]` render as clickable roll buttons for the selected tokens.

## Macros API
`game.cnv.macros` exposes `useItem`, `rollSkill`, `rollSave`, `rollAbility`, `flat`, `groupCheck`, `falling`, `surge`, `takeABreak`, `shortRest`, `longRest`, `openPools` and `openToolkit`.

## Building the Compendiums
The pack source is in `_source/`. Running `python3 _source/build.py` generates the JSON, then `node compile.mjs <json> packs` compiles it with `@foundryvtt/foundryvtt-cli`.
