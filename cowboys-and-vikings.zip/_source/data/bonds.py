"""Bonds chapter: 26 Teamwork Talents (bond items with 4 tiers) and the Bond category tables."""

IMG = "icons/skills/social/diplomacy-unity-alliance.webp"
R1 = "Reaction (1 RP), partner within Close range."

# name: (shape, trigger, t1, t2, t3, t4)
TT = {
    "Coordinated Strike": ("reactive", "Your partner hits a creature with an attack.",
        "Gain 1 Advantage on your next attack against that creature before the start of your partner's next turn.", "2 Advantage.",
        "+1 Strain: your partner also gains 1 Advantage on their next attack against it.", "Or 2 Strain: your partner gains 2 Advantage instead."),
    "Guardian's Intercept": ("reactive", "A creature makes an attack that would hit your partner.",
        "The attack targets you instead, resolved against your Defense.", "Or split the damage evenly between you (round down).",
        "+1 Strain: halve the damage you take.", "Also triggers when your partner fails a save against a damaging effect; or 2 Strain to negate your share entirely."),
    "Rally": ("reactive", "Your partner is about to attempt a check or save.",
        "Grant 1 Advantage on that roll.", "2 Advantage.", "+1 Strain: also cancel 1 Disadvantage on that roll.", "Or 2 Strain: cancel up to 2 Disadvantage."),
    "Blind Trust": ("reactive", "Your partner is about to attempt a check with a skill you have 1+ ranks in.",
        "Grant the Help bonus (+1 status, +1 per 3 of your ranks) without spending the 1 AP.", "Base bonus +2.",
        "+1 Strain: the bonus can apply to a save instead.", "Or 2 Strain: they also roll with Fortune."),
    "Read Each Other": ("reactive", "Your partner is about to Parry or Dodge.",
        "Grant 1 Advantage on that save.", "2 Advantage.", "+1 Strain: they also Step up to 10 ft free as part of dodging (no reactions provoked).",
        "Or 2 Strain: also cancel up to 2 Disadvantage on that save."),
    "Shared Resolve": ("reactive", "Your partner fails a save against a Fear or Mental effect.",
        "They reroll and must keep the new result.", "The reroll has Fortune.", "+1 Strain: instead end an existing Fear or Mental lingering condition on them.",
        "Or 2 Strain: end that condition entirely regardless of its value."),
    "Bonded Mind": ("reactive", "Initiative is about to be rolled for an encounter you both share.",
        "Always: while you can see each other you communicate silently and instantly. Reaction: swap your raw Initiative die results.",
        "May also be used after initiative is rolled, before the first turn resolves.", "+1 Strain: whoever acts later gets 1 Advantage on their first action.",
        "Or 2 Strain: 2 Advantage."),
    "Lend a Hand": ("reactive", "Your partner is about to spend Strain, a Fate Die or SUP on an action.",
        "Pay half that cost (round down, minimum 1) from your own matching resource.", "You may pay the full cost.",
        "+1 Strain: they also gain 1 Advantage on that action.", "Or 2 Strain: 2 Advantage."),
    "United Front": ("reactive", "Your partner attempts Diplomacy, Deception or Intimidation in a scene where you visibly act together.",
        "Grant 1 Advantage on that check.", "2 Advantage.", "+1 Strain: draw any social reaction the creature would have toward your partner onto yourself for the scene.",
        "Or 2 Strain: also give them Fortune on that check."),
    "Swap Places": ("reactive", "Your adjacent partner is about to be forced to move, Grappled or Restrained.",
        "Swap positions instantly; you take their place and any positional effect.", "No longer requires adjacency, only Close range.",
        "+1 Strain: your partner gets 1 Advantage on their next check or save to escape or resist what prompted the swap.", "Or 2 Strain: 2 Advantage."),
    "Open the Wound": ("reactive", "Your partner inflicts a lingering condition on a creature.",
        "If you damage that creature before your partner's next turn, deal +1d6.", "+2d6.", "+1 Strain: that attack ignores the creature's resistance to your damage type.",
        "Or 2 Strain: also treat its immunity as resistance."),
    "Old Feelings": ("activated", "",
        "Spend 1 Strain (no action) to read your partner's general emotional or physical state.", "A look can also carry a single silent word or short phrase.",
        "Or spend 2 Strain to convey a short plan or request.", "The state read (Tier 1) no longer costs Strain."),
    "Danger Sense": ("activated", "You or your partner are about to be surprised by a hazard, ambush or sudden danger while traveling together.",
        "Spend 1 Strain: both gain 1 Advantage on the Perception save.", "2 Advantage.", "+1 Strain: 1 Advantage on the first action either of you takes in response.",
        "Or +2 Strain: 2 Advantage on that response."),
    "In Their Name": ("reactive", "Your partner acts clearly to avenge or honor the loss you share.",
        "Grant 1 Advantage on that action.", "2 Advantage.", "+1 Strain: +1d6 damage if it deals damage.", "Or 2 Strain: +2d6."),
    "Just Us Now": ("reactive", "You and your partner are outnumbered by hostiles in an encounter.",
        "Both gain 1 Advantage on attacks and saves for the encounter or until no longer outnumbered.", "2 Advantage.",
        "+1 Strain: both also gain +1 Soak for the same duration.", "Or 2 Strain: +2 Soak."),
    "Iron Sharpens Iron": ("activated", "During downtime or preparation you propose genuinely different approaches to the same goal and settle on one.",
        "Spend 1 Strain: 1 Advantage on the first check executing the plan.", "2 Advantage.", "+1 Strain: applies to the first check by each of you.",
        "Or +2 Strain: the first two checks each of you makes."),
    "Own It Together": ("reactive", "Your partner fails a save or suffers a harm, and you describe how you step in (GM may adjust the RP cost).",
        "Damage: take half (round down, minimum 1). Condition, Wound or affliction with a recovery roll: you suffer it too, but you both make recovery rolls with Fortune.",
        "For damage, you may take all of it.", "+1 Strain: your partner gets 1 Advantage on their next check.", "Or 2 Strain: 2 Advantage."),
    "Keepers of the Secret": ("reactive", "Your partner makes a Deception or Stealth check to protect your shared secret with you present.",
        "Grant 1 Advantage on that check.", "2 Advantage.", "+1 Strain: they also roll with Fortune.",
        "Or 2 Strain: any lingering suspicion from a failure lands on you instead."),
    "Never Really Apart": ("activated", "",
        "Exploration: spend 1 Strain to make a Survival check to sense your partner's direction or location anywhere on the same plane.", "1 Advantage on this check.",
        "+1 Strain: also sense their emotional state (no check).", "Or +2 Strain: also send a single word or feeling to them."),
    "I Owe You": ("activated", "Your partner needs a consumable but has 0 SUP mid-scene.",
        "Spend 1 Strain to make a Supply Check for them with your SUP at +2 DC (a Reaction in combat). Only when they're truly at 0.", "No DC penalty.",
        "DC reduced by 2.", "You also roll with Fortune."),
    "Second Chances": ("reactive", "The agreed situation that echoes your past betrayal arises, and one of you chooses trust instead.",
        "Agree on the trigger when you take the Bond. Grant 1 Advantage on the action tied to that choice.", "2 Advantage.",
        "+1 Strain: you gain the same Advantage on your own next action.", "Or 2 Strain: both of you get Fortune instead of Advantage."),
    "Steady Hand": ("reactive", "Your partner invokes their Vice and you're present to back them.",
        "Split the GM's complication between you (as Own It Together).", "They may choose a stronger Stakes Menu item.",
        "+1 Strain: you also gain a Stakes Menu item.", "Or 2 Strain: both gain an item and the complication affects only your partner."),
    "United in Faith": ("reactive", "Your partner makes a check or save defending your shared faith or standing.",
        "Grant 1 Advantage on that roll.", "2 Advantage.", "+1 Strain: you get the same Advantage on your own next relevant action.",
        "Or 2 Strain: both of you get Fortune instead."),
    "Unshaken": ("reactive", "Your partner saves against an effect or manipulation meant to divide you.",
        "Grant 1 Advantage on that save.", "2 Advantage.", "+1 Strain: also cancel 1 Disadvantage.",
        "Or 2 Strain: cancel up to 2 Disadvantage; even on a failure the effect can't make them act directly against you."),
    "Two Schools": ("activated", "In a Skill Challenge your partner uses a skill different from one you have ranks in, and you describe your different angle.",
        "Spend 1 Strain (plus 1 RP in combat) to attempt a check with your own skill; a success counts toward the challenge.", "1 Advantage on this check.",
        "+1 Strain: your partner gets 1 Advantage on their next attempt in the challenge.", "Or +2 Strain: 2 Advantage."),
    "We've Seen This Before": ("activated", "You or your partner meet the agreed threat from your shared past again.",
        "Agree on the threat when you take the Bond. Spend 1 Strain: your partner (never yourself) gets 1 Advantage on Perception, Initiative or relevant saves against it for the scene.",
        "2 Advantage.", "+1 Strain: also 1 Advantage on attacks and checks directly against it.", "Or +2 Strain: 2 Advantage on those."),
}

CATEGORIES = {
    "Childhood Friends": ("You grew up in the same place and shared adventures since childhood.", [
        ("Betrayal of Trust", "One revealed the other's secret; trust took years to mend.", "Second Chances, Keepers of the Secret, Blind Trust"),
        ("Unresolved Rivalry", "Childhood competition hardened into friction over leadership.", "Read Each Other, Coordinated Strike, Open the Wound"),
        ("Misadventure Gone Wrong", "A prank or adventure ended in tragedy that still haunts you.", "Own It Together, Guardian's Intercept, Swap Places"),
        ("Family Feud", "Your families' feud forced a choice between friendship and kin.", "United Front, Rally, Swap Places"),
        ("Unrequited Love", "One's feelings went unreturned, leaving distance.", "Old Feelings, Bonded Mind, Read Each Other"),
        ("Blame for a Crime", "Falsely accused and later cleared, but reputations scarred.", "Second Chances, United Front, Blind Trust"),
        ("Different Paths", "One left for adventure, one stayed; resentment grew.", "Never Really Apart, Bonded Mind, Old Feelings"),
        ("Dark Influence", "One fell under a dark power; the other fought to save them.", "Steady Hand, Shared Resolve, Guardian's Intercept")]),
    "Family Ties": ("Siblings, cousins or distant kin who stayed close.", [
        ("Inherited Feud", "A family vendetta keeps dragging you into danger.", "United Front, We've Seen This Before, Swap Places"),
        ("Divided Loyalty", "Elders' disputes forced you onto opposite sides.", "Rally, Blind Trust, United Front"),
        ("Betrayal Within the Family", "A relative betrayed you for gain, souring trust.", "Second Chances, Unshaken, Keepers of the Secret"),
        ("Family Curse", "A generational curse you must break together.", "We've Seen This Before, Shared Resolve, Just Us Now"),
        ("Unfulfilled Expectations", "One carries the family legacy, the other walked away.", "Rally, Blind Trust, Iron Sharpens Iron"),
        ("Financial Ruin", "The family fortune collapsed and must be restored.", "Lend a Hand, I Owe You, Blind Trust"),
        ("Unwanted Marriage", "One is forced into an arranged match; the other helps resist.", "Guardian's Intercept, Swap Places, Rally"),
        ("Lost Heirloom", "A treasured heirloom was stolen and both feel to blame.", "Two Schools, Danger Sense, Blind Trust")]),
    "Student of the Same Teacher": ("You trained under the same mentor.", [
        ("Rivalry", "You competed fiercely for the teacher's favor.", "Coordinated Strike, Read Each Other, Open the Wound"),
        ("Teacher's Disappearance", "Your mentor vanished and you search together.", "Two Schools, Blind Trust, Bonded Mind"),
        ("Conflicting Teachings", "You were taught opposing methods and still argue.", "Two Schools, Iron Sharpens Iron, Blind Trust"),
        ("Failed Experiment", "A supervised experiment exploded and you were both blamed.", "We've Seen This Before, Own It Together, Blind Trust"),
        ("Corrupt Mentor", "Your teacher was using you; you faced the fallout.", "Unshaken, Shared Resolve, Keepers of the Secret"),
        ("Betrayal", "One betrayed the other for the mentor's favor.", "Second Chances, Unshaken, Blind Trust"),
        ("Mentor's Demise", "Your mentor was killed and you seek vengeance.", "In Their Name, Open the Wound, Shared Resolve"),
        ("Forbidden Knowledge", "You learned dangerous secrets that draw powerful enemies.", "Keepers of the Secret, Blind Trust, Unshaken")]),
    "Former Rivals": ("Once competitors, circumstance forced mutual respect.", [
        ("Sabotage Attempts", "Old sabotage still causes problems.", "Read Each Other, Second Chances, Own It Together"),
        ("Differing Methods", "Your approaches clash constantly.", "Two Schools, Iron Sharpens Iron, Blind Trust"),
        ("Past Betrayal", "One betrayed the other during the rivalry.", "Second Chances, Unshaken, Blind Trust"),
        ("Unresolved Competition", "You still try to outdo each other, recklessly.", "Coordinated Strike, Open the Wound, Read Each Other"),
        ("Distrust from Allies", "Your companions doubt the partnership.", "United Front, Second Chances, Rally"),
        ("Blame for Failure", "You each blame the other for past failures.", "Own It Together, Rally, Second Chances"),
        ("Manipulation by Enemies", "Foes exploit your history to divide you.", "Unshaken, Second Chances, United Front"),
        ("Romantic Rivalry", "You both fell for the same person.", "Old Feelings, Coordinated Strike, Bonded Mind")]),
    "Saved One's Life": ("One of you saved the other, forging gratitude and loyalty.", [
        ("Debilitating Injury", "The rescued one was left injured; the savior feels guilt.", "Own It Together, Swap Places, Rally"),
        ("Unwanted Attention", "The rescue made a powerful enemy of you both.", "Guardian's Intercept, Swap Places, We've Seen This Before"),
        ("Debt of Gratitude", "The saved one depends too heavily on the savior.", "I Owe You, Lend a Hand, Rally"),
        ("Misinterpreted Motives", "Others suspect the rescue was self-serving.", "United Front, Second Chances, Keepers of the Secret"),
        ("Haunted by the Past", "The event still brings nightmares to both.", "Shared Resolve, Own It Together, Old Feelings"),
        ("Guilt and Resentment", "The savior blames themself for those not saved.", "Own It Together, Shared Resolve, Rally"),
        ("Different Goals", "The saved one follows out of debt, against their own aims.", "Rally, Blind Trust, Iron Sharpens Iron"),
        ("Endangering the Savior", "Loyalty drives the saved one to reckless protection.", "Guardian's Intercept, Swap Places, Own It Together")]),
    "Religious Connection": ("You met through a shared faith.", [
        ("Doctrinal Disputes", "You interpret the teachings differently.", "Iron Sharpens Iron, Two Schools, Rally"),
        ("Forbidden Relationship", "Your faith forbids something one of you does.", "Keepers of the Secret, Bonded Mind, Second Chances"),
        ("Zealous Rival", "A zealot works to undermine you.", "United in Faith, Unshaken, Rally"),
        ("Religious Persecution", "Your faith is outlawed here.", "Keepers of the Secret, Bonded Mind, United Front"),
        ("Prophecy Pressure", "A prophecy places heavy expectations on you.", "United in Faith, Rally, Shared Resolve"),
        ("Crisis of Faith", "One doubts; the other struggles to support them.", "Shared Resolve, United in Faith, Rally"),
        ("Interfaith Conflict", "Rival believers test your commitment.", "United in Faith, Two Schools, Unshaken"),
        ("Temptation and Corruption", "One is tempted by a dark power.", "Steady Hand, Shared Resolve, Guardian's Intercept")]),
    "Shared Backstory": ("You survived the same disaster or upheaval.", [
        ("Trauma from the Event", "Both still carry the shock of it.", "Shared Resolve, Old Feelings, Own It Together"),
        ("Survivor's Guilt", "You both ask why you lived.", "Own It Together, Shared Resolve, In Their Name"),
        ("Haunted by Memories", "The event left strange manifestations behind.", "Old Feelings, Shared Resolve, We've Seen This Before"),
        ("Injury or Disability", "Lasting injuries shape your adventuring.", "Own It Together, Swap Places, Rally"),
        ("Lost Loved Ones", "Grief for those lost still weighs on you.", "In Their Name, Open the Wound, Shared Resolve"),
        ("Revenge Quest", "You hunt a common foe but disagree on methods.", "In Their Name, Open the Wound, Two Schools"),
        ("Lingering Danger", "The threat that caused it still looms.", "We've Seen This Before, Danger Sense, Just Us Now"),
        ("Distrust of Authority", "You believe those in power failed you.", "United Front, Unshaken, Keepers of the Secret")]),
    "Comrades-in-Arms": ("You fought side by side in a battle or war.", [
        ("Battle Trauma", "One is haunted by the war; the other doesn't know how to help.", "Shared Resolve, Old Feelings, Own It Together"),
        ("Betrayal by a Comrade", "A trusted soldier betrayed your unit.", "Second Chances, Unshaken, Own It Together"),
        ("War Crimes", "One did something in the war the other condemns.", "Own It Together, Unshaken, Shared Resolve"),
        ("Lost Limb", "One lost a limb despite the other's efforts.", "Own It Together, Swap Places, Rally"),
        ("Political Fallout", "You were branded traitors afterward.", "United Front, Keepers of the Secret, We've Seen This Before"),
        ("Addiction", "One turned to a vice to cope.", "Steady Hand, Shared Resolve, Own It Together"),
        ("Blame for a Defeat", "One's decision cost the battle.", "Own It Together, Second Chances, Rally"),
        ("Captured and Tortured", "One was captured by the enemy; scars remain.", "Shared Resolve, Own It Together, Guardian's Intercept")]),
    "Working Partners": ("A deliberate professional partnership—guild, company, order or business.", [
        ("Financial Troubles", "The venture is failing and tempers are short.", "Lend a Hand, I Owe You, Blind Trust"),
        ("Embezzlement", "One skimmed from the business.", "Second Chances, Unshaken, Keepers of the Secret"),
        ("Leadership Conflict", "A promotion upset the balance between you.", "Rally, Blind Trust, Iron Sharpens Iron"),
        ("Frame-Up", "One was framed; the other must choose to help.", "United Front, Swap Places, Second Chances"),
        ("Mysterious Artifact", "A job yielded a dangerous unknown artifact.", "Two Schools, Iron Sharpens Iron, Danger Sense"),
        ("Ethical Dilemma", "A job tested your morals and split you.", "Iron Sharpens Iron, Two Schools, Rally"),
        ("Newly Gained Enemies", "A job made you powerful enemies.", "We've Seen This Before, Guardian's Intercept, Danger Sense"),
        ("Broken Trust", "One withheld or stole during a job.", "Second Chances, Unshaken, Blind Trust")]),
    "Chance Companions": ("Circumstance threw you together and you chose to stay.", [
        ("Trust Issues", "You started out wary of each other.", "Second Chances, Rally, Blind Trust"),
        ("Conflicting Goals", "You're headed for different destinations.", "Rally, Iron Sharpens Iron, Two Schools"),
        ("Ambush", "An ambush you survived together still rattles you.", "Danger Sense, Bonded Mind, Swap Places"),
        ("Cultural Clashes", "Different customs cause friction.", "Two Schools, Iron Sharpens Iron, Rally"),
        ("Hidden Secrets", "One hides a dark past.", "Keepers of the Secret, Bonded Mind, Second Chances"),
        ("Mutual Friend's Betrayal", "The friend who introduced you betrayed you both.", "Just Us Now, Second Chances, Unshaken"),
        ("Romantic Entanglement", "Romance complicates the partnership.", "Old Feelings, Bonded Mind, Read Each Other"),
        ("Past Rivalry", "An old conflict resurfaced when you met.", "Coordinated Strike, Read Each Other, Open the Wound")]),
}


def entries():
    out = []
    for name, (shape, trig, *tiers) in TT.items():
        head = R1 if shape == "reactive" else "Activated: no action cost, but always costs Strain (plus 1 RP if used mid-combat on a trigger)."
        desc = f"<p><em>{'Reactive' if shape == 'reactive' else 'Activated'} Teamwork Talent.</em> {head}</p>"
        if trig:
            desc += f"<p><strong>Trigger:</strong> {trig}</p>"
        desc += "".join(f"<p><strong>Tier {i+1} (Level {[1,5,9,13][i]}):</strong> {t}</p>" for i, t in enumerate(tiers))
        out.append({"name": name, "type": "bond", "img": IMG, "folder": "Teamwork Talents",
                    "system": {"category": "", "partner": "", "origin": "", "unlocked": 1, "cost": "reaction" if shape == "reactive" else "strain",
                               "actionTraits": [shape],
                               "tiers": [{"level": i + 1, "name": f"Tier {i+1}", "text": t} for i, t in enumerate(tiers)], "description": desc}})
    return out


def tables():
    T = [{"name": "Bond Category", "folder": "Bonds", "formula": "1d10", "img": IMG,
          "results": [(i + 1, i + 1, f"{c} — {v[0]}") for i, (c, v) in enumerate(CATEGORIES.items())]}]
    for c, (blurb, rows) in CATEGORIES.items():
        T.append({"name": f"Bonds — {c}", "folder": "Bonds", "formula": "1d8", "img": IMG, "description": blurb,
                  "results": [(i + 1, i + 1, f"<strong>{n}.</strong> {d} <em>Suggested: {s}.</em>") for i, (n, d, s) in enumerate(rows)]})
    return T


RULES = """<h2>Bonds</h2><p>A Bond is a mechanical relationship between two specific PCs. Each Bond grants both a shared Teamwork Talent.</p>
<ul><li>Two characters share at most 1 Bond; each character has up to 3 Bonds, each with a different partner.</li>
<li>Choose, or roll 1d10 for a category then 1d8 for the Bond. Suggested talents are only suggestions—any of the 26 may be used if the fiction supports it (GM has final say).</li>
<li><strong>Reactive</strong> talents: 1 RP, partner within Close range. The RP cost never changes. <strong>Activated</strong> talents cost Strain, never free.</li>
<li>Strain costs only increase at later tiers (Old Feelings Tier 4 is the exception).</li>
<li><strong>Evolving:</strong> tiers unlock at levels 1, 5, 9, 13—but only after a fitting narrative moment both players and the GM agree on.</li>
<li><strong>Breaking:</strong> betrayal, death or estrangement ends the Bond; both lose the talent. A new Bond restarts at Tier 1.</li></ul>"""
