"""Exploration chapter: afflictions (radiation, toxic air, sample poisons), GRAPH, rules text."""

def _aff(name, typ, fam, lvl, vector, dc, onset, maxd, stages, cure="", note=""):
    desc = (f"<p><em>{typ.upper()}{', ' + fam.upper() if fam else ''}{', ' + vector.upper() if vector else ''}</em> · Level {lvl}</p>"
            f"<p><strong>Save:</strong> Fortitude {dc}. <strong>Onset:</strong> {onset or 'immediate'}. <strong>Maximum duration:</strong> {maxd or '—'}.</p><ol>" +
            "".join(f"<li>{t} ({d})</li>" for t, d in stages) + "</ol>" + (f"<p>{note}</p>" if note else ""))
    return {"name": name, "type": "affliction", "img": {"poison": "icons/consumables/potions/bottle-conical-corked-green.webp",
                                                         "radiation": "icons/magic/unholy/orb-glowing-yellow.webp"}.get(typ, "icons/magic/unholy/orb-smoking-green.webp"),
            "folder": "Environmental" if typ != "poison" else "Poisons",
            "system": {"afflictionType": typ, "family": fam, "level": lvl, "vector": vector, "save": {"ability": "fortitude", "dc": dc if isinstance(dc, int) else 15},
                       "onset": onset, "maxDuration": maxd, "stages": [{"text": t, "duration": d} for t, d in stages], "cure": cure, "description": desc}}


def afflictions():
    return [
        _aff("Radiation Sickness", "radiation", "", 1, "", "(by R rating: R2 DC 10/week, R3 DC 15/day, R4 DC 20/hour, R5 DC 25/minute)", "1 hour", "",
             [("Sickened 1", "1 day"), ("Sickened 2 and Enfeebled 1", "1 day"), ("Sickened 3 and Drained 1", "1 day")],
             note="A failed exposure check raises the stage by 1 (2 on a critical failure), max 3. Each interval: save to reduce (critical: by 2) or increase."),
        _aff("Toxic Atmosphere Poisoning", "poison", "", 1, "inhaled", "DC 10 (+1 per previous exposure check)", "", "",
             [("Sickened 1", "10 minutes"), ("Sickened 2 and Stupefied 1", "10 minutes"), ("Sickened 3 and Stupefied 2", "10 minutes")],
             note="Unprotected in an A3 atmosphere: an initial save every minute; each failure raises the stage."),
        _aff("Lockjaw Distillate", "poison", "paralytic", 3, "injury", 18, "1 round", "3 rounds",
             [("Slowed 10", "1 round"), ("Slowed 20", "1 round"), ("Stunned", "1 round")]),
        _aff("Ashlung Dust", "poison", "irritant", 1, "inhaled", 16, "", "3 rounds",
             [("Sickened 1", "1 round"), ("Sickened 2", "1 round"), ("Sickened 3", "1 round")]),
        _aff("Witchbrain Venom", "poison", "neurotoxin", 2, "injury", 17, "1 round", "3 rounds",
             [("Dazed", "1 round"), ("Stupefied 1", "1 round"), ("Dazed and Stupefied 1", "1 round")]),
        _aff("Gravemeat Rot", "poison", "necrotoxin", 2, "contact", 17, "1 minute", "10 minutes",
             [("1 poison damage and Enfeebled 1", "1 minute"), ("1d4 poison damage and Enfeebled 1", "1 minute"), ("1d4 poison damage and Enfeebled 2", "1 minute")]),
        _aff("Greenburn Solvent", "poison", "caustic", 3, "contact", 18, "", "3 rounds",
             [("1d4 acid damage", "1 round"), ("1d6 acid and 1 persistent acid", "1 round"), ("1d6 acid and 1d4 persistent acid", "1 round")]),
    ]


GRAPH = {
    "Gravity": [("G0 Zero", "3 Disadvantage on physical actions involving motion (Acrobatics ranks reduce it); 3 ft of movement per 1 ft of Speed; you can't fall."),
                ("G1 Low", "1 Disadvantage on physical actions; 2 ft per 1 ft of Speed unless trained in Acrobatics; half falling damage."),
                ("G2 Moderate", "No effect."),
                ("G3 High", "1 Disadvantage; each foot costs 2; half jump distance; double falling damage; 1 Strain per day (Fortitude DC 10 halves)."),
                ("G4 Very High", "2 Disadvantage; each foot costs 3; triple falling damage; 2 Strain per hour (DC 15 halves)."),
                ("G5 Super High", "3 Disadvantage; each foot costs 4; quadruple falling damage; 3 Strain per minute (DC 20 halves; every 10 minutes if prone).")],
    "Radiation": [("R0 Zero", "No effect."), ("R1 Low", "No immediate threat."), ("R2 Moderate", "Fortitude DC 10 per week; e-suits and habitats fully protect."),
                  ("R3 High", "DC 15 per day; soft e-suits partial (as R2), hard suits full."), ("R4 Extreme", "DC 20 per hour; e-suits partial (as R3); vehicles full."),
                  ("R5 Lethal", "DC 25 per minute; e-suits partial (as R4); only major vehicles protect.")],
    "Atmosphere": [("A0 Vacuum", "See P0."), ("A1 Inert", "No breathable air—bring your own or suffocate."), ("A2 Moderate", "Breathable."),
                   ("A3 Toxic", "Respirator needed; otherwise a Fortitude save each minute (DC 10 +1 per check) vs Toxic Atmosphere Poisoning."),
                   ("A4 Corrosive", "Full-body protection and air supply; soft suits fail in 1d6 days; unprotected: Moderate acid damage per minute and suffocation."),
                   ("A5 Super Corrosive", "Soft suits dissolve in 1d6 hours, hard in 1d6 days; then Major acid damage per round.")],
    "Pressure": [("P0 Vacuum", "Sealed suit needed; suffocation; heat depends on light and shade."), ("P1 Very Thin", "Unprotected: Fortitude DC 15 or 1 Strain (removed only after 1 hour of good air)."),
                 ("P2 Thin", "1 Disadvantage on physical checks until acclimated (24 hours) or masked."), ("P3 Moderate", "No effect."),
                 ("P4 Dense", "Fortitude DC 10 hourly or 1 Strain (respirator: daily; e-suit: none)."),
                 ("P5 Very Dense", "Moderate crushing damage per minute; DC 15 +1 per check or 2 Strain."),
                 ("P6 Crushing", "Major crushing damage per round; DC 20 +1 per check or 3 Strain; only major vehicles protect.")],
    "Heat/Cold": [("H0 Absolute Zero", "Major cold damage per round; DC 20 +1 or 3 Strain; soft suits hourly checks, hard suits protect."),
                  ("H1 Frigid", "Moderate cold per minute; DC 15 +1 or 2 Strain; bundling or shelter: hourly; e-suits protect."),
                  ("H2 Cold", "Double food after half a day; unprotected DC 10 hourly or 1 Strain."), ("H3 Normal", "No effect."),
                  ("H4 Hot", "Double water after half a day; unprotected DC 10 or 1 Strain."),
                  ("H5 Extreme Heat", "Moderate fire per minute (per round if lethal); DC 15 +1 or 2 Strain."),
                  ("H6 Inferno", "Major fire per round; DC 20 +1 or 3 Strain.")],
}


def tables():
    T = [{"name": f"G.R.A.P.H — {k}", "folder": "Exploration", "formula": f"1d{len(v)}", "img": "icons/environment/wilderness/cave-entrance-mountain-blue.webp",
          "results": [(i + 1, i + 1, f"<strong>{n}:</strong> {t}") for i, (n, t) in enumerate(v)]} for k, v in GRAPH.items()]
    T.append({"name": "Take a Break — Strain Recovered", "folder": "Exploration", "formula": "1d5", "img": "icons/environment/wilderness/camp-improvised.webp",
              "results": [(1, 1, "Levels 1–4: 1d4"), (2, 2, "Levels 5–8: 1d6"), (3, 3, "Levels 9–12: 1d8"), (4, 4, "Levels 13–16: 1d10"), (5, 5, "Levels 17+: 1d12")]})
    T.append({"name": "Environmental Damage", "folder": "Exploration", "formula": "1d4", "img": "icons/magic/fire/flame-burning-campfire-orange.webp",
              "results": [(1, 1, "Minor: 1d6–2d6"), (2, 2, "Moderate: 4d6"), (3, 3, "Major: 8d6–12d6"), (4, 4, "Massive: 16d6–24d6")]})
    return T


RULES = """<h2>Travel</h2><p>Speed = 25 + 5 × half (Might + Reflex). Feet per minute = Speed × 10; miles per day = Speed × 0.8 (8 hours). Difficult terrain halves, greater difficult terrain thirds.</p>
<h2>Exploration Activities</h2><ul>
<li><strong>Avoid Notice:</strong> Stealth at half speed (Swift Sneak full; Legendary Sneak adds a second activity).</li>
<li><strong>Defend:</strong> half speed; you start combat with your shield raised.</li>
<li><strong>Detect Magic:</strong> half speed; ≤300 ft/min never misses an aura, ≤150 ft/min detects before walking in.</li>
<li><strong>Follow the Expert:</strong> follow an ally with 2+ ranks; use ½ your level (up) + ½ their ranks (down) as your bonus.</li>
<li><strong>Hustle:</strong> double speed for Fortitude × 10 minutes (minimum 10); groups use the lowest.</li>
<li><strong>Investigate:</strong> half speed; secret Lore checks for clues.</li>
<li><strong>Scout:</strong> half speed; party gets +1 Initiative in the next encounter.</li>
<li><strong>Search:</strong> half speed (≤300 or ≤150 ft/min to be thorough); GM rolls secret Searches.</li>
<li><strong>Take a Break</strong> (10 min, once per hour): recover 1d4/1d6/1d8/1d10/1d12 Strain by level band.</li>
<li><strong>Short Rest</strong> (1 hour, food and water): −1 exhaustion, regain ¼ max HP and half your Strain limit.</li>
<li><strong>Long Rest</strong> (8 hours, food and water, 16 hours apart, ≥1 HP): full HP (half without shelter), all Strain, ability damage removed, −2 exhaustion (−1 without shelter).
More than 16 hours awake: 1 Strain per hour. Interrupted by initiative, non-cantrip spells, damage, or an hour of exertion (≥1 hour rested = short rest; resume at +1 hour per interruption).</li></ul>
<h2>Falling</h2><p>1d6 per 10 ft (max 200 ft); Brace for Impact (Acrobatics) reduces it; land Prone unless you succeed. Water or snow: 20 ft shorter (30 if diving, up to the depth).
Landing on a creature: its Reflex DC 15 — critical success none, success ¼, failure ½, critical failure full. Falling objects by size per 10 ft: Tiny 1, Small 1d4, Medium 1d6, Large 1d8, Huge 1d10, Gargantuan 1d12.</p>
<h2>Suffocation</h2><p>Hold breath 1 minute, then Fortitude DC 15 (+1 each round) at the end of each round: failure Exhausted +1, critical failure +2. Exhausted 4 from suffocation kills.</p>
<h2>Vision &amp; Light</h2><p>Lightly obscured (dim light, patchy fog): 1 Disadvantage on sight Perception; targets have partial concealment. Heavily obscured (darkness): effectively Blinded; total concealment.</p>
<h2>Food &amp; Water</h2><p>1 lb food and 1 gallon water per day (double in extreme heat or cold). Without food for more than 3 + Fortitude days: 2 Strain per extra day (Fortitude DC 10 +1 per check halves).
Half water: DC 15 Fortitude or 2 Strain; less: 3 Strain. This Strain can't be removed until fed and watered.</p>
<h2>Afflictions</h2><p>Initial save: success unaffected; failure stage 1 after onset; critical failure stage 2. At each interval: success −1 stage, critical success −2; failure +1, critical failure +2 (repeat the top stage).
Below stage 1 it ends. Poisons stack new exposures; curses and diseases don't. Virulent: two consecutive successes for −1. Poison DC is usually 15 + level.
Families: Hemotoxin, Neurotoxin, Necrotoxin, Caustic, Paralytic, Irritant.</p>"""
