"""Weapons, ammunition and weapon techniques (Weapons chapter)."""
import re

MELEE = """Battle axe|1 gp|1d8 S|1|2|1|Sweep, Versatile(1d10(5))
Club|0|1d4 B|L|0|1|Thrown(10), Light
Dagger|2 sp|1d4 P|L|0|1|Agile, Finesse, Thrown(10)
Flail|8 sp|1d6 B|1|2|1|Disarm, Sweep, Trip
Glaive|1 gp|1d10 S|2|3|2|Reach, Deadly
Greataxe|2 gp|1d12 S|2|3|2|Deadly, Sweep
Greatclub|1 gp|1d10 B|2|1|2|Backswing, Shove
Greatsword|2 gp|2d6 S|2|3|2|Deadly
Halberd|2 gp|1d10 S|2|3|2|Reach
Hatchet|4 sp|1d6 S|L|0|1|Agile, Light, Sweep, Thrown(10)
Javelin|1 sp|1d6 P|L|0|1|Thrown(30)
Light hammer|3 sp|1d6 B|L|0|1|Agile, Light, Thrown(20)
Longsword|1 gp|1d8 S|1|2|1|Versatile(1d10(5))
Mace|1 gp|1d6 B|1|0|1|Shove
Maul|3 gp|2d6 B|2|3|2|Shove, Deadly
Morningstar|1 gp|1d8 P|1|2|1|Deadly
Pike|2 gp|1d10 P|2|3|2|Reach
Quarterstaff|0|1d6 B|1|1|1|Versatile(1d8(4))
Rapier|2 gp|1d6 P|1|2|1|Disarm, Finesse
Scimitar|1 gp|1d6 S|1|2|1|Light, Finesse
Shortsword|9 sp|1d6 P|L|2|1|Agile, Light, Finesse
Sickle|2 sp|1d4 S|L|0|1|Agile, Light, Finesse, Trip
Spear|1 sp|1d6 P|1|1|1|Thrown(20), Versatile(1d8(4))
Trident|1 gp|1d6 P|1|2|1|Thrown(20), Versatile(1d8(4))
Warhammer|1 gp|1d8 B|1|2|1|Versatile(1d10(5)), Shove
War Pick|7 sp|1d6 P|1|2|1|Deadly
Whip|1 sp|1d4 S|1|1|1|Disarm, Finesse, Subdual, Reach, Trip"""

MISSILE = """Blowgun|1 sp|1 P|L|0|1|Agile, Subdual, Range(10), Reload(1)
Hand crossbow|3 gp|1d4 P|L|1|1|Reload(1), Range(10)
Heavy crossbow|4 gp|1d12 P|2|2|2|Reload(2), Range(50)
Light crossbow|3 gp|1d10 P|1|1|2|Reload(1), Range(30)
Longbow|6 gp|1d8 P|2|2|1+|Range(100)
Shortbow|3 gp|1d6 P|1|1|1+|Range(60)
Sling|0|1d4 P|L|0|1|Range(50)"""

FIREARMS = """Pistol, Flintlock|6 gp|1d6 P|1|11|1|Reload(2), ArP(2), Range(40)
Revolver|12 gp|1d8 P|L|12|1|Reload(1), ArP(1), Range(30), Capacity(6)
Revolver, Heavy|16 gp|1d10 P|1|12|1|Reload(1), ArP(2), Recoil(1), Range(40), Capacity(5)
Musket, Flintlock|7 gp|1d10 P|1|13|2|Reload(2), ArP(3), Range(70), Deadly
Rifle, Winchester|10 gp|1d8 P|1|14|2|Reload(1), ArP(2), Range(100), Capacity(5)
Rifle, Heavy, Winchester|15 gp|1d10 P|2|14|2|Reload(1), ArP(3), Recoil(1), Deadly, Range(150), Capacity(5)
Shotgun|10 gp|1d8 P|1|12|2|Reload(1), Spread(10), Brutal, ArP(2), Recoil(2), Range(10)
Shotgun, Double Barrel|15 gp|1d8 P|1|12|2|Reload(1), Spread(10), Brutal, ArP(2), Recoil(2), Range(10), Capacity(2), Double Barrel(2d6 P, Recoil(3))"""

MARTIAL = """Bo Staff|2 sp|1d8 B|2|2|2|Parry, Reach, Trip|melee
Kama|1 gp|1d6 S|L|0|1|Agile, Trip|melee
Katar|3 sp|1d4 P|L|0|1|Agile, Deadly|melee
Nunchaku|2 sp|1d6 B|L|1|1|Backswing, Disarm, Finesse|
Rope Dart|1 gp|1d4 P|1|2|2|Disarm, Finesse, Sweep, Tethered, Thrown(20), Trip|
Sai|6 sp|1d4 P|L|1|1|Agile, Finesse, Disarm|melee
Shuriken (10)|1 sp|1d4 P|L|1|1|Agile, Finesse, Thrown(20)|
Temple Sword|2 gp|1d8 S|1|2|1|Trip|melee
Three-Section Staff|2 gp|1d10 B|2|3|2|Backswing, Disarm, Parry|melee
Unarmed Strike|0|1 B|-|0|1|Agile, Finesse, Subdual, Unarmed|"""

AMMO = [("Blowgun Darts (10)", "5 cp"), ("Bolts (10)", "1 sp"), ("Sling Stones (10)", "2 cp"), ("Arrows (10)", "1 sp"),
        ("Flintlock Balls (10)", "1 sp"), ("Pistol Rounds (10)", "5 sp"), ("Heavy Pistol Rounds (10)", "1 gp"),
        ("Rifle Rounds (10)", "5 sp"), ("Heavy Rifle Rounds (10)", "1 gp"), ("Shotgun Rounds (5)", "1 gp")]

from weapon_desc import DESCRIPTIONS

DMG = {"S": "slashing", "P": "piercing", "B": "bludgeoning"}
TRAIT_KEY = {"agile": "agile", "arp": "armorPiercing", "ap": "armorPiercing", "backswing": "backswing", "brutal": "brutal",
             "capacity": "capacity", "deadly": "deadly", "disarm": "disarm", "double barrel": "doubleBarrel",
             "finesse": "finesse", "heavy": "heavy", "light": "light", "parry": "parry", "range": "range", "reach": "reach",
             "recoil": "recoil", "reload": "reload", "scattered": "scattered", "shove": "shove", "spread": "spread",
             "subdual": "subdual", "sweep": "sweep", "tethered": "tethered", "thrown": "thrown", "trip": "trip",
             "unarmed": "unarmed", "unwieldy": "unwieldy", "versatile": "versatile", "volatile": "volatile"}

IMG = {
    "melee": "icons/weapons/swords/sword-guard-brown.webp",
    "missile": "icons/weapons/bows/shortbow-recurve.webp",
    "firearm": "icons/weapons/guns/gun-pistol-flintlock-metal.webp",
    "martial": "icons/weapons/staves/staff-simple.webp",
}
IMG_BY_NAME = {
    "Battle axe": "icons/weapons/axes/axe-battle-black.webp", "Club": "icons/weapons/clubs/club-simple-black.webp",
    "Dagger": "icons/weapons/daggers/dagger-straight-blue.webp", "Flail": "icons/weapons/maces/flail-ball-grey.webp",
    "Glaive": "icons/weapons/polearms/glaive-hooked-steel.webp", "Greataxe": "icons/weapons/axes/axe-double.webp",
    "Greatclub": "icons/weapons/clubs/club-heavy-barbed-brown.webp", "Greatsword": "icons/weapons/swords/greatsword-crossguard-steel.webp",
    "Halberd": "icons/weapons/polearms/halberd-crescent-steel.webp", "Hatchet": "icons/weapons/axes/axe-broad-brown.webp",
    "Javelin": "icons/weapons/polearms/javelin-hooked.webp", "Light hammer": "icons/weapons/hammers/hammer-war-spiked.webp",
    "Longsword": "icons/weapons/swords/sword-guard-steel-green.webp", "Mace": "icons/weapons/maces/mace-round-ornate-steel.webp",
    "Maul": "icons/weapons/hammers/hammer-double-steel.webp", "Morningstar": "icons/weapons/maces/mace-spiked-steel-grey.webp",
    "Pike": "icons/weapons/polearms/pike-flared-brown.webp", "Quarterstaff": "icons/weapons/staves/staff-simple.webp",
    "Rapier": "icons/weapons/swords/rapier-simple-grey.webp", "Scimitar": "icons/weapons/swords/scimitar-guard-brown.webp",
    "Shortsword": "icons/weapons/swords/shortsword-guard-brass.webp", "Sickle": "icons/weapons/sickles/sickle-curved.webp",
    "Spear": "icons/weapons/polearms/spear-flared-steel.webp", "Trident": "icons/weapons/polearms/trident-silver-blue.webp",
    "Warhammer": "icons/weapons/hammers/hammer-war-rounding.webp", "War Pick": "icons/weapons/axes/pickaxe-iron-green.webp",
    "Whip": "icons/weapons/misc/whip-red-yellow.webp", "Blowgun": "icons/weapons/ammunition/arrow-broadhead-glowing-orange.webp",
    "Hand crossbow": "icons/weapons/crossbows/handcrossbow-black.webp", "Heavy crossbow": "icons/weapons/crossbows/crossbow-heavy-black.webp",
    "Light crossbow": "icons/weapons/crossbows/crossbow-simple-brown.webp", "Longbow": "icons/weapons/bows/longbow-recurve-leather-brown.webp",
    "Shortbow": "icons/weapons/bows/shortbow-recurve.webp", "Sling": "icons/weapons/slings/slingshot-wood.webp",
    "Rifle, Winchester": "icons/weapons/guns/rifle-brown.webp", "Rifle, Heavy, Winchester": "icons/weapons/guns/rifle-brown.webp",
    "Musket, Flintlock": "icons/weapons/guns/gun-blunderbuss-gold.webp", "Shotgun": "icons/weapons/guns/gun-blunderbuss-worn.webp",
    "Shotgun, Double Barrel": "icons/weapons/guns/gun-double-barrel.webp", "Revolver": "icons/weapons/guns/gun-pistol-brass.webp",
    "Revolver, Heavy": "icons/weapons/guns/gun-pistol-wood.webp", "Nunchaku": "icons/weapons/misc/nunchaku.webp",
    "Shuriken (10)": "icons/weapons/thrown/shuriken-blue.webp", "Unarmed Strike": "icons/skills/melee/unarmed-punch-fist.webp",
    "Katar": "icons/weapons/daggers/dagger-double-black.webp", "Sai": "icons/weapons/daggers/dagger-jeweled-purple.webp",
    "Kama": "icons/weapons/sickles/sickle-simple-bone.webp", "Bo Staff": "icons/weapons/staves/staff-simple-spiral.webp",
    "Three-Section Staff": "icons/weapons/staves/staff-ornate-wood.webp", "Temple Sword": "icons/weapons/swords/sword-katana-purple.webp",
    "Rope Dart": "icons/weapons/thrown/dart-feathered.webp",
}


def parse_price(p):
    p = p.strip()
    if p in ("0", "-", ""):
        return 0, "sp"
    n, d = p.split()
    return float(n) if "." in n else int(n), d


def parse_bulk(b):
    return {"L": 0.1, "-": 0}.get(b, None) if b in ("L", "-") else float(b)


def parse_traits(props):
    traits, values = [], {}
    # Split on commas not inside parentheses
    parts, depth, cur = [], 0, ""
    for ch in props:
        if ch == "(":
            depth += 1
        elif ch == ")":
            depth -= 1
        if ch == "," and depth == 0:
            parts.append(cur.strip()); cur = ""
        else:
            cur += ch
    if cur.strip():
        parts.append(cur.strip())
    extra = {}
    for p in parts:
        m = re.match(r"([A-Za-z ]+?)\s*\((.*)\)$", p)
        name = (m.group(1) if m else p).strip().lower()
        key = TRAIT_KEY.get(name)
        if not key:
            continue
        traits.append(key)
        if m:
            arg = m.group(2).strip()
            if key == "versatile":
                vm = re.match(r"(\S+)\s*\((\d+)\)", arg)
                extra["versatile"] = vm.group(1) if vm else arg
                extra["versatileSecondary"] = int(vm.group(2)) if vm else 0
            elif key == "doubleBarrel":
                dm = re.match(r"(\S+)\s+([SPB])(?:,\s*Recoil\((\d+)\))?", arg)
                extra["doubleBarrel"] = dm.group(1)
                if dm.group(3):
                    extra["doubleBarrelRecoil"] = int(dm.group(3))
            else:
                try:
                    values[key] = int(arg)
                except ValueError:
                    pass
    return traits, values, extra


def weapon(line, category):
    cols = line.split("|")
    name, price, dmg, bulk, req, hands, props = cols[:7]
    melee_alt = (cols[7] == "melee") if len(cols) > 7 else False
    dice, dtype = dmg.split()
    traits, values, extra = parse_traits(props)
    pv, pd = parse_price(price)
    reqv = int(req)
    ability = "might" if category in ("melee", "martial") else "reflex"
    notes = []
    if reqv > 5:
        printed = reqv
        reqv = (printed - 10) // 2
        notes.append(f"<p><em>Printed requirement {printed} (old score scale), converted to Reflex {reqv}.</em></p>")
    if category == "martial" and melee_alt:
        notes.append("<p><em>You may also use the Melee Weapons skill for this weapon.</em></p>")
    rng = values.get("range") or values.get("thrown") or 0
    skill = {"melee": "meleeWeapons", "missile": "missileWeapons", "firearm": "firearms", "martial": "martialArts"}[category]
    system = {
        "category": "natural" if name == "Unarmed Strike" else category,
        "skill": skill,
        "altSkill": "meleeWeapons" if melee_alt else "",
        "damage": {"dice": dice, "type": DMG[dtype], "secondary": 0, "versatile": extra.get("versatile", ""),
                   "versatileSecondary": extra.get("versatileSecondary", 0), "doubleBarrel": extra.get("doubleBarrel", "")},
        "hands": hands,
        "requirement": {"ability": ability, "value": reqv},
        "traits": traits,
        "traitValues": values,
        "range": rng,
        "ammo": {"value": values.get("capacity", 1 if "reload" in traits else 0), "max": values.get("capacity", 1 if "reload" in traits else 0), "type": ""},
        "price": {"value": pv, "denomination": pd},
        "bulk": parse_bulk(bulk),
        "quantity": 10 if name.startswith("Shuriken") else 1,
        "description": f"<p>{DESCRIPTIONS.get(name, '')}</p>" + "".join(notes),
    }
    if extra.get("doubleBarrelRecoil"):
        system["traitValues"]["doubleBarrelRecoil"] = extra["doubleBarrelRecoil"]
    return {"name": name if name != "Battle axe" else "Battle Axe",
            "type": "weapon", "img": IMG_BY_NAME.get(name, IMG[category]),
            "folder": {"melee": "Melee Weapons", "missile": "Missile Weapons", "firearm": "Firearms", "martial": "Martial Arts Weapons"}[category],
            "system": system}


# --------------------------------------------------------------------------
# Techniques
# --------------------------------------------------------------------------
SAVE_TAIL = ("At the end of each of its turns, it can attempt a DC 15 flat check to end {c}, or it can spend 1 Action Point on its turn to end the condition instead.</p>"
             "<p><strong>Critical Failure:</strong> The target rolls the flat check twice and takes the lower result, and ending {c} by spending actions costs 2 Action Points instead of 1.</p>")
PUSH = "<p><strong>Push:</strong> You may take 1 Strain to use this technique for 1 Action Point instead of 2.</p>"
PUSH_R = "<p><strong>Push:</strong> You may take 1 Strain to use this reaction for 1 Reaction Point instead of 2.</p>"
DC = "the target must make a {s} Save against a DC of 10 + half the damage it actually took (after Soak and Resistances)."


def cond_tech(name, kind, req, flavor, attack, save, cond_text, cond, status, statusValue=None, immune=False):
    desc = f"<p><em>{flavor}</em></p>"
    if immune:
        desc += "<p>Undead and constructs are immune to this technique.</p>"
    desc += f"<p>For 2 Action Points, {attack} If the attack hits and deals damage, " + DC.format(s=save) + "</p>"
    desc += f"<p>On a failed save, {cond_text} " + SAVE_TAIL.format(c=cond) + PUSH
    return tech(name, kind, req, desc, cost="2", save=save.lower(), status=status, statusValue=statusValue)


def tech(name, kind, req, desc, cost="2", save="", status="", statusValue=None, traits=None, skill=None, trigger="", img=None):
    t = traits or ["attack", "technique", kind]
    return {"name": name, "type": "technique",
            "img": img or ("icons/skills/ranged/target-bullseye-arrow-glowing.webp" if kind == "ranged" else "icons/skills/melee/strike-sword-steel-yellow.webp"),
            "folder": "Ranged Techniques" if kind == "ranged" else ("Shield Techniques" if kind == "shield" else "Melee Techniques"),
            "system": {"kind": kind, "requirements": req, "cost": cost, "trigger": trigger, "pushable": True,
                       "actionTraits": t, "description": desc,
                       "roll": {"type": "attack", "save": save, "damage": "", "damageType": ""},
                       "applies": {"status": status, "value": statusValue} if status else {}}}


TECHNIQUES = [
    tech("Aimed Shot", "ranged", "making a ranged weapon attack",
         "<p><em>You take your time to line up a shot.</em></p><p>For 2 Action Points, make a ranged attack with 1 additional level of Advantage.</p>" + PUSH,
         traits=["attack", "technique", "concentrate", "ranged"]),
    tech("Backbreaker", "melee", "making a melee weapon attack that deals bludgeoning damage",
         "<p><em>You put extra force behind your strike to knock an enemy down.</em></p><p>For 2 Action Points, make a melee attack against a creature within reach. On a hit, " + DC.format(s="Fortitude") + " On a failed save, the target falls Prone.</p><p><strong>Critical Failure:</strong> The target must spend 1 Action Point to stand up, in addition to using half its Speed.</p>" + PUSH,
         save="fortitude", status="prone"),
    tech("Brace", "melee", "wielding a melee weapon with the Reach trait",
         "<p><em>You brace your weapon to punish a moving target.</em></p><p><strong>Trigger:</strong> an enemy performs an action with the Move trait within your reach.</p><p>When an enemy within your reach uses an action with the Move trait, you may make a Reaction Strike (2 Reaction Points). Make a melee attack against that creature using a weapon with the Reach trait. If the attack hits, roll the damage twice and use the higher result.</p>" + PUSH_R,
         cost="reaction", trigger="An enemy performs an action with the Move trait within your reach.", traits=["attack", "technique", "reaction", "melee"]),
    tech("Cleave", "melee", "a melee weapon that deals slashing damage",
         "<p><em>You swing your weapon in a wide arc to hit multiple foes.</em></p><p>For 2 Action Points, make one melee attack roll and apply it to each creature in a 5-foot arc from you. Each target makes a save against your attack roll.</p><ul><li><strong>Critical Success:</strong> No damage.</li><li><strong>Success:</strong> Half damage.</li><li><strong>Failure:</strong> Full damage.</li><li><strong>Critical Failure:</strong> Double damage.</li></ul><p>Roll damage once and apply it to all targets.</p>" + PUSH,
         save="reflex"),
    cond_tech("Concussive Smash", "melee", "a melee weapon that deals bludgeoning damage", "You hit with overwhelming force, dealing damage and potentially dazing your target.",
              "make a melee attack against a creature within reach.", "Fortitude", "the target is Dazed.", "Dazed", "dazed"),
    tech("Disarming Strike", "melee", "a melee weapon with the Disarm trait",
         "<p><em>You strike at your foe's hands to force it to drop what it's holding.</em></p><p>For 2 Action Points, make a melee attack against a creature within reach. On a hit, " + DC.format(s="Reflex") + " On a failed save, it drops one held weapon (target's choice unless the GM rules otherwise).</p>" + PUSH,
         save="reflex"),
    tech("Fan the Hammer", "ranged", "a fully loaded, one-handed Firearm with a capacity greater than 1",
         "<p><em>You fire from the hip, slapping the hammer with your off-hand to spray a hail of bullets.</em></p><p>Once per round, for 2 Action Points, while wielding a fully loaded one-handed firearm, choose a 10-foot-by-10-foot area within your weapon's range. Make one attack roll with the firearm. Each creature in the area must make a Reflex Save against your attack roll.</p><ul><li><strong>Critical Success:</strong> No damage.</li><li><strong>Success:</strong> Half damage.</li><li><strong>Failure:</strong> Full weapon damage.</li><li><strong>Critical Failure:</strong> Double weapon damage.</li></ul><p>Roll damage once and apply it to all affected creatures. After using this technique, the firearm's ammunition is completely expended and the weapon must be reloaded before it can be used again.</p>" + PUSH,
         save="reflex", traits=["attack", "technique", "ranged", "taxing"]),
    cond_tech("Flourish", "melee", "a melee weapon with the Finesse trait", "You feint mid-swing to throw your opponent off balance.",
              "make a melee attack against a creature within reach.", "Reflex", "the target is Off-Balance until it ends the condition.", "Off-Balance", "offGuard"),
    cond_tech("Piercing Shot", "ranged", "a ranged weapon that deals piercing damage", "You place a vicious shot that can leave a gaping wound.",
              "make a ranged attack against a target within range.", "Fortitude", "the target gains the Gaping Wound condition.", "the condition", "gapingWound", immune=True),
    cond_tech("Piercing Strike", "melee", "a melee weapon that deals piercing damage", "You drive your blade deep, leaving a gaping wound.",
              "make a melee attack against a creature within reach.", "Fortitude", "the target gains the Gaping Wound condition.", "the condition", "gapingWound", immune=True),
    cond_tech("Pommel Strike", "melee", "a two-handed melee weapon", "You strike to subdue, potentially leaving your target dazed.",
              "make a nonlethal melee attack against a creature within reach.", "Fortitude", "the target is Dazed.", "Dazed", "dazed"),
    tech("Prepare", "melee", "wielding a two-handed melee weapon",
         "<p>For 2 Action Points, you steady your stance and commit to powerful, measured strikes. Until the end of your next turn, add double your Might score to the damage of each weapon attack you make with a weapon that qualifies for this technique.</p>" + PUSH,
         traits=["boost", "technique", "melee"]),
    tech("Lacerate", "melee", "wielding a melee weapon that deals slashing damage",
         "<p><em>You slash at vital points to make your target bleed.</em></p><p>Undead and constructs are immune to this technique.</p><p>For 2 Action Points, make a melee attack against a creature within reach. If the attack hits and deals damage, " + DC.format(s="Fortitude") + "</p><p>On a failed save, the target takes 1d6 persistent bleed damage at the end of each of its turns. " + SAVE_TAIL.format(c="the bleeding") + PUSH,
         save="fortitude", status="persistentDamage"),
    cond_tech("Maiming Strike", "melee", "wielding a melee weapon with the Deadly trait", "You deliver a vicious blow that can maim your target and stop one of their modes of movement. If your target has more than one speed type you must choose the type of movement you are trying to hamper.",
              "make a Melee Weapon attack against a creature within reach.", "Fortitude", "the target becomes Maimed and their chosen movement speed is reduced to 0.", "Maimed", "maimed"),
    cond_tech("Maiming Shot", "ranged", "wielding a ranged weapon with the Deadly trait", "You deliver a vicious blow that can maim your target and stop one of their modes of movement. If your target has more than one speed type you must choose the type of movement you are trying to hamper.",
              "make a Ranged Weapon attack against a creature within 30 feet.", "Fortitude", "the target becomes Maimed and their chosen movement speed is reduced to 0.", "Maimed", "maimed"),
    tech("Tenacity", "melee", "wielding a melee weapon with the Backswing trait",
         "<p>When you miss with a melee weapon that has the Backswing trait, you can still clip your target.</p><p><strong>Reaction (2 Reaction Points):</strong> Deal half your weapon's damage to the target (weapon damage only, plus any magical bonus damage from the weapon). Damage from this reaction can't trigger other reactions or maneuvers.</p>" + PUSH_R,
         cost="reaction", trigger="You miss with a melee weapon that has the Backswing trait.", traits=["attack", "technique", "reaction", "melee"]),
    tech("Topple", "melee", "wielding a melee weapon with the Trip trait",
         "<p><em>You sweep at your target's legs to knock it down.</em></p><p>For 2 Action Points, make a melee attack against a creature within reach. If the attack hits and deals damage, " + DC.format(s="Reflex") + " On a failed save, the target falls Prone.</p><p><strong>Critical Failure:</strong> Standing up costs the target all of its Speed on its next turn (instead of half).</p>" + PUSH,
         save="reflex", status="prone"),
    cond_tech("Rush Attack", "melee", "wielding a weapon with the Light trait", "You charge in and use your momentum to strike and throw your target off balance.",
              "move up to your Speed to end adjacent to a creature you can reach. This movement doesn't provoke Reaction Attacks. Then make a melee weapon attack against that creature.", "Reflex", "the target is Off-Balance.", "Off-Balance", "offGuard"),
    cond_tech("Weakening Strike", "melee", "wielding a weapon with the Agile trait", "You strike at your target's hands with a nonlethal blow, potentially weakening its grip.",
              "make a nonlethal melee attack against a creature within reach.", "Fortitude", "the target gains the Weak Grip condition.", "Weak Grip", "weakenedGrip", 1),
    cond_tech("Hamstring Shot", "ranged", "wielding a ranged weapon", "You shoot your target in the leg to slow it down.",
              "make a ranged attack against a creature within your first range increment.", "Fortitude", "the target is Slowed.", "Slowed", "slowed", 10),
    cond_tech("Heartstopper", "melee", "wielding a two-handed melee weapon that deals piercing damage", "You smash into your target's chest, potentially causing chest trauma.",
              "make a melee attack against a creature within reach.", "Fortitude", "the target gains the Chest Trauma condition.", "Chest Trauma", "chestTrauma", 1, immune=True),
]


def entries():
    out = []
    for block, cat in ((MELEE, "melee"), (MISSILE, "missile"), (FIREARMS, "firearm"), (MARTIAL, "martial")):
        for line in block.strip().splitlines():
            out.append(weapon(line, cat))
    for name, price in AMMO:
        pv, pd = parse_price(price)
        qty = int(re.search(r"\((\d+)\)", name).group(1))
        out.append({"name": name, "type": "gear", "img": "icons/weapons/ammunition/bullets-cartridge-shell-gray.webp" if "Round" in name or "Ball" in name else "icons/weapons/ammunition/arrows-bodkin-yellow-red.webp",
                    "folder": "Ammunition",
                    "system": {"category": "ammunition", "price": {"value": pv, "denomination": pd}, "bulk": 0.1, "quantity": qty, "bundle": qty,
                               "description": f"<p>A bundle of {name.split(' (')[0].lower()}. Price and Bulk are for the full bundle.</p>"}})
    return out


def techniques():
    return TECHNIQUES
