"""Gear chapter: adventuring gear (own short descriptions; mechanics kept)."""
from weapons import parse_price, parse_bulk

# name | price | bulk | hands | category | level | consumable(C) | capacity | description
GEAR = """Adventurer's pack|7 sp|2|-|container|0|C|4|Starter kit: backpack, bedroll, 2 belt pouches, 10 chalk, flint and steel, 50 ft rope, 2 weeks' rations, soap, 5 torches, waterskin. Bulk is for the whole pack.
Alchemist's tools|5 gp|2|2|tools|0||0|A portable laboratory of glassware and reagents needed to craft alchemical items.
Expanded alchemist's tools|55 gp|2|2|tools|3||0|As alchemist's tools; +1 item bonus to Crafting alchemical items.
Artisan's tools|4 gp|2|2|tools|0||0|Tools for one trade (smithing, woodworking…), needed to Craft from raw materials.
Sterling artisan's tools|50 gp|2|2|tools|3||0|As artisan's tools; +1 item bonus to Crafting checks.
Backpack|1 sp|-|-|container|0||4|Holds up to 4 Bulk. Light Bulk when carried rather than worn.
Bandolier|1 sp|-|-|container|0||0|Holds 8 light items within easy reach; a toolkit stored here can be drawn as part of using it. Light Bulk when not worn.
Basic crafter's book|1 sp|L|2|general|0||0|Formulas for crafting common items.
Bedroll|1 cp|L|-|general|0||0|A padded roll for sleeping outdoors.
Belt pouch|4 cp|-|-|container|0||0|Holds up to 4 light items.
Caltrops|3 sp|L|1|consumable|0|C|0|Scatter in an adjacent square (Interact). The first creature entering makes a DC 14 Acrobatics check or takes 1d4 piercing + 1 persistent bleed and −5 ft Speed while bleeding. Ruined once they deal damage; otherwise salvageable.
Candle (10)|1 cp|-|1|light|0|C|0|Dim light in 10 ft for 8 hours.
Chain (10 feet)|4 gp|1|2|general|0||0|Iron chain for binding, securing or climbing.
Chalk (10)|1 cp|-|1|consumable|0|C|0|For marking surfaces and leaving signs.
Chest|6 sp|2|2|container|0||8|Wooden chest holding up to 8 Bulk.
Climbing kit|5 sp|1|2|tools|0|C|0|Rope, pulleys, pitons, hammer, hook and crampons for one climber. Anchored climbing at half speed (minimum 5 ft); DC 5 flat check to avoid falling on a critical failure.
Extreme climbing kit|40 gp|1|2|tools|3|C|0|As climbing kit; +1 item bonus to Athletics to Climb.
Clothing (ordinary)|1 sp|-|-|clothing|0||0|Simple functional garments.
Clothing (explorer's)|1 sp|L|-|clothing|0||0|Sturdy traveling clothes that can be reinforced like light protection.
Clothing (fine)|2 gp|L|-|clothing|0||0|Expensive attire suitable for high society.
Clothing (high-fashion fine)|55 gp|L|-|clothing|3||0|+1 item bonus to Make an Impression on nobles and the upper class.
Clothing (winter)|4 sp|L|-|clothing|0||0|Negates severe cold and treats extreme cold as severe.
Compass|1 gp|-|1|tools|0||0|Needed to navigate without a −2 penalty (where magnetic fields are uniform).
Lensatic compass|20 gp|-|1|tools|3||0|+1 item bonus to navigate.
Cookware|1 gp|2|2|tools|0||0|Pots and utensils for trail cooking.
Crowbar|5 sp|L|2|tools|0||0|Needed to pry things open without a −2 penalty to Force Open.
Levered crowbar|20 gp|L|2|tools|3||0|+1 item bonus to Force Open anything pryable.
Disguise kit|2 gp|L|2|tools|0|C|0|Cosmetics, false hair and wigs used to set up disguises.
Disguise kit (replacement cosmetics)|1 sp|-|-|consumable|0|C|0|Refills a disguise kit.
Elite disguise kit|40 gp|L|2|tools|3|C|0|+1 item bonus to disguise checks.
Elite cosmetics|5 gp|-|-|consumable|3|C|0|Refills an elite disguise kit.
Fishing tackle|8 sp|1|2|tools|0|C|0|Collapsible pole, line, hooks, lures and net.
Professional fishing tackle|20 gp|1|2|tools|3|C|0|+1 item bonus to fishing checks.
Flint and steel|5 cp|-|2|tools|0||0|Starts a fire given time (at least 3 actions, usually longer).
Formula book (blank)|1 gp|1|1|general|0||0|Holds up to 100 formulas.
Grappling hook|1 sp|L|1|tools|0||0|Anchor with an attack roll vs a DC (usually 20+). On a critical failure it seems secure but gives way partway up.
Hammer|1 sp|L|1|tools|0||0|For nails, pitons and breaking things.
Healer's tools|5 gp|1|2|tools|0||0|Needed for Medicine to give first aid or treat wounds, poison and disease.
Expanded healer's tools|50 gp|1|2|tools|3||0|+1 item bonus to those Medicine checks.
Holly and mistletoe|0 cp|-|1|general|0||0|A nature focus, held in one hand.
Hourglass|3 gp|L|1|tools|0||0|Measures time by falling sand.
Ladder (10-foot)|3 cp|3|2|general|0||0|A wooden ladder.
Lantern (bull's-eye)|1 gp|1|1|light|0||0|Bright light in a 60-ft cone (dim 60 ft beyond). Burns 1 pint of oil per 6 hours.
Lantern (hooded)|7 sp|L|1|light|0||0|Bright light 30 ft (dim 30 ft beyond); shutters open or close with an Interact. 1 pint of oil per 6 hours.
Lock (poor)|2 sp|-|2|general|0||0|Picking: 2 successes at DC 15 Thievery.
Lock (simple)|2 gp|-|2|general|1||0|Picking: 3 successes at DC 20.
Lock (average)|15 gp|-|2|general|3||0|Picking: 4 successes at DC 25.
Lock (good)|200 gp|-|2|general|9||0|Picking: 5 successes at DC 30.
Lock (superior)|4500 gp|-|2|general|17||0|Picking: 6 successes at DC 40.
Magnifying glass|40 gp|-|1|tools|3||0|+1 item bonus to Perception to notice minute details.
Manacles (poor)|3 sp|-|2|general|0||0|Apply to a helpless or willing creature (10–30 s). Legs: −15 ft Speed; wrists: DC 5 flat check or MANIPULATE actions fail; bound to an object: immobilized. Escape: 2 successes at DC 17 Thievery.
Manacles (simple)|3 gp|-|2|general|1||0|As poor manacles; escape 3 successes at DC 22.
Manacles (average)|20 gp|-|2|general|3||0|As poor manacles; escape 4 successes at DC 27.
Manacles (good)|250 gp|-|2|general|9||0|As poor manacles; escape 5 successes at DC 32.
Manacles (superior)|5000 gp|-|2|general|17||0|As poor manacles; escape 6 successes at DC 42.
Material component pouch|5 sp|L|1|tools|0||0|Holds spell material components, restocked during rest.
Merchant's scale|2 sp|L|2|tools|0||0|Weighs coins and goods.
Mirror|1 gp|-|1|general|0||0|A small reflective surface.
Mug|1 cp|-|1|general|0||0|A drinking vessel.
Musical instrument (handheld)|8 sp|1|2|tools|0||0|Fiddle, flute, lute, drum and similar.
Musical instrument (virtuoso handheld)|50 gp|1|2|tools|3||0|+1 item bonus to Perform with it.
Musical instrument (heavy)|2 gp|16|2|tools|0||0|Large drums, keyboards and the like; played stationary.
Musical instrument (virtuoso heavy)|100 gp|16|2|tools|3||0|+1 item bonus to Perform with it.
Oil (1 pint)|1 cp|-|2|consumable|0|C|0|Lantern fuel. Or prepare (Interact) and throw as a ranged attack: on a hit, DC 10 flat check to ignite for 1d6 fire.
Piton|1 cp|-|1|consumable|0|C|0|Hammered anchor; a roped piton stops a full fall on a critical failure while climbing.
Rations (1 week)|4 sp|L|1|food|0|C|0|Preserved food and water for a week.
Religious symbol (wooden)|1 sp|L|1|general|0||0|A divine focus, held in one hand.
Religious symbol (silver)|2 gp|L|1|general|0||0|A divine focus, held in one hand.
Religious text|1 gp|L|1|general|0||0|Scripture usable as a divine focus.
Repair kit|2 gp|1|2|tools|0|C|0|Portable anvil, tongs, whetstone and oils to Repair with Crafting.
Superb repair kit|25 gp|1|2|tools|3|C|0|+1 item bonus to Repair.
Rope (50 ft)|5 sp|L|2|general|0||0|Standard adventuring rope.
Sack (5)|1 cp|L|1|container|0||8|Holds up to 8 Bulk; with 2 Bulk or less it can hang from a belt.
Saddlebags|2 sp|L|2|container|0||3|A pair holding 3 Bulk each. 1 Bulk when carried instead of mounted.
Satchel|1 sp|-|2|container|0||2|Holds up to 2 Bulk; light Bulk when not worn.
Scholarly journal|0 gp|L|1|general|3||0|Uncommon. 1 minute of reference gives +1 item bonus to Recall Knowledge on its narrow topic; a compendium (5× price, 2 hands) covers a broad topic. Price and availability set by the GM.
Scroll case|1 sp|-|2|container|0||0|Protects scrolls and maps.
Sheath|1 cp|-|-|container|0||0|Carries a weapon at your side.
Signal whistle|8 cp|-|1|general|0||0|Audible up to half a mile over open ground.
Snare kit|5 gp|2|2|tools|0||0|Tools and materials to Craft snares.
Specialist snare kit|55 gp|2|2|tools|3||0|+1 item bonus to Craft snares.
Soap|2 cp|-|1|consumable|0|C|0|For washing.
Spellbook (blank)|1 gp|1|1|general|0||0|Holds up to 100 spells.
Spyglass|20 gp|L|2|tools|0||0|See eight times farther than normal.
Fine spyglass|80 gp|L|2|tools|4||0|+1 item bonus to Perception for distant details.
Survey map|0 gp|L|1|general|0||0|Uncommon. +1 item bonus to Survival and Recall Knowledge about the mapped location; an atlas costs 5× and needs 2 hands. Price and availability set by the GM.
Tack|4 gp|1|-|mount|0||0|Saddle, bridle and stirrups for a mount; 2 Bulk when carried.
Ten-foot pole|1 cp|1|2|tools|0||0|Seek a square up to 10 ft away. Too flimsy to be a weapon.
Tent (pup)|8 sp|L|2|general|0||0|Shelters one.
Tent (four-person)|5 gp|1|2|general|0||0|Shelters four.
Tent (pavilion)|40 gp|12|2|general|2||0|A large tent for a dozen or more.
Thieves' tools|3 gp|L|2|tools|0||0|Needed to Pick Locks and Disable some Devices.
Thieves' tools (replacement picks)|3 sp|-|-|consumable|0|C|0|Fixes broken thieves' tools without a Repair action.
Infiltrator thieves' tools|50 gp|L|2|tools|3||0|+1 item bonus to Pick Locks and Disable Devices.
Infiltrator picks|3 gp|-|-|consumable|3|C|0|Replacement picks for infiltrator tools.
Tool (long)|1 gp|1|2|tools|0||0|Hoe, shovel or sledge; improvised weapon (1d6).
Tool (short)|4 sp|L|1|tools|0||0|Hand drill, ice hook or trowel; improvised weapon (1d4).
Torch|1 cp|L|1|light|0|C|0|Bright light 20 ft (dim 20 ft beyond). Improvised weapon: 1d4 bludgeoning + 1 fire.
Vial|5 cp|-|1|container|0||0|Holds 1 ounce of liquid.
Waterskin|5 cp|L|1|food|0||0|A day's water for a Small or Medium creature; 1 Bulk when full.
Writing set|1 gp|L|2|tools|0||0|Paper, ink, quill, wax and seal for letters and scrolls.
Writing set (extra ink & paper)|1 sp|-|-|consumable|0|C|0|Refills a writing set."""

IMG = {
    "container": "icons/containers/bags/pack-leather-brown.webp", "tools": "icons/tools/hand/hammer-and-nail.webp",
    "clothing": "icons/equipment/chest/shirt-collared-brown.webp", "light": "icons/sundries/lights/torch-brown-lit.webp",
    "food": "icons/consumables/food/bread-loaf-round-white.webp", "consumable": "icons/consumables/potions/bottle-round-corked-brown.webp",
    "mount": "icons/environment/creatures/horse-brown.webp", "general": "icons/sundries/misc/pin-brass.webp",
}
NAME_IMG = {"Torch": "icons/sundries/lights/torch-brown-lit.webp", "Rope (50 ft)": "icons/sundries/survival/rope-wrapped-brown.webp",
            "Caltrops": "icons/weapons/thrown/shuriken-blue.webp", "Healer's tools": "icons/tools/cooking/mortar-herbs-yellow.webp",
            "Thieves' tools": "icons/tools/hand/lockpicks-steel-grey.webp", "Compass": "icons/tools/navigation/compass-brass-blue-red.webp",
            "Spyglass": "icons/tools/navigation/spyglass-telescope-brass.webp", "Rations (1 week)": "icons/consumables/food/bowl-stew-brown.webp"}
FOLDER = {"container": "Containers", "tools": "Tools & Kits", "clothing": "Clothing", "light": "Light Sources", "food": "Food & Water",
          "consumable": "Consumables", "mount": "Mounts & Tack", "general": "General"}


def entries():
    out = []
    for line in GEAR.splitlines():
        n, p, b, h, cat, lvl, c, cap, d = line.split("|")
        tags = ["consumable"] if c == "C" else []
        if cat == "consumable" or (c == "C" and cat not in ("tools", "container")):
            cat_s = "consumable" if cat == "consumable" else cat
        else:
            cat_s = cat
        desc = f"<p>{d}</p>" + (f"<p><em>Hands: {h}.</em></p>" if h not in ("-", "") else "") + (
            "<p><em>CONSUMABLE — can be replenished with a Supply Check (DC 10 + half item level) once all carried uses are gone.</em></p>" if c == "C" else "")
        out.append({"name": n, "type": "gear", "img": NAME_IMG.get(n, IMG.get(cat, IMG["general"])), "folder": FOLDER[cat],
                    "system": {"price": dict(zip(("value", "denomination"), parse_price(p))), "bulk": parse_bulk(b), "level": int(lvl), "category": cat_s, "capacity": float(cap),
                               "tags": tags, "description": desc, "quantity": 1,
                               "rarity": "uncommon" if n in ("Scholarly journal", "Survey map") else "common"}})
    return out


RULES = """<h2>Coins</h2><p>1 pp = 10 gp = 100 sp = 1,000 cp. The silver piece is the standard. Starting funds: 15 gp for common items.</p>
<h2>Bulk</h2><p>Items are a number, L (light) or — (negligible). 10 light items = 1 Bulk (drop fractions). Carry up to 5 + Might without penalty; above that you are
<strong>Encumbered</strong> (each foot of movement costs 2, no Reflex bonus to Defense, 1 Disadvantage on Might- and Reflex-based checks). Maximum 10 + Might.
Dragged items count half (two hands, about 50 ft/min). Creature Bulk: Tiny 1, Small 3, Medium 6, Large 12, Huge 24, Gargantuan 48.</p>
<p><strong>Size scaling:</strong> Tiny half limit; Large ×2 (treats 1 Bulk as light, light as negligible); Huge ×4; Gargantuan ×8. Items for bigger creatures cost and weigh ×2/×4/×8.</p>
<h2>Item Damage</h2><p>Hardness reduces damage; the rest reduces Durability. At or below the Broken Threshold the item is Broken; at 0 it is destroyed.
Broken melee weapons: 1 Disadvantage. Broken ranged weapons: 1 Disadvantage and halved ranges. Broken armor: half Soak. Broken tools: 1 Disadvantage.</p>
<h2>Supply (SUP)</h2><p>Maximum SUP = 1 + Intellect (minimum 1). SUP only replenishes consumables already on your sheet, of your level or lower, once every carried use is gone.
<strong>Supply Check:</strong> flat check vs DC 10 + half item level; failure costs 1 SUP; either way you get one use (or one pack/box of ammo loaded).
Each current SUP counts as 2 light items for Bulk.</p>
<p><strong>Buying SUP:</strong> a source's Supply Level sets an Availability Die (total SUP for the party) and a Price Die: 0–1 d4/d12; 2–5 d6/d10; 6–12 d8/d8; 13–16 d10/d6; 17+ d12/d4.
Price per SUP by Price Die: 1–2 5 sp, 3–4 10 sp, 5–6 15 sp, 7–8 20 sp, 9–10 25 sp, 11–12 30 sp. One Haggle per refresh (Yes And −2 steps + concession; Yes −1; Yes But −1 + condition;
No But concession; No unchanged; No And +1 step and no more haggling). Steps are 5 sp (5–30 sp). Sources refresh weekly or when circumstances change; conditions step the dice along d4–d12.</p>
<p><strong>Caches:</strong> traveler's stash d4, frontier camp d6, merchant wagon d8, military depot d10, legendary vault d12.</p>"""

MATERIALS = """Paper|0|1|0|Book pages, scrolls
Thin cloth|0|1|0|Silk, undershirts
Thin glass|0|1|0|Bottles, spectacles, window panes
Cloth|1|4|2|Cloth armor, sacks, tents
Glass|1|4|2|Glass blocks, heavy vases
Glass structure|2|8|4|Glass block wall (per 1 ft section)
Thin leather|2|8|4|Backpacks, pouches, whips
Thin rope|2|8|4|Adventuring rope
Thin wood|3|12|6|Chairs, clubs, wooden shields
Leather|4|16|8|Leather armor, saddles
Rope|4|16|8|Ship rigging
Thin stone|4|16|8|Slate tiles, cladding
Thin iron or steel|5|20|10|Chains, steel shields, swords
Wood|5|20|10|Chests, simple doors, tree trunks
Stone|7|28|14|Paving stones, statues
Iron or steel|9|36|18|Anvils, metal armor, stoves
Wooden structure|10|40|20|Reinforced doors, wooden walls (per 1 ft section)
Stone structure|14|56|28|Stone walls (per 1 ft section)
Iron or steel structure|18|72|36|Iron plate walls (per 1 ft section)"""
