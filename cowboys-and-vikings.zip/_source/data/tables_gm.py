"""GM roll tables from the Adversaries chapter."""


def d(name, items, folder, formula=None, img="icons/sundries/documents/document-sealed-brown-red.webp"):
    return {"name": name, "folder": folder, "formula": formula or f"1d{len(items)}", "img": img,
            "results": [(i + 1, i + 1, t) for i, t in enumerate(items)]}


NPC = {
    "Physique": "Athletic, Brawny, Corpulent, Delicate, Gaunt, Hulking, Lanky, Ripped, Rugged, Scrawny, Short, Sinewy, Slender, Flabby, Statuesque, Stout, Tiny, Towering, Willowy, Wiry",
    "Face": "Bloated, Blunt, Bony, Chiseled, Delicate, Elongated, Patrician, Pinched, Hawkish, Broken, Impish, Narrow, Ratlike, Round, Sunken, Sharp, Soft, Square, Wide, Wolfish",
    "Skin": "Battle Scar, Birthmark, Burn Scar, Dark, Makeup, Oily, Pale, Perfect, Pierced, Pockmarked, Reeking, Tattooed, Rosy, Rough, Sallow, Sunburned, Tanned, War Paint, Weathered, Whip Scar",
    "Hair": "Bald, Braided, Bristly, Cropped, Curly, Disheveled, Dreadlocks, Filthy, Frizzy, Greased, Limp, Long, Luxurious, Mohawk, Oily, Ponytail, Silky, Topknot, Wavy, Wispy",
    "Clothing": "Antique, Bloody, Ceremonial, Decorated, Eccentric, Elegant, Fashionable, Filthy, Flamboyant, Stained, Foreign, Frayed, Frumpy, Livery, Oversized, Patched, Perfumed, Rancid, Torn, Undersized",
    "Surname": "Baiter, Black, Buckthorne, Burley, Butterball, Catreizen, Danger, Deerider, Grant, Halva, Maker, Pipp, Seedfall, Snow, Summerholme, Thorne, Tunneler, White, Winterholme, Witter",
    "Background": "Alchemist, Beggar, Butcher, Burglar, Charlatan, Cleric, Cook, Cultist, Gambler, Herbalist, Magician, Mariner, Mercenary, Merchant, Outlaw, Performer, Pickpocket, Smuggler, Student, Tracker",
    "Speech": "Blunt, Booming, Breathy, Cryptic, Drawling, Droning, Flowery, Formal, Gravelly, Hoarse, Mumbling, Precise, Quaint, Rambling, Rapid-fire, Dialect-heavy, Slow, Squeaky, Stuttering, Whispery",
    "Wants": "Freedom, Safety, Escape, Excitement, Power, Meaning, Health, Wealth, Protection, Love, To protect, Food, Friendship, Rest, Knowledge, Savagery, Beauty, Revenge, To serve, Fun",
    "Misfortunes": "Abandoned, Addicted, Blackmailed, Condemned, Cursed, Defrauded, Demoted, Discredited, Disowned, Exiled, Framed, Haunted, Kidnapped, Mutilated, Poor, Pursued, Rejected, Replaced, Robbed, Suspected",
    "Quirk": "Constantly grooming, Obsessed with weather, Very high energy, Traveled and knowledgeable, Cursed by a wizard, Scares easily, Ashamed of past crimes, Very competitive, Flamboyant drunkard, Extremely polite, Unreservedly honest, Slow and careful speech, Quick and erratic speech, Secret servant to cats, Raised by animals, Outcast from home, Many pets, Hates being outdoors, Local hero, Very twitchy face",
    "Virtue": "Ambitious, Cautious, Courageous, Courteous, Curious, Disciplined, Focused, Generous, Gregarious, Honest, Honorable, Humble, Idealistic, Just, Loyal, Merciful, Righteous, Serene, Stoic, Tolerant",
    "Vice": "Aggressive, Arrogant, Bitter, Cowardly, Cruel, Deceitful, Flippant, Gluttonous, Greedy, Irascible, Lazy, Nervous, Prejudiced, Reckless, Rude, Suspicious, Vain, Vengeful, Wasteful, Whiny",
}

NAMES = ("Ada, Agate, Agnes, Aloe, April, Azalea, Bay, Belladonna, Blossom, Brie, Brynn, Cherry, Claire, Crocus, Dahlia, Daisy, Else, Emerald, Erin, Grace, "
         "Gwendoline, Hazel, Heather, Hette, Holly, Hyacinth, Iris, Juniper, Lavender, Lily, Magnolia, Marigold, Marjoram, Myrtle, Odette, Olive, Opal, Pearl, Pepper, Poppy, "
         "Rosemary, Rue, Saffron, Sandy, Sassafras, Shale, Susan, Thistle, Violet, Willow, Alder, Ambrose, Anise, Annatto, August, Avens, Basil, Beryl, Birch, Boldo, "
         "Bill, Burdock, Butter, Cassia, Chicory, Clive, Colby, Dill, Eared, Edmund, Elmer, Ernest, Fennel, Festus, Francis, Gil, Hawthorn, Heath, Horatio, Jack, "
         "Jasper, Konrad, Larkspur, Laurel, Lorenz, Mace, Oliver, Orin, Reepicheep, Rowen, Simon, Sorrel, Stilton, Tarragon, Warren, Wattle, Whatley, Whitacre, Wormwood, Yarrow").split(", ")

PATRON = {
    "Patron — Who They Are (d20)": ["A struggling homesteader", "A respected town elder", "A circuit judge or traveling lawman", "A wealthy rancher or landowner", "A saloon or business owner", "A grieving widow or widower", "A local preacher or religious figure", "A retired soldier or lawman", "A railroad or mining company agent", "A tribal elder or representative", "A traveling merchant", "A disgraced former official", "A frightened parent", "A bounty office clerk", "A gambler with debts to settle", "A newspaper editor chasing a story", "An outlaw looking to go straight", "An immigrant new to the territory", "A masked or anonymous go-between", "Someone with real political power, playing it down"],
    "Patron — What They Want Done (d12)": ["Recover something stolen", "Escort someone or something safely", "Investigate a disappearance", "Deliver a message or package quietly", "Remove a specific threat", "Settle a dispute without more bloodshed", "Find and bring back a missing person", "Secure evidence against someone", "Negotiate or broker a deal", "Guard a place or person for a time", "Track down and confirm the fate of someone", "Do something they can't be seen doing themselves"],
    "Patron — Why They Really Want It (d10)": ["Simple, honest need", "Guilt over a past mistake", "Revenge, dressed up as justice", "Protecting their reputation", "Protecting someone they love", "Financial desperation", "Fear of what happens if they don't act", "Ambition — a stepping stone", "Genuine faith or moral conviction", "They're being pressured or blackmailed"],
    "Patron — The Catch (d8)": ["They're not telling the whole truth", "Someone powerful doesn't want this done", "The timeline is far shorter than they let on", "They can't actually afford what they're offering", "Someone else already tried and failed badly", "The job isn't as clean or legal as it sounds", "A rival wants the same outcome for worse reasons", "Succeeding will make the party a new enemy"],
    "Patron — What's Offered (d6)": ["A modest but fair sum of money", "A favor or debt owed, redeemable later", "Information the party actually needs", "Land, goods, or property", "Protection or influence within the town", "Considerably more than the job seems worth"],
    "Patron — How the Party Meets Them (d4)": ["They seek the party out directly", "The party's reputation reaches them through others", "A mutual contact makes the introduction", "Pure chance throws them together"],
}

WILD = {
    "Wilderness — Nearby Terrain Feature (d20)": ["Abandoned homestead, roof caved in", "Flash-flood-prone creek bed", "Rickety rope bridge over a deep ravine", "Box canyon with a single way in or out", "Loose scree slope, ready to slide", "Wreckage of an old wagon train", "Half-collapsed mine tunnel entrance", "Sheer cliff face with a narrow ledge trail", "Sucking bog or quicksand flat", "Ruins of a burned-out trading post", "Trapper's line shack, still stocked", "Overgrown, untended burial mound", "Narrow mountain pass, easily choked", "Crumbling bathhouse or resort ruin", "Isolated lawman's or ranger's outpost", "Hidden still or smuggler's cache", "Old battlefield, bones still surfacing", "Ground overrun by thorned growth", "Dry brush that catches flame at a spark", "A longship or wagon, stripped and abandoned"],
    "Wilderness — Hostile Force (d12)": ["Bandits holed up nearby (outlaws, opportunists, greed)", "Locals hunting easy marks (desperation, territory, cruelty)", "A rabid or diseased predator (feral, corruption, single threat)", "A hunting pack of beasts (coordination, numbers, instinct)", "A spooked, dangerous herd (panic, chaos, size)", "A swarm of vermin (numbers, disease, relentless)", "An outlaw fleeing the law (desperation, cornered, mobility)", "A brutal landowner and hired guns (authority, muscle, leadership)", "A hermit defending their solitude (isolation, territory, unpredictable)", "A 'friendly' guide leading into a trap (deception, betrayal, setup)", "A harmless-looking but dangerous beast (deception, surprise, misjudged threat)", "A confidence artist working the road (deception, greed, social)"],
    "Wilderness — Nature of the Encounter (d8)": ["Ambush by a group", "A single hidden attacker strikes", "Folks who clearly don't want to be found", "People in genuine need of help", "Hostile creatures on the prowl", "The terrain feature itself turns dangerous", "The terrain feature promises real loot", "Seeming friendlies who aren't, once you're close"],
    "Wilderness — Weather & Light (d6)": ["Clear daylight", "Daylight, fog, mist, or rain", "Daylight, harsh seasonal weather", "Clear night", "Night, rain or obscuring weather", "Night, a brutal storm"],
    "Wilderness — Initial Range (d4)": ["Spotted from a long way off", "Noticed at standard range", "Noticed only at Close range", "Not noticed until adjacent"],
    "Wilderness — Friendly or Neutral Presence (d10)": ["A reclusive but affable hermit", "Loose livestock or a herd animal", "A circuit judge, marshal, or ranger", "Curious wildlife", "An isolated homesteading family", "A working trapper or hunter", "A back-country settler or native guide", "A wandering pilgrim or traveler", "A religious recluse or wandering holy figure", "An exile, cast out from their community"],
}

TOWN = {
    "Town — What's Happening (d20)": ["A parade, wake, or celebration is being disrupted", "Someone's being roughed up in plain sight", "A robbery is in progress", "A dispute over local politics turns loud", "A crowd has turned on someone", "A fire or building collapse is underway", "Someone's badly hurt and needs help fast", "A con artist is working the crowd", "A wagon or horse has bolted", "A religious service is being disrupted", "A duel or grudge match is about to happen", "Livestock has gotten loose downtown", "A lynch mob is forming", "A public trial or hanging draws a crowd", "A bar fight spills into the street", "A traveling preacher or huckster draws a crowd", "A shipment is being loaded or unloaded", "Someone's spreading dangerous rumors", "A gambling dispute turns ugly", "A stranger's arrival has spooked the town"],
    "Town — Who's Involved (d12)": ["A local bully and hangers-on", "A crooked town boss and loyal muscle", "Violent outlaws", "Zealots or fanatics", "An obnoxious, wealthy outsider", "A corrupt or overzealous lawman", "A mob of drunk locals", "A rabble-rousing agitator and followers", "A stubborn local of some standing", "A dangerously capable hired gun", "A self-important local power player", "A confused newcomer, in over their head"],
    "Town — Why the Party Gets Pulled In (d10)": ["Someone sympathetic appeals directly to them", "Every way around is blocked or dangerous", "It's happening right where they are", "Something valuable looks there for the taking", "Someone offers a reward for stepping in", "They're mistaken for someone involved", "The obvious way out leads deeper in", "Blame gets pinned on them", "A familiar face is caught up in it", "Local law demands their involvement"],
    "Town — Where in Town (d8)": ["Main street, in the open", "The town square or plaza", "A back alley", "Inside a local business", "The saloon or tavern", "The stables or livery", "Near the church, meeting hall, or courthouse", "The train depot, dock, or transit point"],
    "Town — What It's Actually About (d6)": ["Money, debt, or unpaid wages", "Respect, pride, or standing", "An old grudge or feud", "Politics, faith, or ideology", "A broken promise or romance", "Land, water rights, or property"],
    "Town — How Far It Has Escalated (d4)": ["Still just talk, for now", "Shoving, threats, drawn weapons — not fired yet", "Already violent when they arrive", "Already over; they deal with the aftermath"],
}

BROKEN = ["Fall back to cover (still fighting)", "Fighting withdrawal — disengage, back up", "Flee", "Surrender", "Bargain or parley", "Rage — reckless attack for 1 round, then withdraws"]


def tables():
    out = []
    for k, v in NPC.items():
        out.append(d(f"NPC {k}", [x.strip() for x in v.split(",")], "NPC Generator", img="icons/environment/people/commoner.webp"))
    out.append(d("NPC Name", NAMES, "NPC Generator", "1d100", img="icons/environment/people/commoner.webp"))
    for k, v in PATRON.items():
        out.append(d(k, v, "One-Roll Frontier Patron", img="icons/environment/people/cleric-orange.webp"))
    for k, v in WILD.items():
        out.append(d(k, v, "One-Roll Wilderness Encounter", img="icons/environment/wilderness/cave-entrance-mountain.webp"))
    for k, v in TOWN.items():
        out.append(d(k, v, "One-Roll Frontier Town Encounter", img="icons/environment/settlement/saloon.webp"))
    out.append(d("Morale — Broken Element Outcome", BROKEN, "Running Encounters", img="icons/skills/social/diplomacy-surrender-flag.webp"))
    # Reaction roll tables per Intellect category (2d6 bands)
    from collections import OrderedDict
    bands = [(2, 2), (3, 5), (6, 8), (9, 11), (12, 12)]
    react = OrderedDict([
        ("Brutish (Intellect 0)", ["Immediate violence. Charges, pounces, or opens fire without hesitation.", "Hostile and reckless. Threatens or attacks with little regard for danger.", "Confused or wary. Hesitates, follows the strongest cue.", "Curious. May accept a simple trade or follow a confident lead.", "Friendly and trusting. Follows a confident lead, may help without understanding the risk."]),
        ("Dull (Intellect 1-2)", ["Lashes out. Fear, confusion, or anger immediately becomes an attack.", "Hostile. Intimidates and may attack, but could retreat or surrender when hurt.", "Wary. Avoids commitment; may be tempted by food, loot, or an easy exit.", "Cautiously friendly. Offers limited help for reward, protection, or reassurance.", "Eager to help. Looks to the party for protection, leadership, or purpose."]),
        ("Average (Intellect 3)", ["Takes cover and threatens. Orders the party to back off; attacks if they hesitate.", "Hostile but listening. A bribe, explanation, or display of authority may prevent violence.", "Cautious parley. Weapons ready, asks the party to explain themselves.", "Open to a bargain. Trades, shares information, or discusses common interests.", "Helpful. Freely shares information, may offer supplies or shelter."]),
        ("Clever (Intellect 4-5)", ["Prepares an ambush. Stalls while taking position, surrounding the party, or calling support.", "Controlled hostility. Holds a strong position, demands concessions, attacks only when advantageous.", "Probes for weakness. Tests claims and looks for an advantage before deciding.", "Professional cooperation. Proposes a mutually beneficial exchange.", "Generously cooperative. Offers resources or contacts on favorable, sensible terms."]),
        ("Genius (Intellect 6+)", ["Creates leverage. Alarms, a crossfire, a hostage, or a prepared trap.", "Feigns calm. Seems willing to negotiate while quietly carrying out a hostile plan.", "Cold calculation. Offers a conditional arrangement while studying the party.", "Attempts recruitment. Proposes a partnership or structured agreement.", "Cultivates an alliance. Helps now while establishing a future favor or bond."]),
    ])
    for k, v in react.items():
        out.append({"name": f"Adversary Reaction — {k}", "folder": "Running Encounters", "formula": "2d6",
                    "img": "icons/skills/social/intimidation-impressing.webp",
                    "results": [(lo, hi, t) for (lo, hi), t in zip(bands, v)]})
    return out
