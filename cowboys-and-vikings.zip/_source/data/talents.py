"""Talents chapter — condensed. Each entry: tree, name, tier, prerequisites, rules summary, options."""
import re

PUSH_A = "Push: take 1 Strain to use this for 1 AP instead of 2."
PUSH_R = "Push: take 1 Strain to use this reaction for 1 RP instead of 2."

TREE_IMG = {
    "Acrobatics": "icons/skills/movement/figure-running-gray.webp", "Alertness": "icons/magic/perception/eye-slit-orange.webp",
    "Assassin": "icons/weapons/daggers/dagger-curved-poison-green.webp", "Athletics": "icons/skills/movement/arrows-up-trio-red.webp",
    "Berserker": "icons/skills/melee/strike-axe-blood-red.webp", "Closer": "icons/skills/social/diplomacy-handshake.webp",
    "Commander": "icons/sundries/flags/banner-flag-white.webp", "Crafting": "icons/tools/smithing/anvil.webp",
    "Deception": "icons/equipment/head/mask-carved-wood-white.webp", "Diplomacy": "icons/skills/social/diplomacy-handshake-yellow.webp",
    "Elusive": "icons/skills/movement/feet-winged-boots-brown.webp", "Intimidation": "icons/skills/social/intimidation-impressing.webp",
    "Grappler": "icons/skills/melee/unarmed-punch-fist.webp", "Kung Fu": "icons/skills/melee/unarmed-punch-fist-yellow-red.webp",
    "Master Thrower": "icons/weapons/thrown/dagger-ringed-steel.webp", "Medicine": "icons/tools/cooking/mortar-herbs-yellow.webp",
    "Melee Weapon": "icons/skills/melee/weapons-crossed-swords-yellow.webp", "Mysticism": "icons/magic/symbols/runes-star-orange.webp",
    "Nature": "icons/magic/nature/leaf-glow-green.webp", "Perform": "icons/tools/instruments/lute-gold-brown.webp",
    "Ranged Combat": "icons/weapons/guns/gun-pistol-flintlock-white.webp", "Scoundrel": "icons/skills/social/theft-pickpocket-bribery-brown.webp",
    "Shield": "icons/equipment/shield/heater-steel-worn.webp", "Sleight of Hand": "icons/sundries/gaming/playing-cards.webp",
    "Society": "icons/sundries/documents/document-sealed-signatures-red.webp", "Stealth": "icons/magic/perception/silhouette-stealth-shadow.webp",
    "Survival": "icons/environment/wilderness/camp-improvised.webp", "Swashbuckler": "icons/weapons/swords/sword-guard-flanged-purple.webp",
    "Thievery": "icons/tools/hand/lockpicks-steel-grey.webp", "Training": "icons/skills/trades/academics-study-reading-book.webp",
}

TALENTS = []


def T(tree, name, tier, req, text, cost="passive", traits="", trigger="", push=False, strain=0, roll=None, repeat=False):
    desc = f"<p><em>Requires: {req or '—'}</em></p>"
    if trigger:
        desc += f"<p><strong>Trigger:</strong> {trigger}</p>"
    desc += "".join(f"<p>{p.strip()}</p>" for p in text.split("\n") if p.strip())
    if push:
        desc += f"<p><em>{PUSH_R if cost == 'reaction' else PUSH_A}</em></p>"
    if repeat:
        desc += "<p><em>Special: this talent can be taken multiple times.</em></p>"
    TALENTS.append({
        "name": name, "type": "talent", "folder": tree, "img": TREE_IMG.get(tree, "icons/sundries/books/book-red-exclamation.webp"),
        "system": {"tree": tree, "tier": tier, "prerequisites": req, "summary": re.sub(r"\s+", " ", text.split("\n")[0])[:160],
                   "actionTraits": [t.strip().lower() for t in traits.split(",") if t.strip()],
                   "cost": cost, "strain": strain, "trigger": trigger, "description": desc,
                   "roll": roll or {}, "ranks": {"value": 1, "max": 99 if repeat else 1}}
    })


def R(skill, n):
    return f"{n}+ ranks in {skill}"


# ---------------------------------------------------------------- ACROBATICS
A = "Acrobatics"
T(A, "Cat Fall", 1, R(A, 1), "Treat falls as 10 ft shorter for damage. 2+ ranks: 25 ft shorter. 5+ ranks: 50 ft. 9+ ranks: you always land on your feet and take no fall damage.", traits="skill")
T(A, "Quick Squeeze", 1, R(A, 1), "Squeeze 5 ft per round (10 ft on a critical success). 9+ ranks: squeeze at full Speed.", traits="skill")
T(A, "Steady Balance", 1, R(A, 1), "Acrobatics checks to keep your balance are critical successes on a natural 19–20. You aren't Off-Guard while balancing on narrow or uneven ground.", traits="skill")
T(A, "Nimble Crawl", 1, R(A, 2), "While Prone your Speed is 5 ft instead of 0. 5+ ranks: half Speed. 9+ ranks: full Speed, and being Prone grants enemies no Advantage against you.", traits="skill")
T(A, "Nimble Conditioning", 1, f"{R(A, 2)}; Reflex 2+", "Use Reflex to determine your maximum Strain.")
T(A, "Kip Up", 1, R(A, 5), "Standing from Prone costs only 5 ft of movement instead of half your Speed.", traits="skill")

# ---------------------------------------------------------------- ALERTNESS
L = "Alertness"
T(L, "Alertness", 1, "", "+2 to Initiative.", traits="combat, exploration")
T(L, "Athletic Reflexes", 2, "Alertness; Might 2+", "You may use Might for Initiative instead of Reflex or Perception.")
T(L, "Clever Reflexes", 2, "Alertness; Intellect 2+", "You may use Intellect for Initiative instead of Reflex or Perception.")
T(L, "Hit the Dirt", 2, "Alertness", "Drop Prone and take cover (2 RP): +4 to the triggering save. You stay Prone until you recover normally.",
  cost="reaction", traits="move, reaction, maneuver", trigger="You fail a Reflex save against a ranged attack you're aware of.", push=True)
T(L, "Reactive Shout", 2, "Alertness", "Shout a warning (2 RP) to an ally who can hear and understand you: 1 Advantage on saves against that enemy's attacks until the start of the ally's next turn.",
  cost="reaction", traits="auditory, reaction, maneuver", trigger="An ally is targeted by an attack from an enemy you're aware of.", push=True)

# ---------------------------------------------------------------- ASSASSIN
S = "Assassin"
T(S, "Shadow Opportunist", 1, R("Stealth", 1), "+1 Advantage on attacks against enemies you are Hidden or Undetected from.")
T(S, "Sneak Attack", 2, f"Shadow Opportunist; {R('Stealth', 2)}", "Once per turn, when you deal damage with a melee attack or a ranged attack within 20 ft that had any Advantage, add 1d4 per level of Advantage.", traits="attack, taxing")
T(S, "Assassin's Strike", 3, f"Shadow Opportunist, Sneak Attack; {R('Stealth', 5)}", "Once per turn, double your Sneak Attack damage while Hidden or Undetected by the target.", traits="attack, taxing")
T(S, "Shadow Feint", 2, f"Shadow Opportunist; {R('Stealth', 2)}", "Stealth check vs the target's Perception save. Success: make a melee attack as part of this action with 1 Advantage (2 on a critical success).",
  cost="2", traits="attack, maneuver", push=True, roll={"type": "check", "skill": "stealth"})
T(S, "Poison Expert", 2, f"Shadow Opportunist; {R('Stealth', 1)}; {R('Crafting', 1)}", "Craft poisons with Crafting. Once per turn, apply a poison to a weapon with Interact for 0 AP.", traits="skill")

# ---------------------------------------------------------------- ATHLETICS
H = "Athletics"
T(H, "Combat Climber", 1, R(H, 1), "You aren't Off-Guard while climbing and can climb with one hand occupied.", traits="skill")
T(H, "Hefty Hauler", 1, R(H, 1), "+2 to your maximum and encumbered Bulk limits.", traits="skill")
T(H, "Underwater Marauder", 1, R(H, 1), "No Disadvantage on attacks with bludgeoning or slashing weapons underwater, and you aren't Off-Guard in water.", traits="skill")
T(H, "Rugged", 1, R(H, 1), "Add half your Athletics ranks (round up) to your Strain limit.")
T(H, "Rugged II", 2, f"Rugged; {R(H, 2)}", "Add double your Athletics ranks to your maximum HP.")
T(H, "Second Wind", 2, f"Rugged; {R(H, 2)}", "Recover Strain equal to half your maximum Strain. This uses one of your short rests for the long rest.", cost="2", traits="healing")
T(H, "Second Wind II", 3, f"Rugged, Second Wind; {R(H, 5)}", "You get one more short rest per long rest (3 total).", traits="healing")
T(H, "Body Hardening", 2, f"Rugged; {R(H, 5)}", "Advantage on Dazed checks when taking damage.")
T(H, "Body Hardening II", 3, f"Rugged, Body Hardening; {R(H, 9)}", "Advantage on Staggered checks when taking damage.")
T(H, "Athletic Resolve", 1, f"{R(H, 2)}; Might 2+", "Use Might instead of Fortitude to determine your maximum Strain.")
T(H, "Rapid Mantle", 1, R(H, 2), "When you Grab an Edge you can pull yourself up and stand, and you may use Athletics instead of a Reflex save to Grab an Edge.", traits="skill")
T(H, "Powerful Leap", 1, R(H, 5), "Double your maximum horizontal and vertical jump distances.", traits="skill")
T(H, "Quick Climb", 1, R(H, 5), "DC 20 Athletics: gain a climb Speed equal to your Speed until the start of your next turn.", traits="skill", roll={"type": "check", "skill": "athletics", "dc": "20"})
T(H, "Quick Swim", 1, R(H, 5), "DC 20 Athletics: gain a swim Speed equal to your Speed until the start of your next turn.", traits="skill", roll={"type": "check", "skill": "athletics", "dc": "20"})
T(H, "Wall Jump", 1, R(H, 5), "If you end a jump next to a wall, you don't fall as long as your next action is another jump. Once per turn (unlimited at 9+ ranks, if each is followed by another jump).", traits="skill")
T(H, "Cloud Jump", 1, R(H, 9), "Triple your maximum Long Jump and High Jump distances.", traits="skill")

# ---------------------------------------------------------------- BERSERKER
B = "Berserker"
BR = f"{R('Athletics', 1)}; {R('Melee Weapons', 1)}"
T(B, "Frenzy", 1, BR, "Spend 2 Strain to enter a frenzy lasting rounds equal to your Fortitude. You can pay 2 more Strain to extend it when it ends.\n"
  "While frenzied: resistance to nonmagical bludgeoning, piercing and slashing; +1 melee damage per 2 Athletics ranks; 1 Advantage on Fortitude saves and saves vs MENTAL; "
  "1 Disadvantage on Might and Reflex saves; no CONCENTRATE actions; your melee attacks lose Finesse, Agile, Disarm and Parry.", cost="stance", traits="combat, stance", strain=2)
T(B, "Reckless Strike", 2, f"Frenzy; {R('Athletics', 2)}; {R('Melee Weapons', 2)}", "Once per turn, make a melee attack with 1 Advantage, then suffer equal Disadvantage (minimum 1) on Might and Reflex saves until the start of your next turn. "
  "Per 3 Athletics ranks you may spend 1 Strain for +1 more Advantage (and +1 more Disadvantage).", cost="2", traits="attack, combat, taxing, maneuver", push=True, roll={"type": "attack"})
T(B, "Whirlwind Attack", 3, f"Frenzy, Reckless Strike; {R('Athletics', 5)}; {R('Melee Weapons', 5)}", "Once per turn, make one melee attack roll against each chosen creature within your reach; each makes a Might save against it. "
  "Critical success: no damage; success: half; failure: full; critical failure: double. Roll damage once.", cost="2", traits="attack, combat, taxing, maneuver", push=True)
T(B, "Whirlwind Attack II", 4, f"Whirlwind Attack; {R('Athletics', 9)}; {R('Melee Weapons', 9)}", "As Whirlwind Attack, but make two attack rolls. Each target saves against both; add damage from each failed save (one damage roll), then apply Soak and resistances.",
  cost="2", traits="attack, combat, taxing, maneuver", push=True)
T(B, "Frenzy II", 2, f"Frenzy; {R('Athletics', 5)}; {R('Melee Weapons', 5)}", "While frenzied: 1 Advantage on flat checks to end persistent damage and on Dazed and Staggered checks, and your melee weapons gain Thrown (20 ft).", traits="combat, stance")
T(B, "Brutal Blow", 2, f"Frenzy; {R('Athletics', 2)}; {R('Melee Weapons', 2)}", "Attack a different creature in reach with the same weapon (2 RP). Excess damage from the killing blow is added to this attack's damage.",
  cost="reaction", traits="attack, combat, reaction, maneuver", trigger="Your melee attack reduces a creature to 0 HP or less.", push=True)
T(B, "Leap Attack", 2, f"Frenzy; {R('Athletics', 2)}; {R('Melee Weapons', 2)}", "After leaping at least 10 ft toward the target, attack and also roll Athletics. If both beat the target's defense, roll damage with Fortune.",
  cost="2", traits="attack, combat, maneuver, move", push=True)
T(B, "Furious Resilience", 2, f"Frenzy; {R('Athletics', 5)}; {R('Melee Weapons', 5)}", "Athletics check vs the attack roll (2 RP). Success: +Soak equal to your Athletics ranks against that attack (double on a critical success).",
  cost="reaction", traits="combat, reaction, maneuver", trigger="You're hit by an attack you're aware of.", push=True)

# ---------------------------------------------------------------- CLOSER
C = "Closer"
CR = "1+ ranks in Intimidation or Diplomacy"
T(C, "Closer", 1, CR, "1 Advantage on Diplomacy checks against creatures with fewer Diplomacy ranks than you, and on Intimidation checks against creatures with fewer Intimidation ranks.", traits="mental, auditory, linguistic")
T(C, "Character Study", 2, f"Closer; {CR}", "After 1 minute of conversation with a creature (Intellect −3 or higher), gain 1 Advantage on Charisma checks against it.", traits="mental, auditory, linguistic")
T(C, "Know the Mark", 3, "Closer, Character Study; 2+ ranks in Intimidation or Diplomacy", "Character Study grants 2 Advantage instead.", traits="mental, auditory, linguistic")
T(C, "Chameleon", 2, f"Closer; {CR}; {R('Deception', 1)}", "While maintaining an assumed identity (disguise or cover story), 1 Advantage on Deception checks that rely on it.", traits="mental, auditory, linguistic")
T(C, "Cultural Sponge", 3, f"Closer, Chameleon; 2+ ranks in Intimidation or Diplomacy; {R('Deception', 2)}; {R('Society', 1)}", "After 24 hours living within another culture, 1 Advantage on Society checks about it.", traits="mental, auditory, linguistic")

# ---------------------------------------------------------------- COMMANDER
M_ = "Commander"
MR = "3+ ranks in Intimidation or Diplomacy"
CD = "Commander Die"
T(M_, "Commanding Presence", 1, "2+ ranks in Intimidation or Diplomacy", f"Gain a {CD} (starts at 1d6, grows with ranks in your Command Style skill). Choose Diplomacy or Intimidation as your Command Style (permanent). "
  f"When you use that skill, you may spend 1 Strain to add the {CD}.", traits="mental, auditory, linguistic")
T(M_, "Bait and Switch", 2, MR, f"Swap places with an adjacent ally (at least 5 ft of movement, no reactions provoked). Roll your {CD}: you or the ally adds it to saves vs physical attacks until your next turn.",
  cost="2", traits="move, maneuver", push=True)
T(M_, "Combat Reflexes", 2, MR, f"Once per turn, make one weapon attack against that enemy (2 RP); add your {CD} to damage on a hit.", cost="reaction", traits="maneuver, taxing, reaction, attack",
  trigger="An enemy you can see moves within 5 ft of you.", push=True)
T(M_, "Commander's Strike", 2, MR, f"Roll your {CD}. An ally who can see or hear you may spend 1 RP to make one weapon attack, adding the die to damage on a hit.", cost="2", traits="mental, auditory, linguistic, maneuver", push=True)
T(M_, "Defensive Stance", 2, MR, f"While this stance is active, when targeted by a physical attack you may react (2 RP) and add your {CD} to your save.", cost="stance", traits="stance", push=True)
HALFDC = "a save against DC 10 + half the damage it actually took (after Soak and resistances)"
T(M_, "Goading Attack", 2, MR, f"Add your {CD} to damage (2 RP). The target makes a Charisma save ({HALFDC[7:]}); failure: 1 Disadvantage on attacks that don't target you until the end of your next turn (+1 per 3 ranks beyond 2).",
  cost="reaction", traits="maneuver, reaction", trigger="You hit a creature with a weapon attack.", push=True)
T(M_, "Menacing Attack", 2, MR, f"Add your {CD} to damage (2 RP). The target makes an Intellect save ({HALFDC[7:]}); failure: Frightened 1 of you (+1 per 3 ranks beyond 2).",
  cost="reaction", traits="maneuver, reaction", trigger="You hit a creature with a weapon attack.", push=True)
T(M_, "Pushing Attack", 2, MR, f"Add your {CD} to damage (2 RP). The target makes a Might save ({HALFDC[7:]}); failure: pushed 15 ft (+5 ft per 3 ranks beyond 2).",
  cost="reaction", traits="maneuver, reaction", trigger="You hit a creature with a weapon attack.", push=True)
T(M_, "Rally", 2, MR, f"An ally who can see or hear you gains temporary HP equal to your {CD} + your Charisma.", cost="2", traits="mental, auditory, linguistic, maneuver", push=True)
T(M_, "Restraining Strike", 2, MR, f"Attempt to Grapple the target (2 RP), adding your {CD} to the Martial Arts check.", cost="reaction", traits="maneuver, reaction", trigger="You hit an enemy with a weapon attack.", push=True)
T(M_, "Shield Charge", 2, f"{MR}; {R('Shields', 1)}", f"Move at least 10 ft straight toward a creature, then make a Shields check (+{CD}) vs its Might save. Win: it takes shield damage + the {CD} and is pushed 10 ft or knocked Prone (your choice).",
  cost="2", traits="move, maneuver", push=True)
T(M_, "Sweeping Attack", 2, MR, f"Choose another creature within 5 ft of the target and in your reach (2 RP). If your attack roll would also hit it, it takes damage equal to your {CD} (same type).",
  cost="reaction", traits="maneuver, reaction", trigger="You hit a creature with a melee weapon attack.", push=True)

# ---------------------------------------------------------------- CRAFTING
K = "Crafting"
T(K, "Alchemical Crafting", 1, f"{R(K, 1)}; alchemist's tools proficiency", "Craft alchemical items. Add four common 1st-level alchemical formulas to your formula book.", traits="skill")
T(K, "Firearm Crafting", 2, f"Alchemical Crafting; {R(K, 2)}; {R('Firearms', 1)}", "Build, repair and modify firearms and bullets. Needed to craft trick bullets.", traits="skill")
T(K, "Quick Repair", 1, R(K, 1), "Repair an item in 1 minute. 5+ ranks: 2 AP. 9+ ranks: 1 AP.", traits="skill")
T(K, "Snare Crafting", 1, R(K, 1), "Craft snares. Add four common snare formulas to your formula book.", traits="skill")
T(K, "Specialty Crafting", 1, R(K, 1), "Choose a tool set: 1 Advantage on Crafting checks with it (2 at 8+ ranks). The GM may grant partial benefit for mixed work.", traits="skill", repeat=True)
T(K, "Impeccable Crafting", 2, f"Specialty Crafting; {R(K, 5)}", "+1 more Advantage on Crafting checks with your specialized tools.")
T(K, "Magical Crafting", 1, f"{R(K, 2)}; {R('Mysticism', 1)}", "Craft magic items. Gain four common magic item formulas of 1st level or lower.")
T(K, "Inventor", 1, R(K, 5), "During downtime, invent a common formula you don't know, using the Craft procedure (research and design instead of building). The formula goes into your book.", traits="skill, downtime")
T(K, "Craft Anything", 1, R(K, 9), "If you have the right crafting talent and meet the level requirement, you can ignore most other item requirements (GM decides). You can't ignore requirements that add cost or unique ones.", traits="skill")

# ---------------------------------------------------------------- DECEPTION
D = "Deception"
T(D, "Charming Liar", 1, R(D, 1), "On a critical success with a meaningful Lie, one target's attitude toward you improves one step (once per conversation).", traits="skill")
T(D, "Lengthy Diversion", 1, R(D, 1), "On a critical success to Create a Diversion, you stay hidden after your turn for at least 1 more round (GM decides how long).", traits="skill")
T(D, "Quick Disguise", 1, R(D, 2), "Set up a disguise in half the time. 5+ ranks: one-tenth (about 1 minute). 9+ ranks: 1 round.", traits="skill")
T(D, "Confabulator", 1, R(D, 5), "Reduce the Advantage targets gain from your previous Lies or Diversions by 1.", traits="skill")
T(D, "Slippery Secrets", 1, R(D, 5), "When magic tries to read your mind, detect your lies or reveal your nature, make a Deception check against its DC; on a success it reveals nothing.", traits="skill")

# ---------------------------------------------------------------- DIPLOMACY
P = "Diplomacy"
T(P, "Group Impression", 1, R(P, 1), "Make an Impression on up to twice your Diplomacy ranks targets, comparing one check against each target's Charisma save.", traits="skill")
T(P, "Glad-Hand", 1, R(P, 2), "Make an Impression on someone you've just met without the minute of conversation, at 2 Disadvantage. If you fail, you can still talk for a minute and try again.", traits="skill")
T(P, "Shameless Request", 1, R(P, 5), "Outrageous Requests have their DC increase reduced by 2, and a critical failure becomes a failure. Targets still grow tired of repeated requests.", traits="skill")
T(P, "Legendary Negotiation", 1, R(P, 9), "In the middle of trouble, Make an Impression and then Request that the foe stop and parley, at 2 Disadvantage. The GM sets the DC, usually very hard. Some creatures refuse or turn violent again.",
  cost="2", traits="skill")

# ---------------------------------------------------------------- ELUSIVE
E = "Elusive"
T(E, "Elusive Footwork", 1, R(A, 1), "While active, if you move at least 10 ft on your turn you gain 1 Advantage on Reflex saves until your next turn (+1 per 6 Acrobatics ranks, maximum 3).", cost="stance", traits="move, stance")
T(E, "Combat Crouch", 2, f"Elusive Footwork; {R(A, 2)}", "While Elusive Footwork is active, cover grants +2 more to your Defense.")
T(E, "Improved Disengage", 2, f"Elusive Footwork; {R(A, 2)}", "Disengage costs 1 AP instead of 2.", traits="move")
T(E, "Evasive Reaction", 2, f"Elusive Footwork; {R(A, 2)}", "While Elusive Footwork is active, when you critically succeed on a Dodge you may spend 1 Strain to move your full Speed instead of half.", traits="move, reaction")
T(E, "Offensive Evasion", 3, f"Elusive Footwork, Evasive Reaction; {R(A, 5)}", "Once per turn, spend 1 Strain to add the Advantage Elusive Footwork gave your Reflex saves to your next weapon attack.", cost="1", traits="move, attack, taxing", strain=1)
T(E, "Evasive Roll", 3, f"Elusive Footwork, Evasive Reaction; {R(A, 5)}", "While Elusive Footwork is active, move 5 ft and halve the damage (2 RP). You must be able to move. Push: take 2 Strain to use this for 1 RP.",
  cost="reaction", traits="move, maneuver, reaction", trigger="You would be hit by a physical attack you're aware of.")

# ---------------------------------------------------------------- INTIMIDATION
I = "Intimidation"
T(I, "Group Coercion", 1, R(I, 1), "Coerce up to twice your Intimidation ranks targets at once, with separate results for each.", traits="skill, mental, auditory, linguistic")
T(I, "Intimidating Glare", 1, R(I, 1), "Demoralize with a glare: it's visual instead of auditory, and there's no penalty if the target doesn't share your language.", traits="skill")
T(I, "Show of Force", 1, f"{R(I, 1)}; Might 2+", "You may use Might instead of Charisma for Intimidation checks.")
T(I, "Intimidating Prowess", 2, f"Show of Force; {R(I, 2)}; Might 3+", "When you can physically menace the target while Coercing or Demoralizing: 1 Advantage and no language penalty (2 Advantage at Might 5+ and 5+ ranks).", traits="skill")
T(I, "Quick Coercion", 1, R(I, 2), "Coerce after 1 round of conversation instead of 1 minute (still not in combat).", traits="skill")
T(I, "Lasting Coercion", 1, R(I, 2), "Coerced targets comply for up to a week (a month at 9+ ranks).", traits="skill")
T(I, "Battle Cry", 1, R(I, 5), "Spend 1 Strain to Demoralize the target (1 RP) with 1 Advantage (2 at 8+ ranks, 3 at 11+).", cost="reaction", traits="skill, reaction",
  trigger="You score a critical hit with a melee weapon.", strain=1)
T(I, "Terrified Retreat", 1, R(I, 5), "When you critically succeed at Demoralize against a lower-level target, it flees for 1 round.", traits="skill")
T(I, "Scared to Death", 1, R(I, 10), "Intimidation vs the Charisma save of a living creature within 30 ft that can perceive you (2 Disadvantage if it can't hear or understand you). It is then immune for 1 minute.\n"
  "Critical success: it makes a Fortitude save vs your check; failure: it dies; success: Frightened 3 and Fleeing for 1 round; critical success: unaffected. Success: Frightened 2. Failure: no effect.",
  cost="2", traits="death, emotion, fear, incapacitation, skill", roll={"type": "check", "skill": "intimidation"})

# ---------------------------------------------------------------- GRAPPLER
G = "Grappler"
MA = "Martial Arts"
T(G, "Grappler", 1, R(MA, 1), "1 Advantage on Martial Arts checks to initiate a grapple.", traits="combat")
T(G, "Disarming Lock", 2, f"Grappler; {R(MA, 2)}", "1 Advantage on Disarm checks against a creature you are Grabbing.", traits="combat")
T(G, "Sleeper Hold", 3, f"Grappler, Disarming Lock; {R(MA, 5)}", "Against a creature you have Restrained, spend 1 Strain and make a Martial Arts check vs its Fortitude save. Critical success: Incapacitated for 5 minutes. "
  "Success: Stunned 1d4+1 rounds. Failure: no effect. Critical failure: it breaks free to merely Grabbed.", cost="2", traits="attack, maneuver", strain=1)
T(G, "Judo Throw", 2, f"Grappler; {R(MA, 2)}", "Spend 1 Strain (1 RP): move the target 5 ft away and knock it Prone. It is no longer Grappled.", cost="reaction", traits="attack, maneuver",
  trigger="You successfully Grapple a creature with a Martial Arts check.", strain=1)
T(G, "Defensive Flip", 3, f"Grappler, Judo Throw; {R(MA, 5)}", "Spend 1 Strain and make a Martial Arts check vs its Reflex save (2 RP). Success: grab it and immediately Judo Throw it. Push: 1 more Strain for 1 RP.",
  cost="reaction", traits="attack, reaction, maneuver", trigger="A creature in your reach uses a CONCENTRATE or MANIPULATE action.", strain=1)
T(G, "Body Slam", 3, f"Grappler, Judo Throw; {R(MA, 5)}", "When Judo Throw knocks a creature Prone, also deal your unarmed strike damage.", traits="combat")
T(G, "Tight Clinch", 2, f"Grappler; {R(MA, 2)}", "1 Advantage on opposed checks when a creature tries to break your grapple.", traits="combat")
T(G, "Titan Wrestler", 2, f"Grappler; {R(MA, 2)}", "Disarm, Grapple, Shove or Trip creatures up to two sizes larger (three at 9+ ranks).", traits="combat")

# ---------------------------------------------------------------- KUNG FU
F = "Kung Fu"
PF = "Powerful Fist"
ST = "Enter only while unarmored or in armor with a minimum Might of 0."
T(F, PF, 1, R(MA, 1), "Your unarmed strike damage die increases one size, and you may ignore the Subdual trait on unarmed strikes.")
T(F, "Flurry of Blows", 2, f"{PF}; {R(MA, 2)}", "Once per round, make two unarmed strikes. Combine hits on the same creature before Soak and resistances.", cost="2", traits="attack, taxing, maneuver", push=True)
T(F, "Flurry of Blows II", 3, f"{PF}, Flurry of Blows; {R(MA, 5)}", "As Flurry of Blows, but three strikes.", cost="2", traits="attack, taxing, maneuver", push=True)
T(F, "Flurry of Blows III", 4, f"{PF}, Flurry of Blows I & II; {R(MA, 10)}", "As Flurry of Blows, but four strikes.", cost="2", traits="attack, taxing, maneuver", push=True)
T(F, "Crane Style", 2, f"{PF}; {R(MA, 2)}", f"{ST} Unarmed strikes gain Backstabber, you get 1 Advantage on saves vs physical attacks, and your jump distance increases by +5 ft horizontal and +2 ft vertical.", cost="stance", traits="stance")
T(F, "Crane Flutter", 3, f"{PF}, Crane Style; {R(MA, 5)}", "In Crane Style (1 RP): +1 Advantage on your save. If the attack misses, make an unarmed strike against the attacker at 1 Disadvantage, even beyond your reach.",
  cost="reaction", traits="reaction", trigger="You're targeted by a melee attack you can see.")
T(F, "Dragon Style", 2, f"{PF}; {R(MA, 2)}", f"{ST} Unarmed strikes deal sonic damage and gain Backswing. Each round ignore 5 × half your Martial Arts ranks (rounded up) feet of difficult terrain.", cost="stance", traits="stance")
T(F, "Dragon Roar", 3, f"{PF}, Dragon Style; {R(MA, 5)}; {R('Intimidation', 1)}", "In Dragon Style, each enemy within 15 ft makes an Intellect save vs your Intimidation: failure Frightened 1, critical failure Frightened 2. Recharges after 1d4 rounds. The effects end if you leave the stance; affected creatures are immune for 1 minute.",
  cost="2", traits="auditory, emotion, fear, mental, maneuver", push=True, roll={"type": "check", "skill": "intimidation"})
T(F, "Mountain Style", 2, f"{PF}; {R(MA, 2)}", f"{ST} Must be touching the ground. Unarmed strikes deal force damage and gain Deadly. You gain +4 status Soak and 1 Advantage on Might saves vs Shove and Trip, but −5 ft Speed and 2 Disadvantage on Dodge.",
  cost="stance", traits="stance")
T(F, "Mountain Stronghold", 3, f"{PF}, Mountain Style; {R(MA, 5)}", "In Mountain Style, +2 circumstance Soak until your next turn (+1 per 3 Martial Arts ranks beyond 5).", cost="2", traits="maneuver", push=True)
T(F, "Tiger Style", 2, f"{PF}; {R(MA, 2)}", f"{ST} Unarmed strikes gain Sweeping, deal slashing damage and add 1d4 persistent bleed. Each extra hit on the same target in a round raises the bleed die one size (max d12). +5 ft Speed.",
  cost="stance", traits="stance")
T(F, "Tiger Slash", 3, f"{PF}, Tiger Style; {R(MA, 5)}", "In Tiger Style, make an unarmed strike. On a hit it deals +2 weapon dice (+3 at 9+ ranks) and pushes the target 5 ft. On a critical hit, add Might or Reflex to the bleed.",
  cost="2", traits="combat, attack, maneuver", push=True)
T(F, "Void Style", 2, f"{PF}; {R(MA, 2)}", f"{ST} Unarmed strikes gain Ghost Touch and deal psionic damage (both physical and energy, so the target applies half Soak). You fall slowly and resist falling damage.", cost="stance", traits="stance")
T(F, "Soul Strike", 3, f"{PF}, Void Style; {R(MA, 5)}", "In Void Style, make an unarmed strike with Reach. On a hit the target makes a Charisma save vs DC 10 + half the damage taken (round up): failure Dazed until the end of your next turn, critical failure Stunned.",
  cost="2", traits="attack, maneuver", push=True)
T(F, "Wolf Style", 2, f"{PF}; {R(MA, 2)}", f"{ST} Unarmed strikes deal piercing damage and gain Backstabber, and your movement doesn't provoke Reaction Attacks.", cost="stance", traits="stance")
T(F, "Wolf Drag", 3, f"{PF}, Wolf Style; {R(MA, 5)}", "In Wolf Style, make an unarmed strike with Deadly. On a hit the target makes a Reflex save vs DC 10 + half the damage taken; failure: it falls Prone and is Grappled by you.",
  cost="2", traits="attack, maneuver", push=True)
T(F, "Deflect Arrow", 2, f"{PF}; {R(MA, 2)}", "Reduce the damage by 1d4 + your Martial Arts bonus (2 RP). If it drops to 0 and you have a free hand, you catch the missile.", cost="reaction", traits="combat, reaction, maneuver",
  trigger="You'd be hit by a thrown or missile weapon.", push=True)
T(F, "Deflect Arrow II", 3, f"{PF}, Deflect Arrow; {R(MA, 5)}", "As Deflect Arrow but reduce by 1d6 + bonus. If you catch it, spend 1 Strain to throw it back (10-ft increment, unarmed die damage).", cost="reaction", traits="combat, reaction, maneuver",
  trigger="You'd be hit by a thrown or missile weapon.", push=True)
T(F, "Deflect Bullets", 4, f"{PF}, Deflect Arrow I & II; {R(MA, 9)}", "As Deflect Arrow II but reduce by 1d8 + bonus, and it also works against firearms.", cost="reaction", traits="combat, reaction, maneuver",
  trigger="You'd be hit by a thrown, missile or firearm attack.", push=True)
T(F, "Fist of Iron", 2, f"{PF}; {R(MA, 5)}", "Your unarmed strikes lose the Unarmed trait and count as melee weapons for any action that requires one.")

# ---------------------------------------------------------------- MASTER THROWER
W = "Master Thrower"
WR = "ranks in Athletics or Sleight of Hand"
T(W, "Weak Spot", 1, f"1+ {WR}", "Choose Athletics or Sleight of Hand as your Throwing Style. Thrown-weapon attacks may use your style's scaling damage (see the chapter table) instead of the weapon's damage.")
T(W, "Doubletoss", 2, f"Weak Spot; 2+ {WR}", "Once per round, make two thrown attacks against one target within 40 ft. Combine hits before Soak.", cost="2", traits="attack, taxing, maneuver", push=True)
T(W, "Trippletoss", 3, f"Weak Spot, Doubletoss; 5+ {WR}", "As Doubletoss, but three attacks within 30 ft.", cost="2", traits="attack, taxing, maneuver", push=True)
T(W, "Cluster Throw", 4, f"Weak Spot, Doubletoss, Trippletoss; 9+ {WR}", "As Doubletoss, but four attacks within 20 ft.", cost="2", traits="attack, taxing, maneuver", push=True)
T(W, "Sneaky Throw", 2, f"Weak Spot; 2+ {WR}", "Throwing Style check vs the target's Perception save. Success: 1 Advantage on your next thrown attack against it before the end of your next turn (2 on a critical success; +1 per 3 ranks beyond 2).",
  cost="2", traits="attack, maneuver", push=True)
T(W, "Deadeye Shot", 3, f"Weak Spot, Sneaky Throw; 5+ {WR}", "Thrown-weapon attacks gain Deadly against targets within 20 ft.")

# ---------------------------------------------------------------- MEDICINE
N = "Medicine"
T(N, "Battle Medicine", 1, R(N, 2), "Treat Wounds on yourself or an adjacent ally mid-fight. That creature is then immune to your Battle Medicine for 1 day.", cost="2", traits="healing, manipulate, skill, maneuver", push=True,
  roll={"type": "check", "skill": "medicine"})
T(N, "Metabolic Expert", 1, f"{R(N, 2)}; Intellect 2+", "Use Intellect to determine your maximum Strain.")
T(N, "Robust Recovery", 1, R(N, 2), "When you Treat Poison or Treat Disease, the target gains +1 Advantage on its next save against it.", traits="skill, healing")
T(N, "Ward Medic", 1, R(N, 2), "Treat Disease or Treat Wounds on extra targets equal to half your Medicine ranks.", traits="skill, healing")

# ---------------------------------------------------------------- MELEE WEAPONS
X = "Melee Weapons"; XT = "Melee Weapon"
T(XT, "Double Strike", 1, R(X, 2), "Make two melee strikes against the same target (each vs its Might save). Combine the damage from the hits before Soak and resistances.", cost="2", traits="attack, combat, taxing, maneuver", push=True)
T(XT, "Triple Strike", 2, f"Double Strike; {R(X, 5)}", "As Double Strike, but three strikes.", cost="2", traits="attack, combat, taxing, maneuver", push=True)
T(XT, "Multi-Strike", 3, f"Double Strike, Triple Strike; {R(X, 10)}", "As Double Strike, but four strikes.", cost="2", traits="attack, combat, taxing, maneuver", push=True)
T(XT, "Defensive Posture", 1, R(X, 2), "Until your next turn, 1 Advantage on Might saves when Parrying physical attacks (+1 per 4 Melee Weapons ranks).", cost="2", traits="combat, maneuver", push=True)
T(XT, "Reaction Attack", 1, R(X, 3), "Make one melee weapon attack against that creature (2 RP).", cost="reaction", traits="combat, reaction, maneuver",
  trigger="A creature in your reach uses a CONCENTRATE or MANIPULATE action.", push=True)

# ---------------------------------------------------------------- MYSTICISM
Y = "Mysticism"
T(Y, "Spell Attunement I", 1, R(Y, 1), "Choose a school. You can learn one spell (or cantrip) of Complexity 1 or less from it. Retaking it lets you add a school, a spell, or the same spell with new trappings.", traits="magic", repeat=True)
T(Y, "Spell Attunement II", 2, f"Spell Attunement I (same school); {R(Y, 2)}", "Learn one spell of Complexity 3 or less from a school you have Attunement I in (Mysticism ranks ≥ Complexity).", traits="magic", repeat=True)
T(Y, "Spell Attunement III", 3, f"Spell Attunement I & II (same school); {R(Y, 4)}", "Learn one spell of Complexity 5 or less from a school you have Attunement II in (ranks ≥ Complexity).", traits="magic", repeat=True)
T(Y, "Spell Attunement IV", 4, f"Spell Attunement I–III (same school); {R(Y, 6)}", "Learn one spell of Complexity 6+ from a school you have Attunement III in (ranks ≥ Complexity).", traits="magic", repeat=True)
T(Y, "School Mastery", 4, f"Spell Attunement I–III (same school); {R(Y, 5)}", "Unlock ★ Mastery modifiers for spells of one school where you have Attunement III.", traits="magic", repeat=True)
T(Y, "Flexible Caster", 5, f"Spell Attunement I–III and School Mastery (same school); {R(Y, 6)}", "For one mastered school, when checking a spell's modified Complexity against your limit, use Mysticism ranks + Intellect or Charisma (chosen when taken). "
  "This doesn't count as ranks for prerequisites or restricted modifiers.", traits="magic", repeat=True)
T(Y, "Metamagic Training", 1, R(Y, 2), "Learn one metamagic modifier (minimum ranks per the metamagic list) and apply it to any spell you cast.", traits="magic", repeat=True)
T(Y, "Quick Cast", 1, R(Y, 3), "Cast a spell for 1 AP instead of 2 by paying +1 Strain; the action gains Taxing.", traits="magic")
T(Y, "Paradox Engine", 1, R(Y, 11), "When casting, you may exceed your Mysticism-rank modifier limit by up to 2 for +2 total Strain.", traits="magic")
T(Y, "Wardsight", 1, f"{R(Y, 2)}; {R('Thievery', 2)}", "Use Mysticism instead of Investigation to Search for magical traps and hazards (it reveals only their auras and locations), and instead of Thievery to disable ones with an accessible magical component.", traits="magic")
T(Y, "Combat Magic", 1, R(Y, 2), "You may use your Intellect or Charisma save instead of Might or Reflex against attacks, with trappings that fit your magic.", traits="magic, ward")

# ---------------------------------------------------------------- NATURE
V = "Nature"
T(V, "Natural Medicine", 1, R(V, 1), "Use Nature instead of Medicine to Treat Wounds. In the wilderness with fresh ingredients you may gain 1 Advantage (GM's call).", traits="skill, healing")
T(V, "Train Animal", 1, R(V, 1), "Over downtime (usually a week or more; GM sets the DC), reinforce a known basic action so it can be commanded without a check, or teach a new basic action.", traits="downtime, manipulate, skill")
T(V, "Bond Animal", 1, R(V, 2), "Spend 7 days of downtime and make a DC 20 Nature check to bond an ordinary animal; it becomes permanently Helpful. Limit 1 bond (+1 at 6 and 12 ranks).", traits="downtime, skill",
  roll={"type": "check", "skill": "nature", "dc": "20"})

# ---------------------------------------------------------------- PERFORM
O = "Perform"
T(O, "Fascinating Performance", 1, R(O, 1), "One creature that can perceive you makes a Charisma save vs your Perform check or is Fascinated for 1 round. In immediate danger it rolls twice, keeps the better, and this gains Incapacitation. "
  "Sustain for 2 AP (pushable). The target is then immune for 1 hour. More ranks add more targets.", cost="2", traits="skill, maneuver, mental, perform", push=True, roll={"type": "check", "skill": "perform"})
T(O, "Impressive Performance", 1, R(O, 1), "Make an Impression with Perform instead of Diplomacy.", traits="skill, mental, perform")
T(O, "Virtuosic Performer", 1, R(O, 1), "Choose a performance specialty: 1 Advantage on Perform checks of that type (2 at 5+ ranks).", traits="skill, mental, perform")
T(O, "Legendary Performer", 2, f"Virtuosic Performer; {R(O, 9)}", "NPCs who succeed at a DC 10 Society check have heard of you, and their attitude usually starts one step better (or more fearful, depending on your reputation).", traits="skill")
T(O, "Force of Personality", 1, f"{R(O, 2)}; Charisma 2+", "Use Charisma to determine your maximum Strain.")

# ---------------------------------------------------------------- RANGED COMBAT
Z = "Ranged Combat"
RR = "ranks in Firearms or Missile Weapons"
T(Z, "Hawkeye", 1, f"1+ {RR}", "Reduce the Disadvantage for shooting beyond your first range increment by 1.", traits="combat, ranged")
T(Z, "Disarming Shot", 2, f"Hawkeye; 2+ {RR}", "Ranged attack vs the Reflex save of a creature within 30 ft. On a success it drops one held item of your choice.", cost="2", traits="attack, combat, ranged, maneuver")
T(Z, "Extreme Range", 2, f"Hawkeye; 2+ {RR}", "You can shoot out to 7 range increments instead of 6.", traits="combat, ranged")
T(Z, "Thousand Meter Stare", 3, f"Hawkeye, Extreme Range; 5+ {RR}", "Double the range increment of your firearms and missile weapons.", traits="combat, ranged")
T(Z, "Instinctive Shooting", 1, f"1+ {RR}", "Ranged attacks made while threatened in melee don't provoke Reaction Attacks if the target is within 30 ft.", traits="combat, ranged")
T(Z, "Reactive Shooting", 2, f"Instinctive Shooting; 2+ {RR}", "While wielding a firearm or missile weapon, make a ranged attack against that creature (2 RP).", cost="reaction", traits="attack, combat, ranged, maneuver",
  trigger="A creature within 30 ft critically fails an attack roll or uses a MANIPULATE or CONCENTRATE action.", push=True)
T(Z, "Ricochet Shot", 2, f"Instinctive Shooting; 2+ {RR}", "Make a ranged attack. If a flat surface or solid object is adjacent to a target within 15 ft and you have line of effect to both, the target gets no cover.", cost="2", traits="attack, combat, ranged, maneuver", push=True)
T(Z, "Quick Draw", 1, f"1+ {RR}", "At the start of combat you may draw one or more firearms or missile weapons; if you do, +2 to Initiative.", traits="combat")
T(Z, "Rapid Reload", 2, f"Quick Draw; 2+ {RR}; {R('Sleight of Hand', 1)}", "Reloading a firearm or missile weapon costs 1 AP less.", traits="combat")
T(Z, "Dramatic Reload", 3, f"Quick Draw; 5+ {RR}; {R('Sleight of Hand', 2)}", "When you reload, make a Sleight of Hand check vs the Perception save of a creature within 50 ft. Success: 1 Advantage on your next attack with that firearm against it (2 on a critical success).", traits="combat")
T(Z, "Butt-Stroke", 2, f"Quick Draw; 2+ {RR}; 1+ ranks in Martial Arts or Melee Weapons", "Attack with your firearm or missile weapon as a club of its size (1 RP).", cost="reaction", traits="attack, combat, reaction, melee",
  trigger="A creature in melee reach uses a CONCENTRATE or MANIPULATE action.")
T(Z, "Sharpshooter", 1, f"1+ {RR}", "+1 more Advantage when using Aimed Shot with a firearm or missile weapon.", traits="combat")
T(Z, "Precise Shot", 2, f"Sharpshooter; 2+ {RR}", "With Aimed Shot, a natural 19–20 is a critical hit.", traits="attack, combat, ranged")
T(Z, "Precise Shot II", 3, f"Sharpshooter, Precise Shot; 5+ {RR}", "With Aimed Shot against a target in your first range increment, it gets no benefit from cover or concealment.", traits="attack, combat, ranged")
T(Z, "Deadly Sniper", 4, f"Sharpshooter, Precise Shot I & II; 9+ {RR}", "With Aimed Shot against a target in your first increment, beating its Defense by 10 (not 15) is a critical hit.", traits="attack, combat, ranged")
T(Z, "Steady Hand", 1, f"1+ {RR}", "Take 1 Strain (1 RP) to reduce the Disadvantage by 1. Per 6 ranks you may take +1 Strain to reduce it by 1 more (maximum 3).", cost="reaction", traits="attack, combat, reaction, ranged",
  trigger="You make a firearm or missile attack with at least 1 Disadvantage.", strain=1)
T(Z, "Kentucky Windage", 2, f"Steady Hand; 2+ {RR}", "After a miss, +1 Advantage on your next attack with the same weapon against the same target, if it's your next action this turn.", traits="attack, combat, ranged")
T(Z, "Cascading Accuracy", 3, f"Steady Hand, Kentucky Windage; 5+ {RR}", "After a hit, +1 Advantage on your next attack against the same target this turn, if it's your next action.", traits="attack, combat, ranged")
T(Z, "Double Shot", 2, f"Steady Hand; 2+ {RR}", "Once per round, make two quick attacks with a weapon of Reload 1 or less. Combine hits on the same target before Soak.", cost="2", traits="attack, combat, ranged, taxing, maneuver", push=True)
T(Z, "Triple Shot", 3, f"Steady Hand, Double Shot; 5+ {RR}", "As Double Shot, but three attacks.", cost="2", traits="attack, combat, ranged, taxing, maneuver", push=True)
T(Z, "Manyshot", 4, f"Steady Hand, Double Shot, Triple Shot; 10+ {RR}", "As Double Shot, but four attacks.", cost="2", traits="attack, combat, ranged, taxing, maneuver", push=True)
T(Z, "Trick Ammunition", 1, f"1+ {RR}; {R('Crafting', 1)}", "Craft custom ammunition dealing bludgeoning or slashing damage; it raises the weapon's damage die 1 step. You still need the relevant crafting talent (Firearm Crafting for bullets).", traits="skill, craft")
T(Z, "Trick Ammunition II", 2, f"Trick Ammunition; 1+ ranks in Mysticism or Alchemical Crafting; {R('Crafting', 5)}; 5+ {RR}", "Custom ammunition can deal acid, cold, electricity, fire or sonic damage and raises the die 2 steps.", traits="skill, craft")
T(Z, "Trick Ammunition III", 3, f"Trick Ammunition I & II; 1+ ranks in Mysticism or Alchemical Crafting; {R('Crafting', 10)}; 10+ {RR}", "Custom ammunition gains Burst (5 ft), damaging all creatures within 5 ft of impact, and raises the die 3 steps.", traits="skill, craft")

# ---------------------------------------------------------------- SCOUNDREL
Q = "Scoundrel"
QR = "Scoundrel's Grit; 3+ ranks in Sleight of Hand or Deception"
GD = "Grit Die"
T(Q, "Scoundrel's Grit", 1, "2+ ranks in Sleight of Hand or Deception", f"Gain a {GD} (starts at 1d6, grows with ranks). Choose Sleight of Hand or Deception as your Scheme Style (permanent). Spend 1 Strain to add the {GD} to a check with that skill.",
  traits="mental, auditory, linguistic")
T(Q, "Ambush", 2, "3+ ranks in Sleight of Hand or Deception", f"Spend 1 Strain to add your {GD} to a Stealth check or Initiative roll.", traits="skill", strain=1)
T(Q, "Blinding Strike", 2, QR, f"Weapon attack at 2 Disadvantage; on a hit add your {GD} to damage. The target makes a Fortitude save vs DC 10 + half damage taken: failure Blinded until the end of your next turn; critical failure it loses an eye.",
  cost="2", traits="attack, maneuver", push=True)
T(Q, "Crippling Attack", 2, QR, f"Add your {GD} to damage (2 RP). Fortitude save vs DC 10 + half damage taken; failure: Speed halved and 1 Disadvantage on Reflex saves per 3 Scheme ranks until the end of your next turn.",
  cost="reaction", traits="maneuver, reaction", trigger="You hit a creature with a weapon attack.", push=True)
T(Q, "Disabling Strike", 2, QR, f"Roll your {GD} (2 RP) and subtract it from the target's next attack roll before the end of its next turn.", cost="reaction", traits="maneuver, reaction", trigger="You hit a creature with a weapon attack.", push=True)
T(Q, "Distracting Attack", 2, QR, f"Add your {GD} to damage (2 RP). The next attack by someone else against the target before your next turn gains 1 Advantage per 3 Scheme ranks.", cost="reaction", traits="maneuver, reaction",
  trigger="You hit a creature with a weapon attack.", push=True)
T(Q, "Down But Not Out", 2, QR, f"While Prone (2 RP), either subtract your {GD} from its attacks against you until the end of your next turn, or trip it (no more than 1 size larger): Might save vs your Scheme check; failure Prone with 0 movement for the turn and {GD} bludgeoning damage.",
  cost="reaction", traits="maneuver, reaction", trigger="A creature attacks you in melee while you're Prone.")
T(Q, "Feinting Attack", 2, QR, f"Weapon attack against a creature within 5 ft with 1 Advantage per 3 Scheme ranks; on a hit add your {GD} to damage.", cost="2", traits="attack, maneuver", push=True)
T(Q, "Knockout Strike", 2, QR, f"Add your {GD} to damage (2 RP). Fortitude save vs DC 10 + half damage taken; failure Stunned until the start of your next turn, critical failure unconscious for 1 minute.",
  cost="reaction", traits="maneuver, reaction", trigger="You hit a creature no more than 1 size larger with a weapon attack.", push=True)
T(Q, "Preemptive Strike", 2, QR, f"Melee attack at 2 Disadvantage (2 RP). On a hit, roll your {GD}: the creature takes Disadvantage equal to half the result (round up) on its next attack against you.", cost="reaction", traits="maneuver, reaction",
  trigger="A creature in your reach makes a melee attack against you.", push=True)
T(Q, "Showboating Attack", 2, QR, f"Each creature (no more than 1 size larger) in a 15-ft cube in front of you makes a Charisma save vs your Scheme check: failure Frightened 1 of you, critical failure Frightened 2, until the end of your next turn. "
  f"Your first hit on a creature frightened of you adds your {GD}.", cost="2", traits="attack, maneuver", push=True)
T(Q, "Trip Attack", 2, QR, f"Add your {GD} to damage (2 RP). A target no more than 1 size larger makes a Might save vs DC 10 + half damage taken or falls Prone.", cost="reaction", traits="maneuver, reaction",
  trigger="You hit a creature with a weapon attack.", push=True)

# ---------------------------------------------------------------- SHIELD
SH = "Shields"
T("Shield", "Improved Bash", 1, R(SH, 1), "Your Shield Bash damage die increases one size.", traits="skill")
T("Shield", "Shield Expert", 1, R(SH, 2), "Once per turn you can Raise Shield for 0 AP.", traits="skill")
T("Shield", "Phalanx", 1, R(SH, 2), "When you Raise Shield next to an ally with a raised shield, your shield bonus increases by 2.", traits="skill")
T("Shield", "Improved Block", 1, R(SH, 5), "Your equipped shield's Hardness increases by half your Shields ranks.", traits="skill")
T("Shield", "Shield Guardian", 1, R(SH, 5), "When you Raise Shield, one adjacent ally also gains your shield bonus to saves.", traits="skill")
T("Shield", "Vanguard", 1, R(SH, 9), "Your equipped shield gains Fortified.", traits="skill")

# ---------------------------------------------------------------- SLEIGHT OF HAND
SL = "Sleight of Hand"
T(SL, "Pickpocket", 1, R(SL, 1), "Steal or Palm closely guarded objects (such as from pockets) without Disadvantage. 5+ ranks: steal from someone in combat or on guard, at 2 MANIPULATE actions and 2 Disadvantage.", traits="skill")
T(SL, "Legendary Thief", 2, f"Pickpocket; {R(SL, 9)}", "Steal wielded or very noticeable items (worn boots, armor) with at least a minute of hidden work and 2 Disadvantage. Prominent items are soon missed.", traits="skill")
T(SL, "Subtle Theft", 1, R(SL, 1), "Observers get 1 Disadvantage to notice your thefts. After a Diversion, one Palm or Steal doesn't end Undetected.", traits="skill")

# ---------------------------------------------------------------- SOCIETY
SO = "Society"
T(SO, "Courtly Graces", 1, R(SO, 1), "Use Society to Make an Impression on nobles, and to pass yourself off as a generic noble. Impersonating a specific noble still uses Deception.", traits="skill")
T(SO, "Connections", 2, f"Courtly Graces; {R(SO, 2)}", "Where you have contacts, use Society to arrange a meeting with an important figure or ask a favor (owing one later). The GM sets the DC.", traits="skill")
T(SO, "Multilingual", 1, R(SO, 1), "Learn two languages, plus one more at 5+ ranks and another at 9+ ranks.", traits="skill", repeat=True)
T(SO, "Legendary Linguist", 2, f"Multilingual; {R(SO, 9)}", "Improvise a pidgin to communicate basic ideas with any creature that has a language, once you've identified how it communicates.", traits="skill")
T(SO, "Read Lips", 1, R(SO, 1), "Read the lips of creatures you can see speaking a language you know. In tense situations you are Fascinated and Off-Guard while focusing and must pass a Society check.", traits="skill")
T(SO, "Sign Language", 1, R(SO, 1), "Know the sign languages for the languages you know (usually two-handed, and hard to use in combat or low visibility).", traits="skill")
T(SO, "Streetwise", 1, R(SO, 1), "In a settlement you know well, Gather Information with Society instantly (at a higher DC). If you fail, you can still gather normally.", traits="skill")
T(SO, "Legendary Codebreaker", 1, R(SO, 9), "Decipher Writing with Society at reading speed. With the normal time, a success counts as a critical success and a critical success gives near word-for-word understanding.", traits="skill")

# ---------------------------------------------------------------- STEALTH (detailed entries only)
SE = "Stealth"
T(SE, "Experienced Smuggler", 1, R(SE, 1), "When the GM checks whether passive observers notice a small concealed item on you, treat your d20 as at least 10 (15 at 5+ ranks; automatic success at 10+). No help against active searches.", traits="skill")
T(SE, "Terrain Stalker", 1, R(SE, 1), "Choose rubble, snow or underbrush. While Undetected in it, Sneak up to 5 ft without a check if you stay more than 10 ft from enemies, and approach to 15 ft while Avoiding Notice.", traits="skill", repeat=True)
T(SE, "Quiet Allies", 1, R(SE, 2), "When you Avoid Notice and allies Follow the Expert, the group rolls one Stealth check with the lowest modifier.", traits="skill")
T(SE, "Foil Senses", 1, R(SE, 5), "You are always considered to be taking precautions against special senses when you Avoid Notice, Hide or Sneak.", traits="skill")
T(SE, "Swift Sneak", 1, R(SE, 5), "Sneak at full Speed, including while burrowing, climbing, flying or swimming.", traits="skill")
T(SE, "Legendary Sneak", 2, f"Swift Sneak; {R(SE, 9)}", "Hide and Sneak without cover or concealment. During exploration you get the benefits of Avoiding Notice while using other tactics.", traits="skill")

# ---------------------------------------------------------------- SURVIVAL
SV = "Survival"
T(SV, "Experienced Tracker", 1, R(SV, 1), "Track at full Speed with 2 Disadvantage (1 at 5+ ranks; none at 9+, and no hourly rechecks unless the trail changes).", traits="skill")
T(SV, "Forager", 1, R(SV, 1), "When foraging, anything below a success becomes a success, a success becomes a critical success, and a critical success doubles the Supply and shelter capacity. "
  "On a success or better, add half your ranks to Supply found and your ranks to shelter capacity (after doubling).", traits="skill")
T(SV, "Survey Wildlife", 1, R(SV, 1), "Spend 10 minutes and make a Survival check to learn what creatures are nearby. Follow-up Lore checks from the signs have 1 Disadvantage (none at 5+ ranks).", traits="skill")
T(SV, "Terrain Expertise", 1, R(SV, 1), "Choose aquatic, arctic, desert, forest, mountain, plains, sky, swamp or underground: 1 Advantage on Survival checks there.", traits="skill", repeat=True)
T(SV, "Planar Survival", 1, R(SV, 5), "Forage on other planes, even without natural resources. A successful Forage may also reduce planar damage (GM's call).", traits="skill")
T(SV, "Legendary Survivalist", 1, R(SV, 11), "Survive indefinitely without food or water and endure extreme heat and cold without damage.", traits="skill")
T(SV, "Always Prepared", 1, R(SV, 5), "Increase your maximum SUP by half your Survival ranks.", traits="skill",)

# ---------------------------------------------------------------- SWASHBUCKLER
SW = "Swashbuckler"
SWR = "3+ ranks in Acrobatics or Perform"
PD = "Panache Die"
T(SW, "Swashbuckler's Panache", 1, "2+ ranks in Acrobatics or Perform", f"Gain a {PD} (starts at 1d6, grows with ranks). Choose Acrobatics or Perform as your style. Spend 1 Strain to add the {PD} to checks with that skill.", traits="skill")
T(SW, "Acrobatic Attack", 2, SWR, f"Move at least 5 ft, then make a DC 15 Acrobatics check against a creature within 5 ft. Success: melee attack with 1 Advantage (2 on a critical success; +1 per 3 ranks beyond 3), adding your {PD} to damage on a hit.",
  cost="2", traits="attack, move, maneuver", push=True, roll={"type": "check", "skill": "acrobatics", "dc": "15"})
T(SW, "Acrobatic Defense", 2, SWR, f"Roll your {PD} and make a DC 15 Acrobatics check (2 RP); add the die to the damage or the check. Success: 1 Disadvantage on the target's next attack against you before the end of your next turn (2 on a critical success; +1 per 3 ranks beyond 3).",
  cost="reaction", traits="move, maneuver, reaction", trigger="You hit a creature with a melee weapon attack.", push=True)
T(SW, "Combination Attack", 2, SWR, f"Roll your {PD} and make one more melee attack against the same target (2 RP), adding the die to damage on a hit.", cost="reaction", traits="attack, maneuver, reaction",
  trigger="You hit with a melee attack.", push=True)
T(SW, "Defensive Feint", 2, SWR, f"Roll your {PD} against a creature within 5 ft: subtract it from that creature's next attack against you before the end of your next turn.", cost="2", traits="maneuver", push=True)
T(SW, "Disarming Attack", 2, SWR, f"Add your {PD} to damage (2 RP). The target makes a Might save vs DC 10 + half damage taken or drops an item of your choice at its feet.", cost="reaction", traits="attack, maneuver, reaction",
  trigger="You hit a creature with a weapon attack.", push=True)
T(SW, "Evasive Footwork", 2, SWR, f"Roll your {PD} (2 RP) and add it to your Reflex saves until the start of your next turn.", cost="reaction", traits="move, maneuver, reaction", trigger="You move at least 10 ft on your turn.", push=True)
T(SW, "Lunging Attack", 2, SWR, f"Melee weapon attack with +5 ft reach; add your {PD} to damage on a hit.", cost="2", traits="attack, maneuver", push=True)
T(SW, "Maneuvering Attack", 2, SWR, f"Add your {PD} to damage (2 RP). An ally who can perceive you may spend 1 RP to move up to half Speed without provoking from the target.", cost="reaction", traits="move, maneuver, reaction",
  trigger="You hit a creature with a weapon attack.", push=True)
T(SW, "Parry (Panache)", 2, SWR, f"Reduce the damage by your {PD} + Reflex (2 RP).", cost="reaction", traits="attack, maneuver, reaction", trigger="A creature damages you with a melee attack.", push=True)
T(SW, "Precision Attack", 2, SWR, f"Make a weapon attack, adding your {PD} to the attack roll.", cost="2", traits="attack, maneuver", push=True)
T(SW, "Riposte", 2, SWR, f"Roll your {PD} and make a melee weapon attack against that creature (2 RP), adding the die to damage on a hit.", cost="reaction", traits="attack, maneuver, reaction",
  trigger="A creature misses you with a melee attack.", push=True)
T(SW, "Whirlwind Defense", 2, SWR, f"Make one weapon attack roll and roll your {PD}. Each creature within 5 ft makes a Reflex save against the attack roll; failure: it subtracts the die from its next attack against you before the end of your next turn.",
  cost="2", traits="maneuver", push=True)

# ---------------------------------------------------------------- THIEVERY
TH = "Thievery"
T(TH, "Arcane Bypass", 1, f"{R(TH, 5)}; {R('Investigation', 2)}", "Search for magical traps as if mundane (you learn presence and location, not properties). Disable those with an accessible magical component using Thievery, against the Dispel DC if no Thievery entry exists.", traits="skill")
T(TH, "Wary Disarmament", 1, R(TH, 2), "1 Advantage on saves against a trap or device you trigger while disarming it (only effects from that failed attempt).", traits="skill")
T(TH, "Quick Unlock", 1, R(TH, 5), "Pick a Lock for 1 AP instead of 2.", traits="skill")

# ---------------------------------------------------------------- TRAINING
TR = "Training"
for ab in ("Might", "Reflex", "Fortitude", "Intellect", "Perception", "Charisma"):
    T(TR, f"{ab} Training", 1, "Level 4", f"Permanent +1 competence bonus to your {ab} score. Each additional time, the minimum level rises by 4.", repeat=True)
T(TR, "Skill Focus", 1, "1+ ranks in the chosen skill", "Permanent +2 competence bonus to one skill with at least 1 rank. Choose a different skill each time.", traits="skill", repeat=True)
T(TR, "Skill Training", 1, "Intellect 1+", "Gain 2 additional skill points. You can take it up to your Intellect score times.", traits="skill", repeat=True)

# Active-effect changes for passive numeric talents
EFFECTS = {
    "Alertness": [("system.initiative.bonus", 2, 2)],
    "Quick Draw": [("system.initiative.bonus", 2, 2)],
    "Hefty Hauler": [("system.bulkBonus", 2, 2)],
    **{f"{ab} Training": [(f"system.abilities.{ab.lower()}.granted", 2, 1)] for ab in ("Might", "Reflex", "Fortitude", "Intellect", "Perception", "Charisma")},
}


def entries():
    out = []
    for t in TALENTS:
        eff = EFFECTS.get(t["name"])
        if eff:
            t["effects"] = [{"name": t["name"], "img": t["img"], "transfer": True, "disabled": False,
                             "changes": [{"key": k, "mode": m, "value": str(v)} for k, m, v in eff]}]
        out.append(t)
    return out
