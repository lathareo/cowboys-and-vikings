"""Spells part 2 (Magic chapter): Evocation, Illusion, Necromancy, Transmutation, plus metamagic."""
from spells_a import sp, M, SPELLS, TOUCH, REMOTE, IMBUE, SINGLE

# ------------------------------------------------------------------ EVOCATION
sp("Arc Flash", "evocation", 0, 0, "Each target makes a Reflex save; failure: Dazed until the end of its next turn.", cantrip=True, dur="1 round", save="reflex",
   traits="burst, control, disrupt", aoe2=True, crit="One target that failed is also Blinded until the end of its next turn.",
   critfail="Also Slowed 10 until the end of its next turn.")
sp("Light", "evocation", 0, 0, "A mote of cool magical light sheds dim light in 10 ft and moves with the chosen point or object. Not sunlight; casting again ends the previous one.",
   cantrip=True, dur="5 rounds", traits="concentration, creation, light", conc=True, crit="It flares to sunlight in 10 ft until the start of your next turn.",
   mods=[M("Longer Light", 1, "Lasts 10 minutes."), M("Lasting Light", 2, "Lasts 1 hour.", True, 3), M("Larger Glow", 1, "20-ft radius."), M("Broad Glow", 2, "30-ft radius.", True, 4)])
sp("Sparkshot", "evocation", 0, 0, "Choose a damage type with your trappings. One target makes a Reflex save; failure: 1d6 damage, +1d6 per 4 Mysticism ranks.",
   cantrip=True, dur="Instant", save="reflex", traits="damage", deliveries=SINGLE, dmg="1d6", dtype="fire",
   crit="+1d6 damage.", critfail="Double damage.",
   mods=[M("Kickback", 1, "On a failed save, push 5 ft."), M("Twin Spark", 2, "Resolve twice (separate saves).", True, 5), M("Chain Spark", 3, "Resolve three times.", True, 10)])
sp("Darkness", "evocation", 1, 2, "Reduce illumination in the delivered area by a step (bright to dim, dim to darkness).", dur="5 rounds", traits="creation",
   crit="The area becomes full darkness.", mods=[M("True Darkness", 2, "Also blocks darkvision and similar (not magical sight)."),
   M("Mobile", 1, "Move it each round, or attach it to an object."), M("Umbral Shroud", 2, "Cast as a Chant lasting 1 stretch.")])
sp("Evoke Damage", "evocation", 1, 2, "Choose a damage type with your trappings. Each target makes a Reflex save; failure: 2d6 damage.", dur="Instant", save="reflex",
   traits="damage", deliveries=SINGLE, dmg="2d6", dtype="fire", crit="3d6 instead.", critfail="Double damage.",
   mods=[M("Area Casting", 1, "May use AOE deliveries."), M("Increased Damage", 2, "+1d6."), M("Greater Damage", 4, "+2d6 and HEAVY."),
         M("Disintegrate", 4, "+1d6; creatures or objects destroyed vanish.", True, 8)])
sp("Havoc", "evocation", 1, 2, "AOE only. Every creature affected is Off-Guard until the end of its next turn; each makes a Fortitude save (airborne: 1 Disadvantage) or is hurled 2d6×5 ft from the origin, taking 1d6 per 10 ft travelled on impact or landing (normal fall mitigation applies).",
   dur="Instant", save="fortitude", traits="damage", deliveries=["aura", "cone", "cube", "line", "sphere"], mods=[M("Greater Havoc", 2, "Hurled 3d6×5 ft.")])
sp("Lanternlight", "evocation", 1, 2, "Bright light fills the delivered area for 10 minutes.", dur="10 minutes", traits="creation, light", aoe2=True,
   crit="Also a free focused Line beam from you.", mods=[M("Mobile", 1, "Move it each round, or attach it to an object."), M("Sunbeam", 3, "Counts as sunlight; lasts 5 rounds.")])
sp("Stun", "evocation", 1, 2, "Each target makes a Fortitude save; failure: Stunned. At the end of each of its turns it repeats the save to recover.", dur="5 rounds",
   save="fortitude", traits="control", aoe2=True, crit="The initial save has 1 Disadvantage.", critfail="Its first recovery save rolls twice, keep the worse.",
   mods=[M("Focused Stun", 2, "Touch or Remote only; recovery saves roll twice, keep the worse.", True, 5)])

# ------------------------------------------------------------------ ILLUSION
sp("Minor Mirage", "illusion", 0, 0, "A silent visual illusion within a 5-ft cube. It can't harm, support or block. Studying, touching or passing through it allows a Perception save to recognize it.",
   cantrip=True, dur="1 minute", save="perception", traits="creation, image", crit="It can include simple repeating motion.",
   mods=[M("Bigger Mirage", 1, "10-ft cube."), M("Lasting Mirage", 1, "Lasts 1 stretch."), M("Fine Detail", 1, "Intricate details, symbols or short writing."),
         M("Obscuring Mirage", 1, "Blocks sight until recognized."), M("Anchored Mirage", 3, "Invested; anchored to an object or point for 1 hour.")])
sp("Phantom Jab", "illusion", 0, 0, "One target makes a Perception save; failure: 1d4 psychic damage and 1 Disadvantage on its next attack.", cantrip=True, dur="Instant",
   save="perception", traits="damage, psychic", deliveries=SINGLE, dmg="1d4", dtype="psychic", crit="1d6 damage.", critfail="Also Dazed until the end of its next turn.")
sp("Veil", "illusion", 0, 0, "You're Concealed until the start of your next turn (attacks against you suffer 1 Disadvantage).", cantrip=True, dur="1 round",
   traits="buff, brewable, concealment", deliveries=[TOUCH], crit="Also 1 Advantage on Stealth until then.")
sp("Conceal Arcana (Illusion)", "illusion", 1, 2, "Veil one creature or object (Medium or smaller) from detect-magic: 1 Disadvantage, and failed detectors don't notice the concealment.",
   time="ritual", dur="1 hour", traits="modify", deliveries=SINGLE, crit="2 Disadvantage.",
   mods=[M("Additional Recipient", 1, "One more creature or object."), M("Strong", 1, "+1 Disadvantage."), M("Larger Object", 2, "+1 size per purchase.", True, 5, True)])
sp("Mirage", "illusion", 1, 3, "A larger visual illusion filling the delivered area, with simple movement, maintained with Concentration. It's intangible; doubt or interaction allows a Perception save to see through it.",
   dur="5 rounds", save="perception", traits="creation, image, concentration", conc=True, crit="Disbelief saves have 1 Disadvantage.")
sp("Silence", "illusion", 1, 1, "Muffle sound on affected creatures or area: 2 Disadvantage on actions relying on sound. Unwilling targeted creatures may make a Perception save to ignore it (area versions give no save).",
   dur="5 rounds", save="perception", traits="control, sound", crit="Complete silence: sound-dependent actions fail.",
   mods=[M("Greater Silence", 1, "Saves have 1 Disadvantage."), M("Mobile", 1, "Move an area version up to standard range for 1 AP each round.")])
sp("Sound", "illusion", 1, 1, "Create a specific sound up to a loud shout at a point in range. To distract, the target makes a Perception save; failure: 1 Disadvantage on its next Perception check or hearing-based action.",
   dur="Instant", save="perception", traits="communication, sound", crit="2 Disadvantage.", mods=[M("Greater Sound", 1, "Saves have 1 Disadvantage.")])
sp("Disguise", "illusion", 3, 2, "A willing creature appears as another of the same size and shape, including gear. Purely visual. Doubters make a Perception save to see through it.",
   time="chant", dur="1 stretch", save="perception", traits="brewable, modify", crit="Those saves have 1 Disadvantage.",
   mods=[M("Alter Size", 1, "Appear one size larger or smaller."), M("Lasting Disguise", 2, "Ritual lasting 1 hour."),
         M("Additional Target", 2, "One more willing creature."), M("Unwilling Disguise", 2, "Target an unwilling creature (Charisma save negates).")])
sp("Invisibility", "illusion", 3, 5, "A willing creature and its gear turn invisible: sight-based attacks and detection against it suffer 2 Disadvantage (1 less when its position is revealed by the environment).",
   dur="5 rounds", traits="buff, brewable", crit="3 Disadvantage.",
   mods=[M("Extended Invisibility", 2, "Chant lasting 1 stretch; ends after a damaging attack or hostile spell."),
         M("Additional Target", 3, "One more willing creature."), M("Unwilling Invisibility", 2, "Target an unwilling creature (Charisma save negates).")])

# ------------------------------------------------------------------ NECROMANCY
sp("Chill Touch", "necromancy", 0, 0, "One target makes a Fortitude save; failure: Slowed 10 until the end of its next turn.", cantrip=True, dur="1", save="fortitude",
   traits="chill, debuff", deliveries=SINGLE, crit="Also 1d6 necrotic, +1d6 per 4 Mysticism ranks.", critfail="Slowed 20 instead.",
   mods=[M("Lingering Chill", 1, "Lasts 2 rounds."), M("Deep Chill", 1, "+10 to Slowed."), M("Bonechill", 2, "A failing target can't regain HP until your next turn."),
         M("Numbing Strike", 1, "A failing target has 1 Disadvantage on its next Reflex save.")])
sp("Grave Dart", "necromancy", 0, 0, "One target makes a Fortitude save; failure: 1d6 necrotic, +1d6 per 4 Mysticism ranks.", cantrip=True, dur="Instant", save="fortitude",
   traits="damage, necrotic", deliveries=SINGLE, dmg="1d6", dtype="necrotic", crit="Gain temporary HP equal to half the damage.", critfail="Also Frightened 1.",
   mods=[M("Hungering Dart", 1, "On a failed save, gain temp HP equal to half your ranks (min 1)."), M("Withering Dart", 1, "A failing target can't regain HP until your next turn."),
         M("Dread Dart", 1, "1 Disadvantage on its next Charisma save."), M("Ravaging Dart", 2, "+1d6 damage."), M("Executioner's Dart", 2, "+1d6 against a Bloodied target."),
         M("Soul Leech", 3, "Steal 1 point of a chosen ability (−1 to it, +1 to you) until the end of its next turn.", True, 6)])
sp("Life Stitch", "necromancy", 0, 0, "Touch only. Roll 1d4 (+1d4 per 4 Mysticism ranks): you take that much necrotic damage (no Soak; resistances apply) and the target heals the damage you actually took. It can't drop you below 1 HP.",
   cantrip=True, dur="Instant", traits="healing, stitch", deliveries=[TOUCH], crit="The target heals +1d6 more (you don't take extra).",
   mods=[M("Measured Transfer", 1, "Take less than rolled (min 1)."), M("Bloodied Stitch", 1, "+1d4 against a Bloodied target."), M("Suture Surge", 2, "+1d4."),
         M("Necrotic Conduit", 2, "Remote delivery, healing split among targets; extra targets cost +2.", True, 6)])
sp("Blind", "necromancy", 1, 2, "Each target makes a Fortitude save; failure: Dazzled 1.", dur="Until shaken off", save="fortitude", traits="debuff",
   crit="Dazzled 2.", critfail="Dazzled 2; with your critical success, Blinded until healed or cleansed.",
   mods=[M("Strong", 1, "Saves have 1 Disadvantage."), M("Deep Blindness", 3, "Blinded instead of Dazzled on a failure.", True, 7)])
sp("Fear", "necromancy", 1, 2, "Each target makes a Charisma save; failure: Frightened 1.", dur="Instant", save="charisma", traits="control, debuff, fear",
   crit="Frightened 2.", critfail="Frightened 2 (3 with your critical success).",
   mods=[M("Strong Fear", 1, "Saves have 1 Disadvantage."), M("Dread Wave", 1, "With an AOE delivery, failures are also Off-Guard until the end of their next turn."),
         M("Greater Fear", 2, "+1 to all Frightened values.", True, 5)])
sp("Lower", "necromancy", 1, 2, "Choose an ability. Each target makes a Fortitude save; failure: the matching condition at 1 (Might Enfeebled, Reflex Clumsy, Fortitude Drained, Intellect Stupefied, Perception Oblivious, Charisma Unnerved).",
   dur="Until shaken off", save="fortitude", traits="debuff", deliveries=SINGLE, crit="Value 2.", critfail="Value 2 (3 with your critical success).",
   mods=[M("Additional Recipient", 1, "One more creature."), M("Strong", 1, "Saves have 1 Disadvantage."), M("Greater Lower", 2, "+1 to the value.", True, 5),
         M("Area Casting", 1, "AOE deliveries at double cost.", True, 6)])
sp("Curse", "necromancy", 3, 5, "Touch only. The target makes a Charisma save; failure: 1 level of Exhaustion now and again every sunset. Only the worst curse applies. It ends if you choose or are slain; Dispel can end it at 1 Disadvantage, one attempt per person.",
   time="ritual", dur="Permanent", save="charisma", traits="debuff", deliveries=[TOUCH],
   mods=[M("Swift Malediction", 2, "Cast as an Invocation for 2 AP.", True, 11), M("Turn to Stone", 5, "Exhaustion each round instead of each day; at 4 levels the target turns to stone.")])
sp("Sloth", "necromancy", 4, 2, "Each target makes a Fortitude save; failure: Speed halved. It repeats the save at the end of each turn to shake it off.", dur="Until shaken off",
   save="fortitude", traits="debuff", crit="Shake-off saves roll twice, keep the worse.", critfail="Move actions cost +1 AP while affected.",
   mods=[M("Strong", 1, "Shake-off saves have 1 Disadvantage."), M("Area Casting", 1, "AOE deliveries at double cost.", True, 6)])
sp("Drain Power", "necromancy", 5, 2, "The target makes a Charisma save; failure: it gains 1d6 Strain and you recover the same. Creatures without Strain suffer Power Drain instead (next recharge roll twice, keep lower).",
   dur="Instant", save="charisma", traits="debuff, modify", crit="+1d6 Strain (or two recharge rolls).",
   critfail="Its maximum Strain also drops by 1d6 until a long rest or cure (Power Drain persists likewise).",
   mods=[M("Power", 2, "2d6 Strain (or two recharge rolls).", True, 7)])

# ------------------------------------------------------------------ TRANSMUTATION
sp("Harden", "transmutation", 0, 0, "Touch an object up to a 5-ft cube: +2 Hardness (+1 per 4 Mysticism ranks) until the start of your next turn; shields apply it to Shield Block.",
   cantrip=True, dur="1 round", traits="buff, modify", deliveries=[TOUCH], crit="+1 more Hardness.",
   mods=[M("Brittle", 1, "The object gains Fragile (an unwilling holder may make a Reflex save)."), M("Fortify", 2, "The object gains Fortified.", True, 7),
         M("Impervious Reinforcement", 5, "The object gains Impervious.", True, 11), M("Sustained Hardening", 2, "Lasts 5 rounds with Concentration.")])
sp("Mend Object", "transmutation", 0, 0, "Touch a mundane object up to a 5-ft cube to fix minor damage: it regains 1d4 Durability (+1d4 per 4 ranks), not above its Broken Threshold. Can't replace missing parts or restore destroyed items.",
   cantrip=True, dur="Instant", traits="modify, repair", deliveries=[TOUCH], crit="+1d4 Durability.",
   mods=[M("Skilled Patch", 1, "Can restore to 1 above the Broken Threshold."), M("Larger Repair", 2, "+1 size per purchase.", False, 0, True),
         M("Magical Mending", 3, "Can affect magic items.", True, 7)])
sp("Quickstep", "transmutation", 0, 0, "Targets gain +10 ft Speed until the end of their next turn.", cantrip=True, dur="1 round", traits="movement, speed", deliveries=SINGLE,
   crit="They also ignore difficult terrain.", mods=[M("Long Stride", 1, "+20 ft."), M("Fleet Step", 1, "Lasts 2 rounds."), M("Surefooted", 1, "Ignore difficult terrain."),
   M("Area Quickstep", 1, "AOE deliveries at double cost.", True, 5)])
sp("Boost", "transmutation", 1, 2, "Choose an ability: targets gain +1 on checks and saves with it (doesn't stack with itself).", dur="5 rounds", traits="buff, brewable", deliveries=SINGLE,
   crit="+2 instead.", mods=[M("Unwilling Target", 2, "Charisma save negates."), M("Greater Boost", 2, "+1 more.", True, 5)])
sp("Darksight", "transmutation", 1, 1, "Targets treat dim light as normal light.", time="chant", dur="1 stretch", traits="buff, brewable", deliveries=SINGLE,
   crit="They also see 10 ft into total darkness.", mods=[M("Quick Darksight", 1, "Invocation for 5 rounds with Concentration.", True, 5),
   M("Greater Darksight", 2, "See 60 ft into darkness in black and white; Dazzled in bright light.", True, 7)])
sp("Elemental Manipulation", "transmutation", 1, 1, "Choose Air, Earth, Fire or Water when learned. Manipulate existing manifestations of it within your standard reach; each round spend 1 AP for a minor trick (shove, douse, shift sand, redirect flame…).",
   dur="5 rounds", traits="control, modify", crit="Double your reach.",
   mods=[M("Greater Reach", 1, "Reach one step further."), M("Increased Volume", 1, "Affect about triple the amount."), M("Area Shaping", 1, "Also affect an adjacent 5-ft space."),
         M("Conjure Base Element", 2, "Create a small amount of your element.", True, 5),
         M("Sub-Domain", 2, "Also manipulate the sub-domain (Air→Lightning, Fire→Metal, Earth→Wood, Water→Ice).", True, 6),
         M("Conjure Sub-Domain", 3, "Create the sub-domain too.", True, 7)])
sp("Entangle", "transmutation", 1, 2, "Each target makes a Fortitude save; failure: Grappled by bindings (Hardness 8) until it Escapes (1 AP: Might save vs your result) or they're destroyed.",
   dur="Until broken free", save="fortitude", traits="control, debuff", deliveries=SINGLE, crit="Restrained instead.", critfail="Restrained instead.",
   mods=[M("Tough", 1, "Hardness 10."), M("Damage", 2, "1d10 at the end of each turn it doesn't escape."), M("Deadly", 4, "2d8 instead."),
         M("Area Casting", 1, "AOE deliveries at double cost.", True, 5)])
sp("Smite", "transmutation", 1, 2, "Imbue only, on a melee or ranged weapon (or its ammunition): +1d6 radiant damage on a hit.", dur="5 rounds", traits="buff, radiant", deliveries=[IMBUE],
   dmg="1d6", dtype="radiant", crit="+1d8 instead.", mods=[M("Greater Smite", 2, "+1d10 and HEAVY (+1d12 critical).")])
sp("Wall Walker", "transmutation", 1, 2, "Targets move on walls and ceilings with a climb Speed of half their Speed.", dur="5 rounds", traits="buff, brewable, movement", deliveries=SINGLE,
   crit="1 Advantage on climbing and clinging checks.", mods=[M("Sure Grip", 1, "+1 Advantage on climbing."), M("Spider Sprint", 1, "Climb Speed equals Speed."),
   M("Ceiling Skitter", 1, "No free hands needed."), M("Lingering Walker", 2, "Chant lasting 1 stretch."), M("Area Wall Walker", 1, "AOE at double cost.", True, 5)])
sp("Environmental Protection", "transmutation", 2, 2, "Targets breathe, speak and move normally in lethal environments: treat Radiation, Atmosphere, Pressure and Heat/Cold as 2 steps closer to normal (minimum R1, A2, P3, H3).",
   time="chant", dur="1 minute", traits="buff, brewable", deliveries=SINGLE, crit="Lasts 1 stretch.",
   mods=[M("Area Protection", 1, "AOE at double cost.", True, 5), M("Selective Protection", 1, "One rating only, lasting 1 stretch."), M("Extended Protection", 2, "Ritual lasting 1 hour."),
         M("Pressure Seal", 1, "Gravity also 2 steps closer (minimum G2)."), M("Hazmat Buffer", 1, "1 Advantage on initial saves vs radiation sickness or toxic atmosphere."),
         M("Greater Protection", 2, "3 steps instead of 2.", True, 7)])
sp("Farsight", "transmutation", 3, 2, "Targets see fine detail up to about a mile away.", dur="5 rounds", traits="buff, brewable", deliveries=SINGLE, crit="Range penalties are halved.",
   mods=[M("Greater Farsight", 2, "Ignore range penalties (critical doubles distance)."), M("Longglass", 1, "2 miles."), M("Eagle Eye", 1, "1 Advantage on sight Perception."),
         M("Steady Aim", 1, "Ignore long-range Disadvantage."), M("Mark Target", 1, "Ignore haze and fog when perceiving one marked target."),
         M("Lingering Sight", 2, "Chant lasting 1 stretch."), M("Area Farsight", 1, "AOE at double cost.", True, 5)])
sp("Growth", "transmutation", 3, 2, "Targets grow one size: 1 Advantage on Might checks and saves, +2 melee damage, 1 Disadvantage on Reflex checks and saves.", dur="5 rounds",
   traits="buff, brewable, modify", deliveries=SINGLE, crit="+5 ft reach.",
   mods=[M("Unwilling Target", 2, "Fortitude save negates."), M("Lingering Growth", 2, "Chant lasting 1 stretch."), M("Greater Growth", 4, "Two sizes.", True, 7),
         M("Area Casting", 2, "AOE at double cost.", True, 9)])
sp("Shrink", "transmutation", 4, 2, "Each target makes a Fortitude save; failure: one size smaller, 1 Advantage on Reflex checks and saves, 1 Disadvantage on Might checks and saves, −2 melee damage.",
   dur="5 rounds", save="fortitude", traits="brewable, modify", deliveries=SINGLE, crit="Lasts 1 minute.",
   mods=[M("Lingering Shrink", 2, "Chant lasting 1 stretch."), M("Powerful Shrink", 2, "No Might Disadvantage."), M("Greater Shrink", 4, "Two sizes.", True, 7),
         M("Area Casting", 2, "AOE at double cost.", True, 9)])
sp("Speed", "transmutation", 3, 2, "Targets double their Speed.", dur="5 rounds", traits="buff, brewable, movement", deliveries=SINGLE, crit="They also ignore difficult terrain.",
   mods=[M("Quickness", 2, "Once each round, 1 bonus AP for Move actions."), M("Greater Speed", 2, "Triple Speed."), M("Lingering Speed", 2, "Chant lasting 1 stretch."),
         M("Enduring Speed", 4, "Ritual lasting 1 hour.", True, 9)])
sp("Telekinesis", "transmutation", 3, 5, "Telekinetic control out to double your standard reach. Use Intellect in place of Might for the Bulk you can move; control 1 + half your Mysticism ranks objects. Each manipulation costs 1 AP. Unwilling creatures make Charisma saves (repeated each turn). You can wield tools and weapons telekinetically.",
   dur="5 rounds", save="charisma", traits="control, movement", crit="Treat Intellect as +2 for Bulk.",
   mods=[M("Focused Control", 1, "+2 objects."), M("Greater Reach", 1, "Triple standard reach."),
         M("Power", 3, "Intellect +2 for Bulk (+4 critical); objects of 12+ Bulk deal Heavy damage."), M("Mind Hulk", 4, "Count as one size larger for Bulk (two on a critical).")])
sp("Haste", "transmutation", 4, 2, "Targets gain +1 maximum AP (Speed unchanged).", dur="5 rounds", traits="buff, brewable", deliveries=SINGLE, crit="Also +1 RP each round.",
   mods=[M("Quick Reflexes", 2, "+1 RP each round."), M("Fleet", 2, "Also double Speed."), M("Unwilling Target", 2, "Fortitude save negates."),
         M("Area Casting", 2, "AOE at double cost.", True, 9)])
sp("Fly", "transmutation", 5, 3, "Targets gain a fly Speed of 30 ft.", dur="5 rounds", traits="buff, brewable, movement", deliveries=SINGLE, crit="Fly Speed 60 ft.",
   mods=[M("Swift Flight", 5, "60 ft (120 critical)."), M("Area Casting", 2, "AOE at double cost.", True, 9), M("Lingering Flight", 2, "Chant lasting 1 stretch."),
         M("Enduring Flight", 2, "Ritual lasting 1 hour.", True, 11)])
sp("Intangibility", "transmutation", 5, 5, "Willing targets become incorporeal: they can't affect the physical world, non-magical physical attacks can't touch them, and they pass through solids. Ending inside a solid shunts them out, Dazed.",
   dur="5 rounds", traits="buff, brewable", deliveries=SINGLE, crit="Also resistance to supernatural damage.",
   mods=[M("Unwilling Target", 2, "Charisma save each turn to end it."), M("Area Casting", 2, "AOE at double cost.", True, 9),
         M("Lingering Intangibility", 2, "Chant lasting 1 stretch."), M("Enduring Intangibility", 2, "Ritual lasting 1 hour.", True, 11)])
sp("Timestop", "transmutation", 8, 8, "After your current turn, immediately take an extra turn before anyone else acts.", dur="Instant", traits="modify, movement",
   crit="+1 maximum AP on the bonus turn.", mods=[M("Time Buffer", 2, "+1 RP during the extra turn."), M("Temporal Anchor", 3, "Return to your starting space when it ends."),
   M("Afterimage", 3, "Concealed until your next turn."), M("Overclock", 4, "+1 maximum AP during the extra turn (stacks).")])

METAMAGIC = [
    ("Anchored Spell", 1, 2, "Glyph deliveries can use a simple trigger (touch, proximity, spoken keyword)."),
    ("Daze Rider", 2, 3, "On a failed save, the target is Dazed until the end of its next turn."),
    ("Extend Duration", 1, 2, "Double the spell's duration, up to 10 minutes."),
    ("Frighten Rider", 2, 3, "On a failed save, the target gains Frightened 1 toward the caster (or the imbued item)."),
    ("Greater Ward", 2, 4, "A numeric bonus the spell grants (save, ability, Soak…) increases by +1."),
    ("Knockback", 1, 2, "On a failed save (or hit), push the target 10 ft."),
    ("Lingering Damage", 2, 3, "On a failed save (or hit), 1d4 persistent damage of the spell's type for 3 rounds (save ends early)."),
    ("Selective Shape", 1, 3, "With an AOE delivery, choose which creatures in the area are affected."),
    ("Slow Rider", 2, 3, "On a failed save, the target is Slowed 10 until the end of its next turn."),
    ("Sniper Range", 1, 2, "Remote or Line delivery range steps up one increment."),
    ("Sunder", 2, 4, "The spell gains HEAVY and deals +1 die against objects and structures."),
    ("Surge Bias", 2, 5, "If you trigger a Wild Surge, roll twice and keep either result."),
]


def entries():
    return SPELLS


def metamagic():
    return [{"name": n, "type": "metamagic", "img": "icons/magic/symbols/rune-sigil-black-pink.webp", "folder": None,
             "system": {"strain": s, "minRanks": r, "requires": f"{r}+ ranks in Mysticism; Metamagic Training talent",
                        "description": f"<p><strong>+{s} Strain</strong> · Requires {r}+ Mysticism ranks.</p><p>{t}</p>"}}
            for n, s, r, t in METAMAGIC]
