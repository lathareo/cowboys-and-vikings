"""Crew abilities and upgrades (The Crew chapter)."""

GENERAL_UPGRADES = [
    ("Cohort", 1, "Recruit a new Cohort, Gang or Expert, at its base tier. See Cohorts."),
    ("Quarters", 1, "Your Lair includes proper living quarters for the crew. Without this Upgrade, each crew member sleeps elsewhere, and may be exposed or vulnerable while doing so."),
    ("Secure Lair", 1, "Your Lair has locks, alarms, and traps to thwart intruders."),
    ("Hidden Lair", 1, "Your Lair's location is disguised and hidden from view. If it's ever discovered, two downtime activities and a currency cost scaled to Crew Level relocate and re-hide it."),
    ("Workshop", 1, "Your Lair has a workshop for tinkering, crafting, and research, plus a small library of books, documents, and maps. Long-term projects can be completed here without leaving the Lair."),
    ("Training", 1, "Choose a skill when you take this Upgrade. Each crew member gains this ability: spend 2 Strain to roll that skill with Fortune. Using it costs no AP or RP. Set the skill on this Upgrade's sheet; each member then gets a clover button beside that skill on their character sheet."),
    ("Second Cohort Type", 1, "A Cohort gains a second type, reflecting a gang or specialist with a genuinely dual skill set. This costs an Upgrade purchase, the same as recruiting the Cohort in the first place."),
]

ELITE = "Cohorts of the {0} type gain 1 Advantage level on checks related to their type."
FORT = "Each crew member gains a permanent +1 bonus to their Fortitude score."

TYPES = {
    "bravos": {
        "upgrades": [
            ("Bravos Rigging", 1, "Choose two weapon or armor items, reduce their Bulk by 1 each."),
            ("Elite Rovers", 4, ELITE.format("Rovers")),
            ("Elite Thugs", 4, ELITE.format("Thugs")),
            ("Hardened", 1, FORT),
        ],
        "abilities": [
            ("Combat Training", 1, "Gain 2 ranks in one combat-related skill of your choice."),
            ("Armor Optimization", 1, "While wearing armor that meets your Might requirement, reduce that armor's Check Penalty by 1, to a minimum of 0."),
            ("Unified Defense", 1, "As an action, choose a number of allies up to your Intellect score (minimum 1) to fight as a unified line. While an ally you chose this way is adjacent to you, you and that ally each gain 1 Advantage level on attack rolls and Defense, and are immune to one condition of your choice (Flanked, Off-Guard from a critical hit, or Grappled) for as long as you Concentrate, up to a number of rounds equal to your Intellect score."),
            ("Blunt Force Skullduggery", 1, "Gain 1 Advantage level on Thievery checks to Pick a Lock or Disable a Device. You may use Might instead of Thievery's normal key ability for these checks."),
            ("Synchronized", 1, "Whenever you or a crewmate uses the Help action for each other, the recipient gains 2 Advantage levels instead of 1. This increases to 3 at Crew Level 12, and 4 at Crew Level 20."),
            ("Iron Resolve", 1, "Once per encounter, when you'd be reduced to 0 HP, you may instead drop to 1 HP."),
        ],
    },
    "shadows": {
        "upgrades": [
            ("Thief Rigging", 1, "Choose two tool kits or gear items, reduce their Bulk by 1 each."),
            ("Elite Rooks", 4, ELITE.format("Rooks")),
            ("Elite Skulks", 4, ELITE.format("Skulks")),
            ("Steady", 1, FORT),
        ],
        "abilities": [
            ("Push for Success", 1, "If you fail a Thievery check to Pick a Lock or Disable a Device by 5 or less, you may spend Strain equal to half the amount you failed by (round up) to succeed anyway."),
            ("Underhanded Luck", 1, "When attempting to bypass a security measure, you only trigger an alarm or alert if you fail by 10 or more."),
            ("Forgettable Faces", 1, "While wearing a disguise, gain 1 Advantage level on Deception checks to support it. This increases to 2 at Crew Level 12, and 3 at Crew Level 20."),
            ("Hide in Plain Sight", 4, "You may attempt to Hide using Stealth even while being observed, as long as you're within 10 feet of a shadow other than your own."),
            ("Trap Master", 4, "You can set up or deploy a hazard in 1 minute or less (GM's call on scope), including improvised hazards or ones you brought materials for (see Hazards)."),
            ("The Shadows Have Eyes", 1, "Gain 1 Advantage level on Perception or Investigation checks made for espionage-related purposes. This increases to 2 at Crew Level 12, and 3 at Crew Level 20."),
        ],
    },
    "smugglers": {
        "upgrades": [
            ("Smugglers Rigging", 1, "Choose two items to carry on your person, reduce their Bulk by 1 each. You may change your selection with a downtime activity."),
            ("Camouflage", 1, "Your vehicle is perfectly concealed at rest, blending into its surroundings or passing as an unremarkable civilian one."),
            ("Elite Rovers", 4, ELITE.format("Rovers")),
            ("Mobile Lair", 4, "You can relocate your Lair to a new location with a downtime activity."),
            ("Steady", 1, FORT),
        ],
        "abilities": [
            ("Stuffed to the Rafters", 1, "Your vehicle's maximum Bulk capacity increases by your Intellect score. This stacks for each crew member who has this ability."),
            ("Swallow the Contraband", 1, "You can conceal a number of Light Bulk objects up to your Intellect or Fortitude score (whichever is higher) on your person. These are undetectable by search, but take 1d6 rounds each to retrieve once hidden."),
            ("Silver Tongue", 1, "Gain 1 Advantage level on Diplomacy or Deception checks made to talk your way past a checkpoint, inspection, or similar official scrutiny."),
            ("Know the Back Roads", 1, "Gain 1 Advantage level on Survival checks made while traveling off the main roads, and you're never the one who determines your group is lost."),
            ("Nothing to See Here", 1, "Once per scene, when a search or inspection would reveal your cargo, you may spend 1 Strain to have it come up clean instead, the specifics of how it stayed hidden are worked out with the GM after the fact."),
            ("Steady Hands", 1, "Gain 1 Advantage level on checks made to keep goods, passengers, or cargo secure and undamaged during rough travel, a bad road, a chase, a sudden stop."),
        ],
    },
    "assassins": {
        "upgrades": [
            ("Assassin's Rigging", 1, "Choose two items (weapon, tool, or gear), reduce their Bulk by 1 each."),
            ("Elite Skulks", 4, ELITE.format("Skulks")),
            ("Elite Thugs", 4, ELITE.format("Thugs")),
            ("Hardened", 1, FORT),
            ("Marked for Silence", 1, "Choose a specific type of authority or organization (lawmen, a particular company, a rival gang) when you take this Upgrade. Cohorts investigating or gathering information related to that group gain 1 Advantage level on checks related to their type."),
        ],
        "abilities": [
            ("Deft Strike", 1, "Once per round, when you hit with an attack that had at least 1 Advantage level, deal +1d6 damage. This increases to +2d6 at Crew Level 12, and +3d6 at Crew Level 20."),
            ("Poison Expert", 1, "You're never at risk of exposure from your own poisons."),
            ("Hide in Plain Sight", 8, "You may attempt to Hide using Stealth even while being observed, as long as you're within 10 feet of a shadow other than your own."),
            ("Uncanny Dodge", 4, "When an attacker you can see hits you with an attack, you may use a Reaction to halve the damage."),
            ("Killing Blow", 1, "When you critically hit a creature that's already Bloodied, you may spend 2 Strain to force it to succeed a Fortitude save or drop to 0 HP."),
            ("Vanish After the Kill", 1, "Once per encounter, immediately after your attack reduces a creature to 0 HP, you may spend a Reaction to move up to your Speed and then attempt a Stealth check to Hide."),
        ],
    },
    "hawkers": {
        "upgrades": [
            ("Hawkers Rigging", 1, "Choose one item you carry, it's perfectly concealed and its Bulk doesn't count against your limit."),
            ("Grease the Wheels", 1, "Choose a specific authority or official body when you take this Upgrade. Cohorts negotiating or dealing with them gain 1 Advantage level on checks related to their type."),
            ("Elite Rooks", 4, ELITE.format("Rooks")),
            ("Elite Thugs", 4, ELITE.format("Thugs")),
            ("Composed", 1, FORT),
        ],
        "abilities": [
            ("Smooth Talking", 1, "Gain 1 Advantage level on Diplomacy or Society checks made to buy or sell goods related to your product. This increases to 2 at Crew Level 12, and 3 at Crew Level 20."),
            ("Dodge the Law", 4, "Gain 1 Advantage level on checks made to create or use disguises and forgeries. This increases to 2 at Crew Level 12, and 3 at Crew Level 20."),
            ("Make It In House", 4, "Gain 2 ranks in Crafting. When crafting alchemical items related to your crew's product, gain 1 Advantage level on the check. This increases to 2 at Crew Level 12, and 3 at Crew Level 20."),
            ("Center of Attention", 1, "While hosting or acting as the center of a social gathering, you and a number of allies up to your Charisma score gain 1 Advantage level on Diplomacy and Deception checks made during it."),
            ("Hawkers Honesty", 1, "Gain 1 Advantage level on Deception or Diplomacy checks made when questioned by authorities about what you're selling."),
            ("Underworld Connections", 1, "Gain 1 Advantage level on Society checks made when dealing with the black market or its patrons. This increases to 2 at Crew Level 12, and 3 at Crew Level 20."),
        ],
    },
    "prospectors": {
        "upgrades": [
            ("Prospector's Rigging", 1, "Choose two survival or excavation tools, reduce their Bulk by 1 each."),
            ("Elite Adepts", 4, ELITE.format("Adepts")),
            ("Elite Rovers", 4, ELITE.format("Rovers")),
            ("Hardy", 1, FORT),
            ("Recognized Claim", 4, "Your Lair doubles as a legally recognized claim, providing a small, steady income between sessions (GM's call on the amount)."),
        ],
        "abilities": [
            ("Nose for Treasure", 1, "Gain 1 Advantage level on Passive Awareness checks made to notice valuable or unusual objects. This increases to 2 at Crew Level 12, and 3 at Crew Level 20."),
            ("Read the Ground", 1, "Gain 1 Advantage level on Survival checks made to judge whether a site is worth digging or diving."),
            ("Appraiser's Eye", 1, "Gain 1 Advantage level on Investigation checks made to determine the value or nature of a found item."),
            ("Steady Under Pressure", 4, "Gain 1 Advantage level on Reaction Saves made against hazards while exploring a ruin, mine, or dig site (see Hazards)."),
            ("Old Hand at Digging", 1, "Once per scene, when you'd spend real time extracting something from the ground or rubble, you may spend 1 Strain to do it in half the time instead."),
            ("Never Lost", 1, "You and up to 3 allies you're guiding never become lost while traveling, barring magical or supernatural interference."),
        ],
    },
    "raiders": {
        "upgrades": [
            ("Raider's Rigging", 1, "Choose two weapon or armor items, reduce their Bulk by 1 each."),
            ("Elite Rovers", 4, ELITE.format("Rovers")),
            ("Elite Thugs", 4, ELITE.format("Thugs")),
            ("Battle-Hardened", 1, FORT),
            ("Feared Name", 8, "Your crew's reputation precedes you. Choose a specific region or settlement when you take this Upgrade; Cohorts operating there gain 1 Advantage level on checks related to their type."),
        ],
        "abilities": [
            ("First Through the Door", 1, "Gain 1 Advantage level on your first attack roll each encounter, provided you're the first member of your crew to act."),
            ("Take What's Owed", 1, "Once per encounter, when you defeat a creature or breach a stronghold, you may immediately Interact to search it as a free action."),
            ("Reckless Charge", 1, "You may move your full Speed and still make an attack at the end of that movement, even against a creature you weren't already aware of at the start of your turn."),
            ("Unbroken Line", 4, "While you and at least one crewmate are both adjacent to the same enemy, you each gain 1 Advantage level on attack rolls against it. This increases to 2 Advantage levels at Crew Level 16."),
            ("Trophy Taker", 1, "Gain 1 Advantage level on Diplomacy or Intimidation checks made while displaying a trophy from a notable kill or raid."),
            ("No Surrender", 1, "Once per encounter, you may spend 2 Strain to remove the Frightened condition from yourself entirely, regardless of its current value."),
        ],
    },
    "wardens": {
        "upgrades": [
            ("Warden's Rigging", 1, "Choose two weapon, armor, or restraint items, reduce their Bulk by 1 each."),
            ("Elite Rovers", 4, ELITE.format("Rovers")),
            ("Elite Adepts", 4, ELITE.format("Adepts")),
            ("Steady", 1, FORT),
            ("Standing Authority", 8, "Choose a specific settlement or region when you take this Upgrade. Your crew is formally recognized as lawful authority there, and Cohorts operating in that capacity gain 1 Advantage level on checks related to their type."),
        ],
        "abilities": [
            ("Read the Trail", 1, "Gain 1 Advantage level on Survival or Investigation checks made to track a specific person."),
            ("Talk Them Down", 1, "Gain 1 Advantage level on Diplomacy checks made to de-escalate a hostile situation before violence breaks out."),
            ("Bring 'Em In Alive", 1, "Your attacks that would reduce a creature to 0 HP may instead leave it at 1 HP, if you choose, with no cost or action required to make that choice."),
            ("Stand Your Ground", 4, "While defending an ally, a prisoner in your custody, or a specific location you've committed to protect, gain 1 Advantage level on Defense and saves."),
            ("Cool Under Fire", 1, "Once per encounter, you may spend 1 Strain to remove 1 level of Disadvantage you're suffering from being outnumbered, injured, or under duress."),
            ("Long Memory", 1, "Gain 1 Advantage level on Investigation checks made to recall or research a past crime or criminal your crew has previously dealt with."),
        ],
    },
    "essenceHunters": {
        "upgrades": [
            ("Hunter's Rigging", 1, "Choose two weapon or harvesting tool items, reduce their Bulk by 1 each."),
            ("Elite Adepts", 4, ELITE.format("Adepts")),
            ("Elite Rooks", 4, ELITE.format("Rooks")),
            ("Hardened", 1, FORT),
            ("Quiet Buyers", 8, "Your crew has cultivated clients who don't ask questions. Cohorts negotiating the sale of Essence, however it was acquired, gain 1 Advantage level on checks related to their type."),
        ],
        "abilities": [
            ("Essence Sense", 1, "Gain 1 Advantage level on Mysticism checks made to detect or identify the presence of Essence."),
            ("Clean Harvest", 1, "Gain 1 Advantage level on checks made to harvest Essence from a creature without degrading its quality."),
            ("Practiced Tracker", 1, "Gain 1 Advantage level on Survival checks made to track a specific creature you intend to harvest from."),
            ("Steady Nerves", 4, "Gain 1 Advantage level on saves against Fear effects caused by a creature you're actively hunting for its Essence."),
            ("Waste Not", 1, "Once per scene, when a creature dies before you can harvest it properly, you may spend 1 Strain to salvage a usable amount of Essence anyway."),
            ("No Questions Asked", 1, "Gain 1 Advantage level on Deception checks made to conceal how a batch of Essence was actually acquired."),
        ],
    },
    "arcaneInvestigators": {
        "upgrades": [
            ("Investigator's Rigging", 1, "Choose two tool kits or ritual components, reduce their Bulk by 1 each."),
            ("Elite Adepts", 4, ELITE.format("Adepts")),
            ("Elite Rooks", 4, ELITE.format("Rooks")),
            ("Steady Mind", 1, FORT),
            ("Trusted Consultants", 8, "Your crew has a real, known reputation for solving what others can't. Cohorts gathering information about a magical or supernatural matter gain 1 Advantage level on checks related to their type."),
        ],
        "abilities": [
            ("Trained Eye", 1, "Gain 1 Advantage level on the Passive Awareness comparison used to detect a magical hazard or unexplained magical effect (see Hazards)."),
            ("Ritual Scholar", 1, "Gain 1 Advantage level on Mysticism checks made using the Detect Magic skill action."),
            ("Read the Scene", 1, "Gain 1 Advantage level on Investigation checks made to determine what caused an unexplained event."),
            ("Steel the Nerves", 4, "Gain 1 Advantage level on saves against Fear or Mental effects caused by something you're actively investigating."),
            ("Close the Book", 1, "Once per scene, when you successfully resolve a haunting, curse, or magical disturbance, you may spend 1 Strain to ensure it doesn't recur at that location."),
            ("Seen It Before", 1, "Gain 1 Advantage level on checks made to identify a magical effect or creature type you've previously encountered and correctly resolved."),
        ],
    },
}

CREW_INFO = {
    "assassins": ("Killers for hire. Death is your business.", "Do you have any scruples about who you kill, or is everyone fair game?", "Training (Stealth or Deception): each member may spend 2 Strain to roll that skill with Fortune, no AP or RP needed. Training (a combat-related skill of your choice): each member may spend 2 Strain to roll that skill with Fortune, no AP or RP needed.", "Favored Job", ["Accident: a killing with no telltale signs of murder.", "Disappearance: the victim vanishes without a trace.", "Murder: an obvious killing that sends a message.", "Ransom: a kidnapping and demand for payment."]),
    "bravos": ("Mercenaries and hired muscle. The fist, the blade, and the gun are all you need.", "Are you brutal thugs, honest sell-swords, or a gang running protection rackets?", "Training (a combat-related skill of your choice): each member may spend 2 Strain to roll that skill with Fortune, no AP or RP needed. A Thugs-type Cohort, at its base tier.", "Favored Job", ["Battle: defeat an enemy through overwhelming force.", "Extortion: threaten violence unless you're paid off.", "Sabotage: hurt an opponent by destroying something.", "Smash & Grab: a fast, violent robbery."]),
    "essenceHunters": ("Trackers and harvesters of Essence, the raw material every rune and enchantment is built from. Someone has to hunt it down, and not everyone asks how it was gathered.", "Do you work within the law, harvesting only from the dead and the willing? Or have you crossed into the taboo trade that pays far better and asks far less?", "Training (Survival or Mysticism): each member may spend 2 Strain to roll that skill with Fortune, no AP or RP needed. A Workshop, at its base tier.", "Favored Job", ["Bounty Harvest: tracking and taking Essence from a specific dangerous creature.", "Supply Run: fulfilling a standing order for a crafter or client.", "Salvage: recovering Essence from an already-dead or abandoned source.", "Black Market Deal: moving Essence too rare, too fresh, or too illegal to sell openly."]),
    "hawkers": ("Vice dealers. Some folks just want to forget their problems and get away, sometimes they need the next best thing. That's when they turn to you.", "What's your product? Who's your supplier? Where and how do you sell it?", "Training (Diplomacy or Society): each member may spend 2 Strain to roll that skill with Fortune, no AP or RP needed. A Secure Lair, at its base tier.", "Sales Type", ["Sale: a significant transaction with a special buyer of illicit product.", "Supply: securing a new product or a new supplier.", "Show of Force: making an example of an enemy to hold territory.", "Socialize: improving customer or supplier relations through social events."]),
    "prospectors": ("Treasure hunters and claim workers. Gold in the ground, relics in the ruins, someone has to go get it.", "Are you honest prospectors working a legal claim, or claim jumpers who take what others already found?", "Training (Survival or Investigation): each member may spend 2 Strain to roll that skill with Fortune, no AP or RP needed. A Workshop, at its base tier.", "Favored Job", ["Claim Working: extracting resources from a legally held site.", "Ruin Diving: recovering treasure or artifacts from ruins or old dig sites.", "Search and Rescue: finding people lost in the wilderness or underground.", "Exploration: charting unknown territory."]),
    "raiders": ("Plunderers and reavers. You don't take contracts, you take what you want, and let your name spread.", "Do you raid for glory, for survival, or because it's the only life you've ever known?", "Training (a combat-related skill of your choice): each member may spend 2 Strain to roll that skill with Fortune, no AP or RP needed. A Rovers-type Cohort, at its base tier.", "Favored Job", ["Raid: a fast, violent strike against a settlement, camp, or caravan.", "Plunder: stripping a defeated enemy or abandoned site of everything worth taking.", "Blood Feud: settling a score with overwhelming, memorable force.", "Show of Strength: a public act of daring meant to be talked about."]),
    "shadows": ("Thieves and spies. Everyone wants something they can't have. That's where you come in.", "Do you spy and steal primarily to serve your own interests, or do you sell your services to whoever will pay?", "Training (Stealth or Thievery): each member may spend 2 Strain to roll that skill with Fortune, no AP or RP needed. A Hidden Lair, at its base tier.", "Favored Job", ["Burglary: theft by breaking and entering.", "Espionage: obtain secret information by covert means.", "Robbery: theft by force or threats.", "Sabotage: hurt an opponent by destroying something."]),
    "smugglers": ("Contraband transporters. Illicit goods move where the law says they shouldn't, and that's where you come in.", "What kind of contraband do you transport? Do you have any rules about what you will or won't carry?", "Training (Diplomacy or Deception): each member may spend 2 Strain to roll that skill with Fortune, no AP or RP needed. A wagon or boat, at its base tier.", "Cargo Type", ["Occult: cursed relics, mystical reagents, rare Essence.", "Arms: restricted weapons, heavy ordnance, explosives.", "Contraband: high-tax luxuries, drugs, banned goods.", "Passengers: people or livestock traveling in secret."]),
    "wardens": ("Lawmen, rangers, and bounty hunters. Someone has to keep the peace, chase down what's owed, and bring the guilty back alive when it's possible.", "Do you wear a badge, or just act like you do? Does the law answer to you, or do you answer to it?", "Training (Investigation or Survival): each member may spend 2 Strain to roll that skill with Fortune, no AP or RP needed. Training (a combat-related skill of your choice): each member may spend 2 Strain to roll that skill with Fortune, no AP or RP needed.", "Favored Job", ["Manhunt: tracking down a specific fugitive.", "Peacekeeping: resolving a dispute before it turns violent.", "Escort: protecting a person, shipment, or place from threat.", "Investigation: determining the truth behind a crime."]),
    "arcaneInvestigators": ("Called in when something can't be explained, a haunting, a curse, a wild surge gone wrong, a magical phenomenon nobody wants sitting unresolved. You find out what happened, and what to do about it.", "Do people call you because they trust you, because you're cheap, or because nobody else will take the job?", "Training (Investigation or Mysticism): each member may spend 2 Strain to roll that skill with Fortune, no AP or RP needed. A Workshop, at its base tier.", "Favored Job", ["Haunting: investigating and resolving a supernatural disturbance.", "Consultation: advising on a magical phenomenon someone else can't explain.", "Curse Breaking: identifying and removing a curse or lingering hex.", "Wild Surge Cleanup: investigating and containing the fallout of an uncontrolled magical event."]),
}

TYPE_NAMES = {
    "assassins": "Assassins", "bravos": "Bravos", "essenceHunters": "Essence Hunters", "hawkers": "Hawkers",
    "prospectors": "Prospectors", "raiders": "Raiders", "shadows": "Shadows", "smugglers": "Smugglers",
    "wardens": "Wardens", "arcaneInvestigators": "Arcane Investigators",
}


def entries():
    out = []
    for name, lvl, text in GENERAL_UPGRADES:
        out.append({"name": name, "type": "crewUpgrade", "img": "icons/environment/settlement/house-cottage.webp",
                    "folder": "General Upgrades",
                    "system": {"crewType": "general", "levelReq": lvl, "cost": "TBD", "description": f"<p>{text}</p>"}})
    for key, data in TYPES.items():
        tname = TYPE_NAMES[key]
        for name, lvl, text in data["upgrades"]:
            out.append({"name": name if name not in ("Elite Rovers", "Elite Thugs", "Elite Rooks", "Elite Skulks", "Elite Adepts", "Hardened", "Steady", "Hide in Plain Sight") else f"{name} ({tname})",
                        "type": "crewUpgrade", "img": "icons/tools/hand/hammer-and-nail.webp", "folder": f"{tname}",
                        "system": {"crewType": key, "levelReq": lvl, "cost": "TBD", "description": f"<p>{text}</p>"}})
        for name, lvl, text in data["abilities"]:
            out.append({"name": name if name != "Hide in Plain Sight" else f"{name} ({tname})",
                        "type": "crewAbility", "img": "icons/sundries/flags/banner-flag-red.webp", "folder": f"{tname}",
                        "system": {"crewType": key, "levelReq": lvl, "description": f"<p>{text}</p>"}})
    return out
