"""Spells part 1 (Magic chapter): Abjuration, Conjuration, Divination, Enchantment. Condensed rules text."""

PUSH = "Push: take 1 Strain to cast for 1 AP instead of 2."
AOE2 = "Area deliveries cost double Strain for this spell."
SPELLS = []


def sp(name, school, cx, st, text, *, cantrip=False, cost="2", time="invocation", dur="", save="", traits="", crit="", critfail="",
       mods=(), push=None, aoe2=False, deliveries=None, dmg="", dtype="", conc=False, invested=False, notes=""):
    push = cantrip if push is None else push
    desc = f"<p>{text}</p>"
    if critfail:
        desc += f"<p><strong>Target critically fails:</strong> {critfail}</p>"
    if aoe2:
        desc += f"<p><em>{AOE2}</em></p>"
    if notes:
        desc += f"<p><em>{notes}</em></p>"
    if push:
        desc += f"<p><em>{PUSH}</em></p>"
    if mods:
        desc += "<p><strong>Optional Modifiers</strong></p><ul>" + "".join(
            f"<li>{'★ ' if m[3] else ''}<b>{m[0]} (+{m[1]}{'*' if m[5] else ''})</b>: {m[2]}{f' [{m[4]}+ ranks]' if m[4] else ''}</li>" for m in mods) + "</ul>"
    SPELLS.append({
        "name": name, "type": "spell", "folder": school.title(),
        "img": IMG.get(school, "icons/magic/symbols/runes-star-pentagon-blue.webp"),
        "system": {
            "school": school, "cantrip": cantrip, "complexity": cx, "strain": st, "cost": cost, "castingTime": time,
            "duration": dur, "save": {"ability": save, "effect": ""}, "spellTraits": [t.strip().lower() for t in traits.split(",") if t.strip()],
            "aoeRestricted": aoe2, "pushable": push, "concentration": conc, "invested": invested,
            "deliveries": deliveries or [], "damage": {"formula": dmg, "type": dtype, "scaling": ""},
            "critSuccess": f"<p>{crit}</p>" if crit else "",
            "modifiers": [{"name": m[0], "strain": m[1], "text": m[2], "mastery": m[3], "minRanks": m[4], "repeatable": m[5]} for m in mods],
            "sustain": dur not in ("", "Instant"), "description": desc
        }
    })


def M(name, strain, text, mastery=False, ranks=0, rep=False):
    return (name, strain, text, mastery, ranks, rep)


IMG = {
    "abjuration": "icons/magic/defensive/shield-barrier-glowing-blue.webp",
    "conjuration": "icons/magic/movement/portal-vortex-orange.webp",
    "divination": "icons/magic/perception/eye-ringed-glow-yellow.webp",
    "enchantment": "icons/magic/control/hypnosis-mesmerism-swirl.webp",
    "evocation": "icons/magic/fire/projectile-fireball-orange.webp",
    "illusion": "icons/magic/perception/silhouette-stealth-shadow.webp",
    "necromancy": "icons/magic/death/skull-energy-light-purple.webp",
    "transmutation": "icons/magic/earth/strike-fist-stone-gray.webp",
}

TOUCH, REMOTE, IMBUE = "touch", "remote", "imbue"
SINGLE = [TOUCH, REMOTE, IMBUE]

# ------------------------------------------------------------------ ABJURATION
sp("Aegis Touch", "abjuration", 0, 0, "Ward the target until the start of your next turn: its next save before then gains +1 per 2 Mysticism ranks.",
   cantrip=True, dur="1", traits="brewable, buff, safeguard, ward", crit="The target also rolls that save twice and keeps the better.",
   mods=[M("Extended Ward", 1, "Duration becomes 1 minute, but the ward still ends after one save.")])
sp("Stitch Ward", "abjuration", 0, 0, "The creature you touch becomes Stable.", cantrip=True, dur="Instant", traits="brewable, healing, ward, touch",
   crit="The target also heals 1d4 HP and resists all damage until the start of your next turn.", notes="Deliveries other than Touch cost +1 Strain.")
sp("Ward Spark", "abjuration", 0, 0, "Each target makes a Fortitude save vs your Channeling result. Failure: 1 Disadvantage on all checks until the start of your next turn.",
   cantrip=True, dur="1", save="fortitude", traits="damage, debuff, hex", critfail="2 Disadvantage instead.",
   crit="Targets that fail also take 1d4 force damage, +1d4 per 3 Mysticism ranks.", dtype="force")
sp("Arcane Protection", "abjuration", 1, 1, "The target gains 1 Advantage on saves against hostile magic for the duration.", dur="5", traits="brewable, ward, concentration",
   conc=True, crit="2 Advantage instead.", mods=[M("Greater Arcane Protection", 2, "2 Advantage (3 on a critical success)."),
   M("Self-Sustaining", 3, "No longer requires Concentration.", True, 6)])
sp("Banish", "abjuration", 1, 2, "An extraplanar creature (ghost, demon, elemental…) makes a Charisma save vs your Channeling result or is sent back to its home plane. The GM decides if and when it returns; on a critical failure, later rather than sooner.",
   dur="Instant", save="charisma", traits="movement, planar", notes="Area deliveries cost +1 Strain, and each area increase +1 more.")
sp("Conceal Arcana (Abjuration)", "abjuration", 1, 2, "Mask a target or area from detect-magic attempts: they suffer 1 Disadvantage. A failed detector isn't aware anything was hidden unless evidence is obvious. Larger than Medium: +2 base Strain per size.",
   time="ritual", dur="1", traits="buff, detection, concealment", crit="2 Disadvantage instead.", mods=[M("Strong", 1, "1 additional Disadvantage on detection.")])
sp("Protection", "abjuration", 1, 2, "Increase the target's Soak by 2 (stacks with armor).", dur="5", traits="brewable, buff, ward", crit="Soak +4 instead.",
   mods=[M("Greater Protection", 4, "Double the Soak increase.", True, 8)])
sp("Deflection", "abjuration", 2, 2, "Choose melee or ranged: attacks of that type against the target suffer 1 Disadvantage.", dur="5", traits="brewable, buff, ward",
   crit="2 Disadvantage instead.", mods=[M("Multiangled Protection", 2, "Applies to both melee and ranged."), M("Greater Deflection", 2, "2 Disadvantage (3 on a critical success).")])
sp("Dispel", "abjuration", 2, 2, "Target an active spell (2 AP), or counter a spell being cast as a Reaction (2 RP). Opposed Channeling (or the caster's Charisma save for innate magic). Win: the spell ends or fails. Beat it by 15+: the caster treats it as a critical failure.",
   cost="2", dur="Instant", traits="countermagic, debuff", aoe2=True,
   mods=[M("Multiple Spells", 1, "A successful dispel ends all spells the target has active."),
         M("Power", 2, "Target a magic item (1–3 Disadvantage by rarity); on success its magic is suppressed 1 round. Critical: Concentration, duration 5, sustainable.", False, 5),
         M("Push", 2, "Each purchase gives +1 Advantage on the dispel check.", False, 0, True),
         M("Anti-Magic Field", 6, "A 10-ft sphere on you for up to 3 rounds (Concentration): magic doesn't function inside; summoned creatures entering make a Charisma save or gain 1 Exhaustion. Can't combine with other modifiers.", True, 7)])
sp("Damage Field", "abjuration", 4, 4, "At the end of each affected creature's turn, every creature adjacent to it (allies included) takes 2d6 damage.", dur="5",
   traits="creation, damage", crit="3d6 instead.", aoe2=True, dmg="2d6",
   mods=[M("Self Preservation", 2, "You're immune to your own field."), M("Damage Boost", 2, "2d8 (3d8 critical)."),
         M("Greater Damage Field", 4, "4d6 heavy damage (5d6 critical).", True, 6), M("Mobile", 2, "Requires Self Preservation: detach and move the field up to your delivery range for 1 AP each round.")])

# ------------------------------------------------------------------ CONJURATION
sp("Conjure Tool", "conjuration", 0, 0, "Conjure one simple one-handed mundane tool (lockpicks, hammer, shovel, lantern…) lasting 1 stretch.", cantrip=True, time="chant", dur="1",
   traits="utility, tool", crit="The first check with it gains 1 Advantage.", mods=[M("Kit", 1, "A small kit of up to three tiny items."),
   M("Emergency", 2, "Becomes an Invocation with Concentration, 1-round casting, lasting up to 5 rounds.")])
sp("Flicker Step", "conjuration", 0, 0, "Teleport to an unoccupied space you can see within 10 ft with a clear line of effect. Squeezing through gaps smaller than you: +1 Strain per size of difference. If grappled or bound, your roll must beat 1d20 + the restriction's level.",
   cantrip=True, dur="Instant", traits="movement, teleport", crit="Double the distance.",
   mods=[M("Passenger", 1, "Bring one willing adjacent creature (restricted gaps double the total cost).", True, 2),
         M("Extended Range", 1, "+5 ft per purchase, up to half your Mysticism ranks.", True, 4, True)])
sp("Kinetic Nudge", "conjuration", 0, 0, "Push a creature 5 ft, or an unattended object 10 ft (Bulk below your Intellect or Charisma), unless it wins a Might save vs your Channeling result. Objects save with their level (0 if none).",
   cantrip=True, dur="Instant", save="might", traits="shove, force", aoe2=True, crit="Push twice as far.",
   critfail="A creature also falls Prone; an object takes falling damage for the distance.")
sp("Ability Restoration", "conjuration", 1, 3, "Restore 1d4 points of ability score damage.", dur="Instant", traits="brewable, healing", crit="Restore 1d4+2 instead.", aoe2=True)
sp("Burrow", "conjuration", 1, 2, "The target gains a Burrow Speed equal to half its land Speed.", dur="5", traits="brewable, movement, buff", crit="Burrow Speed equals land Speed.",
   aoe2=True, mods=[M("Stone-Burrow", 3, "Burrow through stone and similar solids.", True, 5)])
sp("Cleanse Condition", "conjuration", 1, 1, "Remove one negative condition from the target (not one maintained by an ongoing source until that source is removed).",
   dur="Instant", traits="brewable, healing", crit="Remove two conditions.", aoe2=True)
sp("Conjure Item", "conjuration", 1, 2, "Create a simple mundane object of common material. Strain is 2 per Bulk (minimum 2). It fades when the duration ends.",
   time="ritual", dur="1", traits="creation", crit="It's masterwork (+1 on the first relevant check).",
   mods=[M("Complete Set", 1, "A full set within the Bulk limit (quiver, chess set…)."),
         M("Temporary Item", 1, "+1 Complexity, −1 Strain: Invocation with Concentration, lasts 5 rounds. Not with Durable."),
         M("Durable", 1, "+1 Strain per 2 Bulk: permanent until dispelled; that Strain can't be recovered while it exists.", True, 6, True),
         M("Create Food", 2, "Food for one Medium creature for a day (spoils in 24 hours).", False, 0, True),
         M("Create Water", 2, "Clean water for one Medium creature for a day.", False, 0, True)])
sp("Ease Exhaustion", "conjuration", 1, 1, "The target acts as if it had 1 fewer level of Exhaustion (penalties only; it's still incapacitated if Exhaustion would incapacitate it).",
   time="ritual", dur="1 hour", traits="brewable, buff", crit="2 fewer levels.", aoe2=True)
sp("Heal", "conjuration", 1, 1, "The target regains 1d8 + your Mysticism ranks HP.", dur="Instant", traits="brewable, healing", crit="Double the healing.",
   aoe2=True, dmg="1d8 + @ranks.mysticism", dtype="healing",
   mods=[M("Greater Healing", 2, "2d8 + double your ranks."), M("Major Healing", 4, "3d8 + triple your ranks."), M("Supreme Healing", 6, "4d8 + quadruple your ranks."),
         M("Neutralize Affliction", 2, "The target retries a save against one poison or disease with 1 Advantage (2 on a critical); beat the DC to auto-succeed, by 15 to critically succeed."),
         M("Restoration I", 2, "Reduce Exhaustion by 1 (2 critical); immune to this for 24 hours."), M("Restoration II", 5, "Reduce Exhaustion by 2 (3 critical); immune for 24 hours.")])
sp("Numb Pain", "conjuration", 1, 1, "Reduce pain-shock by one step: Staggered becomes Dazed, Dazed is suppressed. Doesn't prevent Dying, Unconscious or incapacitation.",
   dur="5", traits="brewable, buff", crit="Suppress both Dazed and Staggered.", mods=[M("Lingering Numbness", 1, "Cast as a Ritual lasting 1 hour.")])
sp("Soothe Strain", "conjuration", 1, 1, "Heal 1d4 Strain. A creature can benefit once per 24 hours.", dur="Instant", traits="brewable, healing", crit="Double the Strain healed.")
sp("Barrier", "conjuration", 3, 2, "Create a 30-ft-long, 5-ft-high immobile wall conforming to the surface. Each 5-ft section: Hardness 5, Durability 10, Fortified.",
   dur="5", traits="creation", mods=[M("Damage", 1, "Touching it deals 1d6."), M("Deadly", 2, "Touching it deals 2d6."), M("Tough", 2, "Double Hardness and Durability."),
   M("Shaped", 1, "Circle, square or rectangle (no roof or floor; can't trap creatures)."), M("Size", 2, "Double length and height.")])
sp("Warrior's Gift", "conjuration", 3, 4, "While you concentrate, the target gains the benefits of one Combat- or Attack-trait talent you know.", dur="5", conc=True,
   traits="buff, mental, concentration", crit="You may grant such a talent you don't know but qualify for (GM approval); +2 Strain to gain it yourself too.",
   mods=[M("Dual Gift", 4, "Grant two talents.")])
sp("Planar Binding", "conjuration", 5, 8, "During the ritual prepare a binding trap and name the extraplanar creature. It makes a Charisma save vs your Channeling result: if it wins, the spell fails and it knows who tried; if you win, it's bound until it agrees to a service or breaks free (repeat the contest every 24 hours).",
   time="ritual", dur="Instant", save="charisma", traits="control, invested", invested=True, notes="Invested: your maximum Strain is reduced by this spell's Strain until the creature is released. Critical failure: it may appear unbound.",
   mods=[M("Stronger Circle", 1, "Each point adds to your Channeling result for the contest.", False, 0, True)])
sp("Planar Travel", "conjuration", 5, 5, "Open a gateway to another plane. Known destination: within 2d10 miles (critical: exactly there). Only a general locale: failure = random spot, success = general vicinity, critical = close.",
   dur="Instant", save="charisma", traits="planar, teleportation",
   mods=[M("Pocket Refuge", 1, "Create or enter a small persistent extradimensional shelter for up to five."),
         M("Planar Exile", 3, "Send an unwilling creature through (Charisma save; 1 Disadvantage on a critical); it's exiled 5 rounds.", True, 7)])
sp("Resurrection", "conjuration", 8, 20, "Requires a reasonably complete corpse dead no more than a year. Success: the target returns at 1 HP with 2 Exhaustion, Unconscious for 4 hours.",
   time="seance", dur="Instant", traits="healing, resurrection", crit="1 HP, 1 Exhaustion, Unconscious for 1 hour.",
   mods=[M("Raise Decade", 5, "Up to 10 years dead."), M("Greater Resurrection", 10, "Any time since death, no corpse needed; a 12-hour séance and you gain 2 Exhaustion.", True, 8)])

# ------------------------------------------------------------------ DIVINATION
sp("Glimpse", "divination", 0, 0, "Ask the GM one yes/no question about a creature, object or location you perceive. The answer is true but may be cryptic.",
   cantrip=True, dur="Instant", traits="communication, clue", crit="Ask a second question.")
sp("Read the Wind", "divination", 0, 0, "Trigger: you or an ally spends a Fate Die. Reaction (2 RP). Reroll: roll the reroll twice and take the better. Damage: roll the Fate Die twice and take the higher.",
   cantrip=True, cost="reaction", dur="Instant", traits="buff, initiative", crit="+1 to the reroll or to the Fate Die result.",
   mods=[M("Ride the Current", 2, "Apply it to an ally who spends a Fate Die."),
         M("Winds of Fate", 2, "Ritual lasting 1 hour: add your Fate Die (without spending it) to your next Perception save, Initiative or Investigation check (twice on a critical).")])
sp("Spot Weakness", "divination", 0, 0, "Touch or Remote targets make Intellect saves; failures are Marked while you concentrate. Your first attack on a Marked target gains Opening (1 Advantage) or Exploit (+2 damage), then its Mark ends.",
   cantrip=True, dur="5", save="intellect", traits="concentration, debuff, mark", conc=True, deliveries=[TOUCH, REMOTE],
   crit="Gain both benefits, or double one (2 Advantage or +4).", critfail="Gain both benefits or double one against that target.",
   notes="Each additional Remote target costs +2 Strain. Caster critical plus target critical failure: both benefits doubled.")
sp("Detect Arcana", "divination", 1, 2, "Perceive supernatural creatures, magic items and magical effects you can see, including invisible creatures and enchantments.",
   dur="5", traits="communication, detection", crit="Also learn the general type of each magic.", mods=[M("Identify", 2, "Identify a magic item's powers (may need time and handling).")])
sp("Locate", "divination", 1, 3, "Seek one specific, uniquely identifiable creature, object or place within 1 mile. Never seen it: 1 Disadvantage (ignored with a sympathetic link). Obscurity: Hidden 1, Secret 2, Warded 3 Disadvantage. Failure: in/out of range and a vague bearing. Success: direction and rough distance. Critical: exact direction, reliable distance and one extra detail. Critical failure: static or a confident false lead, and a trace that may cause a complication.",
   time="ritual", dur="Instant", traits="detection",
   mods=[M("Find the Path", 1, "Also sense the best route."), M("Far Seeking", 1, "Range steps 1 → 5 → 25 → 100 miles.", False, 0, True),
         M("Pierce Wards", 2, "Reduce Obscurity by 1.", False, 5)])
sp("Mind Link", "divination", 1, 3, "Link two or more willing creatures (not necessarily you) telepathically, up to 1 mile apart; only deliberate thoughts pass. When a linked creature takes damage, the others make an Intellect save (DC the higher of 10 or the damage) or are Dazed 1d4 rounds.",
   time="chant", dur="3", save="charisma", traits="communication, mental, planar", aoe2=True, crit="Range becomes 5 miles.",
   mods=[M("Broadcast", 2, "A one-way message to every sentient mind in an area delivery."), M("Long-Distance Link", 3, "Any familiar mind on the same plane.", True, 6)])
sp("Mind Reading", "divination", 1, 2, "One target makes a Charisma save vs your Channeling result. Success: the spell fails and it knows someone probed. Failure: one truthful answer. Critical failure: two answers, or one plus a related memory. It's aware of the intrusion unless you critically succeed.",
   dur="Instant", save="charisma", traits="communication, control, mental", deliveries=SINGLE, mods=[M("Mind Walk", 2, "Access a whole scene or chain of memories.")])
sp("Speak Language", "divination", 1, 1, "Speak, read and write one sapient language you don't know.", time="chant", dur="1", traits="communication",
   crit="You also handle slang and dialect.", mods=[M("Greater Speak Language", 2, "All sapient languages."), M("Mass Understanding", 5, "Creatures in an area understand one another.")])
sp("Aether Inquiry", "divination", 3, 5, "Commune with an otherworldly being, which answers as best it can (often symbolic). Once per 24 hours per spirit. On ground sacred to it, gain 1 Advantage.",
   time="ritual", dur="Instant", traits="communication", crit="The entity is more helpful and direct.",
   mods=[M("Power", 3, "Sacred ground only. Success: one extra, clearer question. Failure: one true answer and one distorted. Critical: it may manifest with unsolicited advice. Critical failure: something hostile answers.")])
sp("Object Reading", "divination", 3, 2, "Touch an object and receive visions of its past: success gives a vague impression; critical gives faces, names and context.",
   time="chant", dur="Instant", traits="communication", deliveries=[TOUCH],
   mods=[M("Projection", 2, "Project the vision into a room-sized space for others."), M("Remote Scan", 4, "Use Remote delivery.", True, 5)])
sp("Scrying", "divination", 5, 6, "Observe a specific, identifiable creature, object or place within 1 mile from a nearby viewpoint (same Familiarity and Obscurity penalties as Locate). Failure: blurry, misleading snippets. Success: clear sight and sound for the duration. Critical: reposition the viewpoint each round. Critical failure: a false feed and a trace.",
   time="ritual", dur="1", traits="communication, detection",
   mods=[M("Far Scrying", 1, "Range steps 1 → 5 → 25 → 100 miles.", False, 0, True), M("Pierce Wards", 2, "Reduce Obscurity by 1.", True, 7),
         M("Cross the Veil", 4, "Scry across planes (treat as Obscurity 3 with 1 extra Disadvantage).", True, 7),
         M("Sympathetic Focus", 1, "With a strong link, 1 Advantage."), M("Group Sight", 2, "Share the view with willing creatures up to your ranks.", True, 5)])

# ------------------------------------------------------------------ ENCHANTMENT
sp("Calm", "enchantment", 0, 0, "A willing creature gains 1 Advantage on its next Charisma save against fear, charm or emotion (and may immediately retry an existing fear effect). Ends once used.",
   cantrip=True, dur="5", traits="brewable, buff, emotion", crit="2 Advantage.",
   mods=[M("Shared Calm", 1, "One additional willing target."), M("Lingering Calm", 1, "Cast as a Chant lasting 1 stretch.")])
sp("Jolt of Doubt", "enchantment", 0, 0, "Each target makes a Charisma save; failure: 1 Disadvantage on its next action before the spell ends.", cantrip=True, dur="5",
   save="charisma", traits="debuff, mental", aoe2=True, crit="2 Disadvantage.", critfail="Also Dazed until the start of its next turn.")
sp("Pocket Command", "enchantment", 0, 0, "Each target makes a Charisma save; failure: it must step 5 ft, drop one held item, or speak a short phrase (your choice).",
   cantrip=True, dur="Instant", save="charisma", traits="control, command", aoe2=True, crit="Choose two options.", critfail="Also no reactions until its next turn.")
sp("Beast Friend", "enchantment", 0, 0, "Each natural beast makes a Charisma save; failure: it's Friendly to you and you can exchange simple intent and emotion. Harming it ends the spell for it.",
   cantrip=True, time="chant", dur="1", save="charisma", traits="buff, communication, beast, charm", deliveries=[TOUCH, REMOTE], push=False,
   crit="It follows one simple, safe request.", critfail="Also Dazed until the start of its next turn.",
   mods=[M("Quick Bond", 1, "Cast as an Invocation lasting 5 rounds."), M("Deep Rapport", 3, "Ritual lasting 1 hour with clearer communication.", False, 4),
         M("Pack Bond", 2, "Use area deliveries at double cost.", True, 6)])
sp("Confusion", "enchantment", 1, 2, "Each target makes an Intellect save; failure: Confused 1.", dur="Lingering", save="intellect", traits="control, debuff, hypnotic", aoe2=True,
   crit="Confused 2.", critfail="Its next recovery check against this rolls twice, keep the worse.", mods=[M("Greater Confusion", 2, "+1 Confused on both tiers.")])
sp("Empathy", "enchantment", 1, 1, "One target makes a Charisma save (a willing target may fail). Failure: you read its basic emotions and gain 1 Advantage on Diplomacy, Intimidation, Perform and Insight against it (animal handling against animals).",
   dur="5 rounds", save="charisma", traits="buff, brewable, communication, concentration", conc=True, deliveries=SINGLE, crit="2 Advantage.")
sp("Sanctuary", "enchantment", 1, 2, "Ward one creature: anyone attempting a damaging attack against or including it first makes a Charisma save vs your Channeling result or loses that action. The spell ends if you or the warded creature harms anyone.",
   dur="5 rounds", save="charisma", traits="buff, brewable", deliveries=SINGLE, crit="Those saves have 1 Disadvantage.",
   mods=[M("Strong", 1, "1 additional Disadvantage on the save."), M("Remote Ward", 2, "Use Remote; extra targets cost +2 each.", True, 6)])
sp("Slumber", "enchantment", 3, 2, "Each target makes a Charisma save (no effect on creatures that don't sleep). Not Bloodied: failure = Drowsy 1 minute; critical failure = Unconscious 1 minute. Bloodied: failure = Unconscious 1 minute; critical failure = Unconscious 1 hour. Damage wakes a sleeper; an adjacent creature can spend 1 AP to let it save again.",
   dur="Special", save="charisma", traits="control, hypnotic, mental", aoe2=True, crit="Saves have 1 Disadvantage.")
sp("Mind Wipe", "enchantment", 5, 3, "A 1-minute chant on a conscious target that stays in range. Charisma save; failure erases up to 30 minutes of a single event. A target that succeeds is immune to your Mind Wipe for 24 hours. Strong contrary evidence lets it try to recall fragments (save with 1 Disadvantage).",
   time="chant", dur="Instant", save="charisma", traits="debuff, mental, modify", deliveries=SINGLE, crit="Remove a complex memory spanning hours.",
   mods=[M("Edit", 1, "Alter the memory instead."), M("Greater Mind Wipe", 2, "Remove an entire event, person, place, thing or concept."),
         M("Combat Casting", 2, "Cast as an Invocation on a Restrained or otherwise held target.", True, 8)])
sp("Puppet", "enchantment", 5, 3, "One target makes a Charisma save. Success: it knows it was targeted. Failure: you control its actions, though it won't directly harm itself or those it cares about, nor stand idle while allies are in danger.",
   dur="5 rounds", save="charisma", traits="control", deliveries=SINGLE,
   crit="You may give harmful orders; each lets it save again to refuse that order.",
   mods=[M("Strong", 2, "Initial save at 1 Disadvantage; with an active Mind Link, control at any distance on the plane.", True, 6),
         M("Master of Puppets", 3, "Extra targets at triple the normal cost; each rolls its save twice and keeps the better.", True, 11)])
