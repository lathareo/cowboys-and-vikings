"""Example adversaries built with the Adversary Building rules. Items reference maneuver names (looked up at build time)."""

ADV = [
    dict(name="Gunhand", level=2, rank="standard", role="sniper", creatureType="humanoid", img="icons/creatures/magical/humanoid-silhouette-dashes-blue.webp",
         aq=dict(might="weak", reflex="strong", fortitude="average", intellect="average", perception="strong", charisma="weak"),
         quality=dict(hp="weak", soak="weak", damage="average", check="strong", skill="average"),
         skills=[("Firearms", 5), ("Stealth", 3), ("Perception", 4)],
         items=["Crossbow", "Dagger", "Prepared Shot", "Fall Back", "Mercenaries"],
         desc="A hired gun who keeps to the ridgeline, picking off anyone who strays from cover.",
         tactics="Opens from long range, pins the most dangerous target and falls back when rushed. Breaks when the pay stops looking worth it.",
         loot="Crossbow, 10 bolts, 3d6 sp.", morale="Mercenaries"),
    dict(name="Mine Foreman", level=4, rank="elite", role="leader", creatureType="humanoid", img="icons/creatures/magical/humanoid-silhouette-glowing-pink.webp",
         aq=dict(might="average", reflex="weak", fortitude="average", intellect="strong", perception="average", charisma="strong"),
         quality=dict(hp="average", soak="average", damage="average", check="average", skill="strong"),
         skills=[("Intimidation", 8), ("Society", 6), ("Crafting", 5)],
         items=["Warhammer", "Direct Ally", "Rally the Line", "Call Reinforcements", "Follow-Up Strike", "Inspiring Leader"],
         desc="A barrel-chested boss who runs the dig with a whistle and a sledge, and treats the crew as expendable property.",
         tactics="Stays behind two or three miners, directs attacks at whoever looks weakest and calls more hands when the fight turns.",
         loot="Payroll strongbox (Lock, average), 4d10 sp, a signed claim deed.", morale="Inspiring Leader"),
    dict(name="Frost Wolf", level=1, rank="minion", role="skirmisher", creatureType="animal", img="icons/creatures/mammals/wolf-howl-moon-gray.webp",
         aq=dict(might="average", reflex="strong", fortitude="average", intellect="weak", perception="strong", charisma="weak"),
         quality=dict(hp="average", soak="weak", damage="average", check="average", skill="average"),
         skills=[("Stealth", 3), ("Survival", 3)],
         items=["Bite", "Swarm Attack", "Join the Swarm", "Pack Tactics", "Pack Instinct"],
         desc="Pale, lean wolves that hunt in silent packs across the snowfields, pulling down stragglers.",
         tactics="Circle, flank and harry; the pack withdraws once half its number falls.",
         loot="Pelts (Animal, Preservative ingredient).", morale="Pack Instinct", essence="Frost (common)"),
    dict(name="Wendigo-Trapper", level=6, rank="solo", role="predator", creatureType="undead", img="icons/creatures/magical/spirit-undead-horned-blue.webp",
         aq=dict(might="strong", reflex="strong", fortitude="average", intellect="average", perception="strong", charisma="weak"),
         quality=dict(hp="strong", soak="average", damage="strong", check="strong", skill="strong"),
         skills=[("Stealth", 10), ("Survival", 9), ("Athletics", 8)],
         items=["Claw", "Bite", "Predatory Strike", "Hit and Fade", "Seize the Prey", "Hunting Dread", "Hunter's Domain", "Incredible Resilience", "Fearless"],
         desc="What remains of a trapper who survived a starving winter the wrong way. It still sets snares and still wears the old coat, stretched over a frame far too tall.",
         tactics="Stalks the party for days through blizzards, springs snares, drags one victim off and vanishes, then returns when they're exhausted.",
         loot="Rusted bear traps, a frostbitten journal, Death and Frost essence (uncommon).", morale="Fearless", essence="Death, Frost (uncommon)"),
]


def entries(lookup):
    out = []
    for a in ADV:
        items = []
        for n in a["items"]:
            it = lookup.get(n)
            if it:
                items.append({k: v for k, v in it.items() if k not in ("folder", "subfolder")})
        out.append({"name": a["name"], "type": "adversary", "img": a["img"], "folder": None,
                    "prototypeToken": {"name": a["name"], "actorLink": False, "disposition": -1, "displayName": 20, "displayBars": 20,
                                       "bar1": {"attribute": "hp"}},
                    "items": items,
                    "system": {"level": a["level"], "rank": a["rank"], "role": a["role"], "creatureType": a["creatureType"],
                               "abilityQuality": a["aq"], "quality": {**{"magnitude": "average", "step": "average"}, **a["quality"]},
                               "skills": [{"name": n, "mod": m} for n, m in a["skills"]], "autoCalc": True,
                               "morale": {"value": 0, "traits": a["morale"], "group": ""},
                               "crafting": {"essence": a.get("essence", ""), "ingredients": ""},
                               "description": f"<p>{a['desc']}</p>", "tactics": a["tactics"], "loot": a["loot"],
                               "hp": {"value": 999, "max": 999}}})
    return out
