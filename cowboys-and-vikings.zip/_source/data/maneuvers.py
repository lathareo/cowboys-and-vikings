"""Adversary maneuvers, traits and packages (Adversaries chapter).
Text is condensed for the compendium; scaling notes use the Track tables (quality + track)."""

# (name, category, group, traits, cost, trigger, text, essence, ingredients, recharge)
M = []


def add(name, cat, group, traits, cost, text, trigger="", essence="", ingredients="", recharge=False, roll=None):
    M.append(dict(name=name, cat=cat, group=group, traits=traits, cost=cost, text=text, trigger=trigger,
                  essence=essence, ingredients=ingredients, recharge=recharge, roll=roll or {}))


SAVE_DMG = "a save with DC 10 + half the damage taken (after Soak and Resistances)"

# ---------------------------------------------------------------- Baseline attacks
for n, t, dtype, extra, ing, ranged in [
    ("Bite", "average", "piercing", "", "Bone, Preservative", ""),
    ("Claw", "average", "slashing", "", "Bone, Preservative", ""),
    ("Slam", "average", "bludgeoning", "", "", ""),
    ("Tail Strike", "average", "piercing", "Has the Reach trait; deals piercing, slashing or bludgeoning to suit the creature.", "Animal, Preservative", ""),
    ("Beak / Peck", "average", "piercing", "Against a smaller target, add Weak damage.", "Bone, Preservative", ""),
    ("Gore / Horn", "average", "piercing", "If the attacker moved at least 10 feet right before attacking, add Weak damage.", "Bone, Preservative", ""),
    ("Tentacle / Limb Wrap", "average", "bludgeoning", "Has the Reach trait. Instead of dealing damage it may grapple the target, gaining Advantage equal to the Average Step on checks to maintain the grapple.", "Organ, Preservative", ""),
    ("Longsword", "average", "slashing", "If the target is adjacent to one of the attacker's allies, add Weak damage.", "", ""),
    ("Spear", "average", "piercing", "Has the Reach trait. If the attacker moved at least 5 feet right before attacking, add Weak damage.", "", ""),
    ("Warhammer", "strong", "bludgeoning", "The damage has the Heavy trait. On a miss, the target gains 1 Advantage on its next attack against this adversary until the adversary's next action or turn.", "", ""),
    ("Short Sword", "weak", "slashing", "If the attack has at least 1 Advantage, add Weak damage.", "", ""),
    ("Dagger", "weak", "piercing", "Melee, or ranged with Range(10). Against a Prone, grabbed, Restrained or otherwise compromised target, add Weak damage.", "", "10"),
    ("Crossbow", "average", "piercing", "Range(30). Has Armor Piercing equal to the Average Step.", "", "30"),
    ("Bow", "average", "piercing", "Range(40). Within 20 feet, add Weak damage.", "", "40"),
    ("Sling", "average", "piercing", "Range(40). If the target's Soak is no higher than the Average Step, add Weak damage.", "", "40"),
    ("Javelin", "average", "piercing", "Thrown(20). If the attacker moved at least 5 feet first, the attack gains Armor Piercing equal to the Average Step.", "", "20"),
]:
    kind = "ranged" if ranged else "melee"
    txt = f"<p>Make 1 action check with the adversary's {kind} check bonus against 1 creature within {'range' if ranged else 'melee reach'}. On a success, deal {t.title()} {dtype} damage (Damage Track). {extra}</p>"
    add(n, "baseline", "Baseline", ["baseline", kind, "natural" if n in ("Bite", "Claw", "Slam", "Tail Strike", "Beak / Peck", "Gore / Horn", "Tentacle / Limb Wrap") else "weapon"], "1",
        txt, ingredients=ing, roll={"type": "attack", "damage": t, "damageType": dtype, "range": ranged})

# ---------------------------------------------------------------- Minion / Elite / Solo
add("Swarm Attack", "swarm", "Minion", ["attack", "maneuver"], "1",
    "<p><strong>Requires:</strong> Minion rank and at least 1 allied Minion of the same type within Close that hasn't acted this round and can attack the same target.</p>"
    "<p>Declare a Swarm Attack against 1 target within reach. Up to 3 allied Minions of the same type within Close may Join the Swarm. Make 1 attack and damage roll with the Minions' baseline attack; it gains 1 Advantage for each participant after the first and Armor Piercing equal to the number of participants. The target takes half damage on a successful save, and none only on a Critical Success.</p>")
add("Join the Swarm", "swarm", "Minion", ["attack", "reaction", "taxing"], "reaction",
    "<p>Costs 0 Reaction Points. This Minion joins the triggering Swarm Attack; doing so uses its turn for the round.</p>",
    trigger="An allied Minion of the same type within Close declares a Swarm Attack against a target this Minion can also attack, and fewer than 3 have joined.")
add("Minion Resilience", "swarm", "Minion", ["passive"], "passive",
    "<p>A Minion has no HP. It is destroyed when it takes damage greater than its Soak and survives any hit at or below its Soak. Against effects that deal half damage on a successful save, it takes damage only on a failed save. It has 1 Action Point and no Reaction Points.</p>")

add("Bloodied Refresh", "elite", "Elite Action", ["elite", "reaction"], "reaction",
    "<p>Choose 1 maneuver this Elite has that is Discharged or out of uses; recharge it or regain 1 use. Once per encounter.</p>",
    trigger="This Elite first becomes Bloodied.")
add("Follow-Up Strike", "elite", "Elite Action", ["elite", "reaction"], "reaction",
    "<p>Make a Baseline Attack against the triggering target.</p>", trigger="The Elite deals damage to a target with a maneuver.")
add("Press the Advantage", "elite", "Elite Action", ["elite", "reaction"], "reaction",
    "<p>Choose 1 condition the triggering maneuver inflicted. If it has a value X, increase it by 1. Otherwise, the creature suffers Misfortune on recovery checks and other checks to remove it.</p>",
    trigger="The Elite inflicts a condition on a creature with a maneuver.")
add("Tactical Recovery", "elite", "Elite Action", ["elite", "maneuver", "taxing"], "free",
    "<p><strong>Requires:</strong> this Elite is suffering a hindering effect. At the end of its turn, choose 1 hindering effect or condition and attempt an extra save or recovery check against it.</p>")

INCREDIBLE = [
    ("Shifting Step", "The Solo moves up to 5 feet without triggering movement reactions."),
    ("Snap Attack", "The Solo makes 1 Baseline Attack against the creature whose turn just ended, if it is a valid target."),
    ("Pressing Blow", "1 creature within reach or Close must succeed a save against the Solo's action check or become Off-Guard until the start of its next turn."),
    ("Force Out of Position", "1 creature within Close must succeed a Might or Reflex save against the Solo's action check or be pushed, pulled or slid 5 feet."),
    ("Claim the Ground", "A 5-foot space within Close becomes difficult terrain until the start of the Solo's next turn."),
    ("Lingering Pressure", "1 creature within Close that already has a condition suffers Misfortune on its next recovery check against it before the Solo's next turn."),
    ("Sweeping Interference", "1 creature within Close suffers 1 Disadvantage on its next attack roll before the Solo's next turn."),
    ("Ablative Shelter", "The Solo gains 5 temporary HP."),
    ("Crush the Opening", "1 creature within Close that is Off-Guard, Slowed, grabbed, Prone or Bloodied takes Weak persistent damage for the Solo's level, of a type matching one of its baseline attacks."),
    ("Unsettling Surge", "1 creature within Close that can see or hear the Solo must succeed a Charisma, Perception or Fortitude save (as fits the Solo) or become Dazed until the end of its next turn."),
]
for n, t in INCREDIBLE:
    add(n, "solo", "Incredible Action", ["solo", "incredible"], "free",
        f"<p>Incredible Action (use after a PC or PC ally ends its turn; choose 2 options when building the Solo). {t}</p>")

add("Incredible Resilience", "solo", "Solo Package", ["solo", "passive"], "passive",
    "<p>The first time each round the Solo would be fully prevented from acting, reduce the effect instead: it loses part of its action economy (1 action, 1 reaction or 1 Incredible Action) rather than all of it. If the effect allows a save, the Solo also gets an extra save at the end of its turn.</p>")
add("Incredible Recovery", "solo", "Solo Package", ["solo", "passive"], "passive",
    "<p>When the Solo first becomes Bloodied it immediately does one: recharge a Discharged maneuver, use an Incredible Action, or roll a recovery check with Fortune. Its Incredible Presence also escalates to its second phase.</p>")

PRESENCE = [
    ("Tyrant's Reach", "Enemies within Close treat spaces adjacent to the Solo as difficult terrain. Bloodied: they also suffer 1 Disadvantage on checks for actions with the Move trait."),
    ("Crushing Aura", "A creature starting its turn adjacent to the Solo must succeed a Fortitude save against its action check or suffer 1 Disadvantage on physical attacks until the end of its turn. Bloodied: failures are also Slowed 5 until the start of their next turn."),
    ("Dread Presence", "A creature starting its turn within Close that can see or hear the Solo must succeed a Charisma save against its action check or suffer 1 Disadvantage on its first attack that turn. Bloodied: it becomes Frightened 1 instead."),
    ("Warped Battlefield", "Using the Average Magnitude for its level as the area, the Solo projects themed interference (smoke, roots, static, haze). Pick Movement Disruption (Might or Reflex save or Slowed X, X = Average Magnitude) or Visual Impairment (Fortitude or Perception save or Dim-Sighted). Bloodied: saves are made with Misfortune."),
    ("Hunter's Domain", "Once per round, attacking a creature that is Off-Guard or not adjacent to one of its allies, the Solo rolls with Fortune. Bloodied: it also deals extra Weak damage for its level on a hit."),
    ("Relentless Pressure", "Enemies within Close suffer Misfortune on recovery checks against conditions the Solo inflicted. Bloodied: they must also take 1 Strain to make their normal end-of-turn recovery check against those conditions (the Recover action is unaffected)."),
    ("Living Hazard", "Choose a save when selected. A creature that hits the Solo with a melee attack while adjacent must succeed it or suffer: Might — pushed 5 ft plus Average Magnitude; Reflex — Average damage for its level; Fortitude — Slowed 5 plus Average Magnitude; Charisma — Dazzled X (X = Average Step). Bloodied: use Strong values."),
    ("World-Weight", "Enemies within Close of the Solo treat that area as difficult terrain. Bloodied: the first time a creature starts its turn in or enters Close, it must succeed a Charisma save or have Speed 0 until the end of its turn."),
]
for n, t in PRESENCE:
    add(n, "solo", "Incredible Presence", ["solo", "presence"], "passive", f"<p>Incredible Presence (always active; escalates when Bloodied). {t}</p>")

# ---------------------------------------------------------------- Identity traits by creature type
ID = [
    # Aberration
    ("Telepathic Murmur", "Aberration", "Psychic", ["passive"], "passive",
     "A living creature starting its turn adjacent must succeed a Charisma save against this creature's action check or become Drowsy. If already Drowsy from this effect, it becomes Stupefied 1 instead (Weak Step).", "", "Mind", ""),
    ("Grasping Tendrils", "Aberration", "Tentacled", ["maneuver"], "1",
     f"Make 1 melee action check with a natural weapon. On a success, roll damage; the target must succeed a Might save (DC 10 + half damage taken) or be pulled 5 feet (Weak Magnitude) toward this creature, becoming grabbed if it ends adjacent. This creature gains 1 Advantage (Weak Step) to maintain that grapple.", "", "", "Organ, Preservative"),
    ("Implant Brood", "Aberration", "Brood", ["maneuver"], "1",
     "Make 1 melee action check with a natural weapon. On a success, roll damage; the target must succeed a Fortitude save (DC 10 + half damage taken) or be afflicted with Brood Parasite.", "", "Mind, Space", "Organ, Toxic"),
    ("Void Slip", "Aberration", "Void-Touched", ["passive"], "passive",
     "Once per round when it moves, it may shift 5 feet (Weak Magnitude), ignoring one creature, obstacle or gap (Weak Step) that would block movement, ending in a legal space.", "", "Space", ""),
    ("Mutating Flesh", "Aberration", "Fleshwarped", ["passive", "triggered"], "passive",
     "The first time it becomes Bloodied, choose Might, Reflex or Fortitude: it gains 1 Advantage (Weak Step) on saves with that ability for the rest of the encounter.", "", "Mind", "Organ, Preservative"),
    ("Warped Perception", "Aberration", "Reality-Warping", ["reaction"], "reaction",
     "For 1 RP, the attacker must succeed a Perception save against this creature's action check or suffer 1 Disadvantage (Weak Step) on attacks against it until the end of the attacker's next turn.",
     "A creature farther than adjacent makes a sight-reliant attack against this creature.", "Mind", ""),
    ("All-Seeing Sense", "Aberration", "Seer / Blind-Sense", ["passive"], "passive",
     "Gains Blindsight 10 feet (Strong Magnitude) and 1 Advantage (Weak Step) on Perception checks to detect hidden, invisible or disguised creatures.", "", "Mind", ""),
    # Animal
    ("Pack Tactics", "Animal", "Pack Hunter", ["passive"], "passive",
     "Once per round, its attack against a target adjacent to one of its allies is rolled with Fortune.", "", "", ""),
    ("Thick Hide", "Animal", "Great Beast", ["passive"], "passive",
     "+1 Soak (Weak Soak) against physical damage from attacks and effects without Armor Piercing.", "", "", "Animal, Preservative"),
    ("Tunnel Emergence", "Animal", "Burrowing", ["passive", "maneuver"], "1",
     "Gains a burrow speed through yielding ground (can't end inside solid space). It may burrow up to its Speed toward an enemy, emerge adjacent and make 1 melee attack with 1 Advantage (Weak Step).", "", "", "Animal, Preservative"),
    ("Climber", "Animal", "Climbing", ["passive"], "passive",
     "Gains a climb speed equal to its Speed and ignores difficult terrain from branches, ledges, rough stone, roots and rubble.", "", "", "Animal, Preservative"),
    ("Flyby Hunter", "Animal", "Flying", ["passive"], "passive",
     "Gains a fly speed equal to its Speed. When it flies at least 10 feet and passes within reach of an enemy, it attacks that enemy with 1 Advantage (Weak Step).", "", "", "Animal, Preservative"),
    ("Aquatic", "Animal", "Aquatic", ["passive"], "passive",
     "Gains a swim speed equal to its Speed and holds its breath ten times as long (or breathes water). In water it has Fortune on attacks against creatures without a swim speed.", "", "Motion", ""),
    ("Venomous Bite", "Animal", "Venomous", ["maneuver"], "1",
     "Make 1 melee attack with a natural weapon. On a success, roll damage; the target must succeed a Fortitude save (DC 10 + half damage taken) or be afflicted with Hunter's Venom.", "", "", "Organ, Toxic"),
    ("Territorial", "Animal", "Territorial", ["passive"], "passive",
     "While in its den or defended ground, or within Close of whatever it protects, it rolls its first attack each round with Fortune.", "", "", ""),
    ("Nocturnal Hunter", "Animal", "Nocturnal", ["passive"], "passive",
     "Treats darkness as low light and low light as bright light.", "", "", "Animal, Preservative"),
    # Construct
    ("Transferred Animus", "Construct", "Animate", ["maneuver", "recharge"], "1",
     "Choose an unattended object within Close of similar size. It moves its essence into that object, which becomes its new body (its old one goes inert). It keeps its stat block, HP, conditions and effects, and gains Strong Magnitude temporary HP.", "", "Mind", ""),
    ("Perfect Routine", "Construct", "Clockwork", ["passive"], "passive",
     "When it uses the same maneuver on consecutive turns and the previous use succeeded, it rolls this turn's check with Fortune.", "", "Mind", ""),
    ("Servant Logic", "Construct", "Homunculus", ["passive"], "passive",
     "Choose 1 other maneuver it knows: it uses Strong values for it, or if already Strong, gains Fortune on that maneuver's rolls once per round.", "", "Mind", ""),
    ("Timber Frame", "Construct", "Wooden", ["passive"], "passive",
     "Resistance to bludgeoning; Vulnerability to fire.", "", "", "Wood, Preservative"),
    ("Reinforced Resolve", "Construct", "Wooden", ["maneuver", "recharge"], "1",
     "It braces its frame: gain 5 temporary HP (Average Magnitude) and immediately attempt a save against 1 ongoing condition. If Bloodied, it also regains 5 HP (Weak Magnitude).", "", "Ward", "Metallic, Preservative"),
    ("Geometric Correction", "Construct", "Geometric", ["reaction", "recharge"], "reaction",
     "It ignores the triggering effect and moves 5 feet (Weak Magnitude), ignoring difficult terrain. If the source is within Close, that creature is moved 5 feet (Weak Magnitude) to a space of the construct's choice.",
     "It is pushed, pulled, slid, slowed or immobilized by an enemy.", "Mind", ""),
    ("Runic Backlash", "Construct", "Arcane / Guardian", ["reaction"], "reaction",
     "The source of the magic must succeed a Reflex save against its action check or take Average force damage.",
     "It is hit by a magical attack or fails a save against a magical effect.", "Arcane", ""),
    ("Steam Vent", "Construct", "Industrial", ["maneuver", "recharge"], "1",
     "Each other creature in a Close burst makes a Reflex save against its action check. Failure: Average fire damage and pushed 5 feet (Average Magnitude). Success: half damage. Critical success: none; critical failure: double.", "", "Fire", "Metallic, Preservative"),
    ("Guardian Directive", "Construct", "Guardian", ["passive", "reaction"], "passive",
     "On Initiative choose a ward (creature, area or object). Enemy effects that would force it away from its ward suffer 1 Disadvantage (Average Step). Interpose Directive (reaction): when a creature targets its ward, that action suffers 1 Disadvantage (Average Step).", "", "Mind", ""),
    ("Suppressive Output", "Construct", "War Machine", ["maneuver", "recharge"], "1",
     "Each creature in a 10-foot line (Strong Magnitude) makes a Reflex save against its action check: Average damage on a failure (double on critical failure), half on a success (none on critical success). The line is difficult terrain until its next turn, and creatures in it suffer 1 Disadvantage (Average Step) on attacks.", "", "", "Metallic, Preservative"),
    ("Scatterframe", "Construct", "Patchwork", ["reaction", "recharge"], "reaction",
     "It rolls its save against the effect with Fortune. On a success it sheds parts, breaks free and shifts 5 feet (Average Magnitude); the space it left becomes difficult terrain until the end of its next turn.",
     "It would become grabbed, Restrained, immobilized or Slowed by a physical effect.", "Motion", "Metallic, Preservative"),
    # Dragon
    ("Burning Scales", "Dragon", "Fire", ["passive"], "passive",
     "A creature that hits it while adjacent must succeed a Reflex save against its action check or take Average fire damage; natural-weapon or unarmed attackers save with Misfortune.", "", "Fire", "Mineral, Preservative"),
    ("Numbing Presence", "Dragon", "Frost", ["passive"], "passive",
     "A creature starting its turn adjacent must succeed a Fortitude save against its action check or be Slowed 5 (Average Magnitude) until the end of its turn; if already affected, it becomes Clumsy 1 (Average Step) instead.", "", "Frost", "Mineral, Preservative"),
    ("Static Field", "Dragon", "Storm", ["passive"], "passive",
     "A 5-foot emanation (Average Magnitude) is difficult terrain for enemies. A creature starting its turn inside must succeed a Reflex save against its action check or become Dazed.", "", "Storm", "Crystal, Volatile"),
    ("Lingering Ruin", "Dragon", "Venomous", ["passive"], "passive",
     "The first time each round it damages a creature with a natural attack, the target must succeed a Fortitude save (DC 10 + half damage taken) or become Sickened 1 (Average Step); if already Sickened, it takes Average poison damage instead.", "", "", "Organ, Toxic"),
    ("Earthshaking Weight", "Dragon", "Stone", ["passive"], "passive",
     "A 5-foot emanation (Average Magnitude) is difficult terrain. The first time each round it moves 10+ feet on the ground, enemies in the emanation must succeed a Reflex save or fall Prone.", "", "Earth", "Mineral, Preservative"),
    ("Devouring Dark", "Dragon", "Shadow", ["passive"], "passive",
     "A creature starting its turn adjacent while at least partly concealed must succeed a Charisma save or suffer Weakened Grip 1 (Average Step); if already affected, it also becomes Dazed.", "", "Shadow, Fear", ""),
    ("Blinding Aura", "Dragon", "Radiant", ["passive"], "passive",
     "A creature starting its turn adjacent must succeed a Reflex save or become Dazzled 1 (Average Step); if already Dazzled, it becomes Blinded.", "", "Radiance", ""),
    ("Impossible Endurance", "Dragon", "Ancient", ["passive"], "passive",
     "At the start of each of its turns it makes 1 extra recovery check (Average Step count) against a Lingering condition or ongoing effect, ending it on a success.", "", "", ""),
    # Elemental
    ("Elemental Body", "Elemental", "All Elementals", ["passive"], "passive",
     "Its body is unstable elemental substance: it ignores suffocation, drowning and similar stresses that only affect living flesh.", "", "", ""),
    ("Burning Aura", "Elemental", "Fire", ["passive"], "passive",
     "A creature starting its turn adjacent, or hitting it in melee while adjacent, must succeed a Reflex save against its action check or take Average persistent fire damage.", "", "Fire", ""),
    ("Freezing Aura", "Elemental", "Frost", ["passive"], "passive",
     "A creature starting its turn within 5 feet, or hitting it in melee from there, must succeed a Fortitude save or be Slowed 5 until the end of its next turn (Average Magnitude for both).", "", "Frost", ""),
    ("Static Charge", "Elemental", "Storm", ["passive"], "passive",
     "The first time each round it's hit by an attack from within Close, the attacker must succeed a Reflex save or become Dazed.", "", "Storm", ""),
    ("Stoneform", "Elemental", "Stone", ["passive"], "passive",
     "It rolls saves against forced movement, being knocked Prone, or losing its footing with Fortune.", "", "Earth", "Mineral, Preservative"),
    ("Flowing Shape", "Elemental", "Tide", ["passive"], "passive",
     "Ignores difficult terrain from liquid, mud or slick ground; moves through occupied spaces and gaps one size smaller, ending in a legal space; has Fortune on saves against being grabbed, Restrained or immobilized.", "", "Water", ""),
    ("Ash Cloud", "Elemental", "Ash", ["passive"], "passive",
     "A 5-foot emanation (Average Magnitude) of smoke grants partial concealment and 1 Disadvantage on sight-based checks. A creature starting its turn inside must succeed a Fortitude save or become Sickened 1 (Average Step).", "", "Ash", ""),
    ("Windborne", "Elemental", "Wind", ["passive"], "passive",
     "Ignores footing-based difficult terrain; the first 5 feet (Average Magnitude) of each move doesn't trigger movement reactions.", "", "Wind", ""),
    # Fey
    ("Mischief Veil", "Fey", "Trickster", ["reaction"], "reaction",
     "Spend 1 RP to move 10 feet (Average Magnitude). If it ends in cover, dim light, foliage or similar, it may immediately Hide with 1 Advantage (Average Step).", "A creature misses it with an attack.", "Shadow", ""),
    ("Commanding Glamour", "Fey", "Glamour-Bound", ["maneuver"], "1",
     "1 creature within Close that can see or hear it must succeed a Charisma save or become Fascinated by it; if already Fascinated by this effect, it becomes Stupefied 1 (Average Step) instead.", "", "Mind", ""),
    ("Marked Quarry", "Fey", "Wild Hunt", ["maneuver"], "1",
     "Mark 1 visible creature within Close as its Quarry for the encounter (or until it dies or a new Quarry is chosen). Moving toward its Quarry it ignores difficult terrain, and its first attack each turn against it gains 1 Advantage (Average Step).", "", "", ""),
    ("Winter's Geas", "Fey", "Winter", ["maneuver"], "1",
     "1 creature within Close must succeed a Fortitude save or be Slowed 5 (Average Magnitude); if already Slowed, it becomes Drowsy instead.", "", "Frost", ""),
    ("Revel Step", "Fey", "Summer", ["reaction"], "reaction",
     "When it moves adjacent to an enemy on its turn, that enemy must succeed a Charisma save or be Off-Guard until the end of its next turn; if already Off-Guard, it becomes Dazzled instead.", "", "Mind", ""),
    ("Vanish in Moonlight", "Fey", "Gloom", ["passive"], "passive",
     "In low light or while at least partly concealed, it may Hide while observed and without cover, with 1 Advantage (Average Step).", "", "Shadow", ""),
    ("Blooming Snare", "Fey", "Thorned", ["maneuver", "concentration"], "1",
     "1 creature within Close must succeed a Reflex save or become Grappled by the snare, suffering 1 Disadvantage (Average Step) on checks to escape.", "", "", "Wood, Preservative"),
    ("Oathbreaker's Price", "Fey", "Bargain-Bound", ["maneuver", "reaction", "recharge"], "1",
     "1 creature within Close that can hear it must succeed a Charisma save or become Bargain-Marked (one mark at a time) for the encounter. Reaction (1 RP): when a Marked creature acts with hostility toward it or its allies, that creature must succeed a Charisma save or become Charmed by it, ending the mark.", "", "Mind", ""),
    # Magical Beast
    ("Monstrous Frame", "Magical Beast", "Monstrous Body", ["passive"], "passive",
     "Its natural attacks have AP(1) (Average Step). The first time each round it hits with one, the target must succeed a Might save (DC 10 + half damage taken) or be pushed 5 feet (Average Magnitude); on an odd failed result it also falls Prone.", "", "", "Animal, Preservative"),
    ("Witchbrain Venom (Trait)", "Magical Beast", "Unnatural Venom", ["passive"], "passive",
     "When it damages with a natural weapon, the target must succeed a Fortitude save (DC 10 + half damage taken) or be afflicted with Witchbrain Venom.", "", "Mind", "Organ, Toxic"),
    ("Sky Hunter", "Magical Beast", "Aerial Predation", ["passive"], "passive",
     "Gains a fly speed equal to its Speed. While flying or attacking from above, it gains 1 Advantage (Average Step) on melee attacks and on checks to avoid being grappled or Restrained.", "", "Motion", "Animal, Preservative"),
    ("Serpentine Coils", "Magical Beast", "Serpentine", ["maneuver"], "1",
     "Make 1 natural melee attack; on a hit the target must succeed a Might save (DC 10 + half damage taken) or be Grappled. It can hold 2 creatures its size, 1 up to two sizes larger, or +1 per size smaller (minimum Small); it moves normally dragging them along and gains 1 Advantage on reach natural attacks against creatures it grapples.", "", "Motion", "Animal, Preservative"),
    ("Drowning Haze", "Magical Beast", "Aquatic", ["maneuver"], "1",
     "Gains a swim speed and emits a 10-foot haze (Average Magnitude). A creature starting its turn inside must succeed a Fortitude save or become Sickened 1 (Average Step); non-breathers and water-breathers are unaffected.", "", "Water", "Oil, Preservative"),
    ("Quicksilver Form", "Magical Beast", "Mutable Form", ["maneuver", "recharge", "concentration"], "1",
     "It takes the shape of a creature or object within one size of itself, keeping its statistics. Impersonating a specific creature or an ill-fitting body requires Concentration. It can shape simple weapons (Average damage, B/P/S) or simple tools from its body.", "", "Motion, Mind", "Slime, Volatile"),
    ("Displacement Field", "Magical Beast", "Displacement", ["triggered"], "passive",
     "When an attack would hit it and the attack roll is odd, the attack misses. Otherwise the field drops until the start of its next turn or until it moves 10+ feet (Average Step misses before reset).", "", "Shadow, Space", ""),
    # Ooze
    ("Ooze Senses", "Ooze", "All Oozes", ["passive"], "passive",
     "Lacks sight and hearing; has Blindsense 10 feet (Strong Magnitude) through touch, vibration and chemical sense.", "", "", ""),
    ("Engulfing Mass", "Ooze", "Gelatinous", ["maneuver"], "1",
     "Make 1 natural melee attack; on a hit the target must succeed a Might save (DC 10 + half damage taken) or be Partially Engulfed (Grappled, and 1 Disadvantage — Average Step — on attacks against anything but the ooze) until it escapes or the ooze moves away.", "", "", "Slime, Preservative"),
    ("Corrosive Body", "Ooze", "Corrosive", ["reaction"], "reaction",
     "The attacker must succeed a Fortitude save. On an odd failed result it takes Weak persistent acid damage; on an even one its gear corrodes, giving -1 Soak (Average Step) until it passes a DC 15 recovery check.",
     "It is hit by an attack from within 5 feet.", "Acid", "Slime, Toxic"),
    ("Cling and Feed", "Ooze", "Predatory", ["maneuver"], "1",
     "Make 1 natural melee attack; a damaged target must succeed a Might save or be Grappled. The first time each round it damages a creature it grapples, it gains 1d4+1 temporary HP (Weak damage + Weak Step), and the target must succeed a Fortitude save or suffer Weakened Grip equal to half that amount.", "", "Vitality", "Slime, Toxic"),
    ("Split Mass", "Ooze", "Splitting", ["triggered", "recharge"], "passive",
     "When first Bloodied, critically hit or destroyed, if charged it makes a DC 10 flat check (Fortune vs slashing or a vulnerability, Misfortune vs bludgeoning or a resistance). On a success: if destroyed, the result is even, or it's a Minion, it leaves a slime hazard (difficult terrain; entering requires a Reflex save or fall Prone); otherwise it splits off a sub-ooze one rank lower at the same level (starting uncharged).", "", "Vitality", "Slime, Preservative"),
    ("Invasive Coating", "Ooze", "Parasitic", ["maneuver"], "1",
     "Make 1 natural melee attack; a damaged target must succeed a Fortitude save (DC 10 + half damage taken) or be afflicted with Seeping Slime.", "", "Acid or Vitality", "Slime, Toxic"),
    ("Delayed Reveal", "Ooze", "Mimetic", ["passive"], "passive",
     "If it didn't move this turn, it may Hide while observed and without cover, with 1 Advantage (Average Step).", "", "", "Slime, Preservative"),
    ("Dragging Sludge", "Ooze", "Tarry / Sludge", ["passive"], "passive",
     "A 10-foot emanation (Average Magnitude) is difficult terrain; a creature starting its turn inside must succeed a Reflex save or become Clumsy 1 (Average Step).", "", "Motion", "Slime, Irritant"),
    ("Arcane Residue", "Ooze", "Luminous / Arcane", ["passive", "triggered"], "passive",
     "Fortune on saves against magic. When it takes an odd amount of damage it sheds residue into an adjacent square; casting while adjacent to or in residue imposes Misfortune on the Channeling check. Residue lasts until the ooze dies.", "", "Ward", "Crystal, Volatile"),
    # Outsider
    ("Celestial Radiance", "Outsider", "Celestial", ["trigger"], "passive",
     "Once per turn, when it hits with an attack that had at least 1 Advantage, it deals an extra Weak radiant damage.", "", "Radiance", ""),
    ("Infernal Brand", "Outsider", "Infernal", ["maneuver", "concentration"], "1",
     "1 visible enemy within Close must succeed a Charisma save or be Branded while it concentrates (up to 3 rounds). The Branded target's next save against it suffers 1 Disadvantage (Average Step), then the brand ends.", "", "Fire", ""),
    ("Abyssal Hunger", "Outsider", "Abyssal", ["passive"], "passive",
     "Once per round, a check it makes that targets a Bloodied creature gains 1 Advantage (Average Step).", "", "Blood", ""),
    ("Void Passage", "Outsider", "Void-Born", ["reaction", "recharge"], "reaction",
     "It rerolls the failed save with Fortune. On a success it may move up to half its Speed through occupied spaces and gaps one size smaller (Average Step), ending in a legal space.",
     "It fails a save against an effect that would pin, trap, bind, contain or move it.", "Space", ""),
    ("Spirit Form", "Outsider", "Spirit", ["passive"], "passive",
     "Lacks physical senses (Blindsense 15 feet, Strong Magnitude). Ignores difficult terrain and moves through occupied spaces. When a corporeal physical attack or action would hit it and the check result is odd, it fails. Ghost-touch bypasses this.", "", "Spirit", ""),
    ("Herald's Decree", "Outsider", "Heraldic", ["maneuver", "concentration"], "1",
     "1 creature within Near (Weak Step targets) that understands it must succeed a Charisma save or fall under its Decree while it concentrates (up to 3 rounds), suffering 1 Disadvantage (Average Step) on checks that target or oppose the herald.", "", "Mind, Ward", ""),
    ("Tempting Offer", "Outsider", "Tempting", ["maneuver", "recharge"], "1",
     "1 creature within Near (Average Step targets) that understands it must succeed a Charisma save or become Taken In 1 (Average Step).", "", "Mind", ""),
    ("Unstable Passage", "Outsider", "Exile / Wanderer", ["passive"], "passive",
     "Once per turn, after passing through an occupied space or solid object, its Speed increases by 10 feet (Average Magnitude) until the end of its turn. It can pass through both but can't end inside either.", "", "Space, Motion", ""),
    # Plant
    ("Plant Senses", "Plant", "All Plants", ["passive"], "passive",
     "Lacks sight and hearing; has Blindsense 10 feet (Strong Magnitude).", "", "", ""),
    ("Thorn Shelter", "Plant", "Thorned", ["passive", "triggered"], "passive",
     "An adjacent creature that hits it in melee must succeed a Reflex save: on an even failed result it takes Weak persistent bleed damage, otherwise it's Slowed 10 (Average Magnitude) until it uses Recover to clear the brambles.", "", "", "Wood, Preservative"),
    ("Root Snare", "Plant", "Rooted", ["passive"], "passive",
     "A 10-foot emanation (Average Magnitude) of roots and undergrowth is difficult terrain.", "", "", "Plant Fiber, Preservative"),
    ("Spore Bloom", "Plant", "Fungal", ["maneuver", "concentration"], "1",
     "A 5-foot emanation (Average Magnitude) around a point within Close fills with spores while it concentrates (up to 3 rounds). Creatures starting their turn in or entering it must succeed a Fortitude save or become Dazzled 1 (Average Step); if already Dazzled, they take Weak persistent poison damage instead.", "", "Death", "Spore, Poison"),
    ("Parasitic Tendrils", "Plant", "Parasitic", ["maneuver", "recharge"], "1",
     "Make 1 natural ranged attack within Close; on a hit the target must succeed a Fortitude save (DC 10 + half damage taken) or be afflicted with Infested.", "", "Blood", "Plant Fiber, Toxic"),
    ("Dormant Husk", "Plant", "Wooden", ["passive", "triggered"], "passive",
     "The first time each scene it drops to 0 HP it leaves a husk (object; Hardness 5, Durability 20, doubled per size above Medium). If the husk survives until the end of the next round, it reanimates nearby at half its maximum HP.", "", "Vitality", "Botanical, Preservative"),
    ("Bloom Lure", "Plant", "Blooming", ["passive"], "passive",
     "A 10-foot emanation (Average Magnitude) exposes breathing creatures that start their turn in or enter it to the Bloom Lure affliction.", "", "Mind, Vitality", "Botanical, Sedative"),
    ("Sleep Blossom", "Plant", "Blooming", ["maneuver", "recharge"], "1",
     "Each other breathing creature in a 10-foot emanation (Average Magnitude) is exposed to Sleep Pollen.", "", "Mind, Vitality", "Botanical, Sedative"),
    ("Withering Field", "Plant", "Blighted", ["maneuver", "concentration"], "1",
     "A 10x10 area (Average Magnitude) within Close fills with blight while it concentrates (up to 3 rounds). The first time each round a creature enters or starts its turn there, it must succeed a Fortitude save against its action check or become Withered.", "", "Death", "Botanical, Toxic"),
    # Undead
    ("Ghostly Phase", "Undead", "Ghostly", ["passive"], "passive",
     "Lacks sight, hearing, smell and taste (Blindsense 15 feet, Strong Magnitude, sensing the living, the dead and strong emotion). Ignores difficult terrain and moves through creatures and objects, but can't end inside them.", "", "Space", ""),
    ("Corpse-Bound", "Undead", "Corpse-Bound", ["reaction", "recharge"], "reaction",
     "Spend the charge and 1 RP to drop to 1 HP instead and gain 5 temporary HP (Average Magnitude).", "It would be reduced to 0 HP.", "Death", "Animal, Preservative"),
    ("Skeletal", "Undead", "Skeletal", ["passive"], "passive",
     "Resistance to piercing. Whenever it takes bludgeoning damage it becomes Off-Guard until the start of its next turn.", "", "Death", "Bone, Preservative"),
    ("Blood Drinker", "Undead", "Vampiric", ["maneuver"], "1",
     "Make 1 natural melee attack against a creature it's grappling. If it deals damage, it gains 5 temporary HP (Average Magnitude), doubled if the target is Bloodied.", "", "Blood", ""),
    ("Deathly Aura", "Undead", "Necrotic / Deathly", ["passive"], "passive",
     "A living creature starting its turn within a 5-foot emanation (Average Magnitude) must succeed a Fortitude save against its action check or become Withered.", "", "Death", ""),
    ("Shadow Shroud", "Undead", "Shadowed", ["passive"], "passive",
     "While partly concealed, Perception saves and Investigation checks to find it suffer an extra Disadvantage. While fully concealed, it gains an extra Advantage on attacks against creatures that can't see it (Average Step for both).", "", "Shadow", ""),
    ("Corpse Taint (Trait)", "Undead", "Plague-Ridden", ["passive"], "passive",
     "When it damages a living creature with a natural weapon, the target must succeed a Fortitude save (DC 10 + half damage taken) or be afflicted with Corpse Taint.", "", "Death", "Animal, Preservative"),
    # Vermin
    ("Anchoring Strand", "Vermin", "Webspinner", ["maneuver"], "1",
     "1 visible enemy within Close must succeed a Reflex save or be Slowed 10 (Average Magnitude) until it uses Recover to clear the webbing; its square becomes difficult terrain until cleared or the encounter ends.", "", "", "Plant Fiber, Preservative"),
    ("Paralytic Venom (Trait)", "Vermin", "Venomous", ["maneuver"], "passive",
     "When it damages a target with a natural weapon, the target must succeed a Fortitude save (DC 10 + half damage taken) or suffer Paralytic Venom.", "", "", "Organ, Toxic"),
    ("Chitinous Shell", "Vermin", "Carapaced", ["passive"], "passive",
     "+1 Soak (Average Step). Armor Piercing against it is reduced by 1 (Average Step).", "", "Ward", "Bone, Preservative"),
    ("Brood Release", "Vermin", "Brood-Bearing", ["reaction"], "reaction",
     "It drops a brood sac (object; Hardness 2 and Durability 10, scaled by Average Step/Magnitude and doubled per size above Medium) in an adjacent square. If not destroyed by the start of the next round it hatches: a non-Minion produces a creature of its type one rank lower at the same level; a Minion's sac bursts for Average necrotic damage in 5 feet (Reflex save negates).",
     "The first time it becomes Bloodied.", "Vitality", "Organ, Preservative"),
    ("Skittering Motion", "Vermin", "Leaping / Skittering", ["passive"], "passive",
     "Climb speed equal to its Speed; ignores difficult terrain from rubble, cracks, webs and debris. After moving 10+ feet to end adjacent to its target, its next melee attack against it gains 1 Advantage (Average Step).", "", "Motion", ""),
    ("Parasitic Cling", "Vermin", "Parasite", ["maneuver"], "1",
     "Make 1 natural melee attack; a damaged target must succeed a Might save (DC 10 + half damage taken) or be clung to. While clinging it moves with the target without provoking, gains 1 Advantage (Average Step) on melee attacks against it, and gains 5 temporary HP (Average Magnitude) the first time each round it damages it. One host at a time; the host can use Recover to remove it.", "", "Vitality", "Organ, Toxic"),
]
for (n, ctype, sub, traits, cost, text, trig, ess, ing) in ID:
    add(n, "identity", f"{ctype} — {sub}", [ctype.lower().replace(' ', '-'), *traits], cost, f"<p>{text}</p>", trigger=trig,
        essence=ess, ingredients=ing, recharge="recharge" in traits)

# ---------------------------------------------------------------- Role maneuvers
ROLE = [
    # Leader
    ("Direct Ally", "Leader", "Command & Positioning", ["maneuver"], "1", "1 ally within Close moves up to half its Speed and makes a baseline attack against a target of the Leader's choice as a reaction.", "", "Mind"),
    ("Rally the Line", "Leader", "Support", ["maneuver", "recharge"], "1", "The Leader and up to 2 allies (Strong Step) within Close that can see or hear it each gain 10 temporary HP (Strong Magnitude).", "", "Ward"),
    ("Focus Kill", "Leader", "Focus-Fire", ["maneuver", "concentration"], "1", "Choose 1 visible enemy within Close. For up to 3 rounds while concentrating, allies gain 1 Advantage on their first attack each round against it, dealing 1 extra damage die on a hit.", "", ""),
    ("Protect the Chosen", "Leader", "Protection & Sacrifice", ["reaction", "recharge"], "reaction", "The ally rerolls the triggering check with 1 Advantage (Average Step).", "An ally within Close that the Leader can see or hear is hit by an attack or fails a save.", "Ward"),
    ("Break Their Nerve", "Leader", "Fear / Coercion", ["maneuver"], "1", "Up to 2 enemies (Strong Step) within Close that can see or hear the Leader must succeed a Charisma save or become Frightened 1 (Average Step).", "", "Fear"),
    ("Advantageous Ground", "Leader", "Battlefield Setup", ["maneuver", "concentration"], "1", "Choose a 5-foot space (Average Magnitude) within Close. While the Leader concentrates, allies in it have partial cover against attacks from outside it.", "", "Ward"),
    ("Tactical Redeploy", "Leader", "Command & Positioning", ["maneuver"], "1", "Up to 2 allies (Strong Step) within Close that can see or hear the Leader may each move up to their Speed as a reaction, without triggering Move-trait reactions.", "", ""),
    ("Call Reinforcements", "Leader", "Reinforcement Command", ["maneuver", "recharge"], "1", "Place reinforcements adjacent to a doorway, breach, tunnel or similar within Close, worth up to half the Leader's rank value (Minion 0.25, Standard 1, Elite 2, Solo 4); none higher rank than the Leader, none above its level, and drawn from creatures already defined for the encounter. They act at the end of the round unless attacked first.", "", "Summon"),
    # Controller
    ("Force Lure", "Controller", "Position Control", ["maneuver"], "1", "Up to 2 visible enemies (Strong Step) within Close must succeed a Reflex save or be pulled up to 10 feet (Strong Magnitude) closer.", "", "Motion"),
    ("Warped Ground", "Controller", "Battlefield Setup", ["maneuver", "concentration"], "1", "A 10-foot area (Strong Magnitude) within Close becomes difficult terrain while the Controller concentrates. The first time a creature enters it, it must succeed a Reflex save or lose half its Speed; if that would take its remaining Speed below 0 it becomes Slowed 10 (Strong Magnitude) for the duration.", "", "Motion"),
    ("Withering Hex", "Controller", "Ongoing Debilitation", ["maneuver"], "1", "1 visible target (Average Step targets) within Close must succeed a Fortitude save or suffer Weakened Grip 2 (Strong Step).", "", "Death"),
    ("Blinding Veil", "Controller", "Warfare Confusion", ["maneuver"], "1", "1 visible enemy (Average Step targets) within Close must succeed a Perception save or become Dazzled 2 (Strong Step).", "", "Shadow or Mind"),
    ("Wave of Despair", "Controller", "Psychic Pressure", ["maneuver"], "1", "1 enemy (Average Step targets) within Close that can see or hear it must succeed a Charisma save or become Frightened 2 (Strong Step).", "", "Fear"),
    ("Mesmerizing Command", "Controller", "Enemy Command", ["reaction", "recharge"], "reaction", "The enemy must succeed a Charisma save or the Controller distorts the action: it picks the ending space of a move, or changes an attack's target to another legal target.", "An enemy within Close that can see or hear it performs a Move or Attack action.", "Mind"),
    ("Grasping Blast", "Controller", "Control Offense", ["maneuver"], "1", "Make 1 ranged attack; a damaged target must succeed a Reflex save (DC 10 + half damage taken) or be pulled up to 10 feet (Strong Magnitude) closer.", "", "Motion or Storm"),
    ("Swarm Release", "Controller", "Swarm Release", ["maneuver", "recharge"], "1", "Place 1 summoned creature, swarm or hazard of its level or lower (from its stat block) next to a suitable source within Close. It acts at the end of the round unless interacted with first.", "", "Vitality"),
    # Soldier
    ("Hold the Line", "Soldier", "Protection & Space Control", ["maneuver", "concentration"], "1", "Two 5-foot areas (Strong Step) within melee reach become difficult terrain while the Soldier concentrates.", "", "Ward"),
    ("Punishing Response", "Soldier", "Retaliation", ["reaction"], "reaction", "Make 1 melee weapon attack or unarmed strike against the enemy; if it deals damage, the enemy must succeed a Reflex save (DC 10 + half damage taken) or its movement ends.", "An enemy within melee reach performs a Move action.", ""),
    ("Intercepting Strike", "Soldier", "Protection & Space Control", ["reaction"], "reaction", "Make 1 weapon attack or unarmed strike against the enemy; on a success its triggering attack suffers 2 Disadvantage (Strong Step).", "An enemy within melee reach makes an attack that doesn't target the Soldier.", ""),
    ("Lockdown Strike", "Soldier", "Control Offense", ["maneuver"], "1", "Make 1 melee attack; a damaged target must succeed a Might save (DC 10 + half damage taken) or, until the Soldier's next turn, it can't leave the Soldier's reach without winning a Might save against the Soldier's action check.", "", ""),
    ("Close Ranks", "Soldier", "Team Tactics", ["reaction"], "reaction", "Up to 2 triggering allies (Strong Step) may each move up to half their Speed without provoking Move-trait reactions.", "Allies within Close end a move not adjacent to the Soldier or another ally.", ""),
    ("Stand Firm", "Soldier", "Defensive Recovery", ["reaction", "recharge"], "reaction", "Reroll the failed save with 2 Advantage (Strong Step).", "The Soldier fails a save, is knocked Prone, or would be moved against its will.", ""),
    ("Issue Challenge", "Soldier", "Morale Pressure", ["maneuver"], "1", "1 enemy (Average Step targets) within Close that can see or hear it must succeed a Charisma save or suffer 2 Disadvantage (Strong Step) on attacks that don't include the Soldier, until the end of its next turn.", "", "Mind"),
    ("Fearsome Cry", "Soldier", "Morale Pressure", ["reaction", "recharge"], "reaction", "The enemy must succeed a Charisma save against the Soldier's action check (rolled with Fortune) or become Frightened 2 (Strong Step).", "An enemy within Close that can see or hear the Soldier fails an attack against one of its allies.", "Fear"),
    ("Drive Them Back", "Soldier", "Control Offense", ["maneuver"], "1", "Make 1 melee weapon attack against up to 2 enemies (Strong Step) in reach; each damaged target must succeed a Might save (DC 10 + half damage taken) or be pushed 10 feet (Strong Magnitude).", "", ""),
    ("Sweeping Knockdown", "Soldier", "Multi-Target Offense", ["maneuver"], "1", "Make 1 melee weapon attack against up to 2 enemies (Strong Step) in reach; each damaged target must succeed a Reflex save (DC 10 + half damage taken) or fall Prone.", "", ""),
    # Brute
    ("Crushing Blow", "Brute", "Heavy Offense", ["maneuver", "recharge"], "1", "Make 1 melee weapon attack dealing 2 extra damage dice (Strong Step).", "", ""),
    ("Blood Frenzy", "Brute", "Bloodied Escalation", ["passive", "triggered"], "passive", "While Bloodied, its weapon attacks and unarmed strikes critically hit on a natural 19-20 (Strong Step widens the range: 3 means 18-20).", "", "Blood"),
    ("Violent Rush", "Brute", "Knockdown", ["maneuver"], "1", "Its Speed increases by 10 feet (Strong Magnitude) this turn. Make 1 weapon attack or unarmed strike; a damaged target must succeed a Might save (DC 10 + half damage taken) or be pushed up to 10 feet (Strong Magnitude) and fall Prone.", "", ""),
    ("Mauling Grab", "Brute", "Close-Quarters", ["maneuver"], "1", "Make 1 natural melee attack; a damaged target must succeed a Might save or become Grappled. The first time each round it damages a creature it grapples with a weapon attack, add 2 damage dice (Strong Step).", "", ""),
    ("Pain Ignorance", "Brute", "Stubborn Endurance", ["reaction", "recharge"], "reaction", "Reroll the failed save with 2 Advantage (Strong Step).", "It fails a save against an effect that would hamper its ability to attack, move or stay upright.", ""),
    ("Devastating Sweep", "Brute", "Wild Area Pressure", ["maneuver"], "1", "Make 1 melee attack against up to 2 enemies (Strong Step) in reach.", "", ""),
    ("Terrifying Presence", "Brute", "Terror of Force", ["maneuver", "recharge"], "1", "1 enemy within Close that can see or hear it must succeed a Charisma save or become Frightened 2 (Strong Step); with Misfortune if the Brute is Bloodied.", "", "Fear"),
    # Predator
    ("Predatory Strike", "Predator", "Ambush", ["maneuver"], "1", "Make 1 melee weapon attack; if it had at least 1 Advantage, add 2 damage dice (Strong Step).", "", ""),
    ("Hit and Fade", "Predator", "Hit-and-Run", ["maneuver"], "1", "Make 1 melee weapon attack; a damaged target must succeed a Perception save (DC 10 + half damage taken) or become Oblivious 2 (Strong Step) toward it, and its Speed rises by 10 feet (Strong Magnitude) this round. When it moves while a creature is Oblivious to it, that creature must succeed a Perception save or it becomes Hidden to them.", "", "Shadow"),
    ("Venomous Strike", "Predator", "Ongoing Predation", ["maneuver"], "1", "Make 1 melee weapon attack; a damaged target must succeed a Fortitude save (DC 10 + half damage taken) or take 1d4 persistent poison damage (Weak Step).", "", "", ),
    ("Vanishing Veil", "Predator", "Vanish", ["maneuver", "concentration"], "1", "Choose a 10x10 area within Close. While concentrating and inside it, the Predator is Concealed and may Hide even while observed.", "", "Shadow"),
    ("Seize the Prey", "Predator", "Predatory Control", ["maneuver"], "1", "Make 1 natural melee attack; a damaged target must succeed a Might save (DC 10 + half damage taken) or be Grappled and pulled up to 10 feet (Strong Magnitude) to a space of its choice, without spending Speed or provoking Move reactions.", "", ""),
    ("Hunting Dread", "Predator", "Fear Predation", ["maneuver"], "1", "1 enemy within Close that can see or hear it must succeed a Charisma save or become Frightened 2 (Strong Step); with Misfortune if the target is taking persistent damage from it or is Oblivious to it.", "", "Fear"),
    ("Shed the Shell", "Predator", "Predator Trickery", ["reaction", "recharge"], "reaction", "Reroll the failed save with 1 Advantage. On a success it is Concealed until the end of its turn and moves up to 10 feet (Strong Magnitude) for free, through occupied spaces and gaps one size smaller.", "It fails a save against being grabbed, moved against its will or restrained.", "", ),
    # Sniper
    ("Prepared Shot", "Sniper", "Precision Fire", ["readied"], "1", "Choose a visible enemy within range and a trigger (it moves without Disengaging, uses a Manipulate or Concentrate action, or attacks). Until the Sniper's next turn, the first time it happens the Sniper may attack it as a reaction, dealing 1 extra damage die (Average Step) on a hit.", "", ""),
    ("Pinning Shot", "Sniper", "Hindering Fire", ["maneuver"], "1", "Make 1 weapon attack; a damaged target must succeed a Reflex save (DC 10 + half damage taken) or have its Speed halved until the Sniper's next turn.", "", ""),
    ("Fall Back", "Sniper", "Sniper Positioning", ["reaction"], "reaction", "Move up to half its Speed without provoking movement reactions.", "An enemy ends movement within 10 feet (Strong Magnitude).", ""),
    ("Rapid Volley", "Sniper", "Rapid Fire", ["maneuver"], "1", "Make 2 ranged attacks against 1 enemy, combining the damage of all hits before Soak and Resistances.", "", ""),
    ("Covering Fire", "Sniper", "Support Fire", ["maneuver"], "1", "Choose an ally within Close and a visible enemy in range. Until its next turn, either the ally gains 2 Advantage (Strong Step) on melee attacks against that enemy, or the ally's movement doesn't provoke reaction attacks from it.", "", ""),
    ("Explosive Payload", "Sniper", "Bombardment", ["maneuver", "recharge"], "1", "Each creature in a 10-foot emanation (Strong Magnitude) around a point in range makes a Reflex save: half weapon damage on a success (none on a critical success), full on a failure (double on a critical failure).", "", "Explosive"),
    ("Hex Shot", "Sniper", "Hex Shot", ["maneuver"], "1", "Make 1 ranged weapon attack; a damaged target must succeed a Reflex save (DC 10 + half damage taken) or suffer 2 Disadvantage (Strong Step) on its next attack before the Sniper's next turn.", "", "Mind"),
    # Skirmisher
    ("Strike and Slip", "Skirmisher", "Mobile Assault", ["reaction"], "reaction", "Double its Speed until the start of its next turn.", "It hits an enemy with a melee attack.", "Motion"),
    ("Opportunist Strike", "Skirmisher", "Opportunist Pressure", ["reaction", "recharge"], "reaction", "Add 2 damage dice (Strong Step) to the triggering attack.", "It hits with a melee attack after moving at least 10 feet.", ""),
    ("Tactical Withdrawal", "Skirmisher", "Sneaky Positioning", ["reaction"], "reaction", "Move 10 feet (Strong Magnitude) away without provoking Move-trait reactions.", "An enemy ends its turn within its melee reach.", ""),
    ("Harrying Shot", "Skirmisher", "Harassing Attacks", ["maneuver"], "1", "Make 1 ranged weapon attack; a damaged target must succeed a Perception save (DC 10 + half damage taken) or become Dazed until it recovers.", "", ""),
    ("Phase Skip", "Skirmisher", "Mobility Trickery", ["maneuver"], "1", "Until its next turn it moves through occupied spaces, gaps one size smaller and hindering terrain without provoking movement reactions, ending in a legal space.", "", "Space"),
    ("Distracting Burst", "Skirmisher", "Distraction", ["maneuver"], "1", "1 enemy within Close that can see or hear it must succeed a Perception save or become Dazzled 2 (Strong Step).", "", "Mind"),
    ("Scattering Rush", "Skirmisher", "Scatter Attack", ["maneuver"], "1", "It rushes along a 10-foot line (Strong Magnitude) and makes 1 melee weapon attack; each enemy in the line must succeed a save against the attack roll or take its weapon damage.", "", ""),
]
for r in ROLE:
    n, role, group, traits, cost, text, trig, ess = (list(r) + [""] * 8)[:8]
    add(n, "role", f"{role} — {group}", [role.lower(), *traits], cost, f"<p>{text}</p>", trigger=trig, essence=ess, recharge="recharge" in traits)

# ---------------------------------------------------------------- Generic
GEN = [
    ("Hawk's Eye", "Senses", ["maneuver"], "1", "Gains 1 Advantage (Weak Step) on Perception checks. After it spots a hidden or undetected creature, it and its allies gain 1 Advantage (Weak Step) on attacks against that creature until the end of the next round.", "", "Sight"),
    ("Adaptive Resistance", "Defense", ["reaction", "recharge"], "reaction", "Choose a damage type (acid, cold, fire, lightning, thunder…); it gains Resistance to it until the start of its next turn.", "It would take damage of the chosen type.", "Same as damage type"),
    ("Last-Second Dodge", "Defense", ["reaction", "recharge"], "reaction", "Reroll the failed save with 1 Advantage against the triggering attack.", "It fails a save against an Attack action.", ""),
    ("Shake It Off", "Defense", ["reaction", "recharge"], "reaction", "Reroll the failed save with 1 Advantage (Weak Step). While charged, it also has Fortune on recovery checks against Lingering conditions.", "It would fail a save against a condition-imposing effect.", "Resilience"),
    ("Hold Fast", "Generic Control", ["maneuver"], "1", "Make 1 natural melee attack; a damaged target must succeed a Might save (DC 10 + half damage taken) or become Grappled.", "", ""),
    ("Hampering Strike", "Generic Control", ["maneuver"], "1", "Make 1 melee weapon attack; a damaged target must succeed a Reflex save or be Slowed 5 (Weak Magnitude) until the end of its next turn.", "", ""),
    ("Lingering Wound", "Generic Control", ["maneuver"], "1", "Make 1 melee weapon attack; a damaged target must succeed a Fortitude save or take 1d4 persistent damage (Weak quality) of a fitting type.", "", "Same as damage type"),
    ("Rattling Strike", "Generic Control", ["maneuver"], "1", "Make 1 melee weapon attack; a damaged target must succeed a Fortitude save or suffer Weakened Grip 1 (Weak Step).", "", ""),
    ("Double Attack", "Multiattack", ["maneuver"], "1", "Make 1 weapon attack; if it hits, make 1 more (Weak Step additional attacks in sequence) against the same enemy, combining damage before Soak and Resistances.", "", ""),
    ("Follow-Through", "Multiattack", ["maneuver"], "1", "Make 1 melee weapon attack against 2 enemies in reach; if it misses one, the attack against the other gains 1 Advantage (Weak Step).", "", ""),
    ("Press the Opening", "Multiattack", ["reaction"], "reaction", "Make another attack against the same creature.", "It misses an attack that had at least 1 Advantage.", ""),
    ("Bursting Wave", "Area Burst", ["maneuver"], "1", "Each enemy in a 5-foot emanation (Weak Magnitude) must succeed a Reflex save or take Weak damage of a fitting type.", "", "Same as damage type"),
    ("Hurl Payload", "Area Burst", ["maneuver"], "1", "Each enemy in a 5-foot emanation (Weak Magnitude) around a point within Close must succeed a Reflex save or take Weak damage of a fitting type.", "", ""),
    ("Gang Up", "Group", ["passive"], "passive", "Once per turn, attacking a target adjacent to one of its allies grants 1 Advantage (Weak Step).", "", ""),
    ("Stick Together", "Group", ["reaction"], "reaction", "Move up to 5 feet (Weak Magnitude) toward the ally.", "An ally ends its movement no longer adjacent to it.", ""),
    ("Brace Together", "Group", ["passive"], "passive", "Once per turn while adjacent to an ally, gain 1 Advantage (Weak Step) on a save or check to resist being grabbed, knocked Prone or moved.", "", ""),
    ("Pile On", "Group", ["reaction"], "reaction", "Make a baseline attack against the enemy.", "An adjacent ally hits an enemy that is also adjacent to it.", ""),
    ("Shifty", "Mobility", ["passive"], "passive", "The first 5 feet it moves each turn doesn't provoke movement reactions.", "", ""),
    ("Slip Away", "Mobility", ["reaction"], "reaction", "Move up to 5 feet (Weak Magnitude) away without provoking movement reactions.", "It is missed by a targeted attack.", ""),
    ("Glancing Escape", "Mobility", ["reaction"], "reaction", "Attempt a Reflex save (DC 10 + half the attack's damage). On a success, gain Resistance to that damage and move up to 5 feet (Weak Magnitude) without provoking.", "It would take damage from an attack.", ""),
    ("Mystical Step", "Mobility", ["maneuver"], "1", "Teleport to an unoccupied space it can perceive within 5 feet (Weak Magnitude).", "", "Space"),
]
for n, group, traits, cost, text, trig, ess in GEN:
    add(n, "generic", f"Generic — {group}", ["generic", *traits], cost, f"<p>{text}</p>", trigger=trig, essence=ess, recharge="recharge" in traits)

# ---------------------------------------------------------------- Morale traits (as items for GM reference)
MORALE = [
    ("Disciplined", "With a visible or audible leader, morale checks are made with Fortune."),
    ("Elite Nerve", "Morale checks always have Fortune; once per fight ignore an effect forcing Misfortune."),
    ("Green / Untrained", "The first morale check is made with Misfortune."),
    ("Cowardly", "The first time Morale Edge drops below 0, it drops 1 further (once per fight)."),
    ("Fanatical", "Intimidation can't force Misfortune. The first crack becomes a reckless attack for 1 round instead; check again at the next trigger."),
    ("Unbreakable", "No morale checks unless its anchor creature is removed — then checks are made with Misfortune."),
    ("Leader-Dependent", "If the leader drops, ME -2 and the next check has Misfortune."),
    ("Inspiring Leader", "Once per fight, when the Group would crack, reroll the check."),
    ("Tight Formation", "While formation holds, a failed check breaks 1 fewer Element (minimum 1)."),
    ("Loose Rabble", "A failed check breaks 1 additional Element."),
    ("Pack Instinct", "ME +1 if locally outnumbering the party; ME -1 if outnumbered (once per fight)."),
    ("Mercenaries", "The first casualty is an extra -1 ME; a bribe or exit offer makes the next check Misfortune."),
    ("Defending Home", "ME +1 until the objective is breached; -2 once it is."),
    ("Predators (Morale)", "Dropping a PC is ME +1 (max once per round)."),
    ("Treasure-Hungry", "Near loot, checks have Fortune; losing loot is -1 ME."),
    ("Skittish", "The first terrifying display is an extra -1 ME."),
    ("Fearless", "Ignore the first fear or intimidation effect that would force Misfortune."),
    ("Battle-Hardened", "The first casualty doesn't reduce ME."),
    ("Guerrillas", "The first time it breaks, it disengages, repositions or hides instead of fleeing or surrendering."),
    ("Cornered", "On a break with no escape, replace Flee with Surrender or Rage."),
    ("Escape Plan", "When breaking to withdraw, escape and disengage checks have Fortune."),
    ("Bodyguards", "ME +1 while their VIP lives; ME -2 if the VIP drops."),
]
for n, t in MORALE:
    add(n, "morale", "Morale Trait", ["morale"], "passive", f"<p>{t}</p>")


def entries():
    out = []
    folder = {"baseline": "Baseline Attacks", "swarm": "Minion", "elite": "Elite Actions", "solo": "Solo Package",
              "identity": "Identity Traits", "role": "Role Maneuvers", "generic": "Generic Maneuvers", "morale": "Morale Traits"}
    img = {"baseline": "icons/skills/melee/strike-slashes-red.webp", "swarm": "icons/creatures/invertebrates/bug-sixlegged-gray.webp",
           "elite": "icons/magic/control/buff-strength-muscle-damage-orange.webp", "solo": "icons/magic/death/skull-horned-worn-fire-blue.webp",
           "identity": "icons/creatures/abilities/dragon-breath-purple.webp", "role": "icons/skills/social/intimidation-impressing.webp",
           "generic": "icons/skills/movement/feet-winged-boots-brown.webp", "morale": "icons/skills/social/diplomacy-handshake-yellow.webp"}
    for m in M:
        desc = ""
        if m["trigger"]:
            desc += f"<p><strong>Trigger:</strong> {m['trigger']}</p>"
        desc += m["text"]
        if m["essence"] or m["ingredients"]:
            desc += f"<p><strong>Crafting Tags —</strong> Essence: {m['essence'] or 'none'}; Ingredients: {m['ingredients'] or 'none'}</p>"
        sub = m["group"]
        role = sub.split(" — ")[0].lower() if m["cat"] == "role" else ""
        ctype = sub.split(" — ")[0] if m["cat"] == "identity" else ""
        sys = {"category": m["cat"], "role": role, "creatureType": ctype, "actionTraits": m["traits"], "cost": m["cost"],
               "trigger": m["trigger"], "passive": m["cost"] == "passive", "description": desc,
               "recharge": {"enabled": m["recharge"], "threshold": 0, "charged": True},
               "roll": {"type": m["roll"].get("type", ""), "damage": m["roll"].get("damage", ""), "damageType": m["roll"].get("damageType", ""),
                        "skill": "", "ability": "", "save": "", "dc": "", "bonus": 0},
               "tags": [sub]}
        sub_folder = sub.split(" — ")[0] if m["cat"] in ("identity", "role") else None
        out.append({"name": m["name"], "type": "maneuver", "img": img[m["cat"]], "folder": folder[m["cat"]],
                    "subfolder": sub_folder, "system": sys})
    return out


# ---------------------------------------------------------------- Creature afflictions
AFFLICTIONS = [
    ("Brood Parasite", "parasite", "", "Implanted parasite", "Immediate", "3 rounds",
     ["Drowsy", "Stupefied 1 and 1 Disadvantage (Weak Step) on checks and saves against the creature's brood or psychic effects", "Stupefied 1 and Fascinated by the creature"]),
    ("Hunter's Venom", "poison", "paralytic", "Injury", "Immediate", "3 rounds",
     ["Weakened Grip 1", "Weakened Grip 2", "Weakened Grip 2 and Slowed 5 (Weak Step / Weak Magnitude)"]),
    ("Witchbrain Venom", "poison", "neurotoxin", "Injury", "Immediate", "3 rounds",
     ["Sickened 1", "Sickened 1; Concentrate actions cost 1 extra AP", "Sickened 2; Misfortune on Perception and Channeling checks"]),
    ("Seeping Slime", "poison", "paralytic", "Injury", "Immediate", "3 rounds",
     ["Sickened 1", "Sickened 1 and Clumsy 1", "Sickened 2 and Slowed 10 (Average Step / Average Magnitude)"]),
    ("Infested", "parasite", "", "Injury", "Immediate", "None",
     ["When the victim regains HP or temporary HP it gains only half; if the plant is within Close it gains the other half (overflow becomes temporary HP)", "Same effect", "Same effect"]),
    ("Bloom Lure", "poison", "paralytic", "Inhaled (DC 15 + level)", "Immediate", "3 rounds",
     ["Lured (moving away from the source requires a Charisma save, DC 15 + source level, or the move fails and costs half its Speed)", "Lured and Slowed 10 (Average Magnitude)", "Lured and Oblivious 1 (Average Step)"]),
    ("Sleep Pollen", "poison", "paralytic", "Inhaled (DC 15 + level)", "Immediate", "3 rounds",
     ["Drowsy and Clumsy 1", "Drowsy, Slowed 10 and Clumsy 2", "Drowsy, Slowed 20 and Clumsy 3"]),
    ("Corpse Taint", "disease", "necrotoxin", "Injury (DC 15 + level)", "Immediate", "3 stages",
     ["Sickened 1", "Sickened 1 and Drained 1", "Sickened 2 and Drained 1 (conditions from Corpse Taint can't be recovered while it persists)"]),
    ("Paralytic Venom", "poison", "paralytic", "Injury (DC 15 + level)", "Immediate", "None",
     ["Slowed 10", "Slowed 20", "Stunned"]),
]


def afflictions():
    out = []
    for n, t, fam, vec, onset, dur, stages in AFFLICTIONS:
        out.append({"name": n, "type": "affliction", "img": "icons/consumables/potions/bottle-round-corked-green.webp" if t == "poison" else "icons/creatures/invertebrates/worm-brown.webp",
                    "folder": "Creature Afflictions",
                    "system": {"afflictionType": t, "family": fam, "vector": vec, "onset": onset, "maxDuration": dur,
                               "save": {"ability": "fortitude", "dc": 0},
                               "stages": [{"text": s, "duration": "1 round"} for s in stages],
                               "description": f"<p>Delivered by an adversary ability. Save: Fortitude (DC per the delivering effect, or 15 + creature level). Stage interval 1 round.</p><ol>{''.join(f'<li>{s}</li>' for s in stages)}</ol>"}})
    return out
