"""Character Creation chapter: origins, genetic talents/drawbacks, cosmetics, virtues & vices, roll tables. Condensed / paraphrased."""

ORIGIN_IMG = {
    "Arcanist": "icons/sundries/books/book-embossed-blue.webp", "Entertainer": "icons/tools/instruments/lute-gold-brown.webp",
    "Farmer": "icons/tools/hand/pitchfork-steel-grey.webp", "Doctor": "icons/tools/cooking/mortar-herbs-yellow.webp",
    "Hunter": "icons/weapons/bows/shortbow-recurve.webp", "Soldier": "icons/equipment/head/helm-barbute-engraved.webp",
    "Monastic": "icons/equipment/neck/necklace-simple-carved-spiral-red.webp", "Politician": "icons/sundries/documents/document-sealed-signatures-red.webp",
    "Privateer": "icons/weapons/guns/gun-pistol-flintlock-metal.webp", "Cultist": "icons/sundries/lights/candle-lit-red.webp",
    "Criminal": "icons/equipment/head/mask-plague-leather-brown.webp", "Mad Scientist": "icons/tools/laboratory/vials-blue-pink.webp",
}

# name: (ability or choices, talent, skills, summary, equipment, feature(name, text), specialty(label, die, [options]),
#        quirks(8), ideals(6), pledges(6), flaws(6))
ORIGINS = {
    "Arcanist": (["intellect"], "Spell Attunement I", ["mysticism", "crafting"],
        "Apprenticed to a mage or arcane school, you learned the language of magic, disciplined study, and the practical craft that keeps spells stable.",
        ["Apprentice robes or travel clothes with an arcane mantle", "Artisan's tools (your choice)", "Notebook of diagrams and formulas", "Component pouch (chalk, ink, sand, twine)", "15 gp"],
        ("Apprentice Access", "Arcane-friendly circles will usually give you basic shelter, archive access, or an introduction to a local hedge mage, and you can trade a few hours of menial lab work for workspace. This covers apprentice-tier help, not free spells or rare secrets."),
        ("Specialty", "1d6", ["Scrolls and warding circles", "Battlefield evocation", "Transmutation craft", "Alchemy and reagents", "Illusion and stagecraft", "Summoning theory"]),
        ["Takes notes even in danger", "Corrects sloppy magical thinking", "Locked doors are a personal insult", "Treats tools with reverence", "Calm when things get weird", "Shows off small harmless magic", "Respects study over talent", "Dreads mispronouncing a word of power"],
        ["Knowledge", "Discipline", "Innovation", "Responsibility", "Freedom", "Perfection"],
        ["Won't disappoint the mentor who saved me", "Someone wants my page of forbidden research back", "I owe an arcane guild favors", "Searching for a vanished fellow apprentice", "My treasured tools were lost or broken", "I carry a world-changing prototype"],
        ["Overprepared for order, unprepared for chaos", "Defensive about my expertise", "Tempted by dangerous shortcuts", "Freeze when a spell goes wrong", "Experiment at the worst moments", "Keep secrets even from allies"]),
    "Entertainer": (["charisma"], "Virtuosic Performer", ["perform", "society"],
        "You live for an audience, moving crowds to laughter, tears or fury with your art.",
        ["A musical instrument", "An admirer's token", "A costume", "15 gp"],
        ("By Popular Demand", "You can always find somewhere to perform. Where you perform nightly you get free modest or comfortable room and board, and townsfolk who recognize you tend to like you."),
        ("Routines", "1d10", ["Actor", "Dancer", "Fire-eater", "Jester", "Juggler", "Instrumentalist", "Poet", "Singer", "Storyteller", "Tumbler"]),
        ["Has a story for everything", "Collects and spreads local gossip", "Hopeless romantic", "Defuses any tension", "Loves a good insult, even at me", "Sulks when not the center of attention", "Accepts nothing but perfection", "Mood shifts like a key change"],
        ["Beauty", "Tradition", "Creativity", "Greed", "People", "Honesty"],
        ["My instrument reminds me of a loved one", "My stolen instrument must be recovered", "Fame at any cost", "I measure myself against an old hero", "Must outshine my rival", "Loyal to my old troupe"],
        ["Will do anything for renown", "Weak for a pretty face", "A scandal keeps me from home", "A mocked noble wants my head", "My sharp tongue causes trouble", "Unreliable to my friends"]),
    "Farmer": (["fortitude"], "Train Animal", ["athletics", "nature"],
        "Like most common folk, you worked the land for a lord, a company or your family: long, dirty, exhausting days raising living things.",
        ["Farm implement (pitchfork or shovel)", "Work clothes", "Wide-brimmed hat", "Sack of trade goods worth 5 gp", "10 gp"],
        ("Of the Land", "Without formal schooling you still read the sky: you track time and date, predict the weather hours or days ahead, and understand the basic needs and patterns of living things."),
        ("Specialization", "1d6", ["Rancher (livestock for meat and hides)", "Grazier (milk, eggs, wool)", "Stockman (bred working animals)", "Peasant (crops and orchards)", "Forester (timber trees)", "Silk (exotic silk producers)"]),
        ["Early to bed, early to rise", "Keeps gear in careful order", "Speaks with a strong drawl", "Saves every coin", "Just does the work", "Tracks sun, moon and seasons", "Naps in the sun", "Always chewing something"],
        ["Fill the Need", "It's a Living", "Brutal Practicality", "Hard Work", "A Simple Life", "Amusement"],
        ["Want to raise a big family", "Never forget the family farm", "Will own my own land", "Prove I'm the best at my trade", "Find my child lost to war", "Homestead the frontier"],
        ["Sneaks off to nap", "Sheltered and naive", "Blindly obeys nobility", "Fled taxes or conscription", "Overindulges when flush", "Shows off to attractive folk"]),
    "Doctor": (["intellect"], "Battle Medicine", ["medicine", "investigation"],
        "Apothecary, shaman or field medic, you heal through knowledge and procedure rather than faith, and moral temptation follows those who hold life in their hands.",
        ["Bedroll and blanket", "2-person tent", "Notes on your specialty", "Common clothes", "Healer's tools", "15 gp"],
        ("This Ought to Help", "Choose a non-humanoid creature type: you know what helps and harms it, can extrapolate to new species, and owners of valued beasts (steeds, familiars) respect you greatly."),
        ("Field of Practice", "1d6", ["Shaman (ancestral remedies)", "Modern (family medicine)", "Plague (humors, leeches, surgery)", "Holistic (home remedies, acupuncture)", "Cosmic (energies, stones, meditation)", "Folk (poultices and brews)"]),
        ["Obsessed with lives saved and lost", "Practices for faith, nation or clan", "Cold and calculating", "Hands go automatic in a crisis", "Strong opinions on magical healing", "At war with death itself", "Awed by the living body", "Active in medical debate"],
        ["Life", "Oath", "Vigilantism", "Profit", "Survival", "Right"],
        ["My village paid for my schooling", "Pushed into medicine by family", "My professor is everything", "Every lost patient haunts me", "Someone died of something treatable", "Self-taught from hard-won texts"],
        ["Took the healer's vow too lightly", "Have broken my promises before", "Contempt for many patients", "Think I'm better than other doctors", "Go too far chasing knowledge", "Sickened by suffering"]),
    "Hunter": (["reflex"], "Experienced Tracker", ["survival", "stealth"],
        "You've honed your hunting to a fine edge—habitats, feeding patterns, the right trap for the right quarry—whether for your town's table, for sport, or to survive.",
        ["Shortbow with 20 arrows", "Compass", "Notebook of local game", "Trinket from your first kill"],
        ("Hunter's Quarry", "In most habitable places you can hunt enough to feed up to ten people a day, or sell the catch for fair coin (GM permitting)."),
        ("Hunting Grounds", "1d6", ["Arctic", "Desert", "Forest", "Mountain", "Plains", "Swamp"]),
        ["Records every creature", "Hunting is only survival", "Lives for the thrill", "Respects those who respect the work", "There's always a bigger catch", "Hunts for hire"],
        ["Perfectionist", "Ecologist", "Honorable", "Unworthy", "Inescapable", "Enjoyable"],
        ["Make my mentor proud", "Cherish my first-hunt trinket", "Find the beast that marked me", "Still thrilled by the village-saving hunt", "Fill in a researcher's missing notes", "Feed the hungry as I once was"],
        ["Curiosity gets me in messes", "Must document every creature", "Protect my notes at any cost", "Burn out after the hunt", "Ignore the party for a new creature", "Feel the hunt's thrill fighting people"]),
    "Soldier": (["might", "reflex"], "Rugged", ["athletics", "firearms|meleeWeapons|missileWeapons"],
        "War has been your life—drilled young, trained with arms and armor, taught to survive the battlefield in an army, mercenary company or militia.",
        ["Not listed in the source — agree on appropriate gear with your GM"],
        ("Fellow at Arms", "Your military bearing earns respect: you can forge friendly ties with other military factions and request sanctuary or safe passage, especially from your own organization."),
        ("Specialty", "1d8", ["Officer", "Scout", "Infantry", "Cavalry", "Medic", "Quartermaster", "Standard bearer", "Support staff"]),
        ["Stern and polite", "Haunted by the war", "Slow to make friends", "Has a war story for everything", "Unshakable resolve", "Likes being in charge", "Very dark humor", "Prefers simple, direct solutions"],
        ["Co-existence", "Greater Good", "Duty", "Might", "Independence", "Responsibility"],
        ["Would die for my old comrades", "Never leave a friend behind", "My honor is my life", "Justice for a lost battle", "Companions matter more than me", "Fight for those who can't"],
        ["Terrified of one enemy", "Scorn those who can't fight", "Secret fatal mistake", "Blind battle rage", "Obey any law, however cruel", "Never admit a mistake"]),
    "Monastic": (["reflex", "might"], "Grappler|Powerful Fist", ["martialArts", "stealth"],
        "Brought to the monastery young, you barely remember any other life than training beside your brothers and sisters.",
        ["Calligraphy tools", "Monastic symbol (beads, ring or necklace)", "Clothes", "15 gp"],
        ("Monastic Influence", "Your insignia tells those who know your order who you are—earning respect, shelter and aid from friends of the monastery, or making you a target for its foes."),
        None,
        ["A leaf on the wind", "A mountain for my friends", "A still forest lake", "A living flame", "Balance in all things", "Shattered, seeking peace", "Solves problems with a kick", "Secretly unenlightened"],
        ["Brotherhood", "Pacifist", "Traditions", "Power", "Unchained", "Meditation"],
        ["Stand with my order", "Bring enlightenment to others", "The strong protect the weak", "Blame myself for a brother's death", "Bring balance to the land", "Wonder who my parents were"],
        ["Must meditate thrice daily", "Flustered around certain people", "Panic in big cities", "No respect for the self-disrespecting", "Left my master after a fight", "Companions must meditate with me"]),
    "Politician": (["charisma"], "Charming Liar|Group Impression", ["diplomacy", "deception"],
        "Where people chase power, politics follows. You learned how the world is really run and put on a public face to seize some of it.",
        ["Fine clothes", "Fancy ring (5 gp)", "A manifesto you co-wrote", "20 gp"],
        ("Political Presence", "People take you for someone of standing, often assuming noble blood; nobles and officials readily grant you audiences as one of their own."),
        ("Ideology", "1d6", ["Democracy", "Dictatorship", "Egalitarianism", "Anarchy", "Monarchy", "Theocracy"]),
        ["Craves attention", "Only I can fix the world", "The current regime must go", "The people's guiding hope", "Out for myself", "Patient and unreadable", "Above the uncultured", "Just shaking things up"],
        ["Dictator", "Equality", "Humanity", "Self-Interest", "Legacy", "Divine Rule"],
        ["Promised my family I'd change the world", "Others are means to my ends", "Remember the better old days", "Unity for the common good", "Collect connections", "Help now, favors later"],
        ["Compulsive liar", "Very indecisive", "Cruel methods, good intentions", "Let others fight for me", "Secret stage fright", "A career-ending scandal"]),
    "Privateer": (["perception"], "Instinctive Shooting", ["survival", "firearms"],
        "You came of age under a ruthless captain, raiding on the high seas. Bloodshed is familiar, and many port towns know your name—not fondly.",
        ["Not listed in the source — agree on appropriate gear with your GM"],
        ("Bad Reputation", "People fear you. In civilized settlements you can get away with minor offenses—skipping a tavern bill, kicking in a shop door—because few dare report you."),
        None,
        ["Always reliable to friends", "Work hard, play hard", "New port, new friends", "Stretch the truth for a story", "Brawls are introductions", "Never refuse a wager", "Foul-mouthed", "Happy to delegate the work"],
        ["Respect", "Fairness", "Freedom", "Mastery", "People", "Aspiration"],
        ["Captain first, everything else second", "The ship matters most", "Never forget my first ship", "A sweetheart in a harbor town", "Cheated of my share", "Revenge on the pirates who left me to die"],
        ["Follow even wrong orders", "Dodge extra work", "Can't back down from a dare", "Can't stop drinking", "Pocket loose valuables", "Pride will be my ruin"]),
    "Cultist": (["charisma"], "Charming Liar", ["deception", "society"],
        "You once served a cult—of a dark power or a mere fanatic—and did terrible things under its sway. You broke free and now seek a new life.",
        ["Traveler's clothes", "Your cult's identifying mark", "Dagger", "Scroll of a minor ritual", "Pack of candles", "15 gp"],
        ("The Black Sheep", "You readily spot members of cults like yours, and people with similar patterns of manipulation or dependency. Some former brethren may not know you defected and could still offer you shelter."),
        ("Cult Identification", "1d6", ["Markings (tattoos, brands)", "Ritual disfigurement", "Accessories (rings, medallions)", "Distinctive clothing", "Passwords or signs", "Several—roll twice (reroll 6s)"]),
        ["Nightmares of the past", "Explodes when given orders", "Paralyzed by choices", "Tempted to return", "Unclear on boundaries", "Sudden mood swings", "Seeks suffering as atonement", "Sees assassins everywhere"],
        ["Protective", "Nihilist", "Repentant", "Anarchist", "Faithful", "Selfish"],
        ["Can't part with a stolen relic", "Responsible for those I freed", "A loved one still follows the cult", "Revenge on the leader", "Save youths from fanaticism", "No one may know my past"],
        ["Hear commanding voices", "Lose touch with reality", "Seek pain as penance", "Still carry an unfulfilled task", "A lingering craving from cult rituals", "Dread killing again"]),
    "Criminal": (["reflex"], "Pickpocket", ["sleightOfHand", "thievery"],
        "Thief, smuggler, forger or worse—you've lived outside the law, and your nerve with desperate contacts makes you valuable to profit-minded adventurers.",
        ["Not listed in the source — agree on appropriate gear with your GM"],
        ("Criminal Contact", "A reliable liaison connects you to a criminal network. You know the couriers, crooked caravan masters and sailors who can carry your messages far."),
        ("Specialty", "1d8", ["Blackmailer", "Burglar", "Enforcer", "Fence", "Highway robber", "Hired killer", "Pickpocket", "Smuggler"]),
        ["Always has a backup plan", "Never loses composure", "Cases every room", "Prefers friends to enemies", "Very slow to trust", "Ignores the odds", "Dare me and I'll do it", "Explodes at insults"],
        ["Honor", "Freedom", "Charity", "Greed", "People", "Redemption"],
        ["Repaying a benefactor", "My take feeds my family", "Stealing back what's mine", "Become the greatest thief", "Atoning for a terrible crime", "Never repeat a fatal mistake"],
        ["Can't resist valuables", "Money over friends", "Forget or ignore the plan", "Have a tell when lying", "Run when it looks bad", "Let an innocent take my fall"]),
    "Mad Scientist": (["intellect"], "Alchemical Crafting", ["investigation", "crafting"],
        "The fools can't grasp your work! You're always one breakthrough from unlocking life, death or reality itself—and it will never be enough.",
        ["Common clothes", "Lab coat and protective gear", "Alchemist's tools", "10 empty bottles", "Research notes", "A warrant for your arrest", "15 gp"],
        ("Efficacy Enhancer", "With at least an hour of work and supplies you can alter potions and poisons: delay or subtle their effects, change color or texture, or sometimes boost them (up to one die). Work out stronger alterations with the GM."),
        None,
        ["Bow to no master, not even physics", "Widen the cracks in reality", "Addicted to discovery", "Break free of lesser minds", "Nothing matters—make meaning", "Crave power above all", "Teach the next generation", "Magic is fake, and I'll prove it"],
        ["Power", "Light", "Arcana", "Puppetry", "Supremacy", "Rule-breaking"],
        ["Must prevent a future I've seen", "My creations are sacred", "Long for a family", "Pay my mentor's lessons forward", "Animals are my true friends", "Friends? I'll build some"],
        ["Unethical experiments", "Tactlessly smartest in the room", "Always right, end of story", "Can't form attachments", "Enraged by inferior meddlers", "Respect no law of any kind"]),
}

GENETIC_TALENTS = [
    ("Small Stature", "1 Advantage on Stealth and on checks to escape a grapple, and 1 Advantage on attacks against larger creatures while an ally is within 5 ft."),
    ("Large Stature", "Count as one size larger for your Bulk limit, unarmed damage and weapon size limit."),
    ("Claws", "Natural slashing attack: 1d4 Small, 1d6 Medium, 1d8 Large."),
    ("Bite Attack", "Natural piercing attack: 1d4 Small, 1d6 Medium, 1d8 Large."),
    ("Spike Tail", "Natural piercing or bludgeoning attack (choose): 1d6 Small, 1d8 Medium, 1d10 Large."),
    ("Prehensile Tail", "A tail that can hold and manipulate simple objects and let you hang indefinitely. It can't attack, fire weapons or do fine work."),
    ("Thermal Vision", "A second pupil sees heat in grayscale. Switching pupils takes an action."),
    ("Horns", "Gore natural attack, piercing or bludgeoning (choose): 1d8 Small, 1d10 Medium, 1d12 Large."),
    ("Swim Speed", "Swim Speed equal to your Speed."),
    ("Wings", "With both arms free, slow falls to 10 ft/round. Level 5: glide 15 ft horizontally per round. Level 9: fly Speed equal to Speed (Average maneuverability). Level 13: Perfect maneuverability and hover (still spending an action to hold altitude)."),
    ("Burrow Speed", "Burrow through soft soil, sand or gravel at your Speed."),
    ("Climb Speed", "Climb Speed equal to your Speed."),
    ("Gills", "You can breathe underwater."),
    ("Dermal Plating", "Interlocking plates add your Fortitude score to your Soak."),
    ("Lucky", "When you spend a Fate Die on a skill check, roll it twice and keep the higher."),
    ("Big Brained", "You are trained in 2 skills of your choice."),
    ("Chameleon Skin", "Shift your skin to match your surroundings: 1 Advantage on Stealth (+1 at levels 5, 9, 13 and 17) while most of your skin is exposed, and you may attempt Stealth even while observed."),
    ("Venomous", "Secrete a poison with Potency of half your Fortitude + your level. Type d6: 1 Hemotoxin, 2 Neurotoxin, 3 Necrotoxin, 4 Caustic, 5 Paralytic, 6 Irritant. Vector 2d6: 2–6 ingested, 7–11 contact, 12 inhaled."),
    ("Magic Talent", "Learn one Complexity 1 spell, and you are trained in Mysticism."),
    ("Leaper", "Jump twice as far and high."),
    ("Fast Healer", "You recover twice as many HP from all healing."),
    ("Scent", "Detect a familiar smell within 5 ft (+5 ft at levels 5, 9, 13 and 17). Finding its direction and distance takes a Perception check."),
    ("Affliction Resistance", "1 Advantage on checks against disease, poison, curses and radiation (+1 at levels 5, 9, 15 and 17)."),
    ("Echolocation", "Sense size, shape and location by sound instead of sight (no color)."),
    ("Magic Resistance", "1 Advantage on checks to resist magic (+1 at levels 5, 9, 15 and 17)."),
]

DRAWBACKS = [
    ("Blood Hunger", "Your maximum Strain drops by 1 for every full 24 hours without feeding on a living creature's blood. Feeding (1 AP, MANIPULATE): an unarmed strike against a creature you or an ally is grappling. On a hit, if you have a bite or it has an open wound, deal unarmed damage + 1d6 blood loss and restore that much maximum Strain."),
    ("Combat Fear", "The first time each encounter that you roll initiative or take damage, make a Charisma save vs DC 10 + the encounter level; on a failure lose 1d6 Strain."),
    ("Ultraviolet Allergy", "In direct sunlight or strong UV, take 1d6 fire damage at the start of each turn, and light flammable clothing may ignite."),
    ("Ability Decay", "Permanently reduce one ability score by 1 (minimum 0)."),
    ("Brittle Bones", "1 Disadvantage on Reflex saves against falling, and +1d6 falling damage."),
    ("Sound Sensitivity", "1 Disadvantage on all checks while exposed to sound louder than normal speech."),
    ("Light Sensitivity", "Going from dim or darker into normal or brighter light Blinds you until the end of your next turn. 1 Disadvantage on sight-based Perception in bright light."),
    ("Weak Immune System", "1 Disadvantage on Fortitude saves against poison and disease."),
    ("Reduced Speed", "−5 ft to all your Speeds."),
    ("Frailty", "Treat your Fortitude as 2 lower when calculating maximum HP and Strain (not for saves)."),
    ("Heat/Cold Susceptibility", "1 Disadvantage on Fortitude saves against extreme heat or cold."),
    ("Pheromone Repulsion", "1 Disadvantage on Diplomacy and Nature checks against creatures within 30 ft."),
    ("Lethargy", "1 Disadvantage on Reflex saves."),
    ("Mindslave", "1 Disadvantage on Charisma saves against MENTAL effects."),
    ("Thin Skin", "Roll flat checks to resist Light or Heavy Wounds with Misfortune."),
    ("Festering Sores", "Worn armor's check penalty increases by 1 and always applies, even if you meet its Might requirement."),
]

COSMETICS = [
    ("Extra Digits", "Extra functional fingers and toes."), ("Fins", "Decorative fins on your head, back or limbs."),
    ("Forked Tongue", "A snake-like forked tongue."), ("Horns (Cosmetic)", "Small blunt nubs, too small to use as weapons."),
    ("Scaly Skin", "Thick scaled skin, in patches or all over."), ("Thin Fur Coat", "A thin coat of dark fur."),
    ("Unnatural Eyes", "Solid black, glowing or otherwise strange eyes."), ("Unnatural Hair", "Oddly colored, patterned or luminous hair that may shift with mood."),
    ("Unnatural Skin", "An unnatural or shimmering skin hue."), ("Unnatural Voice", "A voice wildly at odds with your size and look."),
]

GENETIC_EFFECTS = {
    "Swim Speed": [("system.speed.swim", 4, 25)], "Climb Speed": [("system.speed.climb", 4, 25)], "Burrow Speed": [("system.speed.burrow", 4, 25)],
    "Reduced Speed": [("system.speed.bonus", 2, -5)],
}

VICES_VIRTUES = [("Aggressive", "Calm"), ("Amoral", "Cheerful"), ("Cowardly", "Compassionate"), ("Curious", "Confident"), ("Dependent", "Courageous"),
                 ("Egotistical", "Energetic"), ("Flippant", "Friendly"), ("Follower", "Generous"), ("Foppish", "Helpful"), ("Frivolous", "Honest"),
                 ("Hateful", "Humble"), ("Humorless", "Humorous"), ("Illogical", "Independent"), ("Lazy", "Kind"), ("Merciless", "Leader"),
                 ("Ominous", "Logical"), ("Passive", "Mysterious"), ("Pessimistic", "Optimistic"), ("Rash", "Peaceful"), ("Rude", "Precise"),
                 ("Selfish", "Quiet"), ("Suspicious", "Religious"), ("Talkative", "Righteous"), ("Thoughtless", "Romantic"), ("Trusting", "Skeptical")]

GEN_MODS = [("Might", "Reflex", "Fortitude", "Intellect", "Perception", "Charisma"), ("Might", "Fortitude", "Reflex", "Intellect", "Perception", "Charisma"),
            ("Might", "Intellect", "Reflex", "Fortitude", "Perception", "Charisma"), ("Might", "Perception", "Reflex", "Fortitude", "Intellect", "Charisma"),
            ("Might", "Charisma", "Reflex", "Fortitude", "Intellect", "Perception"), ("Reflex", "Fortitude", "Might", "Intellect", "Perception", "Charisma"),
            ("Reflex", "Intellect", "Might", "Fortitude", "Perception", "Charisma"), ("Reflex", "Perception", "Might", "Fortitude", "Intellect", "Charisma"),
            ("Reflex", "Charisma", "Might", "Fortitude", "Intellect", "Perception"), ("Fortitude", "Intellect", "Might", "Reflex", "Charisma", "Perception"),
            ("Fortitude", "Perception", "Might", "Reflex", "Charisma", "Intellect"), ("Fortitude", "Charisma", "Might", "Reflex", "Perception", "Intellect"),
            ("Intellect", "Perception", "Might", "Reflex", "Charisma", "Fortitude"), ("Intellect", "Charisma", "Might", "Reflex", "Perception", "Fortitude"),
            ("Perception", "Charisma", "Might", "Reflex", "Intellect", "Fortitude")]

PERSONALITY = {
    "Social: Demeanor": ["Cheerful", "Talkative", "Reserved", "Charming", "Witty", "Relaxed"],
    "Social: Outlook": ["Enthusiastic", "Hopeful", "Fatalistic", "Grim", "Self-assured", "Brooding"],
    "Social: Trust": ["Gullible", "Open-minded", "Skeptical", "Suspicious", "Naive", "Trusting"],
    "Decisions: Assertiveness": ["Humble", "Adaptable", "Commanding", "Timid", "Easygoing", "Impatient"],
    "Decisions: Rules": ["Scrupulous", "Pragmatic", "Dutiful", "Honest", "Flexible", "Wild"],
    "Decisions: Empathy": ["Kind", "Stern", "Thoughtful", "Protective", "Hard-hearted", "Oblivious"],
    "Dire Straits: Courage": ["Brave", "Competitive", "Steady", "Cautious", "Reckless", "Fierce"],
    "Dire Straits: Setbacks": ["Stoic", "Driven", "Happy-go-lucky", "Vengeful", "Bold", "Impassioned"],
    "Dire Straits: Nerves": ["Calm", "Skittish", "Restless", "Impulsive", "Patient", "Unshakable"],
}

SKILL_LABEL = {"meleeWeapons": "Melee Weapons", "missileWeapons": "Missile Weapons", "martialArts": "Martial Arts", "sleightOfHand": "Sleight of Hand"}


def _sk(k):
    return " or ".join(SKILL_LABEL.get(x, x.title()) for x in k.split("|"))


def origins():
    out = []
    for name, (abil, talent, skills, summ, equip, feat, spec, quirks, ideals, pledges, flaws) in ORIGINS.items():
        ab = " or ".join(a.title() for a in abil)
        desc = (f"<p>{summ}</p><p><strong>You gain:</strong> +1 {ab}; the {talent.replace('|', ' or ')} talent; 2 ranks in {_sk(skills[0])} and {_sk(skills[1])}.</p>"
                f"<p><strong>Starting Equipment:</strong></p><ul>{''.join(f'<li>{e}</li>' for e in equip)}</ul>"
                f"<p><strong>Feature — {feat[0]}:</strong> {feat[1]}</p>")
        if spec:
            desc += f"<p><strong>{spec[0]} ({spec[1]}):</strong> {', '.join(f'{i+1}. {o}' for i, o in enumerate(spec[2]))}</p>"
        desc += ("<p><strong>Personality:</strong> roll on this origin's Quirk (1d8), Ideal, Pledge and Flaw (1d6) tables in the Character Creation compendium, "
                 "then pair each with a Virtue or Vice (2 of each).</p>")
        if name == "Cultist":
            desc += "<p><em>The source names a “Lie to Me” talent that doesn't exist; Charming Liar is used instead.</em></p>"
        out.append({"name": name, "type": "origin", "img": ORIGIN_IMG[name], "folder": None,
                    "system": {"ability": abil[0] if len(abil) == 1 else "", "abilityChoices": abil, "talent": talent, "languages": "",
                               "features": f"<p><strong>{feat[0]}.</strong> {feat[1]}</p>", "appearance": "",
                               "skills": skills, "description": desc}})
        # Fixed benefits as a prebuilt effect; the player's picks (ability/skill options) are added on drop
        fixed = []
        if len(abil) == 1:
            fixed.append({"key": f"system.abilities.{abil[0]}.granted", "mode": 2, "value": "1"})
        for sk in skills:
            if "|" not in sk:
                fixed.append({"key": f"system.skills.{sk}.granted", "mode": 2, "value": "2"})
        if fixed:
            out[-1]["effects"] = [{"name": f"Origin: {name}", "img": ORIGIN_IMG[name], "transfer": True, "disabled": False,
                                   "changes": fixed, "flags": {"cowboys-and-vikings": {"origin": "fixed"}}}]
    return out


def genetics():
    out = []
    for i, (n, t) in enumerate(GENETIC_TALENTS):
        e = {"name": n, "type": "genetic", "img": "icons/magic/life/cross-worn-green.webp", "folder": "Genetic Talents",
             "system": {"kind": "talent", "roll": f"{i*4+1}–{i*4+4}", "mechanics": t, "description": f"<p>{t}</p>"}}
        if n in GENETIC_EFFECTS:
            e["effects"] = [{"name": n, "img": e["img"], "transfer": True, "disabled": False,
                             "changes": [{"key": k, "mode": m, "value": str(v)} for k, m, v in GENETIC_EFFECTS[n]]}]
        out.append(e)
    for i, (n, t) in enumerate(DRAWBACKS):
        e = {"name": n, "type": "genetic", "img": "icons/magic/unholy/strike-body-life-soul-purple.webp", "folder": "Genetic Drawbacks",
             "system": {"kind": "drawback", "roll": str(i + 3), "mechanics": t, "description": f"<p>{t}</p>"}}
        if n in GENETIC_EFFECTS:
            e["effects"] = [{"name": n, "img": e["img"], "transfer": True, "disabled": False,
                             "changes": [{"key": k, "mode": m, "value": str(v)} for k, m, v in GENETIC_EFFECTS[n]]}]
        out.append(e)
    for i, (n, t) in enumerate(COSMETICS):
        out.append({"name": n, "type": "genetic", "img": "icons/skills/social/diplomacy-peace-alliance.webp", "folder": "Cosmetic Features",
                    "system": {"kind": "cosmetic", "roll": str(i + 1), "mechanics": t, "description": f"<p>{t} No mechanical effect.</p>"}})
    return out


def tables():
    T = []
    T.append({"name": "Genetic Ability Modifiers", "folder": "Character Creation", "formula": "2d8", "img": "icons/sundries/gaming/dice-runed-brown.webp",
              "description": "Roll 2d8 for the row (two +1s), then 1d4 for the −1. Extreme option: take −2 to raise one +1 to +2.",
              "results": [(i + 2, i + 2 if i < 14 else 16, f"+1 {r[0]}, +1 {r[1]}; −1 (1d4): 1 {r[2]}, 2 {r[3]}, 3 {r[4]}, 4 {r[5]}") for i, r in enumerate(GEN_MODS)]})
    T.append({"name": "Genetic Talents", "folder": "Character Creation", "formula": "1d100", "img": "icons/magic/life/cross-worn-green.webp",
              "results": [(i * 4 + 1, i * 4 + 4, f"{n} — {t}") for i, (n, t) in enumerate(GENETIC_TALENTS)]})
    T.append({"name": "Genetic Drawbacks", "folder": "Character Creation", "formula": "3d6", "img": "icons/magic/unholy/strike-body-life-soul-purple.webp",
              "results": [(i + 3, i + 3, f"{n} — {t}") for i, (n, t) in enumerate(DRAWBACKS)]})
    T.append({"name": "Cosmetic Features", "folder": "Character Creation", "formula": "1d10", "img": "icons/skills/social/diplomacy-peace-alliance.webp",
              "description": "Random characters roll 1d4−1 times.", "results": [(i + 1, i + 1, f"{n} — {t}") for i, (n, t) in enumerate(COSMETICS)]})
    T.append({"name": "Vices & Virtues", "folder": "Character Creation", "formula": "1d100", "img": "icons/sundries/gaming/dice-pair-white-green.webp",
              "results": [(i * 4 + 1, i * 4 + 4, f"Vice: {v} · Virtue: {g}") for i, (v, g) in enumerate(VICES_VIRTUES)]})
    for k, opts in PERSONALITY.items():
        T.append({"name": f"Personality — {k}", "folder": "Character Creation/Personality", "formula": "1d6", "img": "icons/skills/social/diplomacy-writing-letter.webp",
                  "results": [(i + 1, i + 1, o) for i, o in enumerate(opts)]})
    for name, o in ORIGINS.items():
        for label, die, data in (("Quirk", "1d8" if len(o[7]) == 8 else "1d6", o[7]), ("Ideal", "1d6", o[8]), ("Pledge", "1d6", o[9]), ("Flaw", "1d6", o[10])):
            T.append({"name": f"{name} — {label}", "folder": f"Origins/{name}", "formula": die, "img": ORIGIN_IMG[name],
                      "results": [(i + 1, i + 1, x) for i, x in enumerate(data)]})
        if o[6]:
            T.append({"name": f"{name} — {o[6][0]}", "folder": f"Origins/{name}", "formula": o[6][1], "img": ORIGIN_IMG[name],
                      "results": [(i + 1, i + 1, x) for i, x in enumerate(o[6][2])]})
    return T


VIRTUE_VICE_JOURNAL = """<h2>Virtues &amp; Vices</h2><p>Pair each of your origin's four aspects (Quirk, Ideal, Pledge, Flaw) with a Virtue or a Vice—exactly two of each.
When a situation touches an aspect, you may play into its paired trait and use the Stakes Menu.</p>
<p><strong>Virtue:</strong> hold firm despite real pressure and <em>spend</em> one Stakes item for a fitting benefit.
<strong>Vice:</strong> give in and <em>gain</em> one Stakes item; the GM adds a fitting complication.</p>
<p><strong>Stakes Menu</strong> (not exhaustive, not automatic): 1 Fate Die · 1 Advantage (or Disadvantage) on the next relevant roll · a little Strain recovered (or spent) ·
a minor narrative boon · a hook the GM can call back · anything else that fits.</p>"""
