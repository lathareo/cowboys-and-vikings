"""Crafting & Treasure: special materials, alchemical concoctions, essences, ingredients, terrain tables, rules text."""

# ------------------------------------------------------------------ SPECIAL MATERIALS
# name | applies | scaling | cost/dc | effect
MATERIALS = """Aberration Hide (Psychic)|Hoods, masks, helms, light armor, veils, worn items|Flat|+25%, DC +1|+1 on saves vs telepathy, mind-reading and thought-probing.
Aberration Hide (Grasping)|Gloves, wraps, boots, belts, shield facings, wrestling gear|Flat|+25%, DC +1|+1 on checks to Grapple, Escape a Grapple, or keep a hold.
Adhesive Membrane|Gloves, boots, wraps, grip pads, shield linings, climbing gear|Flat|+25%, DC +1|+1 on checks to Climb, keep a grip, or resist Disarm.
Aetherwood|Rods, staves, wands, charms, worn items, light weapons, tools|Synergy|+25%|1 Advantage on Crafting to add or upgrade runes on the item (+1 per higher level band, max 4).
Animal Bone (Keen-Sensed)|Weapon hafts, tool handles, charms, fittings, utility gear|Flat|+25%, DC +1|+1 on checks to track creatures or follow wounded prey.
Animal Hide (Thick-Hided)|Armor, shields, helms, bracers, weather gear|Flat|+25%, DC +1|Reduce penalties from ordinary heat, cold, rain and rough terrain by 1.
Celestial Hide|Armor facings, mantles, shields, icons, cloaks|Flat|+25%, DC +1|+1 on saves vs fear, corruption and despair.
Chitin Plate|Helmets, bracers, shields, armor panels, light and medium armor|Flat|+25%, DC +1|+1 on saves vs being grabbed, pinned or crushed.
Cold Iron|Weapons, ammunition, armor, shields|—|+25%|Counts as Cold Iron for weaknesses, resistances, immunities and special defenses (armor counts when a creature touches or strikes it).
Construct Plating|Armor, shields, helmets, bracers, casings|Flat (special)|+25%, DC +1|+1 Hardness (equals 1 + item bonus, max +3).
Corrosive Sheath|Cloaks, aprons, gloves, boots, wraps, shield facings, outerwear|Hybrid|+25%, DC +1|Immune to ordinary acid wear, rust and mildew; +1 on saves vs acid hazards touching the covered area.
Dragon Fang|Daggers, spear tips, arrowheads, light weapon fittings|Flat (special)|+25%, DC +1|+1 damage vs Bloodied targets (equals 1 + item bonus).
Dragon Scales (Fire-Attuned)|Armor, shields, bracers, helmets, scale facings|—|+50%, DC +2|Full Soak vs fire instead of half.
Dragonbone|Weapons, armor, shields, tools, rods, staves|Flat (special)|+50%, DC +2|+1 Hardness and +50% Durability; counts as Dragonbone where relevant. Hardness +1 per higher band (max +4).
Emberglass|Weapons, ammunition, light armor, shields, worn items, charms|Hybrid|+50%, DC +2|Weapons +1 fire on each hit (or +1 to existing fire); protective items use full Soak vs fire. Brittle under heavy blunt stress.
Glamour Veilskin|Hoods, masks, cloaks, light armor, mantles|Flat|+25%, DC +1|Decorative panels add no Bulk; +1 on saves vs charm, fascination and allure.
Gloom Thread|Cloaks, linings, scarves, bow wraps, stealth wear|Flat|+25%, DC +1|+1 Stealth in dim light, shadow or lightly obscured terrain.
Mimetic Film|Cloaks, hoods, shield facings, light armor|Flat|+25%, DC +1|+1 Stealth while motionless or pressed to a surface.
Rending Fang|Daggers, arrowheads, spear tips, claw fittings|Flat (special)|+25%, DC +1|+1 damage vs creatures adjacent to one of your allies (equals 1 + item bonus).
Rooted Bark|Shield facings, light armor, bracers, staff wraps|Flat|+25%, DC +1|+1 on saves vs forced movement while on natural ground.
Silver|Weapons, ammunition, jewelry, charms, worn items|—|+25%|Counts as Silver for weaknesses and defenses; satisfies silver recipe and ritual requirements. Too soft for heavy armor.
Sky Silk|Clothing, cloaks, garments, light armor|Hybrid|+50%, DC +2|Lightweight (half Bulk). +5 ft to one movement bonus from the item's movement magic (+5 ft per higher band).
Spirit Filament|Charm cords, tassels, veil trim, ritual wraps, tokens|Synergy|+25%, DC +1|+1 on saves vs possession, soul-binding and spirit intrusion.
Thorn Spine|Arrowheads, spear tips, hooks, trap barbs|Flat|+25%, DC +1|+1 damage vs grabbed, restrained or entangled creatures.
Undead Hide (Preserved)|Armor, gloves, masks, belts, wrappings, helmets|Flat|+25%, DC +1|Never rots or spoils; +1 on saves vs rot, corpse-taint and disease.
Webspinner Silk|Rope, nets, bowstrings, cord, stitching, worn items|Flat|+25%, DC +1|+1 on checks to bind, lash, anchor or secure gear and to avoid being knocked loose."""

DURABILITY = """Paper|0|1|0
Thin cloth|0|1|0
Thin glass|0|1|0
Cloth|1|4|2
Glass|1|4|2
Glass structure|2|8|4
Thin leather|2|8|4
Thin rope|2|8|4
Thin wood|3|12|6
Leather|4|16|8
Rope|4|16|8
Thin stone|4|16|8
Thin iron or steel|5|20|10
Wood|5|20|10
Stone|7|28|14
Iron or steel|9|36|18
Wooden structure|10|40|20
Stone structure|14|56|28
Iron or steel structure|18|72|36"""


def materials():
    out = []
    for line in MATERIALS.splitlines():
        n, app, scale, mods, eff = line.split("|")
        desc = (f"<p><strong>Applies to:</strong> {app}</p><p><strong>Effect:</strong> {eff}</p><p><strong>Scaling:</strong> {scale} "
                f"(by finished item level band 0–4 / 5–10 / 11–16 / 17+).</p><p><strong>Crafting:</strong> raw material cost {mods}. "
                "The trait persists through Masterwork and runes.</p>")
        out.append({"name": n, "type": "material", "img": "icons/commodities/materials/hair-tuft-brown.webp", "folder": "Special Materials",
                    "system": {"grade": "special", "appliesTo": app, "description": desc}})
    for line in DURABILITY.splitlines():
        n, h, d, bt = line.split("|")
        out.append({"name": n, "type": "material", "img": "icons/commodities/stone/paver-brick-brown.webp", "folder": "Base Materials",
                    "system": {"grade": "standard", "hardness": int(h), "hp": int(d), "brokenThreshold": int(bt),
                               "description": f"<p>Hardness {h}, Durability {d}, Broken Threshold {bt or '—'}{' (per 1 ft section)' if 'structure' in n else ''}.</p>"}})
    return out


# ------------------------------------------------------------------ CONCOCTIONS
# name | type | level | complexity | req | optional | activate | save | effect | side | optional benefit
C = """Concussion Charge|bomb|2|Involved|Mineral, Volatile|Metallic|Throw (1)|Reflex|On a hit or failed save: 2d6 thunder and Off-Guard until the end of its next turn; critical failure also Dazed.||One more adjacent target takes half and the same effect on a failure.
Corroding Flask|bomb|2|Involved|Metallic, Corrosive|Mineral|Throw (1)|Reflex|2d6 acid. Failure: worn armor or held weapon is Corroded (−1 Soak/effectiveness until repaired); critical failure −2.||3d6 acid.
Fireblood Vial|bomb|4|Complex|Oil, Volatile|Corrosive|Throw (1)||Ranged attack within 20 ft: 1d8 fire + 1d4 persistent fire on a hit; 1 fire on a miss.||A hit also deals 1 Durability damage to objects, shields or worn armor.
Rimeshard Bomb|bomb|2|Involved|Mineral, Volatile|Crystal|Throw (1)|Reflex|2d6 cold and Slowed 10 until the end of its next turn (Slowed 20 on a critical failure).||3d6 cold.
Rot Casque|bomb|3|Involved|Organ, Toxic|Bone|Throw (1)|Reflex|2d6 necrotic and Enfeebled 1 until the end of its next turn (Enfeebled 2 for 1 round on a critical failure).||3d6 necrotic.
Smokestick|bomb|1|Involved|Mineral, Irritant|Volatile|Throw (1)||A 10-ft burst within 20 ft is heavily obscured by smoke until the start of your next turn.||15-ft burst or lasts until the end of your next turn (choose when crafted).
Greater Smokestick|bomb|5|Complex|Mineral, Irritant|Volatile|Throw (1)|Fortitude|15-ft burst of smoke until the end of your next turn. Creatures inside when it bursts: failure Sickened 1, critical failure Sickened 2, until the end of their next turn.||20-ft burst or +1 round.
Storm Vial|bomb|3|Involved|Metallic, Volatile|Crystal|Throw (1)|Reflex|2d8 lightning and Dazed until the end of its next turn; critical failure also Off-Guard.||Arcs to a second target within 10 ft (half damage, same effect on a failure).
Battle Tonic|elixir|1|Involved|Botanical, Stimulant|Medicinal|Drink (1)||+10 ft Speed for 1 round.|Fortitude: failure 1 Strain; critical failure 2 Strain and Slowed 10 until the end of your next turn.|1 Advantage on the side-effect save.
Greater Battle Tonic|elixir|5|Complex|Botanical, Stimulant|Medicinal|Drink (1)||+15 ft Speed for 1 round.|Fortitude: failure 1 Strain and Slowed 10; critical failure 2 Strain and Slowed 20.|1 Advantage on the side-effect save.
Major Battle Tonic|elixir|11|Articulate|Botanical, Stimulant|Medicinal|Drink (1)||+20 ft Speed for 1 round.|Fortitude: failure 2 Strain and Slowed 10; critical failure 3 Strain and Slowed 20.|1 Advantage on the side-effect save.
Cat's Whisker Brew|elixir|1|Involved|Animal, Medicinal|Botanical|Drink (1)||See dim light within 60 ft as bright for 1 hour.|Fortitude: failure 1 Strain.|Lasts 4 hours.
Greater Cat's Whisker Brew|elixir|5|Complex|Animal, Medicinal|Botanical|Drink (1)||For 4 hours, dim light within 60 ft as bright and darkness within 30 ft.|Fortitude: failure 1 Strain; critical failure 2 Strain.|Lasts 8 hours.
Major Cat's Whisker Brew|elixir|11|Articulate|Animal, Medicinal|Botanical|Drink (1)||For 8 hours, dim light within 120 ft as bright and darkness within 60 ft.|Fortitude: failure 2 Strain; critical failure 3 Strain and Dazzled.|Lasts 24 hours.
Farseer's Draught|elixir|2|Involved|Animal, Stimulant|Crystal|Drink (1)||1 Advantage on Perception and ranged attacks for 1 round.|Fortitude: failure Dazzled until the end of your next turn.|2 Advantage.
Greater Farseer's Draught|elixir|6|Complex|Animal, Stimulant|Crystal|Drink (1)||2 Advantage on Perception and ranged attacks for 2 rounds.|Fortitude: failure Dazzled; critical failure Dazzled 1 round and Stupefied 1.|Also ignore concealment for ranged attacks.
Major Farseer's Draught|elixir|12|Articulate|Animal, Stimulant|Crystal|Drink (1)||2 Advantage on Perception and ranged attacks for 3 rounds, ignoring concealment.|Fortitude: failure Dazzled 1 round; critical failure also Stupefied 2.|Also ignore 1 level of cover.
Frostward Tonic|elixir|2|Involved|Mineral, Preservative|Botanical|Drink (1)||For 1 hour, cold resistance equal to half your level (minimum 1) and ignore snow and ice movement penalties.|Fortitude: failure Clumsy 1 until the end of your next turn.|1 Advantage on the side-effect save.
Greater Frostward Tonic|elixir|6|Complex|Mineral, Preservative|Botanical|Drink (1)||For 4 hours, cold resistance equal to your level; ignore snow, ice and cold slowing.|Fortitude: failure Clumsy 1; critical failure Clumsy 2.|2 Advantage on the side-effect save.
Major Frostward Tonic|elixir|12|Articulate|Mineral, Preservative|Botanical|Drink (1)||For 8 hours, immune to cold and to cold-exposure penalties and checks.|Fortitude: failure Clumsy 2; critical failure Clumsy 2 and Slowed 10.|2 Advantage on the side-effect save.
Nightglass Tonic|elixir|2|Involved|Mineral, Medicinal|Crystal|Drink (1)||See in dim light and darkness within 60 ft as bright for 1 hour.|Fortitude: failure Dazzled until the end of your next turn.|120 ft.
Greater Nightglass Tonic|elixir|6|Complex|Mineral, Medicinal|Crystal|Drink (1)||120 ft for 4 hours.|Fortitude: failure Dazzled; critical failure Dazzled 1 round.|240 ft.
Major Nightglass Tonic|elixir|12|Articulate|Mineral, Medicinal|Crystal|Drink (1)||120 ft for 8 hours, including magical darkness.|Fortitude: failure Dazzled 1 round; critical failure also Stupefied 1.|240 ft.
Restwell Tonic|elixir|1|Involved|Botanical, Sedative|Medicinal|Drink (1)||Remove 1 level of Fatigue or a similar Strain-recovery condition as if rested.|Fortitude: failure Drained 1 until a full rest.|1 Advantage on the side-effect save.
Greater Restwell Tonic|elixir|5|Complex|Botanical, Sedative|Medicinal|Drink (1)||Remove 2 levels and heal 1d8.|Fortitude: failure Drained 1; critical failure Drained 2.|2 Advantage on the side-effect save.
Major Restwell Tonic|elixir|11|Articulate|Botanical, Sedative|Medicinal|Drink (1)||Remove all levels and heal 2d8.|Fortitude: failure Drained 2; critical failure Drained 3.|2 Advantage on the side-effect save.
Sea Legs Elixir|elixir|2|Involved|Animal, Medicinal|Oil|Drink (1)||For 1 hour, breathe water and swim at your Speed.|Fortitude: failure Enfeebled 1 until the end of your next turn.|1 Advantage on the side-effect save.
Greater Sea Legs Elixir|elixir|6|Complex|Animal, Medicinal|Oil|Drink (1)||For 4 hours, breathe water, swim at Speed +10 ft, no underwater penalties.|Fortitude: failure Enfeebled 1; critical failure Enfeebled 2.|2 Advantage on the side-effect save.
Major Sea Legs Elixir|elixir|12|Articulate|Animal, Medicinal|Oil|Drink (1)||For 8 hours, breathe water, swim at Speed +20 ft, no underwater penalties, resist cold and deep-water pressure.|Fortitude: failure Enfeebled 2; critical failure also Slowed 10.|2 Advantage on the side-effect save.
Steadfast Draught|elixir|1|Involved|Botanical, Medicinal|Stimulant|Drink (1)||Heal 1d8 and 1 Advantage on saves for 1 round.|Fortitude: failure 1 Strain.|Heal 1d8+2.
Greater Steadfast Draught|elixir|5|Complex|Botanical, Medicinal|Stimulant|Drink (1)||Heal 3d8 and 1 Advantage on saves for 1 round.|Fortitude: failure 1 Strain; critical failure 2 Strain.|Heal 3d8+2.
Major Steadfast Draught|elixir|11|Articulate|Botanical, Medicinal|Stimulant|Drink (1)||Heal 5d8 and 2 Advantage on saves for 2 rounds.|Fortitude: failure 2 Strain; critical failure 3 Strain and Enfeebled 1.|Heal 5d8+2.
Tongue-Loosener's Draught|elixir|1|Involved|Organ, Stimulant|Mineral|Drink (1)||For 10 minutes, understand the literal meaning of any spoken language and read any writing.|Fortitude: failure Stupefied 1 until the end of your next turn.|30 minutes.
Greater Tongue-Loosener's Draught|elixir|5|Complex|Organ, Stimulant|Mineral|Drink (1)||For 30 minutes, also speak any language you hear.|Fortitude: failure Stupefied 1; critical failure Stupefied 2.|1 hour.
Major Tongue-Loosener's Draught|elixir|11|Articulate|Organ, Stimulant|Mineral|Drink (1)||For 1 hour, understand, speak and read any language; 1 Advantage on Deception and Diplomacy in languages you don't know.|Fortitude: failure Stupefied 2; critical failure also mute until the end of your next turn.|4 hours.
Trailside Antidote|elixir|1|Involved|Botanical, Medicinal|Preservative|Drink (1)||1 Advantage on saves vs poison for 1 hour.|Fortitude: failure 1 Strain.|4 hours.
Greater Trailside Antidote|elixir|5|Complex|Botanical, Medicinal|Preservative|Drink (1)||2 Advantage vs poison for 4 hours.|Fortitude: failure 1 Strain; critical failure 2 Strain.|8 hours.
Major Trailside Antidote|elixir|11|Articulate|Botanical, Medicinal|Preservative|Drink (1)||2 Advantage vs poison and poison resistance equal to your level for 8 hours.|Fortitude: failure 2 Strain; critical failure 3 Strain and Enfeebled 1 until a full rest.|24 hours.
Wraithstep Elixir|elixir|3|Complex|Fungal, Volatile|Crystal|Drink (1)||For 1 round, attacks against you have 1 Disadvantage and you can move through occupied spaces.|Fortitude: failure Off-Guard until the end of your next turn.|1 Advantage on the side-effect save.
Greater Wraithstep Elixir|elixir|7|Articulate|Fungal, Volatile|Crystal|Drink (1)||For 2 rounds, as above plus physical resistance equal to half your level.|Fortitude: failure Off-Guard; critical failure also 1 Strain.|2 Advantage on the side-effect save.
Major Wraithstep Elixir|elixir|13|Immaculate|Fungal, Volatile|Crystal|Drink (1)||For 3 rounds, 2 Disadvantage to attacks against you, move through creatures and difficult terrain freely, physical resistance equal to your level.|Fortitude: failure Off-Guard and 1 Strain; critical failure 2 Strain and Slowed 10.|2 Advantage on the side-effect save.
Adrenal Jab|injectable|1|Involved|Blood, Stimulant|Metallic|Inject (1), self||For 1 round, 1 Advantage on Initiative and Reflex saves and +10 ft Speed.|Fortitude: failure 1 Strain.|The Speed bonus lasts 2 rounds.
Clarity Shot|injectable|2|Involved|Mineral, Stimulant|Crystal|Inject (1), self or adjacent||End one Stupefied or Dazzled condition.|Fortitude: failure Stupefied 1 until the end of their next turn.|1 Advantage on their next save vs a mental effect.
Ironveins Serum|injectable|4|Complex|Mineral, Medicinal|Metallic|Inject (1), self||Physical resistance equal to half your level for 1 hour.|Fortitude: failure Slowed 10 until the end of your next turn.|Resistance equals your level.
Numbweb Dart|injectable|3|Complex|Venom, Toxic|Slime|Delivered with a successful attack|Fortitude|Failure: Slowed 20 and Clumsy 2 until the end of its next turn; critical failure for 1 minute.||+1 round on a failure.
Paingate Injector|injectable|3|Complex|Venom, Stimulant|Bone|Inject (1), self||Ignore one Wound penalty until the end of your next turn.|Fortitude: failure 2 Strain.|1 Advantage on the side-effect save.
Quickclot Shot|injectable|1|Involved|Botanical, Medicinal|Blood|Inject (1), self or adjacent||Heal 2d8.|Fortitude: failure Clumsy 1 until the end of their next turn.|Heal 2d8+2.
Ragefire Injector|injectable|4|Complex|Venom, Irritant|Blood|Delivered with a successful attack|Fortitude|Failure: it must attack the nearest creature on its next turn and has 1 Disadvantage on other checks; critical failure for 1 minute.||Critical failure also deals 1d6 to it.
Second Wind Injector|injectable|5|Complex|Stimulant, Blood|Botanical|Inject (1), self||Gain 1 extra reaction this round.|Fortitude: failure 2 Strain.|Also heal 1d8.
Venomlock Serum|injectable|5|Complex|Venom, Sedative|Salt|Delivered with a successful attack|Fortitude|Failure: Enfeebled 2 and no Advantage until the end of its next turn; critical failure for 1 minute.||Also Slowed 10.
Widowfang Vial|injectable|3|Complex|Venom, Toxic|Salt|Inject (1), self or with an unarmed/light attack|Fortitude|Failure: Enfeebled 2 and Slowed 10 for 1 minute; critical failure also 1d6 poison each turn until treated.||1d6+2 poison.
Blackrot Oil|oil|4|Complex|Slime, Toxic|Organ|Apply (1) to a weapon; 1 hour or one delivery|Fortitude|The next damaging hit: failure 1d6 poison each turn for 1 minute; critical failure 2d6.||1d6+2 on a failure.
Glowline Oil|oil|1|Simple|Crystal, Preservative|Mineral|Apply (1); 1 hour||The coated object or skin sheds dim light 10 ft.||Lasts 8 hours.
Honing Oil|oil|1|Involved|Metallic, Stimulant|Resin|Apply (1) to a weapon; 10 minutes or the encounter||+1d4 damage.||Lasts 1 hour.
Numbing Coat|oil|2|Involved|Venom, Sedative|Oil|Apply (1) to a weapon; 1 hour or one delivery|Fortitude|The next damaging hit: failure Clumsy 1 and Enfeebled 1 until the end of its next turn; critical failure 1 minute.||Lasts for 3 hits.
Quickdraw Oil|oil|1|Involved|Oil, Stimulant|Metallic|Apply (1) to a holster, sheath or weapon; 1 hour||Drawing that weapon is free as part of another action.||Also reload costs one step less.
Silverline Oil|oil|2|Involved|Metallic, Preservative|Crystal|Apply (1) to a weapon; 10 minutes||The weapon counts as silver.||Lasts 1 hour.
Slickcoat Oil|oil|2|Involved|Slime, Oil|Botanical|Apply (1) to yourself or restraints; 10 minutes||1 Advantage to Escape grapples or restraints.||2 Advantage.
Truesight Oil|oil|3|Complex|Crystal, Stimulant|Mineral|Apply (1), self; 10 minutes||1 Advantage to see through illusions and disguises and to notice things hidden by magic.||2 Advantage.
Voidglass Oil|oil|3|Complex|Crystal, Preservative|Resin|Apply (1) to armor or a held item; 1 hour or until triggered||Choose acid, cold, fire, lightning or thunder: the first time it would harm the item, it doesn't.||Triggers twice.
Wardplate Oil|oil|1|Involved|Mineral, Preservative|Resin|Apply (1) to armor; 10 minutes||+1 Soak.||+2 Soak.
Blinding Powder|powder|1|Involved|Mineral, Irritant|Crystal|Throw (1), small burst|Reflex|Failure: Dazzled until the end of its next turn; critical failure 1 minute.||Larger burst.
Choke Vapor|powder|3|Involved|Fungal, Toxic|Salt|Throw (1), lingering cloud 1 round|Fortitude|Creatures starting in or entering: failure Stupefied 1 and Enfeebled 1 until the end of their next turn; critical failure 1 minute.||Cloud lasts 2 rounds.
Flash Powder|powder|3|Complex|Mineral, Irritant|Crystal|Scatter (1), 5-ft burst within 10 ft|Perception|Failure: Off-Guard until the start of its next turn; critical failure also Dazzled. You're affected if inside.||10-ft burst or 20-ft range.
Groundshatter Powder|powder|3|Complex|Mineral, Volatile|Metallic|Throw (1), burst|Reflex|The area becomes difficult terrain for 10 minutes. Failure: 1d6 and Prone; critical failure 2d6.||Larger burst.
Itchpowder|powder|1|Involved|Fungal, Irritant|Salt|Throw (1), small burst|Reflex|Failure: Off-Guard until the end of its next turn; critical failure 1 minute.||Larger burst.
Panic Dust|powder|3|Complex|Animal, Irritant|Bone|Throw (1), small burst|Charisma|Failure: it moves its Speed away and treats the area as difficult terrain; critical failure also drops its off-hand item.||Larger burst.
Sneeze Dust|powder|1|Involved|Botanical, Irritant|Fungal|Throw (1), cloud 1 round|Fortitude|Failure: Stupefied 1 until the end of its next turn; critical failure Stupefied 2.||Cloud lasts 2 rounds.
Stickfoot Powder|powder|2|Involved|Resin, Volatile|Slime|Throw (1), sticky patch 1 minute|Reflex|Creatures starting in or entering: failure Slowed 10 while inside; critical failure Slowed 20 and stuck until an Athletics check frees it.||Lasts 10 minutes.
Widow's Kiss Powder|powder|4|Complex|Venom, Toxic|Fungal|Throw (1), cloud 1 round|Fortitude|Failure: Enfeebled 2 until the end of its next turn; critical failure also Slowed 20 for 1 minute.||Cloud lasts 2 rounds.
Witherspore Powder|powder|5|Complex|Fungal, Toxic|Blood|Throw (1), cloud 2 rounds|Fortitude|Creatures starting in or entering: failure Enfeebled 1 and 1d4 poison; critical failure Enfeebled 2 and 1d4+2.||Cloud lasts 3 rounds.
Ashbalm Salve|salve|3|Complex|Botanical, Preservative|Salt|Apply (1), self or adjacent||Heal 2d6 and end ongoing poison damage.|Fortitude: failure Enfeebled 1 until the end of their next turn.|1 Advantage on their next save vs poison.
Boneknit Salve|salve|3|Complex|Bone, Medicinal|Mineral|Apply (1), self or adjacent||Heal 3d6 and end Weakened Grip.|Fortitude: failure Clumsy 1.|Heal 3d6+2.
Clearmind Salve|salve|2|Involved|Crystal, Medicinal|Botanical|Apply (1), self or adjacent||Heal 2d6 and end one Stupefied condition.|Fortitude: failure Stupefied 1 until the end of their next turn.|Heal 2d6+2.
Cooling Salve|salve|2|Involved|Mineral, Medicinal|Botanical|Apply (1), self or adjacent||Heal 2d6 and end ongoing fire damage.|Fortitude: failure Slowed 10 until the end of their next turn.|Heal 2d6+2.
Frost Salve|salve|2|Involved|Botanical, Medicinal|Preservative|Apply (1)||Heal 2d6 and ignore Dazed until the end of its next turn.|Fortitude: failure Slowed 10; critical failure also 1 Strain.|1 Advantage on the side-effect save.
Greater Frost Salve|salve|5|Complex|Botanical, Medicinal|Preservative|Apply (1)||Heal 4d6 and ignore Dazed until the end of its next turn.|Fortitude: failure Slowed 10 and 1 Strain; critical failure Slowed 20 and 2 Strain.|1 Advantage on the side-effect save.
Major Frost Salve|salve|11|Articulate|Botanical, Medicinal|Preservative|Apply (1)||Heal 6d6 and ignore Dazed until the end of its next turn.|Fortitude: failure Slowed 20 and 2 Strain; critical failure also Dazed and 3 Strain.|1 Advantage on the side-effect save.
Numbing Salve|salve|2|Involved|Botanical, Sedative|Mineral|Apply (1), self or adjacent||Heal 2d6 and ignore one Wound penalty until the end of their next turn.|Fortitude: failure Clumsy 1.|Ignore the Wound penalty for 1 minute.
Scarweave Salve|salve|2|Involved|Animal, Medicinal|Bone|Apply (1), self or adjacent||Heal 2d6 and end Weakened Grip or injury-caused Slowed.|Fortitude: failure Enfeebled 1.|Heal 2d6+2.
Steadyhand Salve|salve|2|Involved|Animal, Medicinal|Crystal|Apply (1), self or adjacent||Heal 2d6 and end one Clumsy condition.|Fortitude: failure Slowed 10.|Heal 2d6+2.
Stopbleed Salve|salve|1|Involved|Botanical, Medicinal|Resin|Apply (1), self or adjacent||Heal 2d6 and end ongoing bleeding.|Fortitude: failure Clumsy 1.|Heal 2d6+2.
Vigor Salve|salve|2|Involved|Botanical, Stimulant|Blood|Apply (1), self or adjacent||Heal 2d6 and end one Enfeebled condition.|Fortitude: failure Enfeebled 1.|Heal 2d6+2.
Serpent's Kiss|toxin|2|Complex|Venom, Toxic|Sedative|Apply (1) to a weapon, ammunition or injector||The next creature damaged is exposed to Rattler's Bleed (see Afflictions). You are exposed if you critically fail to craft it.||A creature failing the initial save is also Drowsy until the end of its next turn."""

MATERIAL_COST = [(4, 10), (10, 40), (16, 160), (99, 480)]
CPLX_DC = {"Simple": 5, "Involved": 10, "Complex": 15, "Articulate": 20, "Immaculate": 25}
HEAL_RE = __import__("re").compile(r"[Hh]eal (\d+d\d+(?:\+\d+)?)")
DMG_RE = __import__("re").compile(r"(\d+d\d+(?:\+\d+)?) (thunder|acid|fire|cold|necrotic|lightning|poison)")
CIMG = {"bomb": "icons/weapons/thrown/bomb-fuse-black-grey.webp", "elixir": "icons/consumables/potions/bottle-round-corked-red.webp",
        "injectable": "icons/tools/laboratory/syringe-needle-glass.webp", "oil": "icons/consumables/potions/flask-corked-yellow.webp",
        "powder": "icons/commodities/materials/powder-grey.webp", "salve": "icons/consumables/potions/vial-cork-empty.webp",
        "toxin": "icons/consumables/potions/bottle-conical-corked-green.webp"}


def concoctions():
    out = []
    for line in C.splitlines():
        n, typ, lvl, cx, req, opt, act, save, eff, side, optb = line.split("|")
        lvl = int(lvl)
        cost = next(c for mx, c in MATERIAL_COST if lvl <= mx)
        dc = 15 + lvl
        desc = (f"<p><em>ALCHEMICAL, CONSUMABLE, {typ.upper()} · Level {lvl} · {cx} (Craft DC {CPLX_DC[cx]})</em></p>"
                f"<p><strong>Ingredients:</strong> {req}; optional {opt}. Base materials {cost} sp (listed price).</p><p><strong>Activate:</strong> {act}</p>")
        if save:
            desc += f"<p><strong>Target Save:</strong> {save} DC {dc}</p>"
        desc += f"<p><strong>Effect:</strong> {eff}</p>"
        if side:
            desc += f"<p><strong>Side Effect Save</strong> (DC {dc}): {side}</p>"
        if optb:
            desc += f"<p><strong>Optional Ingredient:</strong> {optb}</p>"
        roll = {}
        h = HEAL_RE.search(eff)
        d = DMG_RE.search(eff)
        if h:
            roll = {"type": "heal", "damage": h.group(1), "damageType": "healing"}
        elif d:
            roll = {"type": "save" if save else "damage", "save": save.lower(), "dc": str(dc), "damage": d.group(1), "damageType": d.group(2)}
        elif save:
            roll = {"type": "save", "save": save.lower(), "dc": str(dc)}
        out.append({"name": n, "type": "concoction", "img": CIMG[typ], "folder": typ.title() + ("s" if not typ.endswith("s") else ""),
                    "system": {"concoctionType": typ, "level": lvl, "price": {"value": cost, "denomination": "sp"}, "bulk": 0.1,
                               "cost": "1", "functions": [t.strip().lower() for t in req.split(",")], "roll": roll, "description": desc,
                               "tags": ["consumable", "alchemical"], "quantity": 1}})
    return out


# ------------------------------------------------------------------ ESSENCES & INGREDIENTS
ESSENCES = [("Fire", "flames, heat, burning, fire resistance"), ("Frost", "cold, ice, slowing, frost resistance"),
            ("Storm", "lightning, thunder, windburst"), ("Acid", "corrosion, caustic damage"), ("Spirit", "ghosts, incorporeal effects, soul magic"),
            ("Vitality", "life force, anti-undead power"), ("Death", "decay, doom, necrotic themes"), ("Blood", "wounds, bleeding, hunger"),
            ("Shadow", "stealth, darkness, invisibility"), ("Mind", "thought, memory, telepathy, charm resistance"), ("Fear", "terror, dread, panic"),
            ("Motion", "speed, flight, falling, repositioning"), ("Space", "storage, anchoring, dimensional reach"), ("Ward", "protection, fortification, barriers"),
            ("Edge", "sharpness, keenness, severing")]

SOURCES = [("Botanical", "herbs, roots, leaves, flowers, bark"), ("Fungal", "mushrooms, molds, spores, lichen"), ("Mineral", "stone dust, clay, ash, sulfur, chalk"),
           ("Metallic", "filings, flakes, alloys"), ("Animal", "hides, fat, sinew, glands, shell"), ("Venom", "poison sacs, stingers, toxic ichor"),
           ("Blood", "fresh or treated blood"), ("Bone", "bone dust, marrow, teeth, horn"), ("Organ", "livers, hearts, eyes, glands"),
           ("Resin", "sap, gum, pitch"), ("Oil", "rendered fat, fish or seed oil"), ("Slime", "ooze, mucus, gel, adhesive secretions"),
           ("Salt", "preserving, alkali and mineral salts"), ("Crystal", "quartz, emberglass shards, frost crystal")]
FUNCTIONS = ["Volatile", "Corrosive", "Toxic", "Medicinal", "Stimulant", "Sedative", "Irritant", "Preservative"]


def essences():
    return [{"name": f"{t} Essence", "type": "essence", "img": "icons/magic/light/orb-lightbulb-gray.webp", "folder": None,
             "system": {"trait": t.lower(), "quality": "common", "quantity": 1,
                        "description": f"<p><strong>{t}:</strong> {d}.</p><p>Quality sets the highest rune tier it supports: Common → Minor, Uncommon → Lesser, Rare → Greater, Legendary → Major. "
                                       "Set the quality and any subtype (e.g. Motion (Flight)) when harvested. Essence stays stable 1d3 rounds after death.</p>"}}
            for t, d in ESSENCES]


def ingredients():
    out = []
    for s, d in SOURCES:
        out.append({"name": f"{s} Ingredient", "type": "ingredient", "img": "icons/commodities/biological/organ-heart-red.webp" if s in ("Organ", "Blood") else "icons/consumables/plants/leaf-herb-green.webp",
                    "folder": None, "system": {"sourceTag": s.lower(), "functions": [], "quantity": 1,
                                               "description": f"<p><strong>Source:</strong> {s} — {d}.</p><p>Add one function tag ({', '.join(FUNCTIONS)}) when gathered.</p>"}})
    return out


TERRAIN = {
    "Forest": [(1, 15, "Botanical, Medicinal"), (16, 25, "Botanical, Sedative"), (26, 35, "Botanical, Irritant"), (36, 45, "Fungal, Toxic"), (46, 55, "Fungal, Sedative"),
               (56, 65, "Resin, Preservative"), (66, 73, "Animal, Stimulant"), (74, 80, "Bone, Medicinal"), (81, 87, "Blood, Toxic"), (88, 93, "Botanical, Preservative"), (94, 100, "Resin, Irritant")],
    "Swamp or Marsh": [(1, 10, "Botanical, Medicinal"), (11, 20, "Botanical, Toxic"), (21, 30, "Fungal, Toxic"), (31, 40, "Fungal, Sedative"), (41, 50, "Venom, Toxic"),
                       (51, 58, "Blood, Toxic"), (59, 66, "Organ, Sedative"), (67, 74, "Organ, Preservative"), (75, 82, "Resin, Irritant"), (83, 90, "Botanical, Preservative"), (91, 100, "Venom, Sedative")],
    "Mountain or Highlands": [(1, 15, "Mineral, Volatile"), (16, 28, "Mineral, Corrosive"), (29, 40, "Metallic, Corrosive"), (41, 50, "Metallic, Preservative"), (51, 62, "Crystal, Volatile"),
                              (63, 72, "Crystal, Preservative"), (73, 80, "Salt, Preservative"), (81, 87, "Bone, Medicinal"), (88, 93, "Animal, Stimulant"), (94, 100, "Mineral, Medicinal")],
    "Plains or Grassland": [(1, 18, "Botanical, Medicinal"), (19, 30, "Botanical, Stimulant"), (31, 42, "Animal, Stimulant"), (43, 52, "Animal, Medicinal"), (53, 62, "Bone, Preservative"),
                            (63, 72, "Blood, Toxic"), (73, 82, "Botanical, Irritant"), (83, 90, "Resin, Preservative"), (91, 100, "Botanical, Sedative")],
    "Desert or Badlands": [(1, 14, "Mineral, Corrosive"), (15, 26, "Mineral, Volatile"), (27, 38, "Salt, Preservative"), (39, 48, "Crystal, Volatile"), (49, 58, "Crystal, Preservative"),
                           (59, 68, "Resin, Irritant"), (69, 78, "Venom, Toxic"), (79, 86, "Venom, Sedative"), (87, 93, "Botanical, Irritant"), (94, 100, "Oil, Volatile")],
    "Coast or Tidal": [(1, 14, "Salt, Preservative"), (15, 26, "Oil, Preservative"), (27, 38, "Animal, Medicinal"), (39, 50, "Animal, Toxic"), (51, 60, "Bone, Preservative"),
                       (61, 70, "Mineral, Corrosive"), (71, 80, "Botanical, Medicinal"), (81, 88, "Botanical, Irritant"), (89, 94, "Oil, Volatile"), (95, 100, "Salt, Medicinal")],
    "Tundra or Frozen Wilds": [(1, 14, "Botanical, Preservative"), (15, 26, "Botanical, Sedative"), (27, 38, "Mineral, Preservative"), (39, 50, "Crystal, Preservative"), (51, 60, "Crystal, Volatile"),
                               (61, 70, "Animal, Medicinal"), (71, 80, "Bone, Preservative"), (81, 88, "Salt, Preservative"), (89, 94, "Botanical, Medicinal"), (95, 100, "Animal, Stimulant")],
    "Jungle": [(1, 12, "Botanical, Medicinal"), (13, 22, "Botanical, Toxic"), (23, 32, "Fungal, Toxic"), (33, 40, "Fungal, Sedative"), (41, 50, "Resin, Irritant"), (51, 60, "Venom, Toxic"),
               (61, 68, "Blood, Toxic"), (69, 76, "Organ, Stimulant"), (77, 84, "Organ, Preservative"), (85, 92, "Botanical, Stimulant"), (93, 100, "Venom, Sedative")],
}


def tables():
    T = [{"name": f"Ingredients — {k}", "folder": "Crafting", "formula": "1d100", "img": "icons/consumables/plants/leaf-herb-green.webp",
          "description": "On a critical success, roll twice.", "results": v} for k, v in TERRAIN.items()]
    T.append({"name": "Creature Ingredient Yield", "folder": "Crafting", "formula": "1d6", "img": "icons/commodities/biological/organ-heart-red.webp",
              "description": "Roll by size (minimum 1; +1 on a critical success).",
              "results": [(1, 1, "Tiny: 1d4−2"), (2, 2, "Small: 1d4−1"), (3, 3, "Medium: 1d4"), (4, 4, "Large: 1d6"), (5, 5, "Huge: 1d8"), (6, 6, "Gargantuan: 1d10")]})
    return T


RULES = """<h2>Crafting</h2><p><strong>Tool proficiency:</strong> one tool set at Crafting rank 1, another at ranks 3, 5, 7, 9 and 11. Without proficiency you add only Intellect,
and can't make Masterwork or magic items with those tools.</p>
<p><strong>Requirements:</strong> item level ≤ your level; Crafting ranks ≥ half item level (round up); proper tools and materials; talents (Alchemical, Magical, Snare Crafting) where needed;
a formula or example for uncommon items.</p>
<p><strong>Complexity:</strong> Simple DC 5 (4 h–1 day) · Involved DC 10 (1–3 days) · Complex DC 15 (3 days–2 weeks) · Articulate DC 20 (2 weeks–2 months) · Immaculate DC 25 (2+ months).
Poor workspace: Misfortune on the first check; ideal workspace or a formula for a common item: Fortune.</p>
<p><strong>Crafting Challenge</strong> (at half time): a Skill Challenge, 3 successes before 3 failures. 3/0 critical success (half time or recover 25% materials, or Masterwork if you have the materials);
3/1 success; 3/2 partial (+50% time or materials); 2/3 partial failure (lose half materials, Fortune on the next attempt); 1/3 failure (lose half, restart); 0/3 lose all.</p>
<p><strong>Batches:</strong> up to 4 consumables per challenge. <strong>Masterwork:</strong> DC +5, materials +50%; double Durability and BT; weapons +1 attack and damage;
armor +1 Soak, +1 MD, −1 CP, +1 Hardness; shields +1 bonus and Hardness; tools 1 Advantage.</p>
<h2>Essence &amp; Runes</h2><p><strong>Analyze Essence</strong> (2 AP, Mysticism) then <strong>Harvest Essence</strong> (2 AP, Survival) within 1d3 rounds. DCs: Common 10/12, Uncommon 15/17, Rare 20/22, Legendary 25/27.
Source level 0–4 Common, 5–10 Uncommon, 11–16 Rare, 17+ Legendary.</p>
<p><strong>Rune capacity</strong> = 1 + Potency (Masterwork required). Potency 1/2/3 sets minimum item level 5/11/17 and grants +1/+2/+3 (weapons: attack and damage; armor: Soak and MD; shields: bonus and Hardness).
Effect runes: Minor (Masterwork), Lesser (P1), Greater (P2), Major (P3). Upgrading reuses the rune: half materials and time, 1 Advantage.</p>
<h2>Attunement</h2><p>Items with controllable abilities need attunement (10 slots). Opposed Skill Challenge against 1d20 + the item's level (or its owner's level if higher), using a skill that fits your approach.
Contested items may roll with Fortune. Gifting: 1-hour ritual (automatic) or 10 minutes (Fortune). Creators always succeed their first attunement.</p>
<h2>Potions</h2><p>Brewing talent (Magical Crafting, 4 Crafting, 4 Mysticism) unlocks <strong>Brew (+3)</strong> for BREWABLE spells. Batch up to 4 (base Strain per potion + 3 once).
Materials: 25 / 100 / 400 / 1,200 sp by level band. Critical success: Stable. On drinking, flat surge check DC 8 + half level (Stable: Fortune; overlevel drinker: Misfortune).</p>
<h2>Alchemy</h2><p>Requires Alchemical Crafting and usually a formula. Materials 10 / 40 / 160 / 480 sp by level band plus a source-tag and a function-tag ingredient (a third for the optional benefit).
Save DC 15 + level (Potent +2, Weak −2). Side-effect saves apply when you use a beneficial concoction on yourself. Damage concoctions deal double on a critical failure unless stated.</p>
<p><strong>Creature ingredients:</strong> Assess (Nature or Mysticism) then Harvest (Survival). Per-stretch harvest limit = Survival ranks. Soft tissue spoils in 1 hour (hot) to 1 day (cold).</p>
<h2>Snares</h2><p>Snare Crafting talent, snare kit, formula. Setting takes 1 minute; your Crafting result is the DC to notice it. Save DC 15 + snare level.</p>"""
