"""Armor, shields and shield maneuvers (Armor chapter). Flavor text rewritten; mechanics as printed.

The printed armor/shield strength column uses a 10-18 score scale. The system's abilities run about -2..5,
so the requirement is converted with (score - 10) / 2, rounded down, and the printed value is noted on the item.
"""

ARMOR = [
    # name, price, soak, maxReflex, cp, str, speedPenalty, bulk, material, properties, category
    ("Padded Armor", "2 sp", 1, 3, 0, 10, 0, "L", "cloth", [], "light"),
    ("Leather", "2 gp", 1, 4, -1, 10, 0, "1", "leather", [], "light"),
    ("Studded Leather", "3 gp", 2, 3, -1, 12, 0, "1", "leather", [], "light"),
    ("Chain Shirt", "5 gp", 3, 3, -1, 12, 0, "1", "metal", ["flexible", "noisy"], "light"),
    ("Hide", "2 gp", 3, 2, -2, 14, 5, "2", "leather", [], "medium"),
    ("Scale Mail", "4 gp", 4, 2, -2, 14, 5, "2", "metal", [], "medium"),
    ("Chain Mail", "6 gp", 5, 1, -2, 16, 5, "2", "metal", ["flexible", "noisy"], "medium"),
    ("Breastplate", "8 gp", 6, 1, -2, 16, 5, "2", "metal", [], "medium"),
    ("Splint Mail", "13 gp", 7, 1, -3, 16, 10, "3", "metal", [], "heavy"),
    ("Half Plate", "18 gp", 8, 1, -3, 16, 10, "3", "metal", [], "heavy"),
    ("Full Plate", "30 gp", 9, 0, -3, 18, 10, "4", "metal", ["bulwark"], "heavy"),
]

ARMOR_DESC = {
    "Padded Armor": "Layers of heavy quilted cloth. Cheap and easy to damage. Heavier suits include a padded undercoat in their price; wearing just the undercoat keeps the heavy armor's runes invested while you sleep or if the outer suit is destroyed, and nobody else can wear your heavy armor without it.",
    "Leather": "Boiled and shaped leather pieces over softer hide, giving some protection while barely slowing you down.",
    "Studded Leather": "Leather armor reinforced with rivets and small plates. Nearly as supple as plain leather and a good deal tougher.",
    "Chain Shirt": "A long shirt of interlocking iron rings covering the torso, upper arms and thighs. Much lighter than a full coat of mail.",
    "Hide": "Thick furs and rawhide, sometimes with molded leather panels. It turns a blade well but makes you heavy on your feet.",
    "Scale Mail": "Overlapping metal scales stitched onto a leather coat that covers the torso, arms and legs.",
    "Chain Mail": "A full coat of linked rings with leggings, sleeves and a hood, protecting most of the body.",
    "Breastplate": "Fitted plates guarding the chest, neck and sometimes hips, trading some coverage for freedom of movement.",
    "Splint Mail": "Mail reinforced with strips of metal along the torso and limbs. Comes with a padded undercoat and gauntlets.",
    "Half Plate": "Plate across the upper body with lighter protection on the arms and legs. Comes with a padded undercoat and gauntlets.",
    "Full Plate": "Interlocking steel plates that encase nearly the whole body. It's costly and heavy, and you'll want a hand putting it on, but little protects better. Comes with a padded undercoat and gauntlets.",
}

ARMOR_IMG = {
    "light": "icons/equipment/chest/breastplate-leather-brown-belted.webp",
    "medium": "icons/equipment/chest/breastplate-scale-grey.webp",
    "heavy": "icons/equipment/chest/breastplate-cuirass-steel-grey.webp",
}

MATERIAL_STATS = {"cloth": (1, 4, 2), "leather": (4, 16, 8), "metal": (9, 36, 18)}

SHIELDS = [
    # name, price, bonus, towerBonus, speedPenalty, bulk, str, hardness, hp, bt, bash, secondary, maneuvers
    ("Buckler", "1 gp", 1, 0, 0, "L", 12, 3, 6, 3, "1d4", 2, ["Shield Block", "Reactive Shield"]),
    ("Light Shield", "1 gp", 2, 0, 0, "1", 13, 3, 12, 6, "1d6", 3, ["Shield Block", "Aggressive Block"]),
    ("Heavy Shield", "2 gp", 2, 0, 0, "1", 14, 5, 18, 9, "1d8", 4, ["Shoving Block", "Shield Block"]),
    ("Tower Shield", "10 gp", 2, 4, 5, "4", 15, 5, 24, 12, "1d10", 5, ["Shield Block", "Shield Warden"]),
]

SHIELD_DESC = {
    "Buckler": "A small steel disc strapped to the forearm, loved by duelists and quick skirmishers. You can raise it while that hand is free or holding a light object that isn't a weapon.",
    "Light Shield": "A round or kite shield of wood or thin steel. Wooden versions are cheaper; steel ones last longer.",
    "Heavy Shield": "A broad, reinforced shield of steel or iron-bound planks, heavy enough to shove a foe back.",
    "Tower Shield": "A massive wall of metal-banded wood that covers nearly the whole body. Once it's raised you can use the Take Cover reaction with the shield as your cover (+2 raised, +4 when taking cover).",
}

MANEUVERS = {
    "Shield Block": ("While your shield is raised and you would take damage from a physical attack, spend 1 Action Point as a reaction to catch the blow. The shield absorbs damage up to its Hardness; you and the shield each take whatever is left, which may break or destroy the shield.",
                     "You would take damage from a physical attack while your shield is raised."),
    "Reactive Shield": ("When an enemy hits you with a melee strike while you're holding a shield that isn't raised, spend 1 Action Point as a reaction to jerk it into place. You immediately Raise a Shield, and its bonus counts toward your defense against the triggering attack.",
                        "An enemy hits you with a melee strike while your shield is lowered."),
    "Aggressive Block": ("When you Shield Block against an adjacent attacker your size or smaller, spend 1 more Action Point to shove back. The attacker chooses: it's pushed 5 feet in a direction you pick, or it becomes Off-Balance until the start of your next turn. If the push would slam it into a solid object, difficult terrain or another creature, it becomes Off-Balance instead.",
                         "You use Shield Block against an adjacent creature your size or smaller."),
    "Shoving Block": ("When you Shield Block against an adjacent attacker no more than two sizes larger than you, spend 1 more Action Point to drive it back 10 feet. If it has to stop early because it hits an object, it takes damage equal to your Might (minimum 1).",
                      "You use Shield Block against an adjacent creature no more than two sizes larger."),
    "Shield Warden": ("While your shield is raised and an adjacent ally would take damage from a physical attack, spend 1 Action Point as a reaction to cover them. The shield absorbs damage up to its Hardness; your ally and the shield each take whatever is left.",
                      "An adjacent ally would take damage from a physical attack while your shield is raised."),
}


def conv(score):
    return (score - 10) // 2


def price(p):
    n, d = p.split()
    return int(n), d


def bulk(b):
    return 0.1 if b == "L" else float(b)


def entries():
    out = []
    for (name, pr, soak, md, cp, st, sp, bk, mat, props, cat) in ARMOR:
        pv, pd = price(pr)
        h, hp, bt = MATERIAL_STATS[mat]
        out.append({"name": name, "type": "armor", "img": ARMOR_IMG[cat], "folder": f"{cat.title()} Armor",
                    "system": {"category": cat, "soak": soak, "maxReflex": md, "penalty": cp,
                               "requirement": {"ability": "might", "value": conv(st)}, "speedPenalty": sp,
                               "traits": props, "price": {"value": pv, "denomination": pd}, "bulk": bulk(bk),
                               "material": mat, "hardness": h, "hp": {"value": hp, "max": hp}, "brokenThreshold": bt,
                               "description": f"<p>{ARMOR_DESC[name]}</p><p><em>Printed strength requirement {st}, converted to Might {conv(st)}.</em></p>"}})
    for (name, pr, bonus, tower, sp, bk, st, hard, hp, bt, bash, sec, mans) in SHIELDS:
        pv, pd = price(pr)
        out.append({"name": name, "type": "shield", "img": "icons/equipment/shield/heater-steel-worn.webp" if name != "Buckler" else "icons/equipment/shield/buckler-wooden-boss-steel.webp",
                    "folder": "Shields",
                    "system": {"bonus": bonus, "coverBonus": tower, "speedPenalty": sp, "price": {"value": pv, "denomination": pd},
                               "bulk": bulk(bk), "requirement": {"ability": "might", "value": conv(st)}, "hardness": hard,
                               "hp": {"value": hp, "max": hp}, "brokenThreshold": bt,
                               "bash": {"dice": bash, "type": "bludgeoning", "secondary": sec}, "maneuvers": mans,
                               "raised": False,
                               "description": f"<p>{SHIELD_DESC[name]}</p><p><strong>Maneuvers:</strong> {', '.join(mans)}.</p><p><em>Printed strength requirement {st}, converted to Might {conv(st)}.</em></p>"}})
    return out


def techniques():
    out = []
    for name, (text, trigger) in MANEUVERS.items():
        out.append({"name": name, "type": "technique", "img": "icons/equipment/shield/heater-crystal-blue.webp",
                    "folder": "Shield Techniques",
                    "system": {"kind": "shield", "requirements": "specialized with a shield that grants this maneuver", "cost": "reaction",
                               "trigger": trigger, "pushable": False, "actionTraits": ["maneuver", "reaction", "shield"],
                               "description": f"<p><strong>Trigger:</strong> {trigger}</p><p>{text}</p>",
                               "roll": {"type": "", "save": "", "damage": "", "damageType": ""}, "applies": {}}})
    return out
