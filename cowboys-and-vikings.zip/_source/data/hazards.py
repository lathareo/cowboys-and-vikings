"""Hazards chapter: worked-example hazard actors and one-roll hazard tables."""

def _rungs(skill, lvl, r):
    return (f"<p><strong>Passive Awareness — {skill}</strong></p><ol>" +
            "".join(f"<li>({lvl + t}+) {x}</li>" for t, x in zip((1, 6, 11, 16), r)) + "</ol>")


HAZARDS = [
    dict(name="Hidden Pit", level=0, nature="reactive", hazardType="trap", skill="thievery", dc=15,
         trigger="A creature steps onto the hidden cover.", fav="Jump to Safety", worst="Duck and Cover",
         desc="A shallow pit disguised under debris, cloth or loose earth.",
         rungs=["The ground looks slightly disturbed.", "A faint seam where the cover doesn't match.", "The pit cover's outline is obvious.", "The holding mechanism is clear; it can be disabled without a roll (GM's call)."],
         effect="Reflex save. Failure: falls in, 1d6 bludgeoning. Success: catches the edge.", damage="1d6", dtype="bludgeoning",
         disable="Thievery DC 15 — wedge the door or jam the mechanism.", reset="Close and reset the door from the pit's edge.", img="icons/environment/traps/pit-hole.webp"),
    dict(name="Sealed Passage", level=1, nature="reactive", hazardType="trap", skill="thievery", dc=16,
         trigger="A creature crosses the hidden threshold.", fav="Jump to Safety", worst="Brace for Impact", hardness=8, hp=40, bt=20,
         desc="A corridor section whose walls grind shut behind whoever passes the threshold.",
         rungs=["The stonework here looks newer.", "A faint seam runs across floor and ceiling.", "You see where a sealing wall would emerge.", "You spot the release and know how to jam it."],
         effect="Reflex save. Failure: a stone wall seals behind the creature (no damage). Success: it scrambles back through. The wall has Hardness 8, Durability 40, BT 20.",
         disable="Thievery DC 16 — jam the mechanism.", reset="Reopen the wall and reset the mechanism from the far side.", img="icons/environment/traps/trap-jaw-tan.webp"),
    dict(name="Sinking Mire", level=3, nature="sustained", hazardType="environmental", skill="survival", dc=18,
         trigger="A creature steps onto the surface.", fav="Duck and Cover", worst="Jump to Safety",
         desc="Ground that looks solid but is a deceptive bog.",
         rungs=["The ground is a little too smooth and glossy.", "A faint sucking sound bubbles up now and then.", "Clear signs of a bog disguised as ground.", "You see a safe path around or across."],
         effect="Reflex save. Failure: Sinking condition. Success: steps back as the ground gives.", status="sinking",
         disable="Survival DC 18 — mark a permanent safe path.", reset="The surface settles after 24 hours.", img="icons/environment/wilderness/terrain-swamp.webp"),
    dict(name="Whispering Alcove", level=0, nature="reactive", hazardType="trap", skill="thievery", dc=15,
         trigger="A specific action near the wall (a word, a knock pattern).", fav="", worst="",
         desc="A wall section that opens onto a hidden alcove or passage.",
         rungs=["The wall sounds slightly hollow.", "A faint draft from a hairline seam.", "You find exactly where the mechanism is.", "You know the specific action that opens it."],
         effect="The wall swings open. No danger.", disable="", reset="Closes when everyone moves away or after 1 minute (GM's call).", img="icons/environment/settlement/door-secret.webp"),
    dict(name="Warded Effigy", level=4, nature="reactive", hazardType="magical", skill="mysticism", dc=19,
         trigger="A creature touches, moves or tries to take the effigy.", fav="", worst="",
         desc="A carved effigy bound to animate a guardian construct when disturbed.",
         rungs=["The carved eyes seem to follow movement.", "Faint runes are etched into the base.", "The sigils are a binding/animation ward.", "You know exactly what guardian will appear and roughly what it can do."],
         effect="A guardian construct (built as an Adversary) animates and joins the scene; combat proceeds normally.",
         disable="Thievery DC 19 — deactivate the runes before disturbing it.", reset="None; spent once triggered or disabled.", img="icons/magic/symbols/rune-sigil-hook-white-red.webp"),
]


def actors():
    out = []
    for h in HAZARDS:
        react = f"Fortune: {h['fav']}; Misfortune: {h['worst']}." if h["fav"] else "No reaction save."
        out.append({"name": h["name"], "type": "hazard", "img": h["img"], "folder": None,
                    "prototypeToken": {"name": h["name"], "actorLink": False, "disposition": -1, "displayName": 20},
                    "system": {"level": h["level"], "nature": h["nature"], "hazardType": h["hazardType"],
                               "stealth": {"dc": h["dc"], "bonus": 0, "minRung": 1, "skill": h["skill"]},
                               "disable": h["disable"], "disableDC": h["dc"] if h["disable"] else 0, "trigger": h["trigger"],
                               "reactions": {"brace": True, "jump": True, "duck": True, "notes": react},
                               "save": {"ability": "reflex" if h["fav"] else "", "dc": h["dc"] if h["fav"] else 0},
                               "damage": h.get("damage", ""), "damageType": h.get("dtype", ""),
                               "hp": {"value": h.get("hp", 0), "max": h.get("hp", 0)}, "hardness": h.get("hardness", 0), "reset": h["reset"],
                               "description": f"<p>{h['desc']}</p>" + _rungs(h["skill"].title(), h["level"], h["rungs"]),
                               "effect": f"<p>{h['effect']}</p>"}})
    return out


TELL = ["A faint smell", "A subtle sound", "A visual irregularity", "A temperature difference", "An odd texture underfoot or underhand", "Structural wear nearby",
        "A residue or stain", "A hard-to-place unease"]
PAIR = ["Fortune: Brace / Misfortune: Jump", "Fortune: Brace / Misfortune: Duck", "Fortune: Jump / Misfortune: Brace", "Fortune: Jump / Misfortune: Duck",
        "Fortune: Duck / Misfortune: Brace", "Fortune: Duck / Misfortune: Jump"]
TRIG_STRIKE = ["Pressure plate (Mechanical — Thievery)", "Tripwire (Mechanical — Thievery)", "Weighted floor panel (Mechanical — Thievery)", "Touch or opening something (Mechanical — Thievery)",
               "Proximity ward (Magical — Mysticism)", "Command-word misfire (Magical — Mysticism)", "Residual curse (Magical — Mysticism)", "Sound-triggered (Mechanical — Thievery)",
               "Broken light beam (Mechanical — Thievery)", "Root or vine tension (Natural — Survival)", "Animal instinct or scent (Natural — Survival)", "Spark from an unstable vein (Natural — Survival)"]
TRIG_DISP = TRIG_STRIKE[:7] + ["Stepping on a marked space (Mechanical — Thievery)", "Crossing a hidden threshold (Mechanical — Thievery)", "Root or vine snare (Natural — Survival)",
                               "Disturbing an animal den (Natural — Survival)", "Unstable ground (Natural — Survival)"]
TRIG_AFF = ["Stepping into the area (Natural — Survival)", "Breathing the air (Natural — Survival)", "Brushing the source (Natural — Survival)", "Lingering too long (Natural — Survival)",
            "Touching the source (Mechanical — Thievery)", "Disturbing a container or seal (Mechanical — Thievery)", "A release mechanism (Mechanical — Thievery)", "Breaking a vessel (Mechanical — Thievery)",
            "Standing in the ward (Magical — Mysticism)", "Reading or speaking near a glyph (Magical — Mysticism)", "Disrupting a magical field (Magical — Mysticism)", "Absorbing residual magic (Magical — Mysticism)"]
TRIG_UTIL = ["A spoken word (Magical — Mysticism)", "A sequence of touches or knocks (Mechanical — Thievery)", "Pressure in the right spot (Mechanical — Thievery)", "Aligning something (Mechanical — Thievery)",
             "Presenting an item or symbol (Magical — Mysticism)", "Waiting quietly (Natural — Survival)", "A time, light or season (Natural — Survival)", "A small ritual gesture (Magical — Mysticism)"]

ONE_ROLL = {
    "Instant Strike": [
        ("Trigger", "1d12", TRIG_STRIKE),
        ("Damage Type", "1d10", ["Bludgeoning", "Piercing", "Slashing", "Fire", "Cold", "Lightning", "Acid", "Poison", "Thunder", "Force"]),
        ("Physical Form", "1d20", ["Spring-loaded blade", "Swinging pendulum", "Collapsing floor panel", "Dart battery", "Rolling boulder", "Spike wall", "Crushing ceiling",
                                   "Thorned vine", "Arcane bolt", "Rune-etched stone burst", "Weighted net", "Steam or gas vent", "Bear-trap jaws", "Javelin rack", "Powder cache",
                                   "Animated statue", "Ice-slick burst", "Whirling saw", "Charged grate", "Glass burst"]),
        ("Sensory Tell", "1d8", TELL), ("Reaction Pairing", "1d6", PAIR),
        ("Targeting", "1d4", ["Single target", "Small burst (plus adjacent)", "Line (corridor-width)", "Whole area"]),
    ],
    "Displacement": [
        ("Trigger", "1d12", TRIG_DISP),
        ("Outcome", "1d10", ["Sealed in", "Swept away", "Bound in place", "Dropped a level", "Space closes in", "Teleported a short way", "Suspended", "Buried",
                             "A companion or item is locked out", "Magically marked for later"]),
        ("Physical Form", "1d20", ["Grinding stone wall", "Iron portcullis", "Collapsing rope bridge", "Tightening net", "Closing stone jaws", "Trapdoor", "Rushing water channel",
                                   "Swinging cage", "Shifting sand pit", "Snapping vines", "Sealing ward-glyph", "Hoisting pulley rig", "Falling rubble", "Sliding wall panel",
                                   "Air whirlpool", "Spring shackles", "Retracting rope ladder", "Sinking platform", "Curling metal cage", "Shimmering rift"]),
        ("Sensory Tell", "1d8", TELL), ("Reaction Pairing", "1d6", PAIR),
        ("Severity", "1d4", ["Minor — undone on its own next turn", "Moderate — needs a successful check", "Significant — needs help or a tool", "Lasting — until disabled or reset"]),
    ],
    "Ambient Affliction": [
        ("Trigger", "1d12", TRIG_AFF),
        ("Condition Flavor", "1d10", ["Sinking", "Poisoned", "Diseased", "Confused", "Frightened", "Drained (Might)", "Enfeebled", "Clumsy", "Sickened", "Drained (Reflex)"]),
        ("Physical Form", "1d20", ["Sinking mud", "Drifting spores", "Creeping mold", "Biting insects", "Caustic slime", "Thorned thicket", "Toxic mineral vein", "Venomous fungi",
                                   "Gnat swarm", "Numbing lichen", "Decaying ward", "Cursed reliquary dust", "Enchanted miasma", "Contagion glyph", "Leaking machinery", "Gas vent",
                                   "Leaking cistern", "Dust-shedding stonework", "Stagnant pool", "Unnaturally cold ground"]),
        ("Sensory Tell", "1d8", TELL), ("Reaction Pairing", "1d6", PAIR),
    ],
    "Utility or Puzzle": [
        ("Trigger", "1d8", TRIG_UTIL),
        ("Revealed", "1d6", ["Hidden passage or alcove", "Concealed cache", "A message or vision", "A shortcut or safer path", "Light, warmth or comfort", "A clue, memory or answer"]),
        ("Physical Form", "1d4", ["Shifting wall or floor", "An object that opens or activates", "A light, sound or magical effect", "A natural feature parts"]),
    ],
}


def tables():
    out = []
    for arch, dice in ONE_ROLL.items():
        for label, formula, rows in dice:
            out.append({"name": f"Hazard ({arch}) — {label}", "folder": "Hazards", "formula": formula, "img": "icons/environment/traps/trap-jaw-steel.webp",
                        "results": [(i + 1, i + 1, r) for i, r in enumerate(rows)]})
    return out


RULES = """<h2>Hazards</h2><p>Fixed, non-thinking dangers that never take turns. <strong>Reactive</strong> hazards fire a Reaction every time their trigger is met.
<strong>Sustained</strong> hazards apply a lingering condition resolved through the victim's own recovery saves. Anything that makes choices should be an Adversary.</p>
<p><strong>Detection:</strong> Passive Awareness (compare Skill Bonus to hazard level: Rung 1 at +1, 2 at +6, 3 at +11 = spotted, 4 at +16);
active Search or Thievery (Perception-keyed) vs Detection DC 15 + level; otherwise a Perception save vs that DC when the trigger is met (group check during travel).</p>
<p><strong>Triggering:</strong> the player describes a reaction—Brace for Impact, Jump to Safety or Duck and Cover. The hazard's favored reaction rolls with Fortune, the worst with Misfortune.</p>
<p><strong>Disabling:</strong> usually Thievery (mechanical), Nature/Survival (environmental), or Dispel (magical). A critical failure triggers it; complex parts need several successes (critical = 2).
Hazards can be smashed (Hardness, Durability, BT); hitting one usually triggers it. Magical hazards without Dispel: a Mysticism Skill Challenge (1+ stretch) —
Yes And suppresses 2d4+2 rounds, Yes 1d4+1, Yes But 1d4; No But retry at a cost; No can't; No And triggers, worsens or surges.</p>
<p><strong>XP:</strong> Reactive = one-fifth of a same-level monster; Sustained = full. By level vs party (−4…+4): Reactive 2/3/4/6/8/12/16/24/32; Sustained 10/15/20/30/40/60/80/120/160.
One-roll hazards: damage 1d6 per hazard level; DCs 15 + level.</p>"""
