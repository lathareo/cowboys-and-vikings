import { compilePack } from "@foundryvtt/foundryvtt-cli";
import fs from "node:fs";
import path from "node:path";

const src = process.argv[2];
const dest = process.argv[3];
fs.rmSync(dest, { recursive: true, force: true });
fs.mkdirSync(dest, { recursive: true });
for ( const name of fs.readdirSync(src) ) {
  const dir = path.join(src, name);
  if ( !fs.statSync(dir).isDirectory() ) continue;
  await compilePack(dir, path.join(dest, name), { log: false, recursive: true });
  console.log("compiled", name);
}
