"""Generate Foundry compendium source JSON for Cowboys & Vikings, then compile to LevelDB via compile.mjs."""
import hashlib, json, os, shutil, sys, re

ROOT = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(ROOT, "data"))
OUT = os.path.join(ROOT, "packs-json")
SYSTEM_ID = "cowboys-and-vikings"
SYS_JSON = json.load(open(os.path.join(ROOT, "..", SYSTEM_ID, "system.json")))
STATS = {"coreVersion": "13.345", "systemId": SYSTEM_ID, "systemVersion": SYS_JSON["version"], "createdTime": 1790000000000,
         "modifiedTime": 1790000000000, "lastModifiedBy": None, "compendiumSource": None, "duplicateSource": None}

import talents, origins, bonds, spells_b, weapons, armor, gear, crafting, runes, maneuvers, exploration, crew, hazards, adversaries, tables_gm, surges

_used = set()
ALNUM = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"


def mkid(*parts):
    seed = "|".join(map(str, parts))
    n = 0
    while True:
        h = hashlib.sha1(f"{seed}#{n}".encode()).digest()
        s = "".join(ALNUM[b % 62] for b in h[:16])
        if s not in _used:
            _used.add(s)
            return s
        n += 1


class Pack:
    def __init__(self, name, doc):
        self.name, self.doc = name, doc
        self.docs, self.folders = [], {}
        self.coll = {"Item": "items", "Actor": "actors", "JournalEntry": "journal", "RollTable": "tables", "Macro": "macros"}[doc]

    def folder(self, path):
        if not path:
            return None
        parts = path.split("/")
        parent = None
        for i in range(len(parts)):
            key = "/".join(parts[:i + 1])
            if key not in self.folders:
                fid = mkid(self.name, "folder", key)
                self.folders[key] = {"_id": fid, "_key": f"!folders!{fid}", "name": parts[i], "type": self.doc, "folder": parent,
                                     "sorting": "a", "sort": 0, "color": None, "description": "", "flags": {}, "_stats": STATS}
            parent = self.folders[key]["_id"]
        return parent

    def add(self, d, folder=None):
        d = dict(d)
        fpath = d.pop("folder", None) if folder is None else folder
        sub = d.pop("subfolder", None)
        if sub and fpath:
            fpath = f"{fpath}/{sub}"
        d["_id"] = did = mkid(self.name, d.get("type", ""), d["name"])
        d["_key"] = f"!{self.coll}!{did}"
        d["folder"] = self.folder(fpath)
        d.setdefault("flags", {})
        d.setdefault("ownership", {"default": 0})
        d.setdefault("sort", 0)
        d["_stats"] = STATS
        if self.doc == "Item":
            d["effects"] = [self._effect(e, f"!items.effects!{did}", did) for e in d.get("effects", [])]
            d.setdefault("img", "icons/svg/item-bag.svg")
        elif self.doc == "Actor":
            items = []
            for it in d.get("items", []):
                it = dict(it)
                iid = mkid(self.name, did, "item", it["name"])
                it.update({"_id": iid, "_key": f"!actors.items!{did}.{iid}", "folder": None, "flags": it.get("flags", {}), "sort": 0, "_stats": STATS,
                           "ownership": {"default": 0}})
                it["effects"] = [self._effect(e, f"!actors.items.effects!{did}.{iid}", iid) for e in it.get("effects", [])]
                items.append(it)
            d["items"] = items
            d["effects"] = []
            pt = {"name": d["name"], "texture": {"src": d.get("img")}, "width": 1, "height": 1, "lockRotation": True, "sight": {"enabled": False}}
            pt.update(d.get("prototypeToken", {}))
            d["prototypeToken"] = pt
        self.docs.append(d)
        return d

    def _effect(self, e, prefix, parent):
        e = dict(e)
        eid = mkid(self.name, parent, "effect", e["name"])
        e.update({"_id": eid, "_key": f"{prefix}.{eid}", "type": "base", "system": {}, "statuses": [], "flags": e.get("flags", {}), "tint": "#ffffff",
                  "duration": {}, "origin": None, "description": "", "sort": 0, "_stats": STATS})
        return e

    def write(self):
        d = os.path.join(OUT, self.name)
        os.makedirs(d, exist_ok=True)
        for f in self.folders.values():
            json.dump(f, open(os.path.join(d, f"folder_{f['_id']}.json"), "w"), indent=1)
        for doc in self.docs:
            slug = re.sub(r"[^A-Za-z0-9]+", "_", doc["name"])[:40]
            json.dump(doc, open(os.path.join(d, f"{slug}_{doc['_id']}.json"), "w"), indent=1)
        print(f"{self.name:12s} {len(self.docs):4d} docs, {len(self.folders):3d} folders")


def table_doc(t):
    res = []
    for i, r in enumerate(t["results"]):
        lo, hi, text = r[0], r[1], r[2]
        name = r[3] if len(r) > 3 else re.sub(r"<[^>]+>", "", text)[:60]
        res.append({"type": "text", "name": name, "description": text if text.startswith("<") else f"<p>{text}</p>", "img": "icons/svg/d20-black.svg",
                    "weight": max(1, hi - lo + 1), "range": [lo, hi], "drawn": False, "flags": {}})
    return {"name": t["name"], "img": t.get("img", "icons/svg/d20-grey.svg"), "description": t.get("description", ""),
            "formula": t.get("formula") or f"1d{max(r[1] for r in t['results'])}", "replacement": True, "displayRoll": True,
            "results": res, "folder": t.get("folder")}


def finish_tables(pack, tables):
    for t in tables:
        d = pack.add(table_doc(t))
        for r in d["results"]:
            rid = mkid(pack.name, d["_id"], "result", r["range"][0], r["range"][1], r["name"])
            r.update({"_id": rid, "_key": f"!tables.results!{d['_id']}.{rid}", "_stats": STATS})


def journal(pack, name, pages, folder=None, img=None):
    doc = {"name": name, "pages": [], "categories": []}
    if img:
        doc["img"] = img
    d = pack.add(doc, folder=folder)
    for i, (title, html) in enumerate(pages):
        pid = mkid(pack.name, d["_id"], "page", title)
        d["pages"].append({"_id": pid, "_key": f"!journal.pages!{d['_id']}.{pid}", "name": title, "type": "text",
                           "title": {"show": True, "level": 1}, "text": {"format": 1, "content": html},
                           "sort": (i + 1) * 100000, "flags": {}, "ownership": {"default": -1}, "system": {}, "src": None,
                           "image": {}, "video": {"controls": True, "volume": 0.5}, "category": None, "_stats": STATS})
    return d


def J(name):
    return open(os.path.join(ROOT, "journals", name)).read()


def main():
    if os.path.isdir(OUT):
        shutil.rmtree(OUT)
    packs = {}

    def P(name, doc):
        packs[name] = Pack(name, doc)
        return packs[name]

    # ------------------------------------------------ Items
    p = P("origins", "Item")
    for e in origins.origins():
        p.add(e)
    p = P("genetics", "Item")
    for e in origins.genetics():
        p.add(e)
    p = P("talents", "Item")
    for e in talents.entries():
        p.add(e)
    p = P("techniques", "Item")
    for e in weapons.techniques():
        p.add(e, folder=e.get("folder") or "Weapon Techniques")
    for e in armor.techniques():
        p.add(e, folder=e.get("folder") or "Shield Techniques")
    p = P("bonds", "Item")
    for e in bonds.entries():
        p.add(e)
    p = P("spells", "Item")
    for e in spells_b.entries():
        p.add(e)
    for n, school, text, crit, trait in runes.CANTRIPS:
        p.add({"name": n, "type": "spell", "img": "icons/magic/perception/eye-ringed-glow-yellow.webp", "folder": "Item-Granted Cantrips",
               "system": {"school": school, "cantrip": True, "complexity": 0, "strain": 0, "cost": "2", "castingTime": "invocation", "pushable": True,
                          "deliveries": ["touch", "remote"] if "Remote" in text else ["touch"], "spellTraits": [t for t in ("cantrip", trait) if t],
                          "critSuccess": f"<p>{crit}</p>" if crit else "", "description": f"<p>{text}</p><p><em>Push: 1 Strain to cast for 1 AP.</em></p><p><em>Granted by certain runes.</em></p>"}})
    p = P("metamagic", "Item")
    for e in spells_b.metamagic():
        p.add(e)
    p = P("weapons", "Item")
    for e in weapons.entries():
        p.add(e)
    p = P("armor", "Item")
    for e in armor.entries():
        p.add(e)
    p = P("gear", "Item")
    for e in gear.entries():
        p.add(e)
    p = P("concoctions", "Item")
    for e in crafting.concoctions():
        p.add(e)
    p = P("runes", "Item")
    for e in runes.entries():
        p.add(e)
    p = P("materials", "Item")
    for e in crafting.materials():
        p.add(e)
    for e in crafting.essences():
        p.add(e, folder="Essences")
    for e in crafting.ingredients():
        p.add(e, folder="Ingredients")
    p = P("afflictions", "Item")
    for e in exploration.afflictions():
        p.add(e)
    for e in maneuvers.afflictions():
        p.add(e, folder=e.get("folder") or "Creature Afflictions")
    p = P("crew", "Item")
    for e in crew.entries():
        p.add(e)
    p = P("maneuvers", "Item")
    man = maneuvers.entries()
    for e in man:
        p.add(e)

    # ------------------------------------------------ Actors
    lookup = {m["name"]: m for m in man}
    p = P("adversaries", "Actor")
    for e in adversaries.entries(lookup):
        p.add(e)
    p = P("hazards", "Actor")
    for e in hazards.actors():
        p.add(e, folder="Worked Examples")

    # ------------------------------------------------ Tables
    p = P("tables", "RollTable")
    all_tables = []
    for t in surges.tables():
        t = dict(t)
        t["folder"] = "Wild Surges"
        all_tables.append(t)
    all_tables += tables_gm.tables() + origins.tables() + bonds.tables() + crafting.tables() + hazards.tables() + exploration.tables()
    finish_tables(p, all_tables)

    # ------------------------------------------------ Journals
    p = P("rules", "JournalEntry")
    journal(p, "System Guide", [("Using This System", J("system-guide.html"))])
    journal(p, "Playing the Game", [("Core Rules", J("playing.html"))], folder="Rules")
    journal(p, "Character Creation", [("Creating a Character", J("creation.html")), ("Virtues & Vices", origins.VIRTUE_VICE_JOURNAL + _vv_list())], folder="Rules")
    journal(p, "Skills", [("Skills & Actions", J("skills.html"))], folder="Rules")
    journal(p, "Encounters", [("Encounter Mode", J("encounters.html"))], folder="Rules")
    journal(p, "Weapons & Armor", [("Weapons, Armor & Shields", J("weapons-armor.html"))], folder="Rules")
    journal(p, "Gear & Supply", [("Gear, Bulk & Supply", gear.RULES)], folder="Rules")
    journal(p, "Magic", [("Magic Rules", J("magic.html"))], folder="Rules")
    journal(p, "Crafting & Treasure", [("Crafting, Runes & Alchemy", crafting.RULES)], folder="Rules")
    journal(p, "Exploration", [("Exploration Mode", exploration.RULES), ("G.R.A.P.H.", _graph_html())], folder="Rules")
    journal(p, "Hazards", [("Hazards", hazards.RULES)], folder="Rules")
    journal(p, "Bonds", [("Bonds", bonds.RULES)], folder="Rules")
    journal(p, "Negotiations", [("Negotiations", J("negotiations.html"))], folder="Game Master")
    journal(p, "Adversaries", [("Building Adversaries", J("adversaries.html"))], folder="Game Master")
    journal(p, "The Crew", [("Crew Rules", J("crew.html"))] + _crew_pages(), folder="Rules")

    # ------------------------------------------------ Macros
    p = P("macros", "Macro")
    for name, img, cmd in MACROS:
        p.add({"name": name, "type": "script", "img": img, "scope": "global", "command": cmd, "author": None})

    for pk in packs.values():
        pk.write()
    return packs


def _vv_list():
    rows = "".join(f"<tr><td>{i*4+1}–{i*4+4}</td><td>{v}</td><td>{g}</td></tr>" for i, (v, g) in enumerate(origins.VICES_VIRTUES))
    return f"<h3>Vices &amp; Virtues (d100)</h3><table><thead><tr><th>d100</th><th>Vice</th><th>Virtue</th></tr></thead><tbody>{rows}</tbody></table>"


def _graph_html():
    out = "<p>Environments are rated for <strong>G</strong>ravity, <strong>R</strong>adiation, <strong>A</strong>tmosphere, <strong>P</strong>ressure and <strong>H</strong>eat/cold. Most checks are Fortitude saves; complete protection ignores a rating, partial protection usually steps it one closer to normal or reduces check frequency.</p>"
    for k, v in exploration.GRAPH.items():
        out += f"<h3>{k}</h3><ul>" + "".join(f"<li><strong>{n}:</strong> {t}</li>" for n, t in v) + "</ul>"
    out += "<p><strong>Environmental damage:</strong> Minor 1d6–2d6, Moderate 4d6, Major 8d6–12d6, Massive 16d6–24d6.</p>"
    return out


def _crew_pages():
    pages = []
    for key, (desc, q, start, jl, jobs) in crew.CREW_INFO.items():
        html = (f"<p>{desc}</p><p><em>{q}</em></p><p><strong>Starting benefits:</strong> {start}</p><p><strong>{jl}s:</strong></p><ul>"
                + "".join(f"<li>{j}</li>" for j in jobs) + "</ul><p>Crew abilities and upgrades for this type are in the <em>Crew Abilities &amp; Upgrades</em> compendium.</p>")
        pages.append((crew.TYPE_NAMES[key], html))
    return pages


MACROS = [
    ("Fate & Chaos Tracker", "icons/sundries/gaming/dice-runed-brown.webp", "game.cnv.macros.openPools();"),
    ("GM Toolkit", "icons/sundries/documents/document-sealed-signatures-red.webp", "game.cnv.macros.openToolkit();"),
    ("Take a Break", "icons/environment/wilderness/camp-improvised.webp", "game.cnv.macros.takeABreak();"),
    ("Short Rest", "icons/magic/time/hourglass-tilted-gray.webp", "game.cnv.macros.shortRest();"),
    ("Long Rest", "icons/magic/time/day-night-sunset-sunrise.webp", "game.cnv.macros.longRest();"),
    ("Flat Check", "icons/svg/d20-black.svg",
     "const dc = await foundry.applications.api.DialogV2.prompt({window:{title:'Flat Check'}, content:'<label>DC <input type=\"number\" name=\"dc\" value=\"15\"></label>', ok:{callback:(e,b)=>Number(b.form.elements.dc.value)}});\nif (dc) game.cnv.macros.flat(dc);"),
    ("Group Check", "icons/skills/social/diplomacy-unity-alliance.webp",
     "const opts = Object.entries(CONFIG.CNV.skills).map(([k,v])=>`<option value=\"${k}\">${game.i18n.localize(v.label)}</option>`).join('');\n"
     "const r = await foundry.applications.api.DialogV2.prompt({window:{title:'Group Check'}, content:`<div class=\"cnv-form\"><label>Skill <select name=\"skill\">${opts}</select></label><label>DC <input type=\"number\" name=\"dc\" value=\"15\"></label></div>`, ok:{callback:(e,b)=>({skill:b.form.elements.skill.value, dc:Number(b.form.elements.dc.value)})}});\n"
     "if (r) game.cnv.macros.groupCheck(r.skill, r.dc);"),
    ("Falling Damage", "icons/magic/movement/trail-streak-zigzag-yellow.webp",
     "const r = await foundry.applications.api.DialogV2.prompt({window:{title:'Falling'}, content:'<div class=\"cnv-form\"><label>Feet fallen <input type=\"number\" name=\"feet\" value=\"20\"></label><label>Soft landing reduction (ft) <input type=\"number\" name=\"soft\" value=\"0\"></label></div>', ok:{callback:(e,b)=>({feet:Number(b.form.elements.feet.value), soft:Number(b.form.elements.soft.value)})}});\n"
     "if (r) game.cnv.macros.falling(r.feet, {soft:r.soft});"),
    ("Wild Surge", "icons/magic/lightning/bolt-strike-purple-pink.webp",
     "const schools = Object.entries(CONFIG.CNV.spellSchools).map(([k,v])=>`<option value=\"${k}\">${game.i18n.localize(v.label ?? v)}</option>`).join('');\n"
     "const r = await foundry.applications.api.DialogV2.prompt({window:{title:'Wild Surge'}, content:`<div class=\"cnv-form\"><label>School <select name=\"school\">${schools}</select></label></div>`, ok:{callback:(e,b)=>b.form.elements.school.value}});\n"
     "if (r) game.cnv.macros.surge(r);"),
    ("Toggle Condition (selected)", "icons/svg/aura.svg",
     "const opts = CONFIG.statusEffects.map(s=>`<option value=\"${s.id}\">${game.i18n.localize(s.name)}</option>`).join('');\n"
     "const id = await foundry.applications.api.DialogV2.prompt({window:{title:'Toggle Condition'}, content:`<select name=\"c\">${opts}</select>`, ok:{callback:(e,b)=>b.form.elements.c.value}});\n"
     "if (id) for (const t of canvas.tokens.controlled) await t.actor?.toggleStatusEffect(id);"),
]

if __name__ == "__main__":
    main()
