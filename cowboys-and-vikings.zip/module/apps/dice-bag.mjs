/**
 * Dice Bag — a visual pool builder for quick, impromptu rolls.
 * Left-click a die to add it, right-click to remove one. Advantage/Disadvantage and Fortune/Misfortune
 * apply to the d20 only (Advantage ±2 per level, Fortune 2d20 keep highest).
 */
const { ApplicationV2, HandlebarsApplicationMixin } = foundry.applications.api;
const L = k => game.i18n.localize(k);
const DICE = [4, 6, 8, 10, 12, 20, 100];

export class DiceBag extends HandlebarsApplicationMixin(ApplicationV2) {
  static DEFAULT_OPTIONS = {
    id: "cnv-dice-bag",
    classes: ["cnv", "cnv-dice-bag"],
    window: { title: "CNV.DiceBag.Title", icon: "fa-solid fa-dice", resizable: false },
    position: { width: 340, height: "auto" },
    actions: {
      addDie: DiceBag.#addDie, clear: DiceBag.#clear, roll: DiceBag.#roll, luck: DiceBag.#luck, adv: DiceBag.#adv
    }
  };

  static PARTS = { main: { template: "systems/cowboys-and-vikings/templates/apps/dice-bag.hbs" } };

  pool = Object.fromEntries(DICE.map(d => [d, 0]));
  modifier = 0;
  adv = 0;           // net levels, + advantage, − disadvantage
  luck = "";          // "", "fortune", "misfortune"
  label = "";

  get formula() {
    const terms = [];
    for ( const d of DICE ) {
      const n = this.pool[d];
      if ( !n ) continue;
      if ( d === 20 && this.luck ) {
        // One d20 gets Fortune/Misfortune; the rest roll normally
        terms.push(this.luck === "fortune" ? "2d20kh" : "2d20kl");
        if ( n > 1 ) terms.push(`${n - 1}d20`);
      } else terms.push(`${n}d${d}`);
    }
    if ( !terms.length ) return "";
    let f = terms.join(" + ");
    const mod = this.modifier + (this.pool[20] ? this.adv * 2 : 0);
    if ( mod ) f += ` ${mod > 0 ? "+" : "−"} ${Math.abs(mod)}`;
    return f.replace("−", "-");
  }

  async _prepareContext() {
    return {
      dice: DICE.map(d => ({ d, count: this.pool[d], icon: d === 100 ? "fa-solid fa-percent" : `fa-solid fa-dice-d${d === 100 ? 10 : d}` })),
      modifier: this.modifier, adv: this.adv, luck: this.luck, label: this.label,
      advLabel: this.adv > 0 ? `${L("CNV.Advantage")} ${this.adv}` : this.adv < 0 ? `${L("CNV.Disadvantage")} ${-this.adv}` : L("CNV.DiceBag.Straight"),
      formula: this.formula || "—",
      rollModes: Object.entries(CONFIG.Dice.rollModes).map(([value, m]) => ({ value, label: L(m?.label ?? m), selected: value === (this.rollMode ?? game.settings.get("core", "rollMode")) }))
    };
  }

  _onRender(context, options) {
    super._onRender?.(context, options);
    const el = this.element;
    el.querySelectorAll("[data-action=addDie]").forEach(b => b.addEventListener("contextmenu", ev => {
      ev.preventDefault();
      const d = Number(b.dataset.die);
      this.pool[d] = Math.max(0, this.pool[d] - 1);
      this.render();
    }));
    el.querySelector("[name=modifier]")?.addEventListener("change", ev => { this.modifier = Number(ev.target.value) || 0; this.render(); });
    el.querySelector("[name=label]")?.addEventListener("change", ev => { this.label = ev.target.value; });
    el.querySelector("[name=rollMode]")?.addEventListener("change", ev => { this.rollMode = ev.target.value; });
  }

  static #addDie(event, target) {
    const d = Number(target.dataset.die);
    this.pool[d] = Math.min(20, this.pool[d] + 1);
    this.render();
  }

  static #adv(event, target) {
    this.adv = Math.clamp(this.adv + Number(target.dataset.delta), -5, 5);
    this.render();
  }

  static #luck(event, target) {
    const v = target.dataset.luck;
    this.luck = this.luck === v ? "" : v;
    this.render();
  }

  static #clear() {
    for ( const d of DICE ) this.pool[d] = 0;
    this.modifier = 0; this.adv = 0; this.luck = ""; this.label = "";
    this.render();
  }

  static async #roll() {
    const formula = this.formula;
    if ( !formula ) return ui.notifications.warn(L("CNV.DiceBag.Empty"));
    const notes = [];
    if ( this.pool[20] && this.adv ) notes.push(this.adv > 0 ? `${L("CNV.Advantage")} ${this.adv}` : `${L("CNV.Disadvantage")} ${-this.adv}`);
    if ( this.pool[20] && this.luck ) notes.push(L(this.luck === "fortune" ? "CNV.Fortune" : "CNV.Misfortune"));
    const flavor = [this.label || L("CNV.DiceBag.Title"), notes.join(", ")].filter(Boolean).join(" — ");
    const roll = await new Roll(formula).evaluate();
    const speaker = ChatMessage.getSpeaker({ actor: canvas.tokens?.controlled[0]?.actor ?? game.user.character });
    await roll.toMessage({ speaker, flavor }, { rollMode: this.rollMode ?? game.settings.get("core", "rollMode") });
  }
}
