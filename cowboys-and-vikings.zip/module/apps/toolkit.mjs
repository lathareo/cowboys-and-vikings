const SYS = "cowboys-and-vikings";
const L = (k, d) => d ? game.i18n.format(k, d) : game.i18n.localize(k);
const { ApplicationV2, HandlebarsApplicationMixin } = foundry.applications.api;

/* -------------------------------------------- */
/*  Fate & Chaos pools                           */
/* -------------------------------------------- */

export class PoolsApp extends HandlebarsApplicationMixin(ApplicationV2) {
  static DEFAULT_OPTIONS = {
    id: "cnv-pools",
    classes: ["cnv", "cnv-pools"],
    window: { title: "CNV.Pools.Title", icon: "fa-solid fa-dice", resizable: false },
    position: { width: 300, height: "auto", top: 80, left: 120 },
    actions: {
      chaos: PoolsApp.#onChaos,
      fate: PoolsApp.#onFate,
      startSession: PoolsApp.#onStartSession,
      rollFate: PoolsApp.#onRollFate
    }
  };
  static PARTS = { main: { template: `systems/${SYS}/templates/apps/pools.hbs` } };

  async _prepareContext() {
    const pcs = game.actors.filter(a => a.type === "character" && a.hasPlayerOwner);
    return {
      isGM: game.user.isGM,
      chaos: game.settings.get(SYS, "chaosPool"),
      pcs: pcs.map(a => ({ id: a.id, name: a.name, img: a.img, fate: a.system.fate.value, die: a.system.fateDie,
        min: a.system.fateMin, max: a.system.fateMax, owner: a.isOwner }))
    };
  }

  adjustChaos(delta) {
    return import("../helpers/socket.mjs").then(m => m.asGM("adjustChaos", { delta }));
  }

  static async #onChaos(event, target) {
    if ( !game.user.isGM ) return;
    const delta = Number(target.dataset.delta);
    await game.settings.set(SYS, "chaosPool", Math.max(0, game.settings.get(SYS, "chaosPool") + delta));
    if ( delta < 0 ) ChatMessage.create({ content: `<div class="cnv-card cnv-chaos"><p>${L("CNV.Pools.ChaosSpent")}</p></div>` });
  }

  static async #onFate(event, target) {
    const actor = game.actors.get(target.dataset.actor);
    if ( !actor?.isOwner ) return;
    const delta = Number(target.dataset.delta);
    await actor.update({ "system.fate.value": Math.clamp(actor.system.fate.value + delta, 0, actor.system.fateMax) });
    this.render();
  }

  static async #onRollFate(event, target) {
    const actor = game.actors.get(target.dataset.actor);
    if ( actor?.isOwner ) await actor.rollFateDie();
    this.render();
  }

  static async #onStartSession() {
    if ( !game.user.isGM ) return;
    const ok = await foundry.applications.api.DialogV2.confirm({ window: { title: L("CNV.Pools.StartSession") }, content: `<p>${L("CNV.Pools.StartSessionHint")}</p>` });
    if ( !ok ) return;
    const pcs = game.actors.filter(a => a.type === "character" && a.hasPlayerOwner);
    for ( const a of pcs ) await a.startSession();
    await game.settings.set(SYS, "chaosPool", pcs.length);
    ChatMessage.create({ content: `<div class="cnv-card"><h4>${L("CNV.Pools.StartSession")}</h4><p>${L("CNV.Pools.SessionStarted", { n: pcs.length })}</p></div>` });
    this.render();
  }
}

/* -------------------------------------------- */
/*  GM Toolkit                                   */
/* -------------------------------------------- */

export class GMToolkit extends HandlebarsApplicationMixin(ApplicationV2) {
  static DEFAULT_OPTIONS = {
    id: "cnv-toolkit",
    classes: ["cnv", "cnv-toolkit"],
    window: { title: "CNV.Toolkit.Title", icon: "fa-solid fa-hat-cowboy", resizable: true },
    position: { width: 560, height: 640 },
    actions: {
      scAdd: GMToolkit.#onSkillChallenge,
      scReset: GMToolkit.#onSkillReset,
      scPost: GMToolkit.#onSkillPost,
      negStart: GMToolkit.#onNegStart,
      negResult: GMToolkit.#onNegResult,
      negPost: GMToolkit.#onNegPost,
      encRefresh: GMToolkit.#onEncRefresh,
      reactionRoll: GMToolkit.#onReaction,
      moraleRoll: GMToolkit.#onMorale,
      brokenRoll: GMToolkit.#onBroken
    },
    form: { handler: GMToolkit.#onSubmit, submitOnChange: true, closeOnSubmit: false },
    tag: "form"
  };

  static PARTS = {
    tabs: { template: "templates/generic/tab-navigation.hbs" },
    challenge: { template: `systems/${SYS}/templates/apps/toolkit-challenge.hbs`, scrollable: [""] },
    negotiation: { template: `systems/${SYS}/templates/apps/toolkit-negotiation.hbs`, scrollable: [""] },
    encounter: { template: `systems/${SYS}/templates/apps/toolkit-encounter.hbs`, scrollable: [""] },
    reaction: { template: `systems/${SYS}/templates/apps/toolkit-reaction.hbs`, scrollable: [""] }
  };

  static TABS = {
    primary: {
      tabs: [
        { id: "challenge", icon: "fa-solid fa-list-check", label: "CNV.Toolkit.SkillChallenge" },
        { id: "negotiation", icon: "fa-solid fa-handshake", label: "CNV.Toolkit.Negotiation" },
        { id: "encounter", icon: "fa-solid fa-scale-balanced", label: "CNV.Toolkit.Encounter" },
        { id: "reaction", icon: "fa-solid fa-face-angry", label: "CNV.Toolkit.Reaction" }
      ],
      initial: "challenge"
    }
  };

  /** Encounter builder working state (not persisted). */
  encounter = { threat: "moderate", partySize: 4, rows: [] };
  reaction = { cat: "average", nudge: 0 };

  async _prepareContext(options) {
    const ctx = await super._prepareContext(options);
    const C = CONFIG.CNV;
    const sc = foundry.utils.mergeObject({ name: "", successes: 0, failures: 0, log: [] }, game.settings.get(SYS, "skillChallenge") ?? {});
    const neg = foundry.utils.mergeObject({ npc: "", attitude: "indifferent", interest: 2, patience: 3, motivations: [{ name: "", used: false }, { name: "", used: false }],
      pitfall: "", limit: "", offers: { 5: "", 4: "", 3: "", 2: "", 1: "", 0: "" }, active: false, log: [] }, game.settings.get(SYS, "negotiation") ?? {});
    const ladderKey = `${Math.min(sc.successes, 3)}-${Math.min(sc.failures, 3)}`;
    const done = sc.successes >= 3 || sc.failures >= 3;
    const partyLevel = game.settings.get(SYS, "partyLevel");
    const enc = this.encounter;
    const budget = C.encounterBudget[enc.threat]?.[Math.clamp(enc.partySize, 1, 6) - 1] ?? 0;
    const spent = enc.rows.reduce((t, r) => t + r.xp * r.count, 0);
    return {
      ...ctx,
      C, sc, neg, partyLevel,
      scPips: { s: [0, 1, 2].map(i => i < sc.successes), f: [0, 1, 2].map(i => i < sc.failures) },
      scResult: done ? C.challengeLadder[ladderKey] : null,
      attitudes: Object.fromEntries(Object.entries(C.attitudes).map(([k, v]) => [k, L(v.label)])),
      negResult: C.negotiationResults[neg.interest],
      negOfferList: [5, 4, 3, 2, 1, 0].map(i => ({ i, label: L(C.negotiationResults[i].label), value: neg.offers?.[i] ?? "" })),
      motivations: C.motivations,
      enc, budget, spent, remaining: budget - spent,
      threats: Object.keys(C.encounterBudget).map(k => ({ key: k, label: L(`CNV.Threat.${k}`) })),
      intellect: C.intellectCategories.map(c => ({ ...c, selected: c.key === this.reaction.cat })),
      reaction: this.reaction,
      tabs: this._prepareTabs("primary")
    };
  }

  async _preparePartContext(partId, context) {
    context = await super._preparePartContext(partId, context);
    if ( context.tabs?.[partId] ) context.tab = context.tabs[partId];
    return context;
  }

  static async #onSubmit(event, form, formData) {
    const data = foundry.utils.expandObject(formData.object);
    if ( data.sc ) await game.settings.set(SYS, "skillChallenge", foundry.utils.mergeObject(game.settings.get(SYS, "skillChallenge") ?? {}, data.sc));
    if ( data.neg ) {
      const cur = game.settings.get(SYS, "negotiation") ?? {};
      if ( data.neg.motivations ) data.neg.motivations = Object.values(data.neg.motivations);
      await game.settings.set(SYS, "negotiation", foundry.utils.mergeObject(cur, data.neg));
    }
    if ( data.reactionCat !== undefined ) this.reaction = { cat: data.reactionCat, nudge: Number(data.reactionNudge) || 0 };
    if ( data.enc ) {
      this.encounter.threat = data.enc.threat ?? this.encounter.threat;
      this.encounter.partySize = Number(data.enc.partySize) || this.encounter.partySize;
      if ( data.enc.rows ) for ( const [i, r] of Object.entries(data.enc.rows) ) {
        if ( this.encounter.rows[i] ) this.encounter.rows[i].count = Number(r.count) || 0;
      }
    }
    this.render();
  }

  /* ---------- Skill Challenge ---------- */
  static async #onSkillChallenge(event, target) {
    const sc = foundry.utils.mergeObject({ successes: 0, failures: 0, log: [] }, game.settings.get(SYS, "skillChallenge") ?? {});
    if ( sc.successes >= 3 || sc.failures >= 3 ) return ui.notifications.info(L("CNV.Challenge.Finished"));
    const kind = target.dataset.kind;
    const alt = event.shiftKey; // crit alternative: double success/failure instead of removing
    switch ( kind ) {
      case "success": sc.successes++; break;
      case "failure": sc.failures++; break;
      case "critSuccess":
        if ( alt || sc.failures === 0 ) sc.successes += 2; else { sc.successes++; sc.failures--; }
        break;
      case "critFailure":
        if ( alt || sc.successes === 0 ) sc.failures += 2; else { sc.failures++; sc.successes--; }
        break;
    }
    sc.successes = Math.min(3, sc.successes); sc.failures = Math.min(3, sc.failures);
    sc.log = [...(sc.log ?? []), L(`CNV.Challenge.${kind}`)];
    await game.settings.set(SYS, "skillChallenge", sc);
    this.render();
    if ( sc.successes >= 3 || sc.failures >= 3 ) GMToolkit.#onSkillPost.call(this);
  }

  static async #onSkillReset() {
    await game.settings.set(SYS, "skillChallenge", { name: "", successes: 0, failures: 0, log: [] });
    this.render();
  }

  static async #onSkillPost() {
    const sc = game.settings.get(SYS, "skillChallenge");
    const key = `${Math.min(sc.successes, 3)}-${Math.min(sc.failures, 3)}`;
    const res = CONFIG.CNV.challengeLadder[key];
    const pips = (n, cls) => [0, 1, 2].map(i => `<i class="fa-${i < n ? "solid" : "regular"} fa-circle ${cls}"></i>`).join("");
    ChatMessage.create({ content: `<div class="cnv-card cnv-challenge"><h4><i class="fa-solid fa-list-check"></i> ${sc.name || L("CNV.Toolkit.SkillChallenge")}</h4>
      <p>${L("CNV.Challenge.Successes")}: ${pips(sc.successes, "success")} · ${L("CNV.Challenge.Failures")}: ${pips(sc.failures, "failure")}</p>
      ${res ? `<p class="cnv-ladder ${res.key}"><strong>${L(res.label)}</strong> — ${L(res.text)}</p>` : ""}</div>` });
  }

  /* ---------- Negotiation ---------- */
  static async #onNegStart() {
    const neg = game.settings.get(SYS, "negotiation") ?? {};
    const att = CONFIG.CNV.attitudes[neg.attitude ?? "indifferent"];
    neg.interest = att.interest; neg.patience = att.patience; neg.active = true; neg.log = [];
    (neg.motivations ?? []).forEach(m => m.used = false);
    await game.settings.set(SYS, "negotiation", neg);
    this.render();
    GMToolkit.#onNegPost.call(this, null, null, L("CNV.Negotiation.Opens"));
  }

  static async #onNegResult(event, target) {
    const neg = game.settings.get(SYS, "negotiation");
    const r = target.dataset.result;
    const d = {
      critSuccess: [1, 0], success: [1, -1], failure: [0, -1], critFailure: [-1, -2],
      pitfall: [-1, -1], limit: [0, -1], readFail: [0, -1], repeat: [0, -1], deceptionCaught: [-2, -2]
    }[r] ?? [0, 0];
    neg.interest = Math.clamp(neg.interest + d[0], 0, 5);
    neg.patience = Math.clamp(neg.patience + d[1], 0, 5);
    neg.log = [...(neg.log ?? []), L(`CNV.Negotiation.R.${r}`)];
    await game.settings.set(SYS, "negotiation", neg);
    this.render();
    let note = L(`CNV.Negotiation.R.${r}`);
    if ( neg.interest >= 5 || neg.interest <= 0 || neg.patience <= 0 ) { neg.active = false; note += ` — ${L("CNV.Negotiation.Ends")}`; await game.settings.set(SYS, "negotiation", neg); }
    GMToolkit.#onNegPost.call(this, null, null, note);
  }

  static async #onNegPost(event, target, note = "") {
    const neg = game.settings.get(SYS, "negotiation");
    const res = CONFIG.CNV.negotiationResults[neg.interest];
    const offer = neg.offers?.[neg.interest];
    const bar = (n, cls) => [1, 2, 3, 4, 5].map(i => `<i class="fa-${i <= n ? "solid" : "regular"} fa-square ${cls}"></i>`).join("");
    ChatMessage.create({ content: `<div class="cnv-card cnv-negotiation"><h4><i class="fa-solid fa-handshake"></i> ${L("CNV.Toolkit.Negotiation")}${neg.npc ? `: ${neg.npc}` : ""}</h4>
      ${note ? `<p><em>${note}</em></p>` : ""}
      <p>${L("CNV.Negotiation.Interest")}: ${bar(neg.interest, "interest")} (${neg.interest})<br>${L("CNV.Negotiation.Patience")}: ${bar(neg.patience, "patience")} (${neg.patience})</p>
      <p class="cnv-ladder ${res.key}"><strong>${L("CNV.Negotiation.CurrentOffer")}: ${L(res.label)}</strong>${offer ? ` — ${offer}` : ""}</p></div>` });
  }

  /* ---------- Encounter ---------- */
  static async #onEncRefresh() {
    const C = CONFIG.CNV;
    const partyLevel = game.settings.get(SYS, "partyLevel");
    const tokens = canvas.tokens?.controlled.length ? canvas.tokens.controlled : (game.combat?.combatants.map(c => c.token?.object).filter(Boolean) ?? []);
    const groups = new Map();
    for ( const t of tokens ) {
      const a = t.actor;
      if ( !a || !["adversary", "hazard"].includes(a.type) ) continue;
      const key = a.uuid;
      const row = groups.get(key) ?? { name: a.name, level: a.system.level, rank: a.system.rank ?? a.system.nature, xp: a.system.xp, count: 0 };
      row.count++;
      groups.set(key, row);
    }
    this.encounter.rows = [...groups.values()];
    const pcs = game.actors.filter(a => a.type === "character" && a.hasPlayerOwner).length;
    if ( pcs ) this.encounter.partySize = Math.clamp(pcs, 1, 6);
    this.render();
  }

  /* ---------- Reaction & Morale ---------- */
  static async #onReaction(event, target) {
    const cat = this.reaction.cat;
    const nudge = this.reaction.nudge;
    const roll = await new Roll("2d6").evaluate();
    const bands = [2, 5, 8, 11, 12];
    let idx = bands.findIndex(b => roll.total <= b);
    idx = Math.clamp(idx + nudge, 0, 4);
    const key = String(bands[idx]);
    const text = CONFIG.CNV.reactionTable[key][cat];
    const catLabel = CONFIG.CNV.intellectCategories.find(c => c.key === cat)?.label ?? cat;
    return roll.toMessage({ flavor: `<div class="cnv-card"><h4>${L("CNV.Toolkit.Reaction")} — ${catLabel}${nudge ? ` (${nudge > 0 ? "+" : ""}${nudge} ${L("CNV.Reaction.Band")})` : ""}</h4><p>${text}</p></div>`,
      whisper: ChatMessage.getWhisperRecipients("GM") });
  }

  static async #onMorale() {
    const tokens = canvas.tokens?.controlled ?? [];
    const adv = tokens.map(t => t.actor).filter(a => a?.type === "adversary");
    if ( !adv.length ) return ui.notifications.warn(L("CNV.Morale.SelectGroup"));
    return adv[0].rollMorale();
  }

  static async #onBroken() {
    const roll = await new Roll("1d6").evaluate();
    const text = CONFIG.CNV.brokenElementOutcomes[roll.total - 1];
    return roll.toMessage({ flavor: `<div class="cnv-card"><h4>${L("CNV.Morale.BrokenOutcome")}</h4><p>${text}</p></div>`, whisper: ChatMessage.getWhisperRecipients("GM") });
  }
}
