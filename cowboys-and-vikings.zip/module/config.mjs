/**
 * Cowboys & Vikings — system configuration constants and rule tables.
 * Everything a sheet, roll or data model needs to look up lives here, on CONFIG.CNV.
 */
export const CNV = {};

CNV.id = "cowboys-and-vikings";

/* -------------------------------------------- */
/*  Abilities                                    */
/* -------------------------------------------- */
CNV.abilities = {
  might: { label: "CNV.Ability.might", abbr: "CNV.AbilityAbbr.might" },
  reflex: { label: "CNV.Ability.reflex", abbr: "CNV.AbilityAbbr.reflex" },
  fortitude: { label: "CNV.Ability.fortitude", abbr: "CNV.AbilityAbbr.fortitude" },
  intellect: { label: "CNV.Ability.intellect", abbr: "CNV.AbilityAbbr.intellect" },
  perception: { label: "CNV.Ability.perception", abbr: "CNV.AbilityAbbr.perception" },
  charisma: { label: "CNV.Ability.charisma", abbr: "CNV.AbilityAbbr.charisma" }
};

/** Short descriptions of each ability score value, from Playing the Game. */
CNV.abilityDescriptions = {
  might: { "-2": "Noticeably weak", "-1": "Below average", "0": "Average adult", "1": "Fit", "2": "Athletic", "3": "Very strong", "4": "Martial strong", "5": "Peak human" },
  reflex: { "-2": "Clumsy", "-1": "Awkward", "0": "Average", "1": "Quick", "2": "Nimble", "3": "Agile", "4": "Expertly nimble", "5": "Exceptional" },
  fortitude: { "-2": "Frail", "-1": "Weak", "0": "Average", "1": "Sturdy", "2": "Tough", "3": "Hardy", "4": "Iron body", "5": "Exceptional" },
  intellect: { "-2": "Dull", "-1": "Slow", "0": "Average", "1": "Bright", "2": "Clever", "3": "Smart", "4": "Brilliant", "5": "Genius" },
  perception: { "-2": "Oblivious", "-1": "Unaware", "0": "Average", "1": "Observant", "2": "Keen", "3": "Insightful", "4": "Wise", "5": "Sage-like" },
  charisma: { "-2": "Off-putting", "-1": "Unpolished", "0": "Average", "1": "Likeable", "2": "Charming", "3": "Compelling", "4": "Captivating", "5": "Magnetic" }
};

/* -------------------------------------------- */
/*  Skills                                       */
/* -------------------------------------------- */
/**
 * Every skill with its default key ability. Skills with two listed abilities
 * (Martial Arts, Melee Weapons, Mysticism) let the character pick which to use.
 */
CNV.skills = {
  acrobatics: { label: "CNV.Skill.acrobatics", ability: "reflex", armorPenalty: true },
  athletics: { label: "CNV.Skill.athletics", ability: "might", armorPenalty: true },
  crafting: { label: "CNV.Skill.crafting", ability: "intellect" },
  deception: { label: "CNV.Skill.deception", ability: "charisma" },
  diplomacy: { label: "CNV.Skill.diplomacy", ability: "charisma" },
  firearms: { label: "CNV.Skill.firearms", ability: "reflex", combat: true },
  intimidation: { label: "CNV.Skill.intimidation", ability: "charisma" },
  investigation: { label: "CNV.Skill.investigation", ability: "intellect" },
  martialArts: { label: "CNV.Skill.martialArts", ability: "might", alt: "reflex", combat: true, armorPenalty: true },
  medicine: { label: "CNV.Skill.medicine", ability: "intellect" },
  meleeWeapons: { label: "CNV.Skill.meleeWeapons", ability: "might", alt: "reflex", combat: true },
  missileWeapons: { label: "CNV.Skill.missileWeapons", ability: "reflex", combat: true },
  mysticism: { label: "CNV.Skill.mysticism", ability: "intellect", alt: "charisma" },
  nature: { label: "CNV.Skill.nature", ability: "perception" },
  perform: { label: "CNV.Skill.perform", ability: "charisma" },
  shields: { label: "CNV.Skill.shields", ability: "might", combat: true },
  sleightOfHand: { label: "CNV.Skill.sleightOfHand", ability: "reflex" },
  society: { label: "CNV.Skill.society", ability: "intellect" },
  stealth: { label: "CNV.Skill.stealth", ability: "reflex" },
  survival: { label: "CNV.Skill.survival", ability: "perception" },
  thievery: { label: "CNV.Skill.thievery", ability: "reflex" }
};

/** Lore skills share the Intellect key ability; each subcategory is its own skill. */
CNV.loreAbility = "intellect";

/** Common Lore subcategories, offered as suggestions on the sheet. */
CNV.commonLores = [
  "Academia", "Accounting", "Architecture", "Art", "Circus", "Engineering", "Farming", "Fishing", "Fortune-Telling",
  "Games", "Genealogy", "Gladiatorial", "Guild", "Heraldry", "Herbalism", "Hunting", "Labor", "Legal", "Library",
  "Mercantile", "Midwifery", "Milling", "Mining", "Sailing", "Scouting", "Scribing", "Stabling", "Tanning", "Theater",
  "Underworld", "Warfare"
];

/** Martial Arts unarmed damage by ranks. */
CNV.martialArtsDamage = [
  { min: 12, dice: "2d10" }, { min: 10, dice: "2d8" }, { min: 8, dice: "2d6" }, { min: 6, dice: "1d10" },
  { min: 4, dice: "1d8" }, { min: 2, dice: "1d6" }, { min: 1, dice: "1d4" }
];

/* -------------------------------------------- */
/*  Character Advancement                        */
/* -------------------------------------------- */
/** Level → { maxRanks, naturalSoak, saveBonus, abilityBoost } */
CNV.advancement = {
  1: { maxRanks: 2, naturalSoak: 0, saveBonus: 0 },
  2: { maxRanks: 3, naturalSoak: 0, saveBonus: 1 },
  3: { maxRanks: 3, naturalSoak: 0, saveBonus: 2 },
  4: { maxRanks: 4, naturalSoak: 1, saveBonus: 3, abilityBoost: true },
  5: { maxRanks: 4, naturalSoak: 1, saveBonus: 3 },
  6: { maxRanks: 5, naturalSoak: 1, saveBonus: 4 },
  7: { maxRanks: 5, naturalSoak: 1, saveBonus: 5 },
  8: { maxRanks: 6, naturalSoak: 2, saveBonus: 6, abilityBoost: true },
  9: { maxRanks: 6, naturalSoak: 2, saveBonus: 6 },
  10: { maxRanks: 7, naturalSoak: 2, saveBonus: 7 },
  11: { maxRanks: 7, naturalSoak: 2, saveBonus: 8 },
  12: { maxRanks: 8, naturalSoak: 3, saveBonus: 9, abilityBoost: true },
  13: { maxRanks: 8, naturalSoak: 3, saveBonus: 9 },
  14: { maxRanks: 9, naturalSoak: 3, saveBonus: 10 },
  15: { maxRanks: 9, naturalSoak: 3, saveBonus: 11 },
  16: { maxRanks: 10, naturalSoak: 4, saveBonus: 12, abilityBoost: true },
  17: { maxRanks: 10, naturalSoak: 4, saveBonus: 12 },
  18: { maxRanks: 11, naturalSoak: 4, saveBonus: 13 },
  19: { maxRanks: 11, naturalSoak: 4, saveBonus: 14 },
  20: { maxRanks: 12, naturalSoak: 5, saveBonus: 15, abilityBoost: true }
};

CNV.xpPerLevel = 1000;
CNV.startingSkillPoints = 6;
CNV.skillPointsPerLevel = 4;
CNV.startingTalents = 3;
CNV.talentsPerLevel = 2;
CNV.abilityPointBuy = 8;
CNV.abilityMaxAtFirst = 4;
CNV.abilityMax = 5;

/** Fate dice by level. */
CNV.fateDice = [
  { min: 16, die: "1d12", minimum: 5 },
  { min: 12, die: "1d10", minimum: 4 },
  { min: 8, die: "1d8", minimum: 3 },
  { min: 4, die: "1d6", minimum: 2 },
  { min: 1, die: "1d4", minimum: 1 }
];

/** Speed, travel and jump limits keyed off Might + Reflex. */
CNV.speedTable = [
  { max: -5, speed: 10, perMinute: 100, mph: 1, mpd: 8, longJump: 5, highJump: 1 },
  { max: -3, speed: 15, perMinute: 150, mph: 1.5, mpd: 12, longJump: 7, highJump: 2 },
  { max: -1, speed: 20, perMinute: 200, mph: 2, mpd: 16, longJump: 10, highJump: 2 },
  { max: 1, speed: 25, perMinute: 250, mph: 2.5, mpd: 20, longJump: 12, highJump: 3 },
  { max: 3, speed: 30, perMinute: 300, mph: 3, mpd: 24, longJump: 15, highJump: 3 },
  { max: 5, speed: 35, perMinute: 350, mph: 3.5, mpd: 28, longJump: 17, highJump: 4 },
  { max: 7, speed: 40, perMinute: 400, mph: 4, mpd: 32, longJump: 20, highJump: 4 },
  { max: 9, speed: 45, perMinute: 450, mph: 4.5, mpd: 36, longJump: 22, highJump: 5 },
  { max: Infinity, speed: 50, perMinute: 500, mph: 5, mpd: 40, longJump: 25, highJump: 5 }
];

/** Take a Break strain recovery die by level. */
CNV.takeABreak = [
  { min: 17, die: "1d12" }, { min: 13, die: "1d10" }, { min: 9, die: "1d8" }, { min: 5, die: "1d6" }, { min: 1, die: "1d4" }
];

/** Exhaustion effects by level. */
CNV.exhaustion = {
  0: { dis: 0, speed: 1, strain: 1 },
  1: { dis: 1, speed: 1, strain: 1 },
  2: { dis: 2, speed: 0.5, strain: 0.5 },
  3: { dis: 3, speed: "5", strain: 0.25 },
  4: { dis: 4, speed: "0", strain: 0, death: true }
};

/** Excess strain beyond the limit converts to exhaustion. */
CNV.excessStrain = [
  { max: 3, levels: 1 }, { max: 6, levels: 2 }, { max: 9, levels: 3 }, { max: Infinity, levels: 4 }
];

/* -------------------------------------------- */
/*  Checks                                       */
/* -------------------------------------------- */
CNV.difficulties = {
  5: "CNV.DC.trivial", 10: "CNV.DC.low", 15: "CNV.DC.medium", 20: "CNV.DC.high",
  25: "CNV.DC.severe", 30: "CNV.DC.extreme", 35: "CNV.DC.legendary", 40: "CNV.DC.impossible"
};

/** Each level of Advantage/Disadvantage shifts the total by this much. */
CNV.advantageStep = 2;
/** Beating (or missing) a DC by this much is a critical. */
CNV.critMargin = 15;
/** Parry/Dodge criticals trigger when a defender beats (or misses) the attack by this much. */
CNV.defenseCritMargin = 10;

CNV.degrees = {
  criticalFailure: "CNV.Degree.criticalFailure",
  failure: "CNV.Degree.failure",
  success: "CNV.Degree.success",
  criticalSuccess: "CNV.Degree.criticalSuccess"
};

/** Skill challenge ladder: key = `${successes}-${failures}` */
CNV.challengeLadder = {
  "3-0": { key: "yesAnd", label: "CNV.Ladder.yesAnd", text: "CNV.Ladder.yesAndText" },
  "3-1": { key: "yes", label: "CNV.Ladder.yes", text: "CNV.Ladder.yesText" },
  "3-2": { key: "yesBut", label: "CNV.Ladder.yesBut", text: "CNV.Ladder.yesButText" },
  "2-3": { key: "noBut", label: "CNV.Ladder.noBut", text: "CNV.Ladder.noButText" },
  "1-3": { key: "no", label: "CNV.Ladder.no", text: "CNV.Ladder.noText" },
  "0-3": { key: "noAnd", label: "CNV.Ladder.noAnd", text: "CNV.Ladder.noAndText" }
};

/* -------------------------------------------- */
/*  Damage                                       */
/* -------------------------------------------- */
CNV.damageTypes = {
  bludgeoning: { label: "CNV.Damage.bludgeoning", physical: true, abbr: "B" },
  piercing: { label: "CNV.Damage.piercing", physical: true, abbr: "P" },
  slashing: { label: "CNV.Damage.slashing", physical: true, abbr: "S" },
  acid: { label: "CNV.Damage.acid" },
  cold: { label: "CNV.Damage.cold" },
  fire: { label: "CNV.Damage.fire" },
  force: { label: "CNV.Damage.force" },
  lightning: { label: "CNV.Damage.lightning" },
  thunder: { label: "CNV.Damage.thunder" },
  sonic: { label: "CNV.Damage.sonic" },
  poison: { label: "CNV.Damage.poison" },
  necrotic: { label: "CNV.Damage.necrotic" },
  radiant: { label: "CNV.Damage.radiant" },
  psychic: { label: "CNV.Damage.psychic" },
  psionic: { label: "CNV.Damage.psionic", halfSoak: true },
  bleed: { label: "CNV.Damage.bleed", physical: true },
  untyped: { label: "CNV.Damage.untyped" }
};

/** Wound location table. */
CNV.woundLocations = {
  head: { label: "CNV.Wound.head", light: "dazed", heavy: "stunned" },
  torso: { label: "CNV.Wound.torso", light: "chestTrauma", lightValue: 1, heavy: "staggered" },
  arm: { label: "CNV.Wound.arm", light: "weakenedGrip", lightValue: 1, heavy: "weakenedGrip", heavyValue: 2 },
  leg: { label: "CNV.Wound.leg", light: "slowed", lightValue: 10, heavy: "prone" }
};

/* -------------------------------------------- */
/*  Weapons, armor and gear                      */
/* -------------------------------------------- */
CNV.weaponCategories = {
  melee: { label: "CNV.WeaponCat.melee", skill: "meleeWeapons" },
  missile: { label: "CNV.WeaponCat.missile", skill: "missileWeapons" },
  firearm: { label: "CNV.WeaponCat.firearm", skill: "firearms" },
  martial: { label: "CNV.WeaponCat.martial", skill: "martialArts" },
  natural: { label: "CNV.WeaponCat.natural", skill: "martialArts" },
  improvised: { label: "CNV.WeaponCat.improvised", skill: "meleeWeapons" }
};

CNV.weaponTraits = {
  agile: "CNV.WTrait.agile", armorPiercing: "CNV.WTrait.armorPiercing", backswing: "CNV.WTrait.backswing",
  brutal: "CNV.WTrait.brutal", capacity: "CNV.WTrait.capacity", deadly: "CNV.WTrait.deadly", disarm: "CNV.WTrait.disarm",
  doubleBarrel: "CNV.WTrait.doubleBarrel", finesse: "CNV.WTrait.finesse", heavy: "CNV.WTrait.heavy", light: "CNV.WTrait.light",
  parry: "CNV.WTrait.parry", range: "CNV.WTrait.range", reach: "CNV.WTrait.reach", recoil: "CNV.WTrait.recoil",
  reload: "CNV.WTrait.reload", scattered: "CNV.WTrait.scattered", shove: "CNV.WTrait.shove", spread: "CNV.WTrait.spread",
  subdual: "CNV.WTrait.subdual", sweep: "CNV.WTrait.sweep", tethered: "CNV.WTrait.tethered", thrown: "CNV.WTrait.thrown",
  trip: "CNV.WTrait.trip", unarmed: "CNV.WTrait.unarmed", unwieldy: "CNV.WTrait.unwieldy", versatile: "CNV.WTrait.versatile",
  volatile: "CNV.WTrait.volatile"
};

CNV.armorCategories = {
  light: "CNV.ArmorCat.light",
  medium: "CNV.ArmorCat.medium",
  heavy: "CNV.ArmorCat.heavy"
};

CNV.armorTraits = { bulwark: "CNV.ATrait.bulwark", flexible: "CNV.ATrait.flexible", noisy: "CNV.ATrait.noisy" };

CNV.materials = {
  paper: { label: "Paper", hardness: 0, durability: 1, bt: 0 },
  thinCloth: { label: "Thin cloth", hardness: 0, durability: 1, bt: 0 },
  thinGlass: { label: "Thin glass", hardness: 0, durability: 1, bt: 0 },
  cloth: { label: "Cloth", hardness: 1, durability: 4, bt: 2 },
  glass: { label: "Glass", hardness: 1, durability: 4, bt: 2 },
  thinLeather: { label: "Thin leather", hardness: 2, durability: 8, bt: 4 },
  thinRope: { label: "Thin rope", hardness: 2, durability: 8, bt: 4 },
  thinWood: { label: "Thin wood", hardness: 3, durability: 12, bt: 6 },
  leather: { label: "Leather", hardness: 4, durability: 16, bt: 8 },
  rope: { label: "Rope", hardness: 4, durability: 16, bt: 8 },
  thinStone: { label: "Thin stone", hardness: 4, durability: 16, bt: 8 },
  thinMetal: { label: "Thin iron or steel", hardness: 5, durability: 20, bt: 10 },
  wood: { label: "Wood", hardness: 5, durability: 20, bt: 10 },
  stone: { label: "Stone", hardness: 7, durability: 28, bt: 14 },
  metal: { label: "Iron or steel", hardness: 9, durability: 36, bt: 18 }
};

CNV.bulkBySize = { tiny: 1, small: 3, medium: 6, large: 12, huge: 24, gargantuan: 48 };
CNV.sizes = {
  tiny: "CNV.Size.tiny", small: "CNV.Size.small", medium: "CNV.Size.medium", large: "CNV.Size.large",
  huge: "CNV.Size.huge", gargantuan: "CNV.Size.gargantuan", colossal: "CNV.Size.colossal"
};
CNV.sizeBulkMultiplier = { tiny: 0.5, small: 1, medium: 1, large: 2, huge: 4, gargantuan: 8, colossal: 16 };

CNV.currency = {
  pp: { label: "CNV.Currency.pp", sp: 100 },
  gp: { label: "CNV.Currency.gp", sp: 10 },
  sp: { label: "CNV.Currency.sp", sp: 1 },
  cp: { label: "CNV.Currency.cp", sp: 0.1 }
};

CNV.toolSets = {
  alchemist: "Alchemist's Tools", jeweler: "Jeweler's Tools", smith: "Smith's Tools", calligrapher: "Calligrapher's Tools",
  glassblowing: "Glassblowing Tools", leatherworking: "Leatherworking Tools", pottery: "Pottery Tools",
  shipwright: "Woodcarver's Tools (Ships)", masonry: "Masonry Tools", tailor: "Tailor's Tools", weaver: "Weaver's Tools",
  woodcarver: "Woodcarver's Tools"
};

/* -------------------------------------------- */
/*  Talents, techniques and actions              */
/* -------------------------------------------- */
CNV.actionCosts = {
  passive: "CNV.Cost.passive",
  free: "CNV.Cost.free",
  "1": "CNV.Cost.one",
  "2": "CNV.Cost.two",
  reaction: "CNV.Cost.reaction",
  stance: "CNV.Cost.stance",
  exploration: "CNV.Cost.exploration",
  downtime: "CNV.Cost.downtime"
};

CNV.talentTrees = [
  "Acrobatics", "Alertness", "Armor", "Assassin", "Athletics", "Berserker", "Closer", "Commander", "Crafting", "Deception",
  "Diplomacy", "Elusive", "Grappler", "Intimidation", "Kung Fu", "Master Thrower", "Medicine", "Melee Weapon", "Mysticism",
  "Nature", "Perform", "Ranged Combat", "Scoundrel", "Shield", "Sleight of Hand", "Society", "Stealth", "Survival",
  "Swashbuckler", "Thievery", "Training"
];

/** Scaling dice for Commander/Grit/Panache dice. Rulebook references "see table"; this uses the house standard. */
CNV.styleDie = [
  { min: 12, die: "1d12" }, { min: 9, die: "1d10" }, { min: 6, die: "1d8" }, { min: 2, die: "1d6" }
];

/** Master Thrower weak-spot damage by throwing style ranks. */
CNV.weakSpotDamage = [
  { min: 12, die: "2d8" }, { min: 10, die: "2d6" }, { min: 8, die: "1d12" }, { min: 6, die: "1d10" },
  { min: 4, die: "1d8" }, { min: 2, die: "1d6" }, { min: 1, die: "1d4" }
];

/* -------------------------------------------- */
/*  Magic                                        */
/* -------------------------------------------- */
CNV.spellSchools = {
  abjuration: "CNV.School.abjuration",
  conjuration: "CNV.School.conjuration",
  divination: "CNV.School.divination",
  enchantment: "CNV.School.enchantment",
  evocation: "CNV.School.evocation",
  illusion: "CNV.School.illusion",
  necromancy: "CNV.School.necromancy",
  transmutation: "CNV.School.transmutation"
};

CNV.castingTimes = {
  invocation: { label: "CNV.Casting.invocation", unit: "rounds" },
  chant: { label: "CNV.Casting.chant", unit: "stretches" },
  ritual: { label: "CNV.Casting.ritual", unit: "hours" },
  seance: { label: "CNV.Casting.seance", unit: "hours" }
};

/** Delivery methods: base Strain cost and incremental scaling cost. */
CNV.deliveries = {
  touch: { label: "CNV.Delivery.touch", cost: 0, aoe: false, scaling: null, hint: "CNV.Delivery.touchHint" },
  remote: { label: "CNV.Delivery.remote", cost: 0, aoe: false, scaling: 1, scaleLabel: "CNV.Delivery.remoteScale", hint: "CNV.Delivery.remoteHint" },
  imbue: { label: "CNV.Delivery.imbue", cost: 0, aoe: false, scaling: 2, scaleLabel: "CNV.Delivery.imbueScale", hint: "CNV.Delivery.imbueHint" },
  aura: { label: "CNV.Delivery.aura", cost: 2, aoe: true, scaling: 1, scaleLabel: "CNV.Delivery.auraScale", hint: "CNV.Delivery.auraHint" },
  cone: { label: "CNV.Delivery.cone", cost: 2, aoe: true, scaling: 2, scaleLabel: "CNV.Delivery.coneScale", hint: "CNV.Delivery.coneHint" },
  cube: { label: "CNV.Delivery.cube", cost: 1, aoe: true, scaling: 4, scaleLabel: "CNV.Delivery.cubeScale", hint: "CNV.Delivery.cubeHint" },
  line: { label: "CNV.Delivery.line", cost: 2, aoe: true, scaling: 1, scaleLabel: "CNV.Delivery.lineScale", hint: "CNV.Delivery.lineHint" },
  sphere: { label: "CNV.Delivery.sphere", cost: 2, aoe: true, scaling: 1, scaleLabel: "CNV.Delivery.sphereScale", hint: "CNV.Delivery.sphereHint" },
  glyph: { label: "CNV.Delivery.glyph", cost: 2, aoe: true, scaling: null, hint: "CNV.Delivery.glyphHint" }
};

/** Wild surge severity by total Strain. */
CNV.surgeSeverity = [
  { max: 4, key: "minor", label: "CNV.Surge.minor" },
  { max: 9, key: "moderate", label: "CNV.Surge.moderate" },
  { max: Infinity, key: "major", label: "CNV.Surge.major" }
];

/** Aura power by spell complexity / item level (Detect Magic). */
CNV.auraPower = [
  { spell: 4, item: 5, label: "Faint" }, { spell: 7, item: 11, label: "Moderate" },
  { spell: 10, item: 17, label: "Strong" }, { spell: Infinity, item: Infinity, label: "Overwhelming" }
];

CNV.minorTricks = {
  sensory: "Sensory Trick", flame: "Flame Trick", cleanse: "Cleanse Trick", comfort: "Comfort Trick",
  marking: "Marking Trick", bauble: "Bauble Trick"
};

CNV.traditions = ["Runecasting", "Shamanism", "Tai Chi", "Technomancy", "Sanguimancy", "Other"];

/* -------------------------------------------- */
/*  Crafting, essence and alchemy                */
/* -------------------------------------------- */
CNV.essenceTraits = {
  fire: "Fire", frost: "Frost", storm: "Storm", acid: "Acid", spirit: "Spirit", vitality: "Vitality", death: "Death",
  blood: "Blood", shadow: "Shadow", mind: "Mind", fear: "Fear", motion: "Motion", space: "Space", ward: "Ward", edge: "Edge"
};

CNV.essenceQualities = {
  common: { label: "CNV.Quality.common", tier: "minor", analyze: 10, harvest: 12 },
  uncommon: { label: "CNV.Quality.uncommon", tier: "lesser", analyze: 15, harvest: 17 },
  rare: { label: "CNV.Quality.rare", tier: "greater", analyze: 20, harvest: 22 },
  legendary: { label: "CNV.Quality.legendary", tier: "major", analyze: 25, harvest: 27 }
};

CNV.runeTiers = {
  minor: { label: "CNV.RuneTier.minor", potency: 0, cost: 50, quality: "common" },
  lesser: { label: "CNV.RuneTier.lesser", potency: 1, cost: 200, quality: "uncommon" },
  greater: { label: "CNV.RuneTier.greater", potency: 2, cost: 800, quality: "rare" },
  major: { label: "CNV.RuneTier.major", potency: 3, cost: 2400, quality: "legendary" }
};

CNV.runeSlots = {
  weapon: "CNV.RuneSlot.weapon", armor: "CNV.RuneSlot.armor", shield: "CNV.RuneSlot.shield", worn: "CNV.RuneSlot.worn"
};

CNV.ingredientSources = {
  botanical: "Botanical", fungal: "Fungal", mineral: "Mineral", metallic: "Metallic", animal: "Animal", venom: "Venom",
  blood: "Blood", bone: "Bone", organ: "Organ", resin: "Resin", oil: "Oil", slime: "Slime", salt: "Salt", crystal: "Crystal"
};

CNV.ingredientFunctions = {
  volatile: "Volatile", corrosive: "Corrosive", toxic: "Toxic", medicinal: "Medicinal", stimulant: "Stimulant",
  sedative: "Sedative", irritant: "Irritant", preservative: "Preservative"
};

CNV.concoctionTypes = {
  elixir: "Elixir", salve: "Salve", oil: "Oil", bomb: "Bomb", powder: "Powder", injectable: "Injectable", toxin: "Toxin"
};

CNV.craftComplexity = {
  simple: { label: "Simple", dc: 5, time: "4 hours to 1 day" },
  involved: { label: "Involved", dc: 10, time: "1 to 3 days" },
  complex: { label: "Complex", dc: 15, time: "3 days to 2 weeks" },
  articulate: { label: "Articulate", dc: 20, time: "2 weeks to 2 months" },
  immaculate: { label: "Immaculate", dc: 25, time: "2 months or more" }
};

CNV.alchemyMaterialCost = [
  { max: 4, sp: 10 }, { max: 10, sp: 40 }, { max: 16, sp: 160 }, { max: Infinity, sp: 480 }
];
CNV.potionMaterialCost = [
  { max: 4, sp: 25 }, { max: 10, sp: 100 }, { max: 16, sp: 400 }, { max: Infinity, sp: 1200 }
];

CNV.poisonFamilies = {
  hemotoxin: "Hemotoxin", neurotoxin: "Neurotoxin", necrotoxin: "Necrotoxin", caustic: "Caustic",
  paralytic: "Paralytic", irritant: "Irritant"
};

CNV.afflictionTypes = { poison: "Poison", disease: "Disease", curse: "Curse", radiation: "Radiation", parasite: "Parasite" };

/* -------------------------------------------- */
/*  Adversaries                                  */
/* -------------------------------------------- */
CNV.ranks = {
  minion: { label: "CNV.Rank.minion", ap: 1, rp: 0, hpMult: 0, bonus: 0, xpMult: 0.25, recharge: 11, traits: "0-1" },
  standard: { label: "CNV.Rank.standard", ap: 1, rp: 1, hpMult: 1, bonus: 0, xpMult: 1, recharge: 9, traits: "1" },
  elite: { label: "CNV.Rank.elite", ap: 2, rp: 1, hpMult: 2, bonus: 2, xpMult: 2, recharge: 7, traits: "2" },
  solo: { label: "CNV.Rank.solo", ap: 2, rp: 2, hpMult: 4, bonus: 4, xpMult: 4, recharge: 5, traits: "2-4" }
};

/** Role qualities: strong/weak lists drive which track column is used. */
CNV.roles = {
  brute: {
    label: "CNV.Role.brute", hp: "strong",
    strong: ["might", "fortitude", "soak", "morale", "melee"], weak: ["intellect", "reflex", "stealth", "perception"]
  },
  controller: {
    label: "CNV.Role.controller", hp: "average",
    strong: ["intellect", "perception"], weak: ["melee", "soak"]
  },
  leader: {
    label: "CNV.Role.leader", hp: "average",
    strong: ["intellect", "charisma"], weak: ["might", "fortitude", "soak"]
  },
  predator: {
    label: "CNV.Role.predator", hp: "weak",
    strong: ["intellect", "reflex", "stealth"], weak: ["fortitude", "soak", "morale"]
  },
  soldier: {
    label: "CNV.Role.soldier", hp: "average",
    strong: ["might", "reflex", "melee", "morale"], weak: ["stealth", "speed"]
  },
  sniper: {
    label: "CNV.Role.sniper", hp: "weak",
    strong: ["reflex", "perception", "ranged"], weak: ["might", "fortitude", "melee", "soak", "morale"]
  },
  skirmisher: {
    label: "CNV.Role.skirmisher", hp: "average",
    strong: ["reflex", "speed"], weak: ["fortitude", "soak", "morale"]
  }
};

CNV.creatureTypes = {
  aberration: "Aberration", animal: "Animal", construct: "Construct", dragon: "Dragon", elemental: "Elemental",
  fey: "Fey", humanoid: "Humanoid", magicalBeast: "Magical Beast", ooze: "Ooze", outsider: "Outsider", plant: "Plant",
  undead: "Undead", vermin: "Vermin"
};

/** Level-banded adversary tracks. Each row: [maxLevel, weak, average, strong]. */
CNV.tracks = {
  ability: [[1, 0, 2, 3], [5, 0, 2, 4], [9, 0, 2, 5], [13, 1, 3, 5], [17, 1, 3, 6], [99, 2, 4, 6]],
  soak: [[2, 1, 3, 5], [4, 2, 4, 6], [6, 3, 5, 7], [8, 4, 6, 8], [10, 5, 7, 9], [12, 6, 8, 10], [14, 7, 9, 11], [16, 8, 10, 12], [18, 9, 11, 13], [99, 10, 12, 14]],
  damage: [[3, "1d4", "1d8", "1d12"], [6, "1d6", "1d10", "2d8"], [9, "1d8", "1d12", "2d10"], [12, "1d10", "2d8", "3d8"], [15, "1d12", "2d10", "3d10"], [18, "2d8", "3d8", "3d12"], [99, "2d10", "3d10", "4d10"]],
  magnitude: [[4, 5, 5, 10], [8, 5, 10, 15], [12, 10, 15, 20], [16, 15, 20, 25], [99, 20, 25, 30]],
  step: [[4, 1, 1, 2], [8, 1, 2, 2], [12, 1, 2, 3], [16, 2, 3, 3], [99, 2, 3, 4]],
  skill: [[1, 0, 1, 2], [3, 1, 2, 3], [5, 2, 3, 4], [7, 2, 3, 5], [9, 3, 4, 6], [11, 3, 5, 7], [13, 4, 6, 8], [15, 4, 6, 9], [17, 5, 7, 10], [19, 6, 8, 11], [99, 6, 9, 12]],
  check: [[1, 0, 3, 5], [3, 1, 4, 7], [5, 2, 5, 8], [7, 2, 5, 10], [9, 3, 6, 11], [11, 4, 8, 12], [13, 5, 9, 13], [15, 5, 9, 15], [17, 6, 10, 16], [19, 8, 12, 17], [99, 8, 13, 18]]
};

/** Adversary HP per level (weak / average / strong): weak = 4 + 4L, average = 7L, strong = 10L. */
CNV.adversaryHP = (level, quality) => {
  const L = Math.max(1, level);
  if ( quality === "weak" ) return 4 + (4 * L);
  if ( quality === "strong" ) return 10 * L;
  return 7 * L;
};

/** XP value by level relative to the party. */
CNV.adversaryXP = { "-4": 10, "-3": 15, "-2": 20, "-1": 30, "0": 40, "1": 60, "2": 80, "3": 120, "4": 160 };
CNV.hazardXP = {
  reactive: { "-4": 2, "-3": 3, "-2": 4, "-1": 6, "0": 8, "1": 12, "2": 16, "3": 24, "4": 32 },
  sustained: { "-4": 10, "-3": 15, "-2": 20, "-1": 30, "0": 40, "1": 60, "2": 80, "3": 120, "4": 160 }
};

CNV.encounterBudget = {
  trivial: [40, 80, 120, 160, 200, 240],
  low: [60, 120, 180, 240, 300, 360],
  moderate: [80, 160, 240, 320, 400, 480],
  severe: [120, 240, 360, 480, 600, 720],
  extreme: [160, 320, 480, 640, 800, 960]
};

CNV.maneuverCategories = {
  baseline: "CNV.ManCat.baseline", role: "CNV.ManCat.role", identity: "CNV.ManCat.identity",
  generic: "CNV.ManCat.generic", elite: "CNV.ManCat.elite", solo: "CNV.ManCat.solo", swarm: "CNV.ManCat.swarm"
};

CNV.qualities = { weak: "CNV.Quality.weak", average: "CNV.Quality.average", strong: "CNV.Quality.strong" };

/** Starting morale edge from level difference. */
CNV.startingMorale = (diff) => {
  const half = diff / 2;
  const rounded = half >= 0 ? Math.ceil(half) : Math.floor(half);
  return Math.clamp(rounded, -3, 3);
};

CNV.intellectCategories = [
  { max: 0, key: "brutish", label: "Brutish" }, { max: 2, key: "dull", label: "Dull" }, { max: 3, key: "average", label: "Average" },
  { max: 5, key: "clever", label: "Clever" }, { max: Infinity, key: "genius", label: "Genius" }
];

CNV.reactionTable = {
  "2": {
    brutish: "Immediate violence. Charges, pounces, or opens fire without hesitation.",
    dull: "Lashes out. Fear, confusion, or anger immediately becomes an attack.",
    average: "Takes cover and threatens. Orders the party to back off; attacks if they hesitate.",
    clever: "Prepares an ambush. Stalls while taking position, surrounding the party, or calling support.",
    genius: "Creates leverage. Activates alarms, arranges a crossfire, threatens a hostage, or springs a prepared trap."
  },
  "5": {
    brutish: "Hostile and reckless. Threatens or attacks with little regard for danger.",
    dull: "Hostile. Intimidates and may attack, but could retreat or surrender when hurt.",
    average: "Hostile but listening. Threatens, though a bribe, explanation, or display of authority may prevent violence.",
    clever: "Controlled hostility. Holds a strong position, demands concessions, attacks only when advantageous.",
    genius: "Feigns calm. Appears willing to negotiate while quietly carrying out a hostile plan."
  },
  "8": {
    brutish: "Confused or wary. Hesitates, follows the strongest cue.",
    dull: "Wary. Avoids commitment; may be tempted by food, loot, or an easy exit.",
    average: "Cautious parley. Weapons ready, asks the party to explain themselves.",
    clever: "Probes for weakness. Tests claims and looks for an advantage before deciding.",
    genius: "Cold calculation. Offers a conditional arrangement while studying the party's motives and resources."
  },
  "11": {
    brutish: "Curious. May accept a simple trade or follow a confident lead.",
    dull: "Cautiously friendly. Offers limited help for reward, protection, or reassurance.",
    average: "Open to a bargain. Trades, shares information, or discusses common interests.",
    clever: "Professional cooperation. Proposes a mutually beneficial exchange - escort, contract, trade, intel.",
    genius: "Attempts recruitment. Sees the party as useful and proposes a partnership or structured agreement."
  },
  "12": {
    brutish: "Friendly and trusting. Follows a confident lead, may help without understanding the risk.",
    dull: "Eager to help. Looks to the party for protection, leadership, or purpose.",
    average: "Helpful. Freely shares information, may offer supplies or shelter.",
    clever: "Generously cooperative. Offers resources or contacts on favorable, sensible terms.",
    genius: "Cultivates an alliance. Helps now while establishing a future favor, obligation, or bond."
  }
};

CNV.brokenElementOutcomes = [
  "Fall back to cover (still fighting)", "Fighting withdrawal — disengage, back up", "Flee", "Surrender",
  "Bargain or parley", "Rage — reckless attack for 1 round, then withdraws"
];

/* -------------------------------------------- */
/*  Negotiation & attitudes                      */
/* -------------------------------------------- */
CNV.attitudes = {
  hostile: { label: "CNV.Attitude.hostile", interest: 1, patience: 2, adv: -2 },
  unfriendly: { label: "CNV.Attitude.unfriendly", interest: 2, patience: 2, adv: -1 },
  indifferent: { label: "CNV.Attitude.indifferent", interest: 2, patience: 3, adv: 0 },
  friendly: { label: "CNV.Attitude.friendly", interest: 3, patience: 4, adv: 1 },
  helpful: { label: "CNV.Attitude.helpful", interest: 4, patience: 5, adv: 2 }
};

CNV.motivations = [
  "Compassion", "Discovery", "Duty", "Freedom", "Greed", "Justice", "Legacy", "Peace", "Power", "Protection", "Revelry", "Vengeance"
];

CNV.negotiationResults = {
  5: { key: "yesAnd", label: "CNV.Ladder.yesAnd", text: "The NPC agrees to the party's request and provides an additional benefit, improved terms, reduced cost, or other favorable concession." },
  4: { key: "yes", label: "CNV.Ladder.yes", text: "The NPC agrees to the request under the expected terms." },
  3: { key: "yesBut", label: "CNV.Ladder.yesBut", text: "The NPC agrees, but demands a meaningful payment, obligation, limitation, delay, favor, or other concession." },
  2: { key: "noBut", label: "CNV.Ladder.noBut", text: "The NPC refuses the full request but offers a lesser service, alternative arrangement, information, or another path forward." },
  1: { key: "no", label: "CNV.Ladder.no", text: "The NPC refuses the request without providing a useful alternative." },
  0: { key: "noAnd", label: "CNV.Ladder.noAnd", text: "The NPC refuses and the situation worsens. Their Attitude may decrease, they may withdraw another offer, alert an enemy, increase their price, or impose another appropriate consequence." }
};

/* -------------------------------------------- */
/*  Hazards                                      */
/* -------------------------------------------- */
CNV.hazardNatures = { reactive: "CNV.Hazard.reactive", sustained: "CNV.Hazard.sustained" };
CNV.hazardReactions = {
  brace: "CNV.Hazard.brace",
  jump: "CNV.Hazard.jump",
  duck: "CNV.Hazard.duck"
};
CNV.passiveRungs = [1, 6, 11, 16];

/* -------------------------------------------- */
/*  The Crew                                     */
/* -------------------------------------------- */
CNV.crewTypes = {
  assassins: "Assassins", bravos: "Bravos", essenceHunters: "Essence Hunters", hawkers: "Hawkers",
  prospectors: "Prospectors", raiders: "Raiders", shadows: "Shadows", smugglers: "Smugglers", wardens: "Wardens",
  arcaneInvestigators: "Arcane Investigators"
};

CNV.favoredJobs = {
  assassins: ["Accident", "Disappearance", "Murder", "Ransom"],
  bravos: ["Battle", "Extortion", "Sabotage", "Smash & Grab"],
  essenceHunters: ["Bounty Harvest", "Supply Run", "Salvage", "Black Market Deal"],
  hawkers: ["Sale", "Supply", "Show of Force", "Socialize"],
  prospectors: ["Claim Working", "Ruin Diving", "Search and Rescue", "Exploration"],
  raiders: ["Raid", "Plunder", "Blood Feud", "Show of Strength"],
  shadows: ["Burglary", "Espionage", "Robbery", "Sabotage"],
  smugglers: ["Occult", "Arms", "Contraband", "Passengers"],
  wardens: ["Manhunt", "Peacekeeping", "Escort", "Investigation"],
  arcaneInvestigators: ["Haunting", "Consultation", "Curse Breaking", "Wild Surge Cleanup"]
};

CNV.cohortTypes = {
  adepts: { label: "Adepts", strong: ["mysticism", "crafting", "investigation"], weak: ["athletics", "intimidation"] },
  rooks: { label: "Rooks", strong: ["deception", "diplomacy", "society"], weak: ["athletics"] },
  rovers: { label: "Rovers", strong: ["survival", "athletics"], weak: ["society"] },
  skulks: { label: "Skulks", strong: ["stealth", "thievery"], weak: ["diplomacy"] },
  thugs: { label: "Thugs", strong: ["athletics", "intimidation"], weak: ["deception", "society"] }
};

CNV.gangScale = [
  { min: 20, label: "Massive gang (around 80 people)" }, { min: 16, label: "Huge gang (around 40 people)" },
  { min: 12, label: "Large gang (around 20 people)" }, { min: 8, label: "Medium gang (around 12 people)" },
  { min: 4, label: "Small gang (3-6 people)" }, { min: 1, label: "1 or 2 people" }
];

/* -------------------------------------------- */
/*  Bonds                                        */
/* -------------------------------------------- */
CNV.bondCategories = [
  "Childhood Friends", "Family Ties", "Student of the Same Teacher", "Former Rivals", "Saved One's Life",
  "Religious Connection", "Shared Backstory", "Comrades-in-Arms", "Working Partners", "Chance Companions"
];
CNV.bondTierLevels = [1, 5, 9, 13];

/* -------------------------------------------- */
/*  Virtues & Vices                              */
/* -------------------------------------------- */
CNV.virtues = [
  "Calm", "Cheerful", "Compassionate", "Confident", "Courageous", "Energetic", "Friendly", "Generous", "Helpful", "Honest",
  "Humble", "Humorous", "Independent", "Kind", "Leader", "Logical", "Mysterious", "Optimistic", "Peaceful", "Precise",
  "Quiet", "Religious", "Righteous", "Romantic", "Skeptical"
];
CNV.vices = [
  "Aggressive", "Amoral", "Cowardly", "Curious", "Dependent", "Egotistical", "Flippant", "Follower", "Foppish", "Frivolous",
  "Hateful", "Humorless", "Illogical", "Lazy", "Merciless", "Ominous", "Passive", "Pessimistic", "Rash", "Rude", "Selfish",
  "Suspicious", "Talkative", "Thoughtless", "Trusting"
];

CNV.stakesMenu = [
  "1 Fate Die", "1 level of Advantage (or Disadvantage) on the next relevant check or save",
  "A small amount of Strain recovered (or spent)", "A minor narrative boon — a favor owed, a scrap of information, a moment's positioning",
  "A complication or hook the GM can call back on later", "Anything else that fits the fiction, GM's call"
];

/* -------------------------------------------- */
/*  G.R.A.P.H. environments                      */
/* -------------------------------------------- */
CNV.graph = {
  gravity: { label: "Gravity (G)", ratings: ["G0 Zero", "G1 Low", "G2 Moderate", "G3 High", "G4 Very High", "G5 Super High"] },
  radiation: { label: "Radiation (R)", ratings: ["R0 Zero", "R1 Low", "R2 Moderate", "R3 High", "R4 Extreme", "R5 Lethal"] },
  atmosphere: { label: "Atmosphere (A)", ratings: ["A0 Vacuum", "A1 Inert", "A2 Moderate", "A3 Toxic", "A4 Corrosive", "A5 Super Corrosive"] },
  pressure: { label: "Pressure (P)", ratings: ["P0 Vacuum", "P1 Very Thin", "P2 Thin", "P3 Moderate", "P4 Dense", "P5 Very Dense", "P6 Crushing"] },
  heat: { label: "Heat/Cold (H)", ratings: ["H0 Absolute Zero", "H1 Frigid", "H2 Cold", "H3 Normal", "H4 Hot", "H5 Extreme Heat", "H6 Inferno"] }
};

CNV.rangeBands = {
  engaged: "CNV.RangeBand.engaged", close: "CNV.RangeBand.close", near: "CNV.RangeBand.near", far: "CNV.RangeBand.far", distant: "CNV.RangeBand.distant"
};

/* -------------------------------------------- */
/*  Helpers                                      */
/* -------------------------------------------- */
/**
 * Look up a banded track value.
 * @param {string} track   Key of CNV.tracks
 * @param {number} level
 * @param {"weak"|"average"|"strong"} quality
 */
CNV.track = (track, level, quality = "average") => {
  const rows = CNV.tracks[track];
  const col = { weak: 1, average: 2, strong: 3 }[quality] ?? 2;
  const row = rows.find(r => level <= r[0]) ?? rows.at(-1);
  return row[col];
};

/** Find the first entry of a banded table matching `min` thresholds (descending). */
CNV.bandMin = (table, value) => table.find(r => value >= r.min) ?? table.at(-1);
/** Find the first entry of a banded table matching `max` thresholds (ascending). */
CNV.bandMax = (table, value) => table.find(r => value <= r.max) ?? table.at(-1);

/* -------------------------------------------- */
/*  Character creation helpers                   */
/* -------------------------------------------- */

/** Genetic ability modifiers (2d8 row): [first +1, second +1, −1 on 1d4 = 1..4]. */
CNV.geneticModifiers = {
  2: ["might", "reflex", ["fortitude", "intellect", "perception", "charisma"]],
  3: ["might", "fortitude", ["reflex", "intellect", "perception", "charisma"]],
  4: ["might", "intellect", ["reflex", "fortitude", "perception", "charisma"]],
  5: ["might", "perception", ["reflex", "fortitude", "intellect", "charisma"]],
  6: ["might", "charisma", ["reflex", "fortitude", "intellect", "perception"]],
  7: ["reflex", "fortitude", ["might", "intellect", "perception", "charisma"]],
  8: ["reflex", "intellect", ["might", "fortitude", "perception", "charisma"]],
  9: ["reflex", "perception", ["might", "fortitude", "intellect", "charisma"]],
  10: ["reflex", "charisma", ["might", "fortitude", "intellect", "perception"]],
  11: ["fortitude", "intellect", ["might", "reflex", "charisma", "perception"]],
  12: ["fortitude", "perception", ["might", "reflex", "charisma", "intellect"]],
  13: ["fortitude", "charisma", ["might", "reflex", "perception", "intellect"]],
  14: ["intellect", "perception", ["might", "reflex", "charisma", "fortitude"]],
  15: ["intellect", "charisma", ["might", "reflex", "perception", "fortitude"]],
  16: ["perception", "charisma", ["might", "reflex", "intellect", "fortitude"]]
};

/** Origin personality aspects, each paired with a Virtue or a Vice. */
CNV.aspects = { quirk: "CNV.Aspect.quirk", ideal: "CNV.Aspect.ideal", pledge: "CNV.Aspect.pledge", flaw: "CNV.Aspect.flaw" };

/** Personality prompts and the Roll Table each one uses. */
CNV.personalityPrompts = {
  social: { label: "CNV.Prompt.social", prompts: {
    demeanor: ["CNV.Prompt.demeanor", "Personality — Social: Demeanor"],
    outlook: ["CNV.Prompt.outlook", "Personality — Social: Outlook"],
    trust: ["CNV.Prompt.trust", "Personality — Social: Trust"] } },
  decisions: { label: "CNV.Prompt.decisions", prompts: {
    assertiveness: ["CNV.Prompt.assertiveness", "Personality — Decisions: Assertiveness"],
    rules: ["CNV.Prompt.rules", "Personality — Decisions: Rules"],
    empathy: ["CNV.Prompt.empathy", "Personality — Decisions: Empathy"] } },
  dire: { label: "CNV.Prompt.dire", prompts: {
    courage: ["CNV.Prompt.courage", "Personality — Dire Straits: Courage"],
    setbacks: ["CNV.Prompt.setbacks", "Personality — Dire Straits: Setbacks"],
    nerves: ["CNV.Prompt.nerves", "Personality — Dire Straits: Nerves"] } }
};
