import { int, num, str, bool, html, resource, rvi } from "./fields.mjs";
import { CreatureData } from "./actor-character.mjs";
const f = foundry.data.fields;

/* -------------------------------------------- */
/*  Adversary                                    */
/* -------------------------------------------- */

export class AdversaryData extends CreatureData {
  static defineSchema() {
    const CNV = CONFIG.CNV;
    const quality = (initial = "average") => str(initial, { choices: () => CONFIG.CNV.qualities });
    return {
      ...this.defineShared(),
      abilities: this.defineAbilities(),
      rank: str("standard", { choices: () => CONFIG.CNV.ranks }),
      role: str("soldier", { choices: () => CONFIG.CNV.roles }),
      creatureType: str("humanoid"),
      subtypes: str(),
      identity: str(),
      morale: new f.SchemaField({ value: int(0, { min: -6, max: 4 }), traits: str(), group: str() }),
      abilityQuality: new f.SchemaField(Object.fromEntries(["might", "reflex", "fortitude", "intellect", "perception", "charisma"].map(k => [k, quality()]))),
      baseline: new f.ArrayField(new f.SchemaField({ name: str(), quality: quality(), type: str("slashing"), range: str(), notes: str() })),
      incredibleActions: str(), incrediblePresence: str(), eliteAction: str(),
      crafting: new f.SchemaField({ essence: str(), ingredients: str() }),
      autoCalc: bool(true),
      // Quality selectors used by auto-calculation from the adversary tables
      quality: new f.SchemaField({
        hp: quality(), soak: quality(), damage: quality(), check: quality(), skill: quality(), magnitude: quality(), step: quality()
      }),
      stats: new f.SchemaField({
        damage: str(""),        // override; blank = table
        magnitude: int(0),
        step: int(0),
        check: int(0),
        skill: int(0),
        soak: int(0),
        hp: int(0)
      }),
      skills: new f.ArrayField(new f.SchemaField({ name: str(), mod: int(0) })),
      recharge: int(0),
      ap: int(0), rp: int(0),
      xpOverride: int(0),
      description: html(),
      tactics: str(),
      loot: str()
    };
  }

  prepareDerivedData() {
    const CNV = CONFIG.CNV;
    const level = Math.max(0, this.level);
    const L = Math.max(1, level);
    const rank = CNV.ranks[this.rank] ?? CNV.ranks.standard;
    const role = CNV.roles[this.role] ?? CNV.roles.soldier;
    this.rankData = rank;
    this.roleData = role;

    const q = (key) => this.quality[key];
    const auto = this.autoCalc;

    // Hit points
    const hpBase = this.stats.hp || CNV.adversaryHP(L, q("hp"));
    if ( this.rank === "minion" ) this.hp.max = 1;
    else this.hp.max = Math.max(1, Math.round(hpBase * rank.hpMult) + this.hp.bonus);
    this.hp.value = Math.min(this.hp.value, this.hp.max);
    this.hp.lightThreshold = Math.max(1, Math.floor(this.hp.max / 4));
    this.hp.heavyThreshold = Math.max(1, Math.floor(this.hp.max / 2));
    this.hp.bloodied = this.hp.value <= this.hp.heavyThreshold;

    // Soak
    this.soak.value = (this.stats.soak || (auto ? CNV.track("soak", L, q("soak")) : 0)) + this.soak.armor + this.soak.bonus;

    // Offense
    this.damage = this.stats.damage || CNV.track("damage", L, q("damage"));
    this.magnitude = this.stats.magnitude || CNV.track("magnitude", L, q("magnitude"));
    this.step = this.stats.step || CNV.track("step", L, q("step"));
    this.checkBonus = (this.stats.check || CNV.track("check", L, q("check"))) + rank.bonus;
    this.skillBonus = (this.stats.skill || CNV.track("skill", L, q("skill"))) + rank.bonus;
    this.saveBonus = CreatureData.saveBonusFor(L) + rank.bonus;

    // Strain
    this.strain.max = Math.max(1, 5 + L + (this.abilities[this.strain.ability]?.value ?? 0) + this.strain.bonus);

    // Abilities & saves: stats track for scores, check track (Good/Average/Poor) for saves
    this.saves = {};
    this.saveTier = {};
    for ( const [k, ab] of Object.entries(this.abilities) ) {
      const aq = this.abilityQuality[k] ?? "average";
      if ( auto ) ab.value = CNV.track("ability", L, aq);
      ab.mod = ab.value + ab.bonus;
      this.saves[k] = CNV.track("check", L, aq) + rank.bonus + ab.save;
      this.saveTier[k] = aq;
    }
    // Baseline attacks resolve their damage dice from the damage track
    for ( const b of this.baseline ) b.dice = CNV.track("damage", L, b.quality);
    this.parry = this.saves.might + this.defenses.parry;
    this.dodge = this.saves.reflex + this.defenses.dodge;

    // Speed
    const sp = CNV.bandMax(CNV.speedTable, this.abilities.might.value + this.abilities.reflex.value);
    this.movement = sp;
    this.speed.value = (this.speed.override || sp.speed) + this.speed.bonus;

    // Initiative
    this.initiative.mod = (this.abilities[this.initiative.ability]?.value ?? 0) + this.initiative.bonus + rank.bonus;

    // Economy
    this.actions = { ap: this.ap || rank.ap, rp: this.rp || rank.rp };
    this.rechargeTarget = this.recharge || rank.recharge;

    // Skills
    for ( const s of this.skills ) s.total = s.mod;

    // XP relative to party level
    const partyLevel = game.settings?.get?.(CNV.id, "partyLevel") ?? 1;
    const diff = Math.clamp(level - partyLevel, -4, 4);
    this.relativeLevel = level - partyLevel;
    const baseXP = level - partyLevel < -4 ? 0 : (CNV.adversaryXP[String(diff)] ?? 0);
    this.xp = this.xpOverride || Math.round(baseXP * rank.xpMult);
    const roleMorale = role.strong.includes("morale") ? 1 : role.weak.includes("morale") ? -1 : 0;
    this.startingMorale = Math.clamp(CNV.startingMorale(level - partyLevel) + roleMorale, -6, 4);

    this._applyExhaustion();
  }
}

/* -------------------------------------------- */
/*  Hazard                                       */
/* -------------------------------------------- */

export class HazardData extends foundry.abstract.TypeDataModel {
  static defineSchema() {
    return {
      level: int(1, { min: 0, max: 30 }),
      nature: str("reactive", { choices: () => CONFIG.CNV.hazardNatures }),
      complexity: str("simple"),
      hazardType: str("trap"),                // trap, environmental, haunt, magical
      stealth: new f.SchemaField({ dc: int(0), bonus: int(0), minRung: int(1), skill: str("survival") }),
      disable: str(),
      disableDC: int(0),
      trigger: str(),
      reactions: new f.SchemaField({ brace: bool(true), jump: bool(true), duck: bool(true), notes: str() }),
      save: new f.SchemaField({ ability: str("reflex"), dc: int(0) }),
      attack: int(0),
      damage: str(""),
      damageType: str(""),
      hp: resource(0, 0),
      soak: new f.SchemaField({ value: int(0) }),
      hardness: int(0),
      initiative: new f.SchemaField({ mod: int(0) }),
      routine: str(),
      reset: str(),
      xpOverride: int(0),
      description: html(),
      effect: html(),
      notes: html()
    };
  }

  prepareDerivedData() {
    const CNV = CONFIG.CNV;
    const L = Math.max(0, this.level);
    this.detectDC = this.stealth.dc || (15 + L);
    this.disableDCValue = this.disableDC || (15 + L);
    this.saveDC = this.save.dc || (15 + L);
    this.damageFormula = this.damage || CNV.track("damage", Math.max(1, L), "strong");
    const partyLevel = game.settings?.get?.(CNV.id, "partyLevel") ?? 1;
    const diff = Math.clamp(L - partyLevel, -4, 4);
    this.xp = this.xpOverride || (CNV.hazardXP[this.nature]?.[String(diff)] ?? 0);
  }
}

/* -------------------------------------------- */
/*  Crew                                         */
/* -------------------------------------------- */

export class CrewData extends foundry.abstract.TypeDataModel {
  static defineSchema() {
    const cohort = () => new f.SchemaField({
      name: str(), kind: str("gang"),               // gang | expert
      type: str("thugs"), type2: str(""),           // Cohort types (a second type is an Upgrade)
      specialty: str(),                              // Expert specialty
      strong: str(), weak: str(),                    // comma-separated skill overrides
      hp: resource(14, 14), elite: bool(false), notes: str()
    });
    return {
      crewType: str("raiders"),
      level: int(1, { min: 1, max: 20 }),
      xp: int(0, { min: 0 }),
      favoredJob: str(),
      lair: str(),
      patron: new f.SchemaField({ name: str(), stake: str(), attitude: str("friendly") }),
      vehicle: str(),
      members: new f.ArrayField(new f.StringField()),
      cohorts: new f.ArrayField(cohort()),
      description: html(),
      notes: html()
    };
  }

  prepareDerivedData() {
    const CNV = CONFIG.CNV;
    this.typeLabel = CNV.crewTypes[this.crewType] ?? this.crewType;
    this.jobSuggestions = CNV.favoredJobs[this.crewType] ?? [];
    this.xpMax = this.level * CNV.xpPerLevel;
    const L = this.level;
    for ( const c of this.cohorts ) {
      const expert = c.kind === "expert";
      c.scale = expert ? "A single specialist" : CNV.bandMin(CNV.gangScale, L).label;
      const shift = q => expert ? ({ weak: "average", average: "strong", strong: "strong" }[q]) : q;
      const bonus = q => CNV.track("check", L, shift(q)) + ((expert && q === "strong") ? 2 : 0);
      c.check = { weak: bonus("weak"), average: bonus("average"), strong: bonus("strong") };
      c.hpMax = CNV.adversaryHP(L, shift("average"));
      c.soak = CNV.track("soak", L, shift("average"));
      c.damage = CNV.track("damage", L, shift("average"));
      const types = [c.type, c.type2].filter(Boolean).map(t => CNV.cohortTypes[t]).filter(Boolean);
      const extraStrong = c.strong.split(",").map(s => s.trim()).filter(Boolean);
      const extraWeak = c.weak.split(",").map(s => s.trim()).filter(Boolean);
      c.strongSkills = [...new Set(types.flatMap(t => t.strong).map(k => game.i18n.localize(CNV.skills[k]?.label ?? k)).concat(extraStrong))];
      c.weakSkills = [...new Set(types.flatMap(t => t.weak).map(k => game.i18n.localize(CNV.skills[k]?.label ?? k)).concat(extraWeak))]
        .filter(s => !c.strongSkills.includes(s));
      c.typeLabel = types.map(t => t.label).join(" / ");
    }
  }
}
