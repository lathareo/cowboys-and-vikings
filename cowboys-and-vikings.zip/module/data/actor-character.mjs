import { int, num, str, bool, html, resource, rvi } from "./fields.mjs";
const f = foundry.data.fields;

/**
 * Base data shared by every creature-like actor (characters and adversaries).
 */
export class CreatureData extends foundry.abstract.TypeDataModel {
  static defineAbilities() {
    const CNV = CONFIG.CNV;
    return new f.SchemaField(Object.fromEntries(Object.keys(CNV.abilities).map(k => [k, new f.SchemaField({
      value: int(0, { min: -5, max: 10 }),   // characters: points spent (creation choice); adversaries: score
      genetic: int(0, { min: -2, max: 2 }),  // characters: genetic modifier (rolled at creation)
      granted: int(0),    // bonuses from origin, talents, items (Active Effects target this, never "value")
      save: int(0),       // misc bonus to saves with this ability
      bonus: int(0)       // misc bonus to checks with this ability
    })])));
  }

  static defineShared() {
    return {
      level: int(1, { min: 0, max: 30 }),
      hp: resource(10, 10, { temp: int(0, { min: 0 }), bonus: int(0) }),
      strain: resource(0, 5, { bonus: int(0), ability: str("fortitude") }),
      exhaustion: int(0, { min: 0, max: 4 }),
      soak: new f.SchemaField({ bonus: int(0), armor: int(0) }),
      speed: new f.SchemaField({ bonus: int(0), override: int(0), climb: int(0), swim: int(0), fly: int(0), burrow: int(0) }),
      initiative: new f.SchemaField({ ability: str("reflex"), bonus: int(0) }),
      defenses: new f.SchemaField({ parry: int(0), dodge: int(0) }),
      traits: rvi(),
      size: str("medium"),
      senses: str(),
      languages: str(),
      notes: html()
    };
  }

  /** Save bonus for a level. */
  static saveBonusFor(level) {
    return CONFIG.CNV.advancement[Math.clamp(level, 1, 20)]?.saveBonus ?? 0;
  }

  get abilityTotals() {
    return Object.fromEntries(Object.entries(this.abilities).map(([k, v]) => [k, v.value]));
  }

  /** Compute exhaustion side effects. */
  _applyExhaustion() {
    const ex = CONFIG.CNV.exhaustion[this.exhaustion] ?? CONFIG.CNV.exhaustion[0];
    this.exhaustionEffects = ex;
    if ( typeof ex.strain === "number" ) this.strain.max = Math.floor(this.strain.max * ex.strain);
    if ( typeof ex.speed === "number" ) this.speed.value = Math.floor(this.speed.value * ex.speed / 5) * 5;
    else this.speed.value = Number(ex.speed);
  }
}

/* -------------------------------------------- */

export class CharacterData extends CreatureData {

  static defineSchema() {
    const CNV = CONFIG.CNV;
    // ranks = ranks bought with skill points; granted = free ranks from origin, talents, crew (Active Effects target this)
    const skill = () => new f.SchemaField({ ranks: int(0, { min: 0, max: 20 }), granted: int(0), bonus: int(0), ability: str("") });
    const aspect = () => new f.SchemaField({ text: str(), kind: str(""), trait: str() });
    return {
      ...this.defineShared(),
      abilities: this.defineAbilities(),
      skills: new f.SchemaField(Object.fromEntries(Object.keys(CNV.skills).map(k => [k, skill()]))),
      lores: new f.ArrayField(new f.SchemaField({ name: str(), ranks: int(0, { min: 0 }), bonus: int(0) })),
      xp: new f.SchemaField({ value: int(0, { min: 0 }) }),
      fate: new f.SchemaField({ value: int(0, { min: 0 }), carried: int(0, { min: 0 }) }),
      sup: resource(0, 1, { bonus: int(0) }),
      currency: new f.SchemaField({ pp: int(0, { min: 0 }), gp: int(0, { min: 0 }), sp: int(0, { min: 0 }), cp: int(0, { min: 0 }) }),
      details: new f.SchemaField({
        origin: str(), pronouns: str(), age: str(), height: str(), weight: str(), hair: str(), eyes: str(),
        virtue: str(), vice: str(), personality: str(), background: str(), appearance: str(), tradition: str(),
        patron: str(), goals: str(), specialty: str(),
        aspects: new f.SchemaField({ quirk: aspect(), ideal: aspect(), pledge: aspect(), flaw: aspect() }),
        prompts: new f.SchemaField(Object.fromEntries(["demeanor", "outlook", "trust", "assertiveness", "rules", "empathy", "courage", "setbacks", "nerves"].map(k => [k, str()])))
      }),
      stakes: new f.ArrayField(new f.SchemaField({ text: str(), active: bool(true) })),
      wounds: new f.SchemaField({ light: int(0, { min: 0 }), heavy: int(0, { min: 0 }) }),
      deathTimer: resource(0, 0),
      dying: bool(false),
      stable: bool(false),
      spellcasting: new f.SchemaField({ skill: str("mysticism"), ability: str("intellect"), invested: int(0, { min: 0 }), sustained: str() }),
      bulkBonus: int(0),
      points: new f.SchemaField({ skillBonus: int(0), talentBonus: int(0) }),
      biography: html()
    };
  }

  prepareBaseData() {
    // Nothing: values are raw until effects apply.
  }

  prepareDerivedData() {
    const CNV = CONFIG.CNV;
    const a = this.abilities;
    const level = Math.max(1, this.level);
    const adv = CNV.advancement[Math.min(level, 20)];

    // Ability score = points spent + genetic modifier + granted bonuses (origin, talents, items)
    let pointsSpent = 0;
    for ( const ab of Object.values(a) ) {
      ab.points = ab.value;
      pointsSpent += Math.max(0, ab.value);
      ab.value = ab.points + (ab.genetic ?? 0) + (ab.granted ?? 0);
    }
    this.abilityPoints = { spent: pointsSpent, max: CNV.abilityPointBuy };

    // Level-derived
    this.saveBonus = adv.saveBonus;
    this.maxRanks = adv.maxRanks;
    this.naturalSoak = adv.naturalSoak;
    const fate = CNV.bandMin(CNV.fateDice, level);
    this.fateDie = fate.die;
    this.fateMin = fate.minimum;
    this.fateMax = fate.minimum * 2;
    this.breakDie = CNV.bandMin(CNV.takeABreak, level).die;
    this.xp.max = level * CNV.xpPerLevel;
    this.xp.pct = Math.clamp(Math.round(((this.xp.value - ((level - 1) * CNV.xpPerLevel)) / CNV.xpPerLevel) * 100), 0, 100);

    // Hit points
    const fort = a.fortitude.value;
    const formula = game.settings?.get?.(CNV.id, "hpFormula") ?? "creation";
    const base = formula === "encounters" ? ((fort + 5) * level) + 10 : (fort + 5) * (level + 2);
    this.hp.max = Math.max(1, base + this.hp.bonus);
    this.hp.value = Math.min(this.hp.value, this.hp.max);
    this.hp.lightThreshold = Math.max(1, Math.floor(this.hp.max / 4));
    this.hp.heavyThreshold = Math.max(1, Math.floor(this.hp.max / 2));
    this.hp.bloodied = this.hp.value <= this.hp.heavyThreshold;

    // Strain
    const strainAbility = a[this.strain.ability]?.value ?? fort;
    this.strain.max = Math.max(1, 5 + level + strainAbility + this.strain.bonus - (this.spellcasting.invested ?? 0));

    // Soak
    this.soak.value = this.naturalSoak + this.soak.armor + this.soak.bonus;

    // Speed
    const mr = a.might.value + a.reflex.value;
    const sp = CNV.bandMax(CNV.speedTable, mr);
    this.movement = sp;
    this.speed.value = (this.speed.override || sp.speed) + this.speed.bonus;

    // Supplies & Bulk
    this.sup.max = Math.max(1, 1 + a.intellect.value) + this.sup.bonus;
    this.bulk = { limit: 5 + a.might.value + this.bulkBonus, max: 10 + a.might.value + this.bulkBonus, value: 0 };

    // Initiative
    this.initiative.mod = (a[this.initiative.ability]?.value ?? a.reflex.value) + this.initiative.bonus;

    // Saves
    this.saves = {};
    for ( const [k, ab] of Object.entries(a) ) {
      ab.mod = ab.value + ab.bonus;
      this.saves[k] = ab.value + this.saveBonus + ab.save;
    }
    this.parry = this.saves.might + this.defenses.parry;
    this.dodge = this.saves.reflex + this.defenses.dodge;

    // Skills
    for ( const [k, s] of Object.entries(this.skills) ) {
      const cfg = CNV.skills[k];
      s.key = k;
      s.label = cfg.label;
      s.abilityKey = s.ability || cfg.ability;
      s.purchased = s.ranks;
      s.ranks = s.purchased + (s.granted ?? 0);           // total ranks used everywhere else
      s.mod = (a[s.abilityKey]?.value ?? 0) + s.ranks + s.bonus;
      s.trained = s.ranks > 0;
      s.overCap = s.ranks > this.maxRanks;
    }
    for ( const l of this.lores ) l.mod = a.intellect.value + l.ranks + l.bonus;

    // Spent skill points
    const skillSpent = Object.values(this.skills).reduce((t, s) => t + s.purchased, 0) + this.lores.reduce((t, l) => t + l.ranks, 0);
    this.skillPoints = {
      spent: skillSpent,
      max: CNV.startingSkillPoints + ((level - 1) * CNV.skillPointsPerLevel) + this.points.skillBonus
    };

    if ( this.parent?.items ) this.prepareItemTotals(this.parent.items);
    this._applyExhaustion();
  }

  /** Called by the Actor document after items have prepared, to add bulk totals and armor soak. */
  prepareItemTotals(items) {
    let bulk = 0;
    let armorSoak = 0;
    let armorPenalty = 0;
    for ( const i of items ) {
      const s = i.system;
      if ( !("bulk" in s) ) continue;
      if ( s.carried === false ) continue;
      bulk += (s.bulk ?? 0) * (["gear", "concoction"].includes(i.type) ? Math.ceil((s.quantity ?? 1) / (s.bundle || 1)) : (s.quantity ?? 1));
      if ( (i.type === "armor") && s.equipped ) {
        armorSoak = Math.max(armorSoak, s.soak ?? 0);
        armorPenalty += s.penalty ?? 0;
      }
    }
    this.bulk.value = Math.round(bulk * 10) / 10;
    this.encumbered = this.bulk.value > this.bulk.limit;
    this.overloaded = this.bulk.value > this.bulk.max;
    this.soak.armor = armorSoak;
    this.soak.value = this.naturalSoak + armorSoak + this.soak.bonus;
    this.armorPenalty = armorPenalty;
    // Origin-granted talents are free and don't count against talent picks
    this.talentCount = items.filter(i => (i.type === "talent" && !i.system.origin) || i.type === "technique").length;
    this.talentMax = CONFIG.CNV.startingTalents + ((Math.max(1, this.level) - 1) * CONFIG.CNV.talentsPerLevel) + this.points.talentBonus;
  }
}
