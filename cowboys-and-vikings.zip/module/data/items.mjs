import { int, num, str, bool, html, formula, resource, sourceFields, physicalFields, activationFields } from "./fields.mjs";
const f = foundry.data.fields;

const strArr = () => new f.ArrayField(new f.StringField());
const damage = () => new f.SchemaField({
  dice: str("1d6"), type: str("bludgeoning"), secondary: int(0), versatile: str(), versatileSecondary: int(0), doubleBarrel: str()
});
const requirement = (ability = "might") => new f.SchemaField({ ability: str(ability), value: int(0) });
const durability = () => ({
  hardness: int(0), hp: resource(0, 0), brokenThreshold: int(0)
});

/** Base for every item type. */
class BaseItemData extends foundry.abstract.TypeDataModel {
  static defineSchema() { return sourceFields(); }
  get isPhysical() { return false; }
}

/* -------------------------------------------- */
/*  Physical items                               */
/* -------------------------------------------- */

export class WeaponData extends BaseItemData {
  static defineSchema() {
    return {
      ...super.defineSchema(), ...physicalFields(),
      category: str("melee"),
      skill: str("meleeWeapons"),
      altSkill: str(),
      damage: damage(),
      hands: str("1"),
      twoHanded: bool(false),           // currently wielded in two hands (versatile)
      requirement: requirement("might"),
      traits: strArr(),
      traitValues: new f.ObjectField(),
      range: int(0),
      ammo: new f.SchemaField({ value: int(0), max: int(0), type: str() }),
      attackBonus: int(0),
      damageBonus: int(0),
      specialized: bool(false),
      ...durability()
    };
  }
  get isPhysical() { return true; }
  hasTrait(t) { return this.traits.includes(t); }
  traitValue(t) { return Number(this.traitValues?.[t] ?? 0); }

  prepareDerivedData() {
    const CNV = CONFIG.CNV;
    this.traitLabels = this.traits.map(t => {
      const label = game.i18n.localize(CNV.weaponTraits[t] ?? t);
      const v = this.traitValues?.[t];
      if ( t === "versatile" && this.damage.versatile ) return `${label} (${this.damage.versatile})`;
      if ( t === "doubleBarrel" && this.damage.doubleBarrel ) return `${label} (${this.damage.doubleBarrel})`;
      return (v !== undefined && v !== null && v !== "") ? `${label} (${v})` : label;
    });
    this.isRanged = ["missile", "firearm"].includes(this.category) || (this.range > 0 && !this.hasTrait("thrown"));
    this.canThrow = this.hasTrait("thrown");
    this.armorPiercing = this.traitValue("armorPiercing");
    this.usesAmmo = this.hasTrait("reload") || this.hasTrait("capacity");
  }
}

export class ArmorData extends BaseItemData {
  static defineSchema() {
    return {
      ...super.defineSchema(), ...physicalFields(),
      category: str("light"),
      soak: int(0),
      maxReflex: int(99),
      penalty: int(0),
      speedPenalty: int(0),
      requirement: requirement("might"),
      traits: strArr(),
      specialized: bool(false),
      ...durability()
    };
  }
  get isPhysical() { return true; }
}

export class ShieldData extends BaseItemData {
  static defineSchema() {
    return {
      ...super.defineSchema(), ...physicalFields(),
      bonus: int(1),
      coverBonus: int(0),
      speedPenalty: int(0),
      requirement: requirement("might"),
      bash: damage(),
      maneuvers: strArr(),
      raised: bool(false),
      specialized: bool(false),
      ...durability()
    };
  }
  get isPhysical() { return true; }
  prepareDerivedData() {
    this.effectiveBonus = this.bonus + (this.specialized ? 1 : 0);
    this.effectiveHardness = this.hardness + (this.specialized ? 1 : 0);
    this.broken = this.hp.max > 0 && this.hp.value <= this.brokenThreshold;
    this.destroyed = this.hp.max > 0 && this.hp.value <= 0;
  }
}

export class GearData extends BaseItemData {
  static defineSchema() {
    return {
      ...super.defineSchema(), ...physicalFields(), ...activationFields(),
      category: str("general"),
      bundle: int(1, { min: 1 }),
      capacity: num(0),
      ...durability()
    };
  }
  get isPhysical() { return true; }
}

export class ConcoctionData extends BaseItemData {
  static defineSchema() {
    return {
      ...super.defineSchema(), ...physicalFields(), ...activationFields(),
      concoctionType: str("elixir"),
      potion: bool(false),
      functions: strArr(),
      duration: str(),
      bundle: int(1, { min: 1 })
    };
  }
  get isPhysical() { return true; }
}

/* -------------------------------------------- */
/*  Character options                            */
/* -------------------------------------------- */

export class TalentData extends BaseItemData {
  static defineSchema() {
    return {
      ...super.defineSchema(), ...activationFields(),
      tree: str(),
      tier: int(1, { min: 0 }),
      prerequisites: str(),
      actionTraits: strArr(),
      ranks: resource(1, 1),
      origin: bool(false),
      summary: str()
    };
  }
}

export class TechniqueData extends BaseItemData {
  static defineSchema() {
    return {
      ...super.defineSchema(), ...activationFields(),
      kind: str("melee"),
      requirements: str(),
      pushable: bool(true),
      actionTraits: strArr(),
      applies: new f.SchemaField({ status: str(), value: int(0, { nullable: true }) })
    };
  }
}

export class SpellData extends BaseItemData {
  static defineSchema() {
    return {
      ...super.defineSchema(),
      school: str("evocation"),
      cantrip: bool(false),
      complexity: int(0, { min: 0 }),
      strain: int(0, { min: 0 }),
      cost: str("2"),
      spellTraits: strArr(),
      aoeRestricted: bool(false),          // AOE deliveries cost double (or are barred)
      pushable: bool(false),
      invested: bool(false),
      modifiers: new f.ArrayField(new f.SchemaField({
        name: str(), strain: int(1), text: str(), mastery: bool(false), minRanks: int(0), repeatable: bool(false)
      })),
      castingTime: str("invocation"),
      castingValue: int(1),
      components: strArr(),                // verbal, somatic, material
      material: str(),
      deliveries: strArr(),                // allowed delivery keys
      range: str(),
      duration: str(),
      sustain: bool(false),
      concentration: bool(false),
      save: new f.SchemaField({ ability: str(), effect: str() }),
      attack: bool(false),
      damage: new f.SchemaField({ formula: formula(), type: str(), scaling: str() }),
      trappings: str(),
      heightening: str(),
      critSuccess: html(),
      tradition: str(),
      prepared: bool(true)
    };
  }
  prepareDerivedData() {
    const s = CONFIG.CNV.bandMax(CONFIG.CNV.surgeSeverity, this.strain);
    this.severity = s.key;
    this.attunementTier = this.complexity <= 1 ? 1 : this.complexity <= 3 ? 2 : this.complexity <= 5 ? 3 : 4;
  }
}

export class MetamagicData extends BaseItemData {
  static defineSchema() {
    return { ...super.defineSchema(), strain: int(1), minRanks: int(2), requires: str() };
  }
}

export class OriginData extends BaseItemData {
  static defineSchema() {
    return {
      ...super.defineSchema(),
      ability: str(),                    // ability that receives +1, blank = choose
      abilityChoices: strArr(),
      skills: strArr(),                  // two skills at 2 granted ranks; "a|b|c" = player chooses one
      talent: str(),                     // name of the origin talent; "A|B" = player chooses one
      languages: str(),
      features: html(),
      appearance: str()
    };
  }
}

export class GeneticData extends BaseItemData {
  static defineSchema() {
    return {
      ...super.defineSchema(),
      kind: str("talent"),               // talent | drawback | cosmetic
      roll: str(),
      mechanics: str()
    };
  }
}

export class BondData extends BaseItemData {
  static defineSchema() {
    return {
      ...super.defineSchema(),
      category: str(),
      partner: str(),
      origin: str(),
      tiers: new f.ArrayField(new f.SchemaField({ level: int(1), name: str(), text: str() })),
      unlocked: int(1, { min: 0, max: 4 }),
      actionTraits: strArr(),
      cost: str()
    };
  }
}

export class ManeuverData extends BaseItemData {
  static defineSchema() {
    return {
      ...super.defineSchema(), ...activationFields(),
      category: str("generic"),
      role: str(),
      creatureType: str(),
      actionTraits: strArr(),
      passive: bool(false)
    };
  }
}

export class AfflictionData extends BaseItemData {
  static defineSchema() {
    return {
      ...super.defineSchema(),
      afflictionType: str("poison"),
      family: str(),
      level: int(1),
      vector: str(),
      save: new f.SchemaField({ ability: str("fortitude"), dc: int(15) }),
      onset: str(),
      maxDuration: str(),
      stage: int(0, { min: 0 }),
      stages: new f.ArrayField(new f.SchemaField({ text: str(), duration: str() })),
      cure: str(),
      price: new f.SchemaField({ value: num(0), denomination: str("sp") })
    };
  }
}

export class RuneData extends BaseItemData {
  static defineSchema() {
    return {
      ...super.defineSchema(),
      slot: str("weapon"),
      tier: str("minor"),
      essence: str(),
      level: int(1),
      price: new f.SchemaField({ value: num(0), denomination: str("sp") }),
      tierText: new f.SchemaField({ minor: str(), lesser: str(), greater: str(), major: str() }),
      attuned: bool(false)
    };
  }
  prepareDerivedData() {
    this.potency = CONFIG.CNV.runeTiers[this.tier]?.potency ?? 0;
  }
}

export class MaterialData extends BaseItemData {
  static defineSchema() {
    return {
      ...super.defineSchema(),
      grade: str("standard"),
      hardness: int(0), hp: int(0), brokenThreshold: int(0),
      price: new f.SchemaField({ value: num(0), denomination: str("sp") }),
      appliesTo: str(),
      level: int(0)
    };
  }
}

export class EssenceData extends BaseItemData {
  static defineSchema() {
    return {
      ...super.defineSchema(),
      trait: str("fire"),
      quality: str("common"),
      creature: str(),
      quantity: int(1, { min: 0 }),
      bulk: num(0),
      price: new f.SchemaField({ value: num(0), denomination: str("sp") })
    };
  }
  get isPhysical() { return true; }
}

export class IngredientData extends BaseItemData {
  static defineSchema() {
    return {
      ...super.defineSchema(),
      sourceTag: str("botanical"),
      functions: strArr(),
      terrain: str(),
      rarity: str("common"),
      quantity: int(1, { min: 0 }),
      bulk: num(0),
      price: new f.SchemaField({ value: num(0), denomination: str("sp") })
    };
  }
  get isPhysical() { return true; }
}

export class CrewAbilityData extends BaseItemData {
  static defineSchema() {
    return { ...super.defineSchema(), crewType: str(), levelReq: int(1) };
  }
}

export class CrewUpgradeData extends BaseItemData {
  static defineSchema() {
    return { ...super.defineSchema(), crewType: str("general"), levelReq: int(1), cost: str(), tier: int(1), purchased: bool(false),
      trainingSkill: str() };          // Training upgrade: members may spend 2 Strain to roll this skill with Fortune
  }
}
