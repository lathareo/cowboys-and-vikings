/**
 * Shared field factories for Cowboys & Vikings data models.
 */
const f = foundry.data.fields;

export const int = (initial = 0, opts = {}) => new f.NumberField({ required: true, nullable: false, integer: true, initial, ...opts });
export const num = (initial = 0, opts = {}) => new f.NumberField({ required: true, nullable: false, initial, ...opts });
export const str = (initial = "", opts = {}) => new f.StringField({ required: true, blank: true, initial, ...opts });
export const bool = (initial = false) => new f.BooleanField({ initial });
export const html = () => new f.HTMLField({ required: true, blank: true, initial: "" });
export const formula = (initial = "") => new f.StringField({ required: true, blank: true, initial });

/** A resource with value and max. */
export const resource = (value = 0, max = 0, extra = {}) => new f.SchemaField({
  value: int(value),
  max: int(max),
  ...extra
});

/** Resistances, vulnerabilities and immunities. */
export const rvi = () => new f.SchemaField({
  resist: new f.SetField(new f.StringField()),
  vuln: new f.SetField(new f.StringField()),
  immune: new f.SetField(new f.StringField()),
  conditionImmune: new f.SetField(new f.StringField()),
  notes: str()
});

/** Common item source/identity fields. */
export const sourceFields = () => ({
  description: html(),
  source: str(),
  tags: new f.SetField(new f.StringField())
});

/** Physical items: price, bulk, quantity, equipped. */
export const physicalFields = () => ({
  quantity: int(1, { min: 0 }),
  bulk: num(0, { min: 0 }),
  price: new f.SchemaField({ value: num(0, { min: 0 }), denomination: str("sp") }),
  level: int(0, { min: 0 }),
  equipped: bool(false),
  carried: bool(true),
  rarity: str("common"),
  material: str(),
  runes: new f.ArrayField(new f.SchemaField({ name: str(), tier: str("minor"), uuid: str() }))
});

/** An activatable item: cost, uses, recharge, roll. */
export const activationFields = () => ({
  cost: str("1"),
  strain: int(0, { min: 0 }),
  sup: int(0, { min: 0 }),
  trigger: str(),
  frequency: str(),
  uses: new f.SchemaField({ value: int(0), max: int(0), per: str() }),
  recharge: new f.SchemaField({ enabled: bool(false), threshold: int(0), charged: bool(true) }),
  roll: new f.SchemaField({
    type: str(""),           // "", "check", "attack", "save", "damage"
    skill: str(""),
    ability: str(""),
    save: str(""),
    dc: str(""),
    damage: formula(),
    damageType: str(""),
    bonus: int(0)
  })
});
