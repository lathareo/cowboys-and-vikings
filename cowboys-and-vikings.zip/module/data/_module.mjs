import { CharacterData } from "./actor-character.mjs";
import { AdversaryData, HazardData, CrewData } from "./actor-others.mjs";
import * as I from "./items.mjs";

export const actorModels = {
  character: CharacterData,
  adversary: AdversaryData,
  hazard: HazardData,
  crew: CrewData
};

export const itemModels = {
  weapon: I.WeaponData,
  armor: I.ArmorData,
  shield: I.ShieldData,
  gear: I.GearData,
  concoction: I.ConcoctionData,
  talent: I.TalentData,
  technique: I.TechniqueData,
  spell: I.SpellData,
  metamagic: I.MetamagicData,
  origin: I.OriginData,
  genetic: I.GeneticData,
  bond: I.BondData,
  maneuver: I.ManeuverData,
  affliction: I.AfflictionData,
  rune: I.RuneData,
  material: I.MaterialData,
  essence: I.EssenceData,
  ingredient: I.IngredientData,
  crewAbility: I.CrewAbilityData,
  crewUpgrade: I.CrewUpgradeData
};
