/**
 * Cowboys & Vikings d20 roll.
 *  - 1d20 + modifiers, each net level of Advantage = +2 (Disadvantage = -2), cancelling 1:1.
 *  - Fortune rolls 2d20 keep highest, Misfortune keeps lowest; they cancel each other and never stack.
 *  - Critical success: natural 20, or beat the DC by 15+. Critical failure: natural 1, or miss by 15+.
 */
export class CNVRoll extends Roll {
  static CHAT_TEMPLATE = "systems/cowboys-and-vikings/templates/chat/roll.hbs";

  /**
   * Build a check.
   * @param {object} config
   * @param {Array<{label:string, value:number}>} config.parts   Named modifiers
   * @param {number} config.adv       Advantage levels
   * @param {number} config.dis       Disadvantage levels
   * @param {boolean} config.fortune
   * @param {boolean} config.misfortune
   * @param {number} config.dc
   * @param {object} data             Roll data
   */
  static build(config, data = {}) {
    const net = (config.adv ?? 0) - (config.dis ?? 0);
    const fortune = !!config.fortune && !config.misfortune;
    const misfortune = !!config.misfortune && !config.fortune;
    const die = config.flat ? "1d20" : fortune ? "2d20kh" : misfortune ? "2d20kl" : "1d20";
    const terms = [die];
    if ( !config.flat ) {
      for ( const p of config.parts ?? [] ) {
        const v = Number(p.value) || 0;
        if ( !v ) continue;
        terms.push(`${v < 0 ? "-" : "+"} ${Math.abs(v)}[${p.label.replace(/[\[\]]/g, "")}]`);
      }
      if ( net ) {
        const step = CONFIG.CNV.advantageStep;
        const label = game.i18n.localize(net > 0 ? "CNV.Roll.Advantage" : "CNV.Roll.Disadvantage");
        terms.push(`${net < 0 ? "-" : "+"} ${Math.abs(net) * step}[${label} ${Math.abs(net)}]`);
      }
      if ( config.situational ) terms.push(`+ (${config.situational})`);
    }
    const options = {
      dc: Number.isFinite(config.dc) ? config.dc : null,
      net, fortune, misfortune, flat: !!config.flat,
      kind: config.kind ?? "check",
      autoFail: !!config.autoFail,
      critMargin: config.critMargin ?? CONFIG.CNV.critMargin,
      notes: config.notes ?? []
    };
    return new this(terms.join(" "), data, options);
  }

  get d20() {
    return this.dice.find(d => d.faces === 20);
  }

  /** The kept natural d20 result. */
  get natural() {
    const d = this.d20;
    if ( !d ) return null;
    return d.results.find(r => r.active && !r.discarded)?.result ?? null;
  }

  get isNat20() { return this.natural === 20; }
  get isNat1() { return this.natural === 1; }

  /**
   * Degree of success versus a DC (or an opposed total).
   * @param {number} [dc]
   * @param {number} [margin]
   * @returns {"criticalSuccess"|"success"|"failure"|"criticalFailure"|null}
   */
  degree(dc = this.options.dc, margin = this.options.critMargin) {
    if ( this.options.autoFail ) return "criticalFailure";
    if ( !this._evaluated ) return null;
    if ( this.isNat20 ) return "criticalSuccess";
    if ( this.isNat1 ) return "criticalFailure";
    if ( dc === null || dc === undefined ) return null;
    const t = this.total;
    if ( t >= dc + margin ) return "criticalSuccess";
    if ( t <= dc - margin ) return "criticalFailure";
    return t >= dc ? "success" : "failure";
  }

  /** True when this success earns a Fate Die: a critical failure, or a success that needed 19+ on the die. */
  earnsFate(dc = this.options.dc) {
    const deg = this.degree(dc);
    if ( deg === "criticalFailure" ) return true;
    if ( (deg === "success" || deg === "criticalSuccess") && dc !== null ) {
      const needed = dc - (this.total - this.natural);
      return needed >= 19;
    }
    return false;
  }

  /** @override */
  async render({ flavor, template = this.constructor.CHAT_TEMPLATE, isPrivate = false } = {}) {
    if ( !this._evaluated ) await this.evaluate();
    const degree = this.degree();
    const context = {
      formula: isPrivate ? "???" : this._formula,
      flavor: isPrivate ? null : flavor ?? this.options.flavor,
      user: game.user.id,
      tooltip: isPrivate ? "" : await this.getTooltip(),
      total: isPrivate ? "?" : Math.round(this.total * 100) / 100,
      natural: this.natural,
      dc: this.options.dc,
      degree,
      degreeLabel: degree ? game.i18n.localize(CONFIG.CNV.degrees[degree]) : null,
      fortune: this.options.fortune,
      misfortune: this.options.misfortune,
      net: this.options.net,
      notes: this.options.notes,
      isPrivate
    };
    return foundry.applications.handlebars.renderTemplate(template, context);
  }
}

/* -------------------------------------------- */
/*  Roll dialog                                  */
/* -------------------------------------------- */

/**
 * Show the roll configuration dialog.
 * @returns {Promise<object|null>} updated config or null if cancelled
 */
export async function rollDialog(config) {
  const content = await foundry.applications.handlebars.renderTemplate("systems/cowboys-and-vikings/templates/dialog/roll-dialog.hbs", {
    config,
    parts: config.parts.filter(p => p.value),
    rollModes: CONFIG.Dice.rollModes,
    rollMode: game.settings.get("core", "rollMode"),
    difficulties: CONFIG.CNV.difficulties
  });
  const result = await foundry.applications.api.DialogV2.wait({
    window: { title: config.title ?? game.i18n.localize("CNV.Roll.Configure"), icon: "fa-solid fa-dice-d20" },
    classes: ["cnv", "cnv-roll-dialog"],
    position: { width: 420 },
    content,
    buttons: [{
      action: "roll", label: game.i18n.localize("CNV.Roll.Roll"), icon: "fa-solid fa-dice-d20", default: true,
      callback: (event, button) => new foundry.applications.ux.FormDataExtended(button.form).object
    }, { action: "cancel", label: game.i18n.localize("Cancel") }],
    render: (event, dialog) => {
      const el = dialog.element;
      el.querySelectorAll("[data-step]").forEach(btn => btn.addEventListener("click", ev => {
        ev.preventDefault();
        const input = el.querySelector(`input[name="${btn.dataset.target}"]`);
        input.value = Math.max(0, (Number(input.value) || 0) + Number(btn.dataset.step));
      }));
    },
    rejectClose: false
  });
  if ( !result || result === "cancel" ) return null;
  return {
    ...config,
    adv: Number(result.adv) || 0,
    dis: Number(result.dis) || 0,
    fortune: result.luck === "fortune",
    misfortune: result.luck === "misfortune",
    situational: result.situational?.trim() || "",
    dc: result.dc === "" || result.dc === undefined || result.dc === null ? null : Number(result.dc),
    rollMode: result.rollMode
  };
}

/**
 * Configure (optionally), evaluate, and post a check.
 * @param {object} config  see CNVRoll.build, plus { title, flavor, speaker, actor, skipDialog, rollMode, flags, extraContent }
 */
export async function performCheck(config) {
  let cfg = { parts: [], adv: 0, dis: 0, ...config };
  const fast = cfg.skipDialog ?? (game.settings.get("cowboys-and-vikings", "skipRollDialog") !== !!cfg.event?.shiftKey);
  if ( !fast ) {
    cfg = await rollDialog(cfg);
    if ( !cfg ) return null;
  }
  const roll = CNVRoll.build(cfg, cfg.data ?? cfg.actor?.getRollData?.() ?? {});
  await roll.evaluate();

  const degree = roll.degree();
  const flags = { "cowboys-and-vikings": { ...(cfg.flags ?? {}), check: {
    kind: cfg.kind ?? "check", ability: cfg.ability ?? null, skill: cfg.skill ?? null, dc: roll.options.dc,
    degree, actorUuid: cfg.actor?.uuid ?? null, config: foundry.utils.deepClone({
      parts: cfg.parts, adv: cfg.adv, dis: cfg.dis, fortune: cfg.fortune, misfortune: cfg.misfortune,
      situational: cfg.situational, kind: cfg.kind, ability: cfg.ability, skill: cfg.skill, title: cfg.title, flat: cfg.flat
    }), earnsFate: roll.earnsFate()
  } } };

  const messageData = {
    speaker: cfg.speaker ?? ChatMessage.getSpeaker({ actor: cfg.actor }),
    flavor: cfg.flavor ?? cfg.title,
    flags
  };
  if ( cfg.extraContent ) messageData.content = cfg.extraContent;
  const msg = await roll.toMessage(messageData, { rollMode: cfg.rollMode ?? game.settings.get("core", "rollMode") });

  // Fate & Chaos bookkeeping
  const actor = cfg.actor;
  if ( actor?.type === "character" && actor.isOwner ) {
    if ( roll.earnsFate() && game.settings.get("cowboys-and-vikings", "autoFate") ) {
      await actor.update({ "system.fate.value": Math.min(actor.system.fate.value + 1, actor.system.fateMax) });
      ui.notifications.info(game.i18n.format("CNV.Fate.Gained", { name: actor.name }));
    }
    if ( degree === "criticalSuccess" && game.settings.get("cowboys-and-vikings", "autoChaos") ) {
      game.cnv.pools.adjustChaos(1);
    }
  }
  return { roll, message: msg, degree };
}

/** Roll a flat check (plain d20 vs DC). */
export async function flatCheck(dc, { actor, title } = {}) {
  return performCheck({
    actor, flat: true, dc, kind: "flat", skipDialog: true,
    title: title ?? game.i18n.format("CNV.Roll.FlatCheck", { dc })
  });
}
