const SYS = "cowboys-and-vikings";

/**
 * World migration entry point. Records the system version so future releases can transform data.
 */
export async function migrateWorld() {
  const current = game.system.version;
  const last = game.settings.get(SYS, "systemMigrationVersion");
  if ( last === current ) return;
  if ( !last ) return game.settings.set(SYS, "systemMigrationVersion", current);
  if ( foundry.utils.isNewerVersion(current, last) ) {
    if ( foundry.utils.isNewerVersion("1.1.0", last) ) await migrate110();
    ui.notifications.info(game.i18n.format("CNV.Migration.Done", { version: current }));
    await game.settings.set(SYS, "systemMigrationVersion", current);
  }
}

/** Rewrite a list of effect changes so bonuses target the "granted" fields. */
function grantedChanges(changes) {
  let dirty = false;
  const out = changes.map(c => {
    const key = c.key.replace(/^system\.abilities\.(\w+)\.value$/, "system.abilities.$1.granted")
      .replace(/^system\.skills\.(\w+)\.ranks$/, "system.skills.$1.granted");
    if ( key !== c.key ) dirty = true;
    return { ...c, key };
  });
  return dirty ? out : null;
}

async function migrateEffects(parent) {
  const updates = [];
  for ( const e of parent.effects ) {
    const changes = grantedChanges(e.changes);
    if ( changes ) updates.push({ _id: e._id ?? e.id, changes });
  }
  if ( updates.length ) await parent.updateEmbeddedDocuments("ActiveEffect", updates);
}

/** 1.1.0: effects that raised ability scores or skill ranks now add to "granted" so they don't count as spent points. */
async function migrate110() {
  for ( const item of game.items ) await migrateEffects(item);
  for ( const actor of game.actors ) {
    if ( actor.type !== "character" ) continue;
    await migrateEffects(actor);
    for ( const item of actor.items ) await migrateEffects(item);
  }
}
