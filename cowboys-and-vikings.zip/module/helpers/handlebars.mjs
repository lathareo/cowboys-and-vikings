const SYS = "cowboys-and-vikings";

export function registerHandlebars() {
  const H = Handlebars;
  H.registerHelper("cnvSigned", v => { const n = Number(v) || 0; return n >= 0 ? `+${n}` : `${n}`; });
  H.registerHelper("cnvEq", (a, b) => a === b);
  H.registerHelper("cnvIncludes", (arr, v) => Array.isArray(arr) ? arr.includes(v) : (arr instanceof Set ? arr.has(v) : false));
  H.registerHelper("cnvTimes", (n, block) => { let out = ""; for ( let i = 0; i < n; i++ ) out += block.fn({ index: i, n: i + 1 }); return out; });
  H.registerHelper("cnvLookupLabel", (obj, key) => {
    const v = obj?.[key];
    return game.i18n.localize(typeof v === "string" ? v : v?.label ?? key ?? "");
  });
  H.registerHelper("cnvHas", (obj, key) => obj != null && obj[key] !== undefined && obj[key] !== null);
  H.registerHelper("cnvJson", v => JSON.stringify(v));
  H.registerHelper("cnvPct", (v, max) => Math.clamp(Math.round(((Number(v) || 0) / Math.max(1, Number(max) || 1)) * 100), 0, 100));
  H.registerHelper("cnvCap", s => typeof s === "string" ? s.charAt(0).toUpperCase() + s.slice(1) : s);
  H.registerHelper("cnvCost", c => {
    const map = { "1": "①", "2": "②", reaction: "Ⓡ", free: "⓪", passive: "", stance: "Ⓢ" };
    return map[c] ?? "";
  });
  H.registerHelper("cnvPrice", p => p?.value ? `${p.value} ${p.denomination}` : "—");
  H.registerHelper("cnvBulk", b => b === 0 ? "—" : (b > 0 && b < 1 ? "L" : b));
}

export function preloadTemplates() {
  const base = `systems/${SYS}/templates`;
  const itemTypes = ["weapon", "armor", "shield", "gear", "concoction", "talent", "technique", "spell", "metamagic", "origin", "genetic",
    "bond", "maneuver", "affliction", "rune", "material", "essence", "ingredient", "crewAbility", "crewUpgrade"];
  const paths = [
    `${base}/actor/parts/item-row.hbs`,
    `${base}/actor/parts/conditions.hbs`,
    `${base}/actor/parts/item-controls.hbs`,
    `${base}/item/parts/physical.hbs`,
    `${base}/item/parts/activation.hbs`,
    ...itemTypes.map(t => `${base}/item/details/${t}.hbs`)
  ];
  return foundry.applications.handlebars.loadTemplates(paths);
}
