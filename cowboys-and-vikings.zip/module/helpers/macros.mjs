/**
 * Macro helpers exposed at game.cnv.macros.
 */
const L = (k, d) => d ? game.i18n.format(k, d) : game.i18n.localize(k);

function speakerActor() {
  const speaker = ChatMessage.getSpeaker();
  let actor = speaker.token ? game.actors.tokens[speaker.token] : null;
  actor ??= game.actors.get(speaker.actor) ?? game.user.character;
  return actor;
}

/** Create a hotbar macro that uses an item by name. */
export async function createItemMacro(data, slot) {
  const item = await fromUuid(data.uuid);
  if ( !item ) return;
  const command = `game.cnv.macros.useItem(${JSON.stringify(item.name)});`;
  let macro = game.macros.find(m => m.name === item.name && m.command === command);
  macro ??= await Macro.create({ name: item.name, type: "script", img: item.img, command, flags: { "cowboys-and-vikings.itemMacro": true } });
  return game.user.assignHotbarMacro(macro, slot);
}

export function useItem(name) {
  const actor = speakerActor();
  const item = actor?.items.getName(name);
  if ( !item ) return ui.notifications.warn(L("CNV.Macro.NoItem", { name }));
  return item.use();
}

export function rollSkill(skill, opts = {}) {
  const actor = speakerActor();
  if ( !actor ) return ui.notifications.warn(L("CNV.Chat.SelectToken"));
  return actor.rollSkill(skill, opts);
}

export function rollSave(ability, opts = {}) {
  const actor = speakerActor();
  if ( !actor ) return ui.notifications.warn(L("CNV.Chat.SelectToken"));
  return actor.rollSave(ability, opts);
}

export function rollAbility(ability, opts = {}) {
  const actor = speakerActor();
  if ( !actor ) return ui.notifications.warn(L("CNV.Chat.SelectToken"));
  return actor.rollAbility(ability, opts);
}

export function flat(dc = 15) {
  return game.cnv.flatCheck(dc, { actor: speakerActor() });
}

export function openPools() { return game.cnv.pools.render(true); }
export function openToolkit() { return game.cnv.toolkit.render(true); }
export function takeABreak() { return speakerActor()?.takeABreak(); }
export function shortRest() { return speakerActor()?.shortRest(); }
export function longRest() { return speakerActor()?.longRest(); }
export function surge(school = "evocation", severity = "minor") { return game.cnv.rollWildSurge(school, severity, "1d30", { actor: speakerActor() }); }

/** Group check: roll the same skill for all selected tokens; half or more must succeed. */
export async function groupCheck(skill, dc = 15) {
  const actors = canvas.tokens.controlled.map(t => t.actor).filter(Boolean);
  if ( !actors.length ) return ui.notifications.warn(L("CNV.Chat.SelectToken"));
  let passed = 0;
  for ( const a of actors ) {
    const r = await a.rollSkill(skill, { dc, skipDialog: true });
    if ( r && ["success", "criticalSuccess"].includes(r.degree) ) passed++;
  }
  const ok = passed >= Math.ceil(actors.length / 2);
  return ChatMessage.create({ content: `<div class="cnv-card"><h4>${L("CNV.GroupCheck")}</h4><p>${L(ok ? "CNV.GroupCheckPass" : "CNV.GroupCheckFail", { passed, total: actors.length })}</p></div>` });
}

/** Falling damage: 1d6 per 10 feet (max 200 feet). */
export function falling(feet = 10, { soft = 0 } = {}) {
  const eff = Math.clamp(feet - soft, 0, 200);
  const dice = Math.floor(eff / 10);
  if ( !dice ) return;
  const actor = speakerActor();
  return actor?.postDamage(`${dice}d6`, { type: "bludgeoning", flavor: L("CNV.Falling", { feet: eff }) });
}
