/**
 * Minimal GM relay so players can trigger world updates (combat bump target, chaos pool, applying
 * damage to tokens they don't own).
 */
const SYS = "cowboys-and-vikings";
const CHANNEL = `system.${SYS}`;

const handlers = {
  async setLastTarget({ combatId, combatantId }) {
    const combat = game.combats.get(combatId);
    if ( combat ) await combat.setFlag(SYS, "lastTarget", combatantId);
  },
  async adjustChaos({ delta }) {
    const v = Math.max(0, game.settings.get(SYS, "chaosPool") + delta);
    await game.settings.set(SYS, "chaosPool", v);
  },
  async applyDamage({ actorUuid, amount, opts }) {
    const actor = await fromUuid(actorUuid);
    const a = actor?.actor ?? actor;
    if ( a ) await a.applyDamage(amount, opts);
  },
  async spendAP({ combatantId, combatId, ap = 0, rp = 0 }) {
    const c = game.combats.get(combatId)?.combatants.get(combatantId);
    if ( !c ) return;
    await c.update({
      [`flags.${SYS}.ap`]: Math.max(0, (c.getFlag(SYS, "ap") ?? 0) - ap),
      [`flags.${SYS}.rp`]: Math.max(0, (c.getFlag(SYS, "rp") ?? 0) - rp)
    });
  }
};

export function registerSocket() {
  game.socket.on(CHANNEL, async ({ action, data }) => {
    if ( !game.user.isActiveGM ) return;
    await handlers[action]?.(data);
  });
}

/** Run an action as the GM (directly if we are the GM). */
export async function asGM(action, data) {
  if ( game.user.isActiveGM ) return handlers[action]?.(data);
  if ( !game.users.activeGM ) return ui.notifications.warn(game.i18n.localize("CNV.NoGM"));
  game.socket.emit(CHANNEL, { action, data });
}
