/**
 * Conditions (Encounters chapter). Each is registered as a token status effect.
 * `mods` is read by the roll engine:
 *   dis        — Disadvantage levels applied to a scope ({ all, might, reflex, ..., perception, attack, sightAttack, parry, dodge, athletics, acrobatics, concentrate })
 *   penalty    — flat penalties by ability ({ might: "X" }) where "X" means the condition's value
 *   attackersAdv — Advantage levels granted to attacks against the creature
 *   autoFail   — saves that automatically fail
 *   noReactions, incapacitated, speed ("0" | "half" | "-X")
 */
const X = "X";

export const CONDITIONS = [
  { id: "bloodied", name: "Bloodied", img: "icons/svg/blood.svg", auto: true,
    text: "Current HP at half of maximum or lower. No penalty of its own; many abilities key off it." },
  { id: "confused", name: "Confused", img: "icons/svg/daze.svg", lingering: true, valued: true,
    text: "X levels of Disadvantage on actions with the Concentrate or Manipulate traits.", mods: { dis: { concentrate: X, manipulate: X } } },
  { id: "dazed", name: "Dazed", img: "icons/svg/stoned.svg", lingering: true,
    text: "Can't take Reactions.", mods: { noReactions: true } },
  { id: "frightened", name: "Frightened", img: "icons/svg/terror.svg", lingering: true, valued: true,
    text: "X levels of Disadvantage on all checks. Adversaries also suffer it on Morale.", mods: { dis: { all: X } } },
  { id: "persistentDamage", name: "Persistent Damage", img: "icons/svg/blood.svg", lingering: true, valued: true, formulaValue: true,
    text: "Take the listed damage at the end of each turn, then a DC 15 flat check ends it. Soak doesn't apply; resistance, vulnerability and immunity do. Different damage types stack; the same type uses the higher value." },
  { id: "staggered", name: "Staggered", img: "icons/svg/downgrade.svg", lingering: true,
    text: "Can't take Reactions and start each turn with 1 fewer Action Point.", mods: { noReactions: true, apLoss: 1 } },
  { id: "encumbered", name: "Encumbered", img: "icons/svg/anchor.svg",
    text: "Every foot moved costs 2 feet of Speed. 1 level of Disadvantage on Might and Reflex checks and saves.", mods: { dis: { might: 1, reflex: 1 } } },
  { id: "enfeebled", name: "Enfeebled", img: "icons/svg/degen.svg", lingering: true, valued: true,
    text: "-X to Might checks and saves.", mods: { penalty: { might: X } } },
  { id: "clumsy", name: "Clumsy", img: "icons/svg/degen.svg", lingering: true, valued: true,
    text: "-X to Reflex checks and saves.", mods: { penalty: { reflex: X } } },
  { id: "drained", name: "Drained", img: "icons/svg/degen.svg", lingering: true, valued: true,
    text: "-X to Fortitude checks and saves.", mods: { penalty: { fortitude: X } } },
  { id: "stupefied", name: "Stupefied", img: "icons/svg/degen.svg", lingering: true, valued: true,
    text: "-X to Intellect checks and saves. Casting a spell requires a DC 5 + X flat check or the spell is disrupted.", mods: { penalty: { intellect: X } } },
  { id: "oblivious", name: "Oblivious", img: "icons/svg/degen.svg", lingering: true, valued: true,
    text: "-X to Perception checks and saves.", mods: { penalty: { perception: X } } },
  { id: "unnerved", name: "Unnerved", img: "icons/svg/degen.svg", lingering: true, valued: true,
    text: "-X to Charisma checks and saves.", mods: { penalty: { charisma: X } } },
  { id: "restrained", name: "Restrained", img: "icons/svg/net.svg",
    text: "Speed 0 with no Speed bonuses. Attacks against you gain 1 Advantage; your attacks and Reflex saves suffer 1 Disadvantage.",
    mods: { speed: "0", attackersAdv: 1, dis: { attack: 1, reflexSave: 1 } } },
  { id: "paralyzed", name: "Paralyzed", img: "icons/svg/paralysis.svg",
    text: "Incapacitated, can't move, barely speaks. Automatically fails Might and Reflex saves. Attacks against you gain 1 Advantage; hits from within 5 feet are critical.",
    mods: { incapacitated: true, speed: "0", autoFail: ["might", "reflex"], attackersAdv: 1, meleeCrit: true } },
  { id: "prone", name: "Prone", img: "icons/svg/falling.svg",
    text: "Effective Speed 0 (so you can't Dodge). Standing costs half your Speed. 1 Disadvantage on Might saves to Parry.",
    mods: { noDodge: true, dis: { parry: 1 } } },
  { id: "blinded", name: "Blinded", img: "icons/svg/blind.svg",
    text: "Can't see; fails sight-based checks. Attacks against you gain 1 Advantage; your sight-based attacks suffer 1 Disadvantage.",
    mods: { attackersAdv: 1, dis: { attack: 1 } } },
  { id: "dazzled", name: "Dazzled", img: "icons/svg/sun.svg", lingering: true, valued: true,
    text: "X levels of Disadvantage on sight-based Perception checks and saves, and on attacks that rely on sight.", mods: { dis: { perception: X, attack: X } } },
  { id: "drowsy", name: "Drowsy", img: "icons/svg/sleep.svg", lingering: true,
    text: "1 level of Disadvantage on Perception checks and saves.", mods: { dis: { perception: 1 } } },
  { id: "sickened", name: "Sickened", img: "icons/svg/poison.svg", lingering: true, valued: true,
    text: "X levels of Disadvantage on all checks. Some sources stop you reducing it while they persist.", mods: { dis: { all: X } } },
  { id: "fascinated", name: "Fascinated", img: "icons/svg/eye.svg",
    text: "1 Disadvantage on Perception checks and saves; Concentrate actions only toward the subject. Ends if anyone acts hostile toward you or your allies.",
    mods: { dis: { perception: 1 } } },
  { id: "offGuard", name: "Off-Guard", img: "icons/svg/target.svg",
    text: "Attacks against you gain 1 Advantage. 1 Disadvantage on Reflex saves, Athletics and Acrobatics. Off-Balance effects make you Off-Guard.",
    mods: { attackersAdv: 1, dis: { reflexSave: 1, athletics: 1, acrobatics: 1, dodge: 1 } } },
  { id: "weakenedGrip", name: "Weakened Grip", img: "icons/svg/sword.svg", lingering: true, valued: true,
    text: "X levels of Disadvantage on weapon attacks, Grapple checks and weapon damage.", mods: { dis: { attack: X, grapple: X } } },
  { id: "chestTrauma", name: "Chest Trauma", img: "icons/svg/bones.svg", lingering: true, valued: true,
    text: "Every action you take causes X extra Strain (or X Strain if it normally causes none).", mods: { actionStrain: X } },
  { id: "gapingWound", name: "Gaping Wound", img: "icons/svg/blood.svg", lingering: true,
    text: "Piercing or slashing hits deal +2 damage to you. Ends when you next regain HP from healing (or First Aid, GM's call).", mods: { gaping: 2 } },
  { id: "slowed", name: "Slowed", img: "icons/svg/frozen.svg", valued: true,
    text: "Speed reduced by X feet (minimum 0). Multiple sources: use the highest.", mods: { speed: "-X" } },
  { id: "charmed", name: "Charmed", img: "icons/svg/angel.svg", lingering: true,
    text: "Can't attack or harm the charmer, who gains 1 Advantage on social checks with you. Ends if the charmer acts hostile to you or your allies." },
  { id: "deafened", name: "Deafened", img: "icons/svg/deaf.svg", lingering: true,
    text: "Can't hear; fails hearing checks. Auditory actions need a DC 5 flat check first." },
  { id: "grappled", name: "Grappled", img: "icons/svg/net.svg",
    text: "Speed 0 with no Speed bonuses; Off-Guard to the grappler. Ends if the grappler is Incapacitated, you're moved out of reach, or you Escape.",
    mods: { speed: "0", noDodge: true } },
  { id: "incapacitated", name: "Incapacitated", img: "icons/svg/cancel.svg",
    text: "Can't take actions or reactions.", mods: { incapacitated: true, noReactions: true } },
  { id: "invisible", name: "Invisible", img: "icons/svg/invisible.svg",
    text: "Unseen without magic or special senses. Sight-reliant attacks against you suffer 1 Disadvantage; your attacks against sight-reliant targets gain 1 Advantage.",
    mods: { adv: { attack: 1 }, attackersDis: 1 } },
  { id: "stunned", name: "Stunned", img: "icons/svg/daze.svg", lingering: true,
    text: "Incapacitated, can't move, barely speaks. Automatically fails Might and Reflex saves. Attacks against you gain 1 Advantage.",
    mods: { incapacitated: true, speed: "0", autoFail: ["might", "reflex"], attackersAdv: 1 } },
  { id: "unconscious", name: "Unconscious", img: "icons/svg/unconscious.svg",
    text: "Incapacitated, unaware, drops held items and falls Prone. Automatically fails Might and Reflex saves. Attacks against you gain 1 Advantage; hits from within 5 feet are critical.",
    mods: { incapacitated: true, speed: "0", autoFail: ["might", "reflex"], attackersAdv: 1, meleeCrit: true } },
  { id: "withered", name: "Withered", img: "icons/svg/skull.svg", lingering: true,
    text: "Can't gain HP or temporary HP.", mods: { noHealing: true } },
  { id: "takenIn", name: "Taken In", img: "icons/svg/mystery-man.svg", lingering: true, valued: true,
    text: "X levels of Disadvantage on saves against non-attack effects from the creature that imposed it." },
  { id: "dimSighted", name: "Dim-Sighted", img: "icons/svg/eye.svg", lingering: true,
    text: "Everything you perceive by sight counts as Concealed from you." },
  { id: "sinking", name: "Sinking", img: "icons/svg/anchor.svg", lingering: true, valued: true,
    text: "Restrained and being pulled under. Start of turn: Athletics vs the hazard DC (success -1, failure +1). At 3 you're submerged and begin Suffocating.",
    mods: { speed: "0", attackersAdv: 1, dis: { attack: 1, reflexSave: 1 } } },
  { id: "maimed", name: "Maimed", img: "icons/svg/bones.svg", lingering: true,
    text: "One chosen movement speed is reduced to 0 until the condition ends.", mods: { speed: "0" } },
  { id: "hidden", name: "Hidden", img: "icons/svg/mystery-man.svg",
    text: "Your space is known but you can't be perceived clearly. Targeting you requires a DC 11 flat check." },
  { id: "undetected", name: "Undetected", img: "icons/svg/invisible.svg",
    text: "Observers don't know which space you occupy; they must guess and roll as if you were Hidden." },
  { id: "concealed", name: "Concealed", img: "icons/svg/aura.svg",
    text: "Obscured by mist, smoke or dim light. Targeting you requires a DC 5 flat check." },
  { id: "dying", name: "Dying", img: "icons/svg/skull.svg",
    text: "At 0 HP. Each turn start roll 1d20: natural 20 regains 1 HP, otherwise the Death Timer drops by 1 unless Stable. Damage reduces the timer by 1 (2 on a critical).",
    mods: { incapacitated: true } },
  { id: "stable", name: "Stable", img: "icons/svg/heal.svg",
    text: "Your Death Timer doesn't tick down. Lost when you take damage or regain HP." },
  { id: "dead", name: "Dead", img: "icons/svg/skull.svg", text: "Dead." }
];

/** Build the CONFIG.statusEffects list. */
export function registerConditions() {
  const effects = CONDITIONS.map(c => ({
    id: c.id,
    name: c.name,
    img: c.img,
    description: `<p>${c.text}</p>${c.lingering ? "<p><em>Lingering: DC 15 flat check at the end of your turn to recover (reduce by 1 if valued). The Recover action (1 AP, optional 1 SUP to reduce by 2) makes an extra attempt.</em></p>" : ""}`,
    _id: `cnv${c.id}`.padEnd(16, "0").slice(0, 16),
    flags: { "cowboys-and-vikings": { valued: !!c.valued, lingering: !!c.lingering } }
  }));
  CONFIG.statusEffects = effects;
  CONFIG.CNV.conditions = Object.fromEntries(CONDITIONS.map(c => [c.id, c]));
  CONFIG.specialStatusEffects.DEFEATED = "dead";
  CONFIG.specialStatusEffects.INVISIBLE = "invisible";
  CONFIG.specialStatusEffects.BLIND = "blinded";
}

/**
 * Collect condition modifiers active on an actor.
 * @param {Actor} actor
 * @returns {{list: object[], mods: object}}
 */
export function conditionMods(actor) {
  const out = [];
  if ( !actor ) return out;
  for ( const effect of actor.appliedEffects ?? actor.effects ) {
    for ( const status of effect.statuses ?? [] ) {
      const c = CONFIG.CNV.conditions?.[status];
      if ( !c ) continue;
      const value = Number(effect.getFlag?.("cowboys-and-vikings", "value") ?? 1) || 1;
      out.push({ id: status, name: c.name, value, mods: c.mods ?? {}, effect });
    }
  }
  return out;
}

/** Resolve an "X" placeholder. */
export const resolveX = (v, value) => (v === X ? value : Number(v) || 0);

/**
 * Compute Advantage levels, flat penalties and auto-fail from conditions for a roll.
 * @param {Actor} actor
 * @param {object} ctx  { ability, skill, kind: "check"|"save"|"attack"|"parry"|"dodge", traits: [] }
 */
export function conditionAdjustments(actor, ctx) {
  const res = { adv: 0, dis: 0, penalty: 0, autoFail: false, notes: [] };
  const list = conditionMods(actor);
  const ex = actor?.system?.exhaustion ?? 0;
  if ( ex > 0 && ex < 4 ) { res.dis += ex; res.notes.push(`${game.i18n.localize("CNV.Exhaustion")} ${ex}`); }
  for ( const c of list ) {
    const m = c.mods;
    const scopes = new Set(["all"]);
    if ( ctx.ability ) scopes.add(ctx.ability);
    if ( ctx.skill ) scopes.add(ctx.skill);
    if ( ctx.kind === "attack" ) scopes.add("attack");
    if ( ctx.kind === "parry" ) scopes.add("parry");
    if ( ctx.kind === "dodge" ) { scopes.add("dodge"); scopes.add("reflexSave"); }
    if ( ctx.kind === "save" && ctx.ability === "reflex" ) scopes.add("reflexSave");
    for ( const t of ctx.traits ?? [] ) scopes.add(t);
    let applied = false;
    for ( const [scope, v] of Object.entries(m.dis ?? {}) ) {
      if ( scopes.has(scope) ) { res.dis += resolveX(v, c.value); applied = true; }
    }
    for ( const [scope, v] of Object.entries(m.adv ?? {}) ) {
      if ( scopes.has(scope) ) { res.adv += resolveX(v, c.value); applied = true; }
    }
    for ( const [ab, v] of Object.entries(m.penalty ?? {}) ) {
      if ( ab === ctx.ability ) { res.penalty += resolveX(v, c.value); applied = true; }
    }
    if ( ["save", "parry", "dodge"].includes(ctx.kind) && m.autoFail?.includes(ctx.ability) ) { res.autoFail = true; applied = true; }
    if ( applied ) res.notes.push(c.value > 1 || CONFIG.CNV.conditions[c.id]?.valued ? `${c.name} ${c.value}` : c.name);
  }
  return res;
}

/** Advantage granted to attackers by the target's conditions. */
export function targetAdjustments(target) {
  const res = { adv: 0, dis: 0, notes: [], meleeCrit: false, gaping: 0 };
  for ( const c of conditionMods(target) ) {
    if ( c.mods.attackersAdv ) { res.adv += c.mods.attackersAdv; res.notes.push(c.name); }
    if ( c.mods.attackersDis ) { res.dis += c.mods.attackersDis; res.notes.push(c.name); }
    if ( c.mods.meleeCrit ) res.meleeCrit = true;
    if ( c.mods.gaping ) res.gaping = c.mods.gaping;
  }
  return res;
}

/** Toggle or set a valued condition on an actor. */
export async function setCondition(actor, id, value = null) {
  const c = CONFIG.CNV.conditions[id];
  if ( !c ) return;
  const existing = actor.effects.find(e => e.statuses.has(id));
  if ( value === 0 || (value === null && existing && !c.valued) ) {
    if ( existing ) await existing.delete();
    return;
  }
  const v = value ?? ((existing?.getFlag("cowboys-and-vikings", "value") ?? 0) + 1);
  if ( existing ) {
    // Lingering: keep the higher value.
    return existing.update({ "flags.cowboys-and-vikings.value": v, name: c.valued ? `${c.name} ${v}` : c.name });
  }
  const effect = await ActiveEffect.implementation.fromStatusEffect(id);
  const data = effect.toObject();
  data.name = c.valued ? `${c.name} ${v}` : c.name;
  foundry.utils.setProperty(data, "flags.cowboys-and-vikings.value", v);
  return ActiveEffect.implementation.create(data, { parent: actor, keepId: true });
}
