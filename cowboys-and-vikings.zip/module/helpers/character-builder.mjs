/**
 * Character-creation helpers: origin application, roll/choose from Roll Tables onto the sheet,
 * genetic rolls, crew training, and token-art display.
 */
const SYS = "cowboys-and-vikings";
const L = (k, d) => d ? game.i18n.format(k, d) : game.i18n.localize(k);
const { DialogV2 } = foundry.applications.api;
const strip = html => String(html ?? "").replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim();

/* -------------------------------------------- */
/*  Roll Tables                                  */
/* -------------------------------------------- */

/** Find a Roll Table by name in the world, then in the system's Roll Tables compendium. */
export async function getTable(name) {
  const world = game.tables.getName(name);
  if ( world ) return world;
  const pack = game.packs.get(`${SYS}.tables`);
  if ( !pack ) return null;
  const idx = (await pack.getIndex()).find(e => e.name === name);
  return idx ? pack.getDocument(idx._id) : null;
}

/** Find all compendium/world table names that start with a prefix. */
export async function findTables(prefix) {
  const names = new Set(game.tables.filter(t => t.name.startsWith(prefix)).map(t => t.name));
  const pack = game.packs.get(`${SYS}.tables`);
  if ( pack ) for ( const e of await pack.getIndex() ) if ( e.name.startsWith(prefix) ) names.add(e.name);
  return [...names];
}

/** Plain text of a table result. */
export function resultText(r) {
  return strip(r.description || r.text || r.name);
}

/**
 * Roll on a table (posting to chat) or let the user choose a result.
 * @returns {Promise<string|null>} the chosen/rolled result text
 */
export async function drawFromTable(name, { choose = false, actor } = {}) {
  const table = await getTable(name);
  if ( !table ) {
    ui.notifications.warn(L("CNV.Builder.NoTable", { name }));
    return null;
  }
  if ( choose ) {
    const results = table.results.contents.sort((a, b) => a.range[0] - b.range[0]);
    const options = results.map((r, i) => `<option value="${i}">${r.range[0] === r.range[1] ? r.range[0] : `${r.range[0]}–${r.range[1]}`}: ${foundry.utils.escapeHTML(resultText(r))}</option>`).join("");
    const pick = await DialogV2.prompt({
      window: { title: L("CNV.Builder.ChooseFrom", { name }) }, position: { width: 520 },
      content: `<div class="cnv-form"><select name="pick" size="12" style="width:100%;height:auto">${options}</select></div>`,
      ok: { label: L("CNV.Builder.Choose"), callback: (e, b) => b.form.elements.pick.value }, rejectClose: false
    });
    if ( pick === null || pick === undefined || pick === "" ) return null;
    return resultText(results[Number(pick)]);
  }
  const draw = await table.draw({ displayChat: true, rollMode: game.settings.get("core", "rollMode"),
    ...(actor ? { speaker: ChatMessage.getSpeaker({ actor }) } : {}) });
  const r = draw.results?.[0];
  return r ? resultText(r) : null;
}

/* -------------------------------------------- */
/*  Origin                                       */
/* -------------------------------------------- */

/** The character's origin name (item first, then the text field). */
export function originName(actor) {
  return actor.items.find(i => i.type === "origin")?.name ?? actor.system.details?.origin ?? "";
}

/**
 * Apply an origin that was just added to a character: replace any previous origin, ask for the player's
 * choices, record them as an Active Effect on the origin item, and add the origin talent (free).
 */
export async function applyOrigin(actor, item) {
  const s = item.system;
  const C = CONFIG.CNV;

  // Replace a previous origin and the talent it granted
  const old = actor.items.filter(i => i.type === "origin" && i.id !== item.id);
  const oldTalents = actor.items.filter(i => i.getFlag(SYS, "grantedBy") && old.some(o => o.id === i.getFlag(SYS, "grantedBy")));
  if ( old.length ) await actor.deleteEmbeddedDocuments("Item", [...old, ...oldTalents].map(i => i.id));

  // Gather the choices this origin needs
  const abilityOpts = s.ability ? [] : (s.abilityChoices ?? []);
  const skillChoices = (s.skills ?? []).map((k, i) => ({ i, opts: k.split("|") })).filter(x => x.opts.length > 1);
  const talentOpts = (s.talent ?? "").split("|").map(t => t.trim()).filter(Boolean);
  const sel = (name, opts, label) => `<div class="form-group"><label>${label}</label><select name="${name}">${opts.map(o => `<option value="${o.value}">${o.label}</option>`).join("")}</select></div>`;
  let html = "";
  if ( abilityOpts.length > 1 ) html += sel("ability", abilityOpts.map(k => ({ value: k, label: L(C.abilities[k]?.label ?? k) })), L("CNV.Builder.OriginAbility"));
  for ( const sc of skillChoices ) html += sel(`skill${sc.i}`, sc.opts.map(k => ({ value: k, label: L(C.skills[k]?.label ?? k) })), L("CNV.Builder.OriginSkill"));
  if ( talentOpts.length > 1 ) html += sel("talent", talentOpts.map(t => ({ value: t, label: t })), L("CNV.Builder.OriginTalent"));
  let picks = {};
  if ( html ) {
    picks = await DialogV2.prompt({
      window: { title: L("CNV.Builder.OriginChoices", { name: item.name }) },
      content: `<p class="hint">${L("CNV.Builder.OriginChoicesHint")}</p><div class="cnv-form">${html}</div>`,
      ok: { callback: (e, b) => Object.fromEntries(new FormData(b.form).entries()) }, rejectClose: false
    }) ?? {};
  }

  // Record the player's choices on the origin item (fixed parts are already in the compendium effect)
  const changes = [];
  const ability = s.ability ? null : (picks.ability ?? abilityOpts[0]);
  if ( ability ) changes.push({ key: `system.abilities.${ability}.granted`, mode: 2, value: "1" });
  for ( const sc of skillChoices ) changes.push({ key: `system.skills.${picks[`skill${sc.i}`] ?? sc.opts[0]}.granted`, mode: 2, value: "2" });
  // If the origin item has no prebuilt effect (e.g. homebrew), build the fixed parts too
  const hasFixed = item.effects.some(e => e.getFlag(SYS, "origin") === "fixed");
  if ( !hasFixed ) {
    if ( s.ability ) changes.push({ key: `system.abilities.${s.ability}.granted`, mode: 2, value: "1" });
    for ( const k of (s.skills ?? []) ) if ( !k.includes("|") ) changes.push({ key: `system.skills.${k}.granted`, mode: 2, value: "2" });
  }
  const stale = item.effects.filter(e => e.getFlag(SYS, "origin") === "choice").map(e => e.id);
  if ( stale.length ) await item.deleteEmbeddedDocuments("ActiveEffect", stale);
  if ( changes.length ) {
    await item.createEmbeddedDocuments("ActiveEffect", [{
      name: L("CNV.Builder.OriginChoiceEffect", { name: item.name }), img: item.img, transfer: true, changes,
      flags: { [SYS]: { origin: "choice" } }
    }]);
  }

  // Origin talent (free: flagged system.origin)
  const talentName = picks.talent ?? talentOpts[0];
  if ( talentName && !actor.items.some(i => i.type === "talent" && i.name === talentName) ) {
    const talent = await findCompendiumItem("talents", talentName);
    if ( talent ) {
      const data = talent.toObject();
      data.system.origin = true;
      foundry.utils.setProperty(data, `flags.${SYS}.grantedBy`, item.id);
      await actor.createEmbeddedDocuments("Item", [data]);
    } else ui.notifications.warn(L("CNV.Builder.NoTalent", { name: talentName }));
  }
  await actor.update({ "system.details.origin": item.name });
  ui.notifications.info(L("CNV.Builder.OriginApplied", { name: item.name }));
}

/** Remove talents granted by a deleted origin. */
export async function removeOriginGrants(actor, item) {
  const granted = actor.items.filter(i => i.getFlag(SYS, "grantedBy") === item.id);
  if ( granted.length ) await actor.deleteEmbeddedDocuments("Item", granted.map(i => i.id));
}

export async function findCompendiumItem(packName, name) {
  const pack = game.packs.get(`${SYS}.${packName}`);
  if ( !pack ) return null;
  const idx = (await pack.getIndex()).find(e => e.name === name);
  return idx ? pack.getDocument(idx._id) : null;
}

/* -------------------------------------------- */
/*  Genetics                                     */
/* -------------------------------------------- */

/** Roll 2d8 + 1d4 for the genetic ability modifiers; optionally take the Extreme option; store on the actor. */
export async function rollGeneticModifiers(actor) {
  const C = CONFIG.CNV;
  const roll = await new Roll("2d8").evaluate();
  const r2 = await new Roll("1d4").evaluate();
  const row = C.geneticModifiers[roll.total];
  const [plusA, plusB, minusList] = row;
  const minus = minusList[r2.total - 1];
  const lab = k => L(C.abilities[k].label);
  const content = `<p>${L("CNV.Builder.GeneticRolled", { row: roll.total, d4: r2.total })}</p>
    <ul><li><strong>+1 ${lab(plusA)}</strong></li><li><strong>+1 ${lab(plusB)}</strong></li><li><strong>−1 ${lab(minus)}</strong></li></ul>
    <div class="cnv-form"><label class="checkbox"><input type="checkbox" name="extreme"> ${L("CNV.Builder.Extreme")}</label>
    <div class="form-group"><label>${L("CNV.Builder.ExtremeWhich")}</label><select name="which"><option value="${plusA}">${lab(plusA)}</option><option value="${plusB}">${lab(plusB)}</option></select></div></div>`;
  await roll.toMessage({ speaker: ChatMessage.getSpeaker({ actor }), flavor: L("CNV.Builder.GeneticTitle") });
  const res = await DialogV2.prompt({ window: { title: L("CNV.Builder.GeneticTitle") }, content,
    ok: { label: L("CNV.Builder.Apply"), callback: (e, b) => ({ extreme: b.form.elements.extreme.checked, which: b.form.elements.which.value }) }, rejectClose: false });
  if ( !res ) return;
  const upd = Object.fromEntries(Object.keys(C.abilities).map(k => [`system.abilities.${k}.genetic`, 0]));
  upd[`system.abilities.${plusA}.genetic`] = 1;
  upd[`system.abilities.${plusB}.genetic`] = 1;
  upd[`system.abilities.${minus}.genetic`] = -1;
  if ( res.extreme ) { upd[`system.abilities.${res.which}.genetic`] = 2; upd[`system.abilities.${minus}.genetic`] = -2; }
  await actor.update(upd);
  ChatMessage.create({ speaker: ChatMessage.getSpeaker({ actor }), content: `<div class="cnv-card"><h4>${L("CNV.Builder.GeneticTitle")}</h4><p>+${upd[`system.abilities.${plusA}.genetic`]} ${lab(plusA)}, +${upd[`system.abilities.${plusB}.genetic`]} ${lab(plusB)}, ${upd[`system.abilities.${minus}.genetic`]} ${lab(minus)}</p></div>` });
}

const GENETIC_TABLES = { talent: "Genetic Talents", drawback: "Genetic Drawbacks", cosmetic: "Cosmetic Features" };

/** Roll (or choose) a Genetic Talent / Drawback / Cosmetic and add the matching item. */
export async function addGeneticFromTable(actor, kind, { choose = false } = {}) {
  const text = await drawFromTable(GENETIC_TABLES[kind], { choose, actor });
  if ( !text ) return;
  let name = text.split(" — ")[0].trim();
  if ( kind === "cosmetic" && name === "Horns" ) name = "Horns (Cosmetic)";
  if ( actor.items.some(i => i.type === "genetic" && i.name === name) ) return ui.notifications.warn(L("CNV.Builder.AlreadyHave", { name }));
  const item = await findCompendiumItem("genetics", name);
  if ( !item ) return ui.notifications.warn(L("CNV.Builder.NoItem", { name }));
  await actor.createEmbeddedDocuments("Item", [item.toObject()]);
}

/* -------------------------------------------- */
/*  Personality                                  */
/* -------------------------------------------- */

/** Table used for an origin aspect (quirk / ideal / pledge / flaw) or the specialty. */
export async function aspectTableName(actor, aspect) {
  const origin = originName(actor);
  if ( !origin ) { ui.notifications.warn(L("CNV.Builder.NoOrigin")); return null; }
  if ( aspect !== "specialty" ) return `${origin} — ${aspect.charAt(0).toUpperCase()}${aspect.slice(1)}`;
  const names = (await findTables(`${origin} — `)).filter(n => !/— (Quirk|Ideal|Pledge|Flaw)$/.test(n));
  if ( !names.length ) { ui.notifications.warn(L("CNV.Builder.NoSpecialty", { origin })); return null; }
  return names[0];
}

/** Counts of Virtues and Vices chosen for the four aspects. */
export function pairingCounts(actor) {
  const a = actor.system.details.aspects;
  const kinds = Object.values(a).map(x => x.kind);
  return { virtue: kinds.filter(k => k === "virtue").length, vice: kinds.filter(k => k === "vice").length };
}

/**
 * Roll or choose the Virtue/Vice for an aspect. The pairing type (virtue/vice) is taken from the aspect;
 * if unset, it is forced when the other type already has 2, otherwise the player picks.
 */
export async function drawTrait(actor, aspect, { choose = false } = {}) {
  const a = actor.system.details.aspects;
  let kind = a[aspect].kind;
  if ( !kind ) {
    const c = pairingCounts(actor);
    if ( c.virtue >= 2 ) kind = "vice";
    else if ( c.vice >= 2 ) kind = "virtue";
    else kind = await DialogV2.wait({ window: { title: L("CNV.Builder.PairWith") }, content: `<p>${L("CNV.Builder.PairWithHint")}</p>`,
      buttons: [{ action: "virtue", label: L("CNV.Virtue") }, { action: "vice", label: L("CNV.Vice") }], rejectClose: false });
    if ( !kind ) return;
  }
  let trait;
  if ( choose ) {
    const list = kind === "virtue" ? CONFIG.CNV.virtues : CONFIG.CNV.vices;
    trait = await DialogV2.prompt({ window: { title: L(kind === "virtue" ? "CNV.Virtue" : "CNV.Vice") },
      content: `<div class="cnv-form"><select name="t" size="12" style="width:100%;height:auto">${list.map(v => `<option>${v}</option>`).join("")}</select></div>`,
      ok: { callback: (e, b) => b.form.elements.t.value }, rejectClose: false });
  } else {
    const text = await drawFromTable("Vices & Virtues", { actor });
    const m = text?.match(/Vice:\s*([^·]+)·\s*Virtue:\s*(.+)$/);
    trait = m ? (kind === "vice" ? m[1] : m[2]).trim() : null;
  }
  if ( !trait ) return;
  const upd = { [`system.details.aspects.${aspect}.kind`]: kind, [`system.details.aspects.${aspect}.trait`]: trait };
  // Auto-assign the remaining pairing type once one side reaches 2
  const after = Object.fromEntries(Object.entries(a).map(([k, v]) => [k, k === aspect ? kind : v.kind]));
  const nV = Object.values(after).filter(k => k === "virtue").length, nC = Object.values(after).filter(k => k === "vice").length;
  for ( const [k, v] of Object.entries(after) ) {
    if ( v ) continue;
    if ( nV >= 2 ) upd[`system.details.aspects.${k}.kind`] = "vice";
    else if ( nC >= 2 ) upd[`system.details.aspects.${k}.kind`] = "virtue";
  }
  return actor.update(upd);
}

/* -------------------------------------------- */
/*  Crew training                                */
/* -------------------------------------------- */

/** Training upgrades from every crew this character belongs to: { skillKey: [crewName, ...] } */
export function crewTrainings(actor) {
  const out = {};
  for ( const crew of game.actors.filter(a => a.type === "crew" && a.system.members.includes(actor.uuid)) ) {
    for ( const up of crew.items.filter(i => i.type === "crewUpgrade" && i.system.trainingSkill) ) {
      (out[up.system.trainingSkill] ??= []).push(crew.name);
    }
  }
  return out;
}

/** Spend 2 Strain and roll the trained skill with Fortune (no AP or RP). */
export async function useCrewTraining(actor, skill) {
  const crews = crewTrainings(actor)[skill];
  if ( !crews ) return;
  await actor.spendStrain(2, { reason: L("CNV.Crew.TrainingUse") });
  return actor.rollSkill(skill, { fortune: true, flavor: L("CNV.Crew.TrainingFlavor", { crew: crews.join(", ") }) });
}

/* -------------------------------------------- */
/*  Token art                                    */
/* -------------------------------------------- */

/** Show a token's art in an image popout, for the user who asked. */
export function showTokenArt(token) {
  const doc = token?.document ?? token;
  const src = doc?.texture?.src;
  if ( !src ) return;
  const title = doc.name || doc.actor?.name || "";
  const IP = foundry.applications.apps?.ImagePopout;
  if ( IP ) return new IP({ src, uuid: doc.uuid, window: { title } }).render({ force: true });
  return new ImagePopout(src, { title, uuid: doc.uuid }).render(true);
}

/** Floating "show art" button over the hovered token, usable by anyone who can see the token. */
export function registerTokenArtButton() {
  let btn = null, current = null, hideTimer = null;
  const ensure = () => {
    if ( btn ) return btn;
    btn = document.createElement("a");
    btn.id = "cnv-token-art-btn";
    btn.innerHTML = '<i class="fa-solid fa-image"></i>';
    btn.dataset.tooltip = L("CNV.TokenArt.Show");
    btn.addEventListener("mouseenter", () => clearTimeout(hideTimer));
    btn.addEventListener("mouseleave", () => hide(300));
    btn.addEventListener("click", ev => { ev.preventDefault(); ev.stopPropagation(); if ( current ) showTokenArt(current); hide(0); });
    document.body.appendChild(btn);
    return btn;
  };
  const hide = (delay = 300) => {
    clearTimeout(hideTimer);
    hideTimer = setTimeout(() => { if ( btn ) btn.style.display = "none"; current = null; }, delay);
  };
  Hooks.on("hoverToken", (token, hovered) => {
    if ( !game.settings.get(SYS, "tokenArtButton") ) return;
    if ( !hovered ) return hide(400);
    if ( !token.visible || !token.document.texture?.src ) return;
    clearTimeout(hideTimer);
    current = token;
    const el = ensure();
    const rect = canvas.app.view.getBoundingClientRect();
    const p = canvas.stage.worldTransform.apply({ x: token.x + token.w, y: token.y });
    el.style.left = `${rect.left + p.x - 10}px`;
    el.style.top = `${rect.top + p.y - 10}px`;
    el.style.display = "flex";
  });
  Hooks.on("canvasPan", () => hide(0));
  Hooks.on("canvasTearDown", () => hide(0));
}
