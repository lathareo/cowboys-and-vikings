const SYS = "cowboys-and-vikings";

export function registerSettings() {
  const reg = (key, data) => game.settings.register(SYS, key, { name: `CNV.Setting.${key}.Name`, hint: `CNV.Setting.${key}.Hint`, ...data });

  reg("hpFormula", {
    scope: "world", config: true, type: String, default: "creation",
    choices: { creation: "CNV.Setting.hpFormula.Creation", encounters: "CNV.Setting.hpFormula.Encounters" },
    onChange: () => game.actors?.forEach(a => a.prepareData())
  });
  reg("initiativeMode", {
    scope: "world", config: true, type: String, default: "bump",
    choices: { bump: "CNV.Setting.initiativeMode.Bump", standard: "CNV.Setting.initiativeMode.Standard" }
  });
  reg("partyLevel", {
    scope: "world", config: true, type: Number, default: 1, range: { min: 1, max: 20, step: 1 },
    onChange: () => game.actors?.forEach(a => ["adversary", "hazard"].includes(a.type) && a.prepareData())
  });
  reg("useWounds", { scope: "world", config: true, type: Boolean, default: true });
  reg("turnUpkeep", { scope: "world", config: true, type: Boolean, default: true });
  reg("autoFate", { scope: "world", config: true, type: Boolean, default: true });
  reg("autoChaos", { scope: "world", config: true, type: Boolean, default: true });
  reg("critSuccessSurge", { scope: "world", config: true, type: Boolean, default: true });
  reg("damageReports", {
    scope: "world", config: true, type: String, default: "all",
    choices: { all: "CNV.Setting.damageReports.All", gm: "CNV.Setting.damageReports.GM", none: "CNV.Setting.damageReports.None" }
  });
  reg("deleteEmptyConsumables", { scope: "world", config: true, type: Boolean, default: false });
  reg("skipRollDialog", { scope: "client", config: true, type: Boolean, default: false });
  reg("tokenArtButton", { scope: "client", config: true, type: Boolean, default: true });
  reg("showPoolsHud", { scope: "client", config: true, type: Boolean, default: true, onChange: () => game.cnv?.pools?.render() });

  // Hidden state
  game.settings.register(SYS, "chaosPool", { scope: "world", config: false, type: Number, default: 0, onChange: () => game.cnv?.pools?.render() });
  game.settings.register(SYS, "skillChallenge", { scope: "world", config: false, type: Object, default: {} });
  game.settings.register(SYS, "negotiation", { scope: "world", config: false, type: Object, default: {} });
  game.settings.register(SYS, "systemMigrationVersion", { scope: "world", config: false, type: String, default: "" });
}
