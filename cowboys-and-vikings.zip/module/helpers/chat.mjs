import { asGM } from "./socket.mjs";
import { CNVRoll, performCheck } from "../dice/cnv-roll.mjs";
import { setCondition } from "./conditions.mjs";

const SYS = "cowboys-and-vikings";
const L = (k, d) => d ? game.i18n.format(k, d) : game.i18n.localize(k);

/** Resolve an actor from a token or actor UUID. */
async function actorFrom(uuid) {
  const doc = await fromUuid(uuid);
  return doc?.actor ?? doc;
}

/** Selected tokens' actors, falling back to the user's character. */
function selectedActors() {
  const list = canvas.tokens?.controlled.map(t => t.actor).filter(Boolean) ?? [];
  if ( !list.length && game.user.character ) list.push(game.user.character);
  return list;
}

/**
 * Wire interactive buttons on system chat cards.
 */
export function registerChatListeners() {
  Hooks.on("renderChatMessageHTML", (message, html) => {
    const flags = message.flags?.[SYS] ?? {};
    html.querySelectorAll("[data-cnv-action]").forEach(btn => {
      btn.addEventListener("click", ev => onChatAction(ev, message, flags));
    });

    // Fate reroll button on failed checks by the owner of a PC
    const check = flags.check;
    if ( check && ["failure", "criticalFailure"].includes(check.degree) && check.actorUuid ) {
      const actor = fromUuidSync(check.actorUuid);
      if ( actor?.isOwner && actor.type === "character" && check.config && !flags.rerolled ) {
        const div = document.createElement("div");
        div.className = "cnv-card-buttons";
        div.innerHTML = `<button type="button" data-cnv-action="fateReroll"><i class="fa-solid fa-clover"></i> ${L("CNV.Fate.Reroll", { n: actor.system.fate.value })}</button>`;
        div.querySelector("button").addEventListener("click", ev => onChatAction(ev, message, flags));
        html.querySelector(".message-content")?.append(div);
      }
    }
    // Hide GM-only controls
    if ( !game.user.isGM ) html.querySelectorAll(".gm-only").forEach(e => e.remove());
  });

  // Context menu entries for damage application
  Hooks.on("getChatMessageContextOptions", (app, options) => {
    const canApply = li => {
      const msg = game.messages.get(li.dataset.messageId);
      return msg?.isRoll && canvas.tokens?.controlled.length;
    };
    const apply = (mult) => li => {
      const msg = game.messages.get(li.dataset.messageId);
      const total = msg.rolls[0]?.total ?? 0;
      const dmg = msg.flags?.[SYS]?.damage ?? {};
      for ( const a of selectedActors() ) {
        if ( mult < 0 ) a.applyHealing(total);
        else a.applyDamage(total, { ...dmg, multiplier: mult });
      }
    };
    options.push(
      { name: L("CNV.Chat.ApplyDamage"), icon: '<i class="fa-solid fa-heart-crack"></i>', condition: canApply, callback: apply(1) },
      { name: L("CNV.Chat.ApplyHalf"), icon: '<i class="fa-solid fa-heart-half-stroke"></i>', condition: canApply, callback: apply(0.5) },
      { name: L("CNV.Chat.ApplyDouble"), icon: '<i class="fa-solid fa-heart-pulse"></i>', condition: canApply, callback: apply(2) },
      { name: L("CNV.Chat.ApplyHealing"), icon: '<i class="fa-solid fa-heart"></i>', condition: canApply, callback: apply(-1) }
    );
  });
}

async function onChatAction(event, message, flags) {
  event.preventDefault();
  const btn = event.currentTarget;
  const action = btn.dataset.cnvAction;

  switch ( action ) {
    /* ---------- Defense against an attack ---------- */
    case "parry":
    case "dodge": {
      const card = flags.attackCard;
      const target = await actorFrom(btn.dataset.target);
      if ( !target ) return;
      if ( !target.isOwner ) return ui.notifications.warn(L("CNV.Chat.NotOwner"));
      const attacker = await actorFrom(card.actorUuid);
      const res = await target.rollDefense(action, card.attackTotal, card.attackNatural, { melee: card.melee, attackerName: attacker?.name ?? "" });
      if ( !res ) return;
      return postDefenseOutcome(res.outcome, target, card, action);
    }
    case "takeHit": {
      const card = flags.attackCard;
      const target = await actorFrom(btn.dataset.target);
      if ( !target?.isOwner && !game.user.isGM ) return;
      return postDefenseOutcome(card.attackNatural === 20 ? "critHit" : "hit", target, card, null);
    }
    case "rollDamage": {
      const card = flags.defense ?? flags.attackCard;
      const attacker = await actorFrom(card.actorUuid);
      const item = await fromUuid(card.itemUuid);
      if ( !attacker || !item ) return;
      if ( !attacker.isOwner ) return ui.notifications.warn(L("CNV.Chat.NotOwner"));
      const crit = btn.dataset.crit === "true";
      const brutal = item.system.traits?.includes("brutal") ? await foundry.applications.api.DialogV2.confirm({
        window: { title: L("CNV.WTrait.brutal") }, content: `<p>${L("CNV.Attack.BrutalPrompt")}</p>`, rejectClose: false }) : false;
      if ( item.type === "maneuver" || (item.type !== "weapon" && item.type !== "shield") ) {
        const dice = item.system.damage?.dice ?? attacker.system.damage;
        return attacker.postDamage(crit ? `(${dice}) * 2` : dice, { type: item.system.damage?.type ?? "untyped", crit, flavor: item.name, targetUuid: btn.dataset.target });
      }
      if ( item.type === "shield" ) {
        const formula = `${item.system.bash.dice} + ${attacker.system.abilities?.might?.value ?? 0}`;
        return attacker.postDamage(crit ? `(${formula}) * 2` : formula, { type: "bludgeoning", crit, flavor: `${item.name} (${L("CNV.Shield.Bash")})`, targetUuid: btn.dataset.target });
      }
      return attacker.rollWeaponDamage(item, { crit, twoHanded: card.twoHanded, doubleBarrel: card.doubleBarrel, brutal, targetUuid: btn.dataset.target });
    }
    /* ---------- Damage application ---------- */
    case "applyDamage": {
      const dmg = flags.damage;
      const mult = Number(btn.dataset.mult ?? 1);
      let actors = selectedActors();
      if ( !actors.length && dmg.targetUuid ) actors = [await actorFrom(dmg.targetUuid)].filter(Boolean);
      if ( !actors.length ) return ui.notifications.warn(L("CNV.Chat.SelectToken"));
      for ( const a of actors ) {
        const opts = { type: dmg.type, ap: dmg.ap, heavy: dmg.heavy, crit: dmg.crit, multiplier: mult };
        if ( a.isOwner ) await a.applyDamage(dmg.total, opts);
        else await asGM("applyDamage", { actorUuid: a.uuid, amount: dmg.total, opts });
      }
      return;
    }
    case "applyHealing": {
      const total = message.rolls[0]?.total ?? Number(btn.dataset.amount) ?? 0;
      for ( const a of selectedActors() ) await a.applyHealing(total);
      return;
    }
    /* ---------- Fate ---------- */
    case "fateReroll": {
      const check = flags.check;
      const actor = await actorFrom(check.actorUuid);
      if ( !actor || !(await actor.spendFate()) ) return;
      await message.setFlag(SYS, "rerolled", true);
      return performCheck({ ...check.config, actor, dc: check.dc, skipDialog: true,
        title: `${check.config.title ?? ""} (${L("CNV.Fate.Rerolled")})` });
    }
    /* ---------- Spell saves ---------- */
    case "spellSave": {
      const sc = flags.spellCard;
      const actors = selectedActors();
      for ( const a of actors ) {
        await a.rollSave(sc.saveAbility, { dc: sc.total, title: L("CNV.Spell.SaveVs", { spell: btn.dataset.spell, total: sc.total }) });
      }
      return;
    }
    case "spellDamage": {
      const sc = flags.spellCard;
      const actor = await actorFrom(sc.actorUuid);
      if ( !actor?.isOwner ) return;
      const crit = btn.dataset.crit === "true";
      return actor.postDamage(crit ? `(${sc.damage}) * 2` : sc.damage, { type: sc.damageType || "untyped", flavor: btn.dataset.spell });
    }
    /* ---------- Upkeep ---------- */
    case "recover": {
      const actor = await actorFrom(flags.upkeep.actorUuid);
      const effect = actor?.effects.get(btn.dataset.effect);
      if ( !actor?.isOwner || !effect ) return;
      if ( effect.statuses.has("persistentDamage") ) {
        const f = effect.getFlag(SYS, "formula") || "1d4";
        const type = effect.getFlag(SYS, "damageType") || "untyped";
        const roll = await new Roll(f).evaluate();
        await roll.toMessage({ speaker: ChatMessage.getSpeaker({ actor }), flavor: L("CNV.Upkeep.Persistent", { type }) });
        await actor.applyDamage(roll.total, { type, ignoreSoak: true });
      }
      const res = await actor.rollFlat(15, L("CNV.Upkeep.Recovery", { name: effect.name }));
      if ( res && ["success", "criticalSuccess"].includes(res.degree) ) {
        const valued = effect.getFlag(SYS, "value");
        const id = [...effect.statuses][0];
        if ( valued && valued > 1 ) await setCondition(actor, id, valued - 1);
        else await effect.delete();
      }
      return;
    }
    /* ---------- Generic ---------- */
    case "rollSave": {
      const ability = btn.dataset.ability;
      const dc = Number(btn.dataset.dc) || null;
      for ( const a of selectedActors() ) await a.rollSave(ability, { dc });
      return;
    }
    case "rollSkill": {
      const skill = btn.dataset.skill;
      const dc = Number(btn.dataset.dc) || null;
      for ( const a of selectedActors() ) await a.rollSkill(skill, { dc });
      return;
    }
  }
}

/** Post the outcome of a Parry/Dodge with the right follow-up buttons. */
async function postDefenseOutcome(outcome, target, card, mode) {
  const texts = {
    critDefense: L(mode === "parry" ? "CNV.Defense.CritParry" : "CNV.Defense.CritDodge", { name: target.name }),
    defended: L("CNV.Defense.Defended", { name: target.name }),
    hit: L("CNV.Defense.Hit", { name: target.name }),
    critHit: L("CNV.Defense.CritHit", { name: target.name })
  };
  const hit = outcome === "hit" || outcome === "critHit";
  const tokenUuid = target.token?.uuid ?? target.getActiveTokens()[0]?.document.uuid ?? target.uuid;
  const content = `<div class="cnv-card cnv-defense ${outcome}"><p class="cnv-outcome">${texts[outcome]}</p>
    ${hit ? `<div class="cnv-card-buttons"><button type="button" data-cnv-action="rollDamage" data-crit="${outcome === "critHit"}" data-target="${tokenUuid}">
      <i class="fa-solid fa-burst"></i> ${L(outcome === "critHit" ? "CNV.Chat.RollCritDamage" : "CNV.Chat.RollDamage")}</button></div>` : ""}</div>`;
  return ChatMessage.create({ speaker: ChatMessage.getSpeaker({ actor: target }), content,
    flags: { [SYS]: { defense: { ...card, outcome } } } });
}
