const SYS = "cowboys-and-vikings";
const L = (k, d) => d ? game.i18n.format(k, d) : game.i18n.localize(k);

/**
 * Combat with optional "bump" initiative: after a combatant's turn, the initiative passes to the
 * creature it attacked (or to anyone who still has AP if it didn't attack). Combatants that have
 * acted this round are flagged; the round ends when everyone has acted.
 */
export class CNVCombat extends Combat {

  get bumpMode() { return game.settings.get(SYS, "initiativeMode") === "bump"; }

  /** Combatants who have not yet acted this round. */
  get waiting() {
    return this.combatants.filter(c => !c.defeated && !c.getFlag(SYS, "acted"));
  }

  async startCombat() {
    await this._resetActed();
    await this._refreshEconomy();
    return super.startCombat();
  }

  async nextRound() {
    await this._resetActed();
    await this._refreshEconomy();
    if ( this.bumpMode ) {
      // The last creature attacked opens the next round (or the last actor's choice).
      const last = this.getFlag(SYS, "lastTarget");
      const r = await super.nextRound();
      const idx = last ? this.turns.findIndex(t => t.id === last) : -1;
      if ( idx >= 0 ) await this.update({ turn: idx });
      return r;
    }
    return super.nextRound();
  }

  async nextTurn() {
    const current = this.combatant;
    if ( current ) await current.setFlag(SYS, "acted", true);
    await this._onTurnEnd(current);
    if ( !this.bumpMode ) return super.nextTurn();

    const waiting = this.waiting.filter(c => c.id !== current?.id);
    if ( !waiting.length ) return this.nextRound();
    const lastTarget = this.getFlag(SYS, "lastTarget");
    const targetCombatant = waiting.find(c => c.id === lastTarget);
    let nextId = targetCombatant?.id;
    if ( !nextId ) nextId = await this._chooseBump(waiting);
    if ( !nextId ) return;
    await this.unsetFlag(SYS, "lastTarget");
    const idx = this.turns.findIndex(t => t.id === nextId);
    return this.update({ turn: idx }, { direction: 1 });
  }

  /** Let the GM (or current owner) pick who gets the initiative next. */
  async _chooseBump(waiting) {
    if ( waiting.length === 1 ) return waiting[0].id;
    const buttons = waiting.map(c => ({ action: c.id, label: c.name, icon: c.hasPlayerOwner ? "fa-solid fa-user" : "fa-solid fa-skull" }));
    return foundry.applications.api.DialogV2.wait({
      window: { title: L("CNV.Combat.BumpTitle") },
      content: `<p>${L("CNV.Combat.BumpHint")}</p>`,
      buttons, rejectClose: false
    });
  }

  async _resetActed() {
    const updates = this.combatants.map(c => ({ _id: c.id, [`flags.${SYS}.acted`]: false }));
    if ( updates.length ) await this.updateEmbeddedDocuments("Combatant", updates);
  }

  /** Reset AP/RP on each combatant at the start of a round. */
  async _refreshEconomy() {
    const updates = this.combatants.map(c => {
      const a = c.actor;
      let ap = 2, rp = 2;
      if ( a?.type === "adversary" ) { ap = a.system.actions.ap; rp = a.system.actions.rp; }
      if ( a?.statuses?.has("staggered") ) ap = Math.max(0, ap - 1);
      return { _id: c.id, [`flags.${SYS}.ap`]: ap, [`flags.${SYS}.rp`]: rp, [`flags.${SYS}.apMax`]: ap, [`flags.${SYS}.rpMax`]: rp };
    });
    if ( updates.length ) await this.updateEmbeddedDocuments("Combatant", updates);
  }

  /** End-of-turn upkeep reminder: persistent damage and lingering recovery. */
  async _onTurnEnd(combatant) {
    const actor = combatant?.actor;
    if ( !actor || !game.settings.get(SYS, "turnUpkeep") ) return;
    const lingering = actor.effects.filter(e => [...e.statuses].some(s => CONFIG.CNV.conditions[s]?.lingering));
    if ( !lingering.length ) return;
    const content = await foundry.applications.handlebars.renderTemplate(`systems/${SYS}/templates/chat/upkeep-card.hbs`, {
      actor, effects: lingering.map(e => ({ id: e.id, name: e.name, img: e.img, persistent: e.statuses.has("persistentDamage"),
        formula: e.getFlag(SYS, "formula") ?? "", damageType: e.getFlag(SYS, "damageType") ?? "" }))
    });
    return ChatMessage.create({ speaker: ChatMessage.getSpeaker({ actor }), content, whisper: game.users.filter(u => actor.testUserPermission(u, "OWNER")).map(u => u.id),
      flags: { [SYS]: { upkeep: { actorUuid: actor.uuid } } } });
  }

  /** Called when a turn begins: dying roll, recharge reminders. */
  async _onStartTurn(combatant, context) {
    await super._onStartTurn?.(combatant, context);
    const actor = combatant?.actor;
    if ( !actor || !game.user.isActiveGM ) return;
    if ( actor.type === "character" && actor.system.dying ) await actor.rollDying();
  }
}

/** Initiative uses Reflex (or the chosen ability) plus bonuses. */
export class CNVCombatant extends Combatant {
  _getInitiativeFormula() {
    const mod = this.actor?.system?.initiative?.mod ?? 0;
    return `1d20 + ${mod}`;
  }
}
