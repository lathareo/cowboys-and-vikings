import { performCheck } from "../dice/cnv-roll.mjs";
import { setCondition } from "../helpers/conditions.mjs";

const SYS = "cowboys-and-vikings";
const L = (k, d) => d ? game.i18n.format(k, d) : game.i18n.localize(k);

export class CNVItem extends Item {

  get isPhysical() { return !!this.system.isPhysical; }

  /** Chat description card for any item. */
  async toChat() {
    const content = await foundry.applications.handlebars.renderTemplate(`systems/${SYS}/templates/chat/item-card.hbs`, {
      item: this, system: this.system, labels: this.chatLabels(),
      description: await foundry.applications.ux.TextEditor.implementation.enrichHTML(this.system.description ?? "", { relativeTo: this, secrets: this.isOwner })
    });
    return ChatMessage.create({ speaker: ChatMessage.getSpeaker({ actor: this.actor }), content, flags: { [SYS]: { itemUuid: this.uuid } } });
  }

  /** Short property labels for cards and sheets. */
  chatLabels() {
    const s = this.system; const C = CONFIG.CNV; const out = [];
    switch ( this.type ) {
      case "weapon":
        out.push(`${s.damage.dice} ${L(C.damageTypes[s.damage.type]?.label ?? s.damage.type)}`);
        if ( s.hands ) out.push(`${L("CNV.Hands")}: ${s.hands}`);
        out.push(...(s.traitLabels ?? []));
        break;
      case "armor":
        out.push(`${L("CNV.Soak")} ${s.soak}`, L(C.armorCategories[s.category] ?? s.category));
        if ( s.penalty ) out.push(`${L("CNV.CheckPenalty")} ${s.penalty}`);
        break;
      case "shield":
        out.push(`+${s.bonus} ${L("CNV.Shield.Bonus")}`, `${L("CNV.Hardness")} ${s.hardness}`, `${L("CNV.Shield.Bash")} ${s.bash.dice}`);
        break;
      case "spell":
        out.push(L(C.spellSchools[s.school] ?? s.school), `${L("CNV.Spell.Complexity")} ${s.complexity}`, `${L("CNV.Strain.Label")} ${s.strain}`);
        if ( s.cantrip ) out.push(L("CNV.Spell.Cantrip"));
        if ( s.duration ) out.push(`${L("CNV.Duration")}: ${s.duration}`);
        if ( s.save?.ability ) out.push(`${L("CNV.Save")}: ${L(C.abilities[s.save.ability]?.label ?? s.save.ability)}`);
        break;
      case "talent": case "technique": case "maneuver":
        if ( s.cost ) out.push(L(C.actionCosts[s.cost] ?? s.cost));
        out.push(...(s.actionTraits ?? []).map(t => t.toUpperCase()));
        if ( s.strain ) out.push(`${s.strain} ${L("CNV.Strain.Label")}`);
        break;
    }
    return out;
  }

  /* -------------------------------------------- */
  /*  Use                                          */
  /* -------------------------------------------- */

  /**
   * Primary use of the item from a sheet.
   */
  async use({ event } = {}) {
    const actor = this.actor;
    switch ( this.type ) {
      case "weapon": return actor ? this.attack({ event }) : this.toChat();
      case "spell": return actor ? this.cast({ event }) : this.toChat();
      case "shield": return actor ? this.bash({ event }) : this.toChat();
      case "concoction": case "gear": return this.consume({ event });
      case "maneuver": return this.useManeuver({ event });
      case "affliction": return this.expose();
      default: return this.activate({ event });
    }
  }

  async attack({ event, twoHanded, doubleBarrel } = {}) {
    const s = this.system;
    let opts = { event, twoHanded: twoHanded ?? s.twoHanded, doubleBarrel };
    if ( !event?.shiftKey && (s.damage.versatile || s.damage.doubleBarrel || s.range) ) {
      const choice = await this._attackOptions();
      if ( !choice ) return;
      opts = { ...opts, ...choice };
    }
    return this.actor.rollAttack(this, opts);
  }

  async _attackOptions() {
    const s = this.system;
    const content = `
      <div class="cnv-form">
        ${s.damage.versatile ? `<label class="checkbox"><input type="checkbox" name="twoHanded" ${s.twoHanded ? "checked" : ""}> ${L("CNV.Attack.TwoHanded", { dice: s.damage.versatile })}</label>` : ""}
        ${s.damage.doubleBarrel ? `<label class="checkbox"><input type="checkbox" name="doubleBarrel"> ${L("CNV.Attack.DoubleBarrel", { dice: s.damage.doubleBarrel })}</label>` : ""}
        ${s.range ? `<div class="form-group"><label>${L("CNV.Attack.RangeIncrements", { range: s.range })}</label><input type="number" name="rangeIncrements" value="0" min="0" max="5"></div>` : ""}
      </div>`;
    const r = await foundry.applications.api.DialogV2.prompt({
      window: { title: L("CNV.Roll.Attack", { weapon: this.name }) }, content,
      ok: { label: L("CNV.Roll.Roll"), callback: (e, b) => new foundry.applications.ux.FormDataExtended(b.form).object },
      rejectClose: false
    });
    if ( !r ) return null;
    return { twoHanded: !!r.twoHanded, doubleBarrel: !!r.doubleBarrel, rangeIncrements: Number(r.rangeIncrements) || 0 };
  }

  /** Shield bash uses the Shields skill. */
  async bash({ event } = {}) {
    const s = this.system;
    const pseudo = {
      name: `${this.name} (${L("CNV.Shield.Bash")})`, uuid: this.uuid, type: "shield",
      system: {
        isRanged: false, skill: "shields", altSkill: "", category: "melee", traits: ["shove"], traitValues: {},
        requirement: s.requirement, attackBonus: 0, damage: s.bash, usesAmmo: false, ammo: {}
      }
    };
    return this.actor.rollAttack(pseudo, { event });
  }

  /** Talents, techniques and bonds: spend costs, post card, roll if configured. */
  async activate({ event, push = false } = {}) {
    const actor = this.actor;
    const s = this.system;
    if ( !actor ) return this.toChat();
    // Uses
    if ( s.uses?.max ) {
      if ( s.uses.value < 1 ) return ui.notifications.warn(L("CNV.UseItem.NoUses", { item: this.name }));
      await this.update({ "system.uses.value": s.uses.value - 1 });
    }
    // Strain: listed cost, Push, and Chest Trauma
    let strain = (s.strain ?? 0) + (push ? 1 : 0);
    if ( actor.chestTrauma && s.cost && !["passive", "free"].includes(s.cost) ) strain += actor.chestTrauma;
    if ( strain ) await actor.spendStrain(strain, { reason: this.name });
    if ( s.sup ) await actor.update({ "system.sup.value": Math.max(0, actor.system.sup.value - s.sup) });

    await this.toChat();
    const r = s.roll;
    if ( r?.type === "check" && r.skill ) return actor.rollSkill(r.skill, { event, parts: undefined });
    if ( r?.type === "save" && r.ability ) return actor.rollSave(r.ability, { event });
    if ( r?.type === "damage" && r.damage ) return actor.postDamage(r.damage, { type: r.damageType || "untyped", flavor: this.name });
  }

  /** Adversary maneuver: optionally roll an attack using the adversary's check bonus. */
  async useManeuver({ event } = {}) {
    const actor = this.actor;
    const s = this.system;
    if ( !actor ) return this.toChat();
    if ( s.recharge?.enabled && !s.recharge.charged ) return ui.notifications.warn(L("CNV.Recharge.Discharged", { item: this.name }));
    if ( s.recharge?.enabled ) await this.update({ "system.recharge.charged": false });
    await this.toChat();
    if ( s.roll?.type === "attack" && actor.type === "adversary" ) {
      const quality = s.roll.damage || "average";
      const L2 = Math.max(1, actor.system.level);
      const pseudo = {
        name: this.name, uuid: this.uuid, type: "maneuver",
        system: {
          isRanged: !!s.roll.range, skill: "", category: "natural", traits: [], traitValues: {}, requirement: {},
          attackBonus: 0, usesAmmo: false, ammo: {},
          damage: { dice: CONFIG.CNV.track("damage", L2, ["weak", "average", "strong"].includes(quality) ? quality : "average"), type: s.roll.damageType || "bludgeoning" }
        }
      };
      return actor.rollAttack(pseudo, { event });
    }
  }

  /** Consumables: reduce quantity, roll listed effect. */
  async consume({ event } = {}) {
    const s = this.system;
    await this.toChat();
    if ( !this.actor ) return;
    if ( s.roll?.damage ) {
      const heal = s.roll.type === "heal" || /heal/i.test(s.roll.damageType ?? "");
      if ( heal ) {
        const roll = await new Roll(s.roll.damage, this.actor.getRollData()).evaluate();
        await roll.toMessage({ speaker: ChatMessage.getSpeaker({ actor: this.actor }), flavor: L("CNV.UseItem.Healing", { item: this.name }) });
      } else await this.actor.postDamage(s.roll.damage, { type: s.roll.damageType || "untyped", flavor: this.name });
    }
    if ( ["concoction"].includes(this.type) || s.category === "consumable" || s.category === "ammunition" ) {
      const q = Math.max(0, (s.quantity ?? 1) - 1);
      if ( q === 0 && game.settings.get(SYS, "deleteEmptyConsumables") ) return this.delete();
      return this.update({ "system.quantity": q });
    }
  }

  /** Expose the targeted tokens (or self) to an affliction: prompts a save. */
  async expose() {
    await this.toChat();
  }

  /* -------------------------------------------- */
  /*  Spellcasting                                 */
  /* -------------------------------------------- */

  /** Compute the Strain cost for a casting configuration. */
  static spellCost(spell, cfg) {
    const s = spell.system;
    const C = CONFIG.CNV;
    const lines = [];
    let total = s.strain;
    lines.push([L("CNV.Spell.Base"), s.strain]);
    const del = C.deliveries[cfg.delivery];
    if ( del ) {
      let cost = del.cost + (del.scaling ? (cfg.scale ?? 0) * del.scaling : 0);
      if ( del.aoe && s.aoeRestricted ) cost *= 2;
      total += cost;
      lines.push([`${L(del.label)}${cfg.scale ? ` +${cfg.scale}` : ""}`, cost]);
    }
    // Components
    const comps = cfg.components ?? [];
    let comp = 0;
    const v = comps.includes("verbal"), so = comps.includes("somatic"), m = comps.includes("material");
    const n = [v, so, m].filter(Boolean).length;
    if ( n === 0 ) comp = 1;
    else if ( n === 3 ) comp = -2;
    else if ( v && so && !m ) comp = -1;
    else if ( m && n === 1 ) comp = -1;
    else if ( m ) comp = -1;
    else comp = 0;
    if ( comp ) { total += comp; lines.push([L("CNV.Spell.Components"), comp]); }
    if ( cfg.selfOnly ) { total -= 1; lines.push([L("CNV.Spell.SelfTrapping"), -1]); }
    // Modifiers
    for ( const mod of cfg.modifiers ?? [] ) { total += mod.strain * (mod.times ?? 1); lines.push([mod.name + (mod.times > 1 ? ` ×${mod.times}` : ""), mod.strain * (mod.times ?? 1)]); }
    for ( const mm of cfg.metamagic ?? [] ) { total += mm.strain; lines.push([mm.name, mm.strain]); }
    const min = s.cantrip ? 0 : 1;
    total = Math.max(min, total);
    if ( s.cantrip && cfg.push ) { lines.push([L("CNV.Push"), 1]); }
    return { total, lines, dc: 10 + total, strainTaken: total + (s.cantrip && cfg.push ? 1 : 0) };
  }

  async cast({ event } = {}) {
    const actor = this.actor;
    const s = this.system;
    const ranks = actor.system.skills?.mysticism?.ranks ?? 0;
    const metamagic = actor.items.filter(i => i.type === "metamagic");
    const context = {
      spell: this, system: s, ranks,
      deliveries: Object.entries(CONFIG.CNV.deliveries)
        .filter(([k]) => !s.deliveries?.length || s.deliveries.includes(k))
        .map(([k, v]) => ({ key: k, label: L(v.label), cost: v.cost, scaling: v.scaling, scaleLabel: v.scaleLabel ? L(v.scaleLabel) : "", hint: L(v.hint), aoe: v.aoe })),
      modifiers: s.modifiers.map((m, i) => ({ ...m, index: i, locked: (m.minRanks && ranks < m.minRanks) })),
      metamagic: metamagic.map(m => ({ id: m.id, name: m.name, strain: m.system.strain, minRanks: m.system.minRanks, locked: ranks < m.system.minRanks })),
      components: [{ key: "verbal", label: L("CNV.Spell.Verbal") }, { key: "somatic", label: L("CNV.Spell.Somatic") }, { key: "material", label: L("CNV.Spell.Material") }]
    };
    const content = await foundry.applications.handlebars.renderTemplate(`systems/${SYS}/templates/dialog/cast-dialog.hbs`, context);
    const read = (form) => {
      const fd = new foundry.applications.ux.FormDataExtended(form).object;
      const mods = s.modifiers.map((m, i) => ({ ...m, times: Number(fd[`mod-${i}`]) || (fd[`mod-${i}`] === true ? 1 : 0) })).filter(m => m.times > 0);
      const mms = metamagic.filter(m => fd[`mm-${m.id}`]).map(m => ({ name: m.name, strain: m.system.strain }));
      return {
        delivery: fd.delivery, scale: Number(fd.scale) || 0, components: ["verbal", "somatic", "material"].filter(k => fd[`comp-${k}`]),
        selfOnly: !!fd.selfOnly, modifiers: mods, metamagic: mms, push: !!fd.push
      };
    };
    const result = await foundry.applications.api.DialogV2.wait({
      window: { title: L("CNV.Spell.CastTitle", { spell: this.name }), icon: "fa-solid fa-hand-sparkles" },
      classes: ["cnv", "cnv-cast-dialog"], position: { width: 480 }, content,
      buttons: [{ action: "cast", label: L("CNV.Spell.Cast"), icon: "fa-solid fa-wand-sparkles", default: true, callback: (e, b) => read(b.form) },
        { action: "cancel", label: L("Cancel") }],
      render: (ev, dialog) => {
        const form = dialog.element.querySelector("form");
        const update = () => {
          const cfg = read(form);
          const cost = CNVItem.spellCost(this, cfg);
          dialog.element.querySelector("[data-total]").textContent = cost.total;
          dialog.element.querySelector("[data-dc]").textContent = cost.dc;
          dialog.element.querySelector("[data-breakdown]").innerHTML = cost.lines.map(([l, v]) => `<li>${l}: ${v >= 0 ? "+" : ""}${v}</li>`).join("");
          const sev = CONFIG.CNV.bandMax(CONFIG.CNV.surgeSeverity, cost.total);
          dialog.element.querySelector("[data-severity]").textContent = L(sev.label);
          const warn = dialog.element.querySelector("[data-warn]");
          const overRanks = !s.cantrip && ranks < (s.complexity + cfg.modifiers.reduce((t, m) => t + m.strain * m.times, 0));
          warn.hidden = !overRanks;
        };
        form.addEventListener("change", update);
        form.addEventListener("input", update);
        update();
      },
      rejectClose: false
    });
    if ( !result || result === "cancel" ) return;
    return this._resolveCast(result, event);
  }

  async _resolveCast(cfg, event) {
    const actor = this.actor;
    const s = this.system;
    const cost = CNVItem.spellCost(this, cfg);
    const skill = actor.system.spellcasting?.skill || "mysticism";
    const ability = actor.system.spellcasting?.ability || actor.system.skills?.[skill]?.abilityKey;
    // Stupefied: flat check 5 + X or disrupted
    const stup = actor.effects.find(e => e.statuses.has("stupefied"));
    if ( stup ) {
      const x = stup.getFlag(SYS, "value") ?? 1;
      const flat = await actor.rollFlat(5 + x, L("CNV.Spell.StupefiedCheck"));
      if ( flat && ["failure", "criticalFailure"].includes(flat.degree) ) {
        await actor.spendStrain(cost.strainTaken, { reason: this.name });
        return ChatMessage.create({ speaker: ChatMessage.getSpeaker({ actor }), content: `<div class="cnv-card"><p>${L("CNV.Spell.Disrupted", { spell: this.name })}</p></div>` });
      }
    }
    const summary = `<ul class="cnv-cost">${cost.lines.map(([l, v]) => `<li>${l}: ${v >= 0 ? "+" : ""}${v}</li>`).join("")}</ul>`;
    const res = await actor.rollSkill(skill, {
      ability, dc: cost.dc, kind: "channeling", event,
      title: L("CNV.Spell.Channeling", { spell: this.name, dc: cost.dc }),
      notes: [L("CNV.Spell.TotalStrain", { n: cost.total })],
      flags: { cast: { spellUuid: this.uuid, total: cost.total, cfg } }
    });
    if ( !res ) return;
    await actor.spendStrain(cost.strainTaken, { reason: this.name });
    const degree = res.degree;
    const severity = CONFIG.CNV.bandMax(CONFIG.CNV.surgeSeverity, cost.total);
    // Spell effect card
    const content = await foundry.applications.handlebars.renderTemplate(`systems/${SYS}/templates/chat/spell-card.hbs`, {
      spell: this, system: s, total: res.roll.total, degree, degreeLabel: L(CONFIG.CNV.degrees[degree]),
      summary, severityLabel: L(severity.label), cost,
      failed: degree === "criticalFailure",
      critText: degree === "criticalSuccess" ? await foundry.applications.ux.TextEditor.implementation.enrichHTML(s.critSuccess ?? "") : "",
      description: await foundry.applications.ux.TextEditor.implementation.enrichHTML(s.description ?? "", { relativeTo: this }),
      hasSave: !!s.save?.ability, saveLabel: s.save?.ability ? L(CONFIG.CNV.abilities[s.save.ability]?.label ?? s.save.ability) : "",
      damage: s.damage?.formula, targets: [...game.user.targets].map(t => ({ uuid: t.document.uuid, name: t.name }))
    });
    await ChatMessage.create({ speaker: ChatMessage.getSpeaker({ actor }), content,
      flags: { [SYS]: { spellCard: { spellUuid: this.uuid, actorUuid: actor.uuid, total: res.roll.total, degree, saveAbility: s.save?.ability ?? null, damage: s.damage?.formula ?? "", damageType: s.damage?.type ?? "" } } } });
    // Wild surge
    if ( degree === "failure" ) return rollWildSurge(s.school, severity.key, "1d30", { actor });
    if ( degree === "criticalFailure" ) return rollWildSurge(s.school, severity.key, "2d8", { actor, side: "negative" });
    if ( degree === "criticalSuccess" && game.settings.get(SYS, "critSuccessSurge") ) return rollWildSurge(s.school, severity.key, "2d8", { actor, side: "positive" });
  }
}

/**
 * Roll on a school's Wild Surge table from the compendium (or world).
 * Table naming: "Wild Surge — <School>". On 2d8 rolls, the side picks odd (negative) or even (positive) entries.
 */
export async function rollWildSurge(school, severity, formula = "1d30", { actor, side } = {}) {
  const name = `Wild Surge — ${school.charAt(0).toUpperCase()}${school.slice(1)}`;
  let table = game.tables.getName(name);
  if ( !table ) {
    const pack = game.packs.get(`${SYS}.tables`);
    const idx = pack ? (await pack.getIndex()).find(e => e.name === name) : null;
    if ( idx ) table = await pack.getDocument(idx._id);
  }
  const roll = await new Roll(formula).evaluate();
  let n = roll.total;
  // 2d8 (2-16) indexes a row of the two-column table: row r -> negative entry 2r-3, positive entry 2r-2
  if ( side ) n = side === "negative" ? (2 * n) - 3 : (2 * n) - 2;
  n = Math.clamp(n, 1, 30);
  const result = table?.results.find(r => n >= r.range[0] && n <= r.range[1]);
  const kind = n % 2 ? L("CNV.Surge.Negative") : L("CNV.Surge.Positive");
  const text = result ? (result.description || result.text || result.name) : L("CNV.Surge.NoTable", { name });
  const content = `<div class="cnv-card cnv-surge ${n % 2 ? "negative" : "positive"}"><h4><i class="fa-solid fa-burst"></i> ${L("CNV.Surge.Title")} — ${school} (${L(`CNV.Surge.${severity}`)})</h4>
    <p class="cnv-surge-roll">${formula}${side ? ` → ${L("CNV.Surge.Row")} ${roll.total}` : ""} = <strong>${n}</strong> · ${kind}</p><div class="cnv-surge-text">${text}</div>
    <p class="hint">${L("CNV.Surge.SeverityHint", { severity: L(`CNV.Surge.${severity}`) })}${side === "positive" ? ` ${L("CNV.Surge.MayIgnore")}` : ""}</p></div>`;
  return roll.toMessage({ speaker: ChatMessage.getSpeaker({ actor }), content, flavor: L("CNV.Surge.Title") });
}
