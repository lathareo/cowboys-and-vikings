import { performCheck, flatCheck, CNVRoll } from "../dice/cnv-roll.mjs";
import { conditionAdjustments, targetAdjustments, setCondition } from "../helpers/conditions.mjs";
import { asGM } from "../helpers/socket.mjs";

const SYS = "cowboys-and-vikings";
const L = (k, d) => d ? game.i18n.format(k, d) : game.i18n.localize(k);

export class CNVActor extends Actor {

  /* -------------------------------------------- */
  /*  Data                                         */
  /* -------------------------------------------- */

  /** @override */
  getRollData() {
    const data = { ...super.getRollData() };
    const s = this.system;
    if ( s.abilities ) {
      for ( const [k, v] of Object.entries(s.abilities) ) data[k] = v.value;
      data.abil = Object.fromEntries(Object.entries(s.abilities).map(([k, v]) => [k, v.value]));
    }
    if ( s.skills && !Array.isArray(s.skills) ) {
      data.skill = Object.fromEntries(Object.entries(s.skills).map(([k, v]) => [k, v.mod]));
      data.ranks = Object.fromEntries(Object.entries(s.skills).map(([k, v]) => [k, v.ranks]));
    }
    data.lvl = s.level ?? 0;
    data.halfLevel = Math.floor((s.level ?? 0) / 2);
    return data;
  }

  get isPC() { return this.type === "character"; }

  /** Assign token defaults for new actors. */
  async _preCreate(data, options, user) {
    if ( (await super._preCreate(data, options, user)) === false ) return false;
    const proto = {};
    if ( this.type === "character" ) Object.assign(proto, { actorLink: true, disposition: CONST.TOKEN_DISPOSITIONS.FRIENDLY, sight: { enabled: true } });
    else if ( this.type === "crew" ) Object.assign(proto, { actorLink: true });
    else Object.assign(proto, { disposition: CONST.TOKEN_DISPOSITIONS.HOSTILE });
    proto.bar1 = { attribute: "hp" };
    proto.bar2 = { attribute: this.type === "hazard" ? null : "strain" };
    this.updateSource({ prototypeToken: proto });
  }

  /** Keep the Bloodied / Dying statuses in sync with HP. */
  async _onUpdate(changed, options, userId) {
    super._onUpdate(changed, options, userId);
    if ( game.user.id !== userId ) return;
    if ( foundry.utils.hasProperty(changed, "system.hp.value") && this.system.hp ) {
      const bloodied = this.system.hp.value <= this.system.hp.heavyThreshold && this.system.hp.value > 0;
      if ( bloodied !== this.statuses.has("bloodied") ) await this.toggleStatusEffect("bloodied", { active: bloodied });
    }
  }

  /* -------------------------------------------- */
  /*  Checks                                       */
  /* -------------------------------------------- */

  _checkParts(ability, extra = []) {
    const a = this.system.abilities?.[ability];
    const parts = [];
    if ( a ) parts.push({ label: L(CONFIG.CNV.abilities[ability].label), value: a.value });
    return parts.concat(extra);
  }

  _applyConditions(cfg) {
    const adj = conditionAdjustments(this, cfg);
    cfg.adv = (cfg.adv ?? 0) + adj.adv;
    cfg.dis = (cfg.dis ?? 0) + adj.dis;
    if ( adj.penalty ) cfg.parts.push({ label: L("CNV.Conditions"), value: -adj.penalty });
    if ( adj.autoFail ) cfg.autoFail = true;
    cfg.notes = [...(cfg.notes ?? []), ...adj.notes];
    return cfg;
  }

  /** Raw ability check. */
  async rollAbility(ability, opts = {}) {
    const cfg = this._applyConditions({
      actor: this, kind: "check", ability,
      title: L("CNV.Roll.AbilityCheck", { ability: L(CONFIG.CNV.abilities[ability].label) }),
      parts: this._checkParts(ability, [{ label: L("CNV.Misc"), value: this.system.abilities[ability].bonus ?? 0 }]),
      ...opts
    });
    return performCheck(cfg);
  }

  /** Skill check (characters) or adversary skill line. */
  async rollSkill(skill, opts = {}) {
    const s = this.system;
    if ( this.type === "adversary" ) {
      const line = s.skills.find(l => l.name === skill) ?? { name: skill, mod: s.skillBonus };
      const cfg = this._applyConditions({
        actor: this, kind: "check", skill, title: L("CNV.Roll.SkillCheck", { skill: line.name }),
        parts: [{ label: line.name, value: line.mod || s.skillBonus }], ...opts
      });
      return performCheck(cfg);
    }
    const sk = s.skills[skill];
    const cfgSkill = CONFIG.CNV.skills[skill];
    const ability = opts.ability ?? sk.abilityKey;
    const parts = this._checkParts(ability, [
      { label: L("CNV.Ranks"), value: sk.ranks },
      { label: L("CNV.Misc"), value: sk.bonus }
    ]);
    if ( cfgSkill.armorPenalty && s.armorPenalty ) parts.push({ label: L("CNV.ArmorPenalty"), value: s.armorPenalty });
    const cfg = this._applyConditions({
      actor: this, kind: "check", skill, ability,
      title: L("CNV.Roll.SkillCheck", { skill: L(cfgSkill.label) }), parts, ...opts
    });
    return performCheck(cfg);
  }

  async rollLore(index, opts = {}) {
    const lore = this.system.lores[index];
    if ( !lore ) return;
    const cfg = this._applyConditions({
      actor: this, kind: "check", ability: "intellect", skill: "lore",
      title: L("CNV.Roll.SkillCheck", { skill: `${L("CNV.Lore")}: ${lore.name}` }),
      parts: this._checkParts("intellect", [{ label: L("CNV.Ranks"), value: lore.ranks }, { label: L("CNV.Misc"), value: lore.bonus }]),
      ...opts
    });
    return performCheck(cfg);
  }

  /** Saving throw. */
  async rollSave(ability, opts = {}) {
    const s = this.system;
    const parts = this._checkParts(ability, [
      { label: L("CNV.SaveBonus"), value: s.saveBonus ?? 0 },
      { label: L("CNV.Misc"), value: s.abilities[ability].save ?? 0 }
    ]);
    const cfg = this._applyConditions({
      actor: this, kind: opts.kind ?? "save", ability,
      title: opts.title ?? L("CNV.Roll.Save", { ability: L(CONFIG.CNV.abilities[ability].label) }),
      parts, ...opts
    });
    return performCheck(cfg);
  }

  /** Flat check with an optional DC. */
  async rollFlat(dc = 15, title) { return flatCheck(dc, { actor: this, title }); }

  /* -------------------------------------------- */
  /*  Attacks & Defense                            */
  /* -------------------------------------------- */

  /** Which ability a weapon attack uses. */
  weaponAbility(weapon) {
    const a = this.system.abilities;
    const sys = weapon.system;
    const ranged = sys.isRanged;
    let ability = ranged ? "reflex" : "might";
    if ( sys.category === "martial" || sys.category === "natural" ) {
      const sk = this.system.skills?.martialArts;
      ability = sk?.ability || "might";
    }
    if ( sys.traits?.includes("finesse") && a.reflex.value > a[ability].value ) ability = "reflex";
    return ability;
  }

  /**
   * Make a weapon attack. Posts an attack card with Parry/Dodge buttons for each targeted token.
   * @param {Item} weapon
   * @param {object} opts  { event, twoHanded, doubleBarrel, rangeIncrements, technique }
   */
  async rollAttack(weapon, opts = {}) {
    const sys = weapon.system;
    const s = this.system;
    const ability = this.weaponAbility(weapon);
    let skill = sys.skill;
    if ( sys.altSkill && this.isPC && (s.skills[sys.altSkill]?.ranks ?? 0) > (s.skills[skill]?.ranks ?? 0) ) skill = sys.altSkill;
    const parts = [];
    if ( this.isPC ) {
      parts.push({ label: L(CONFIG.CNV.abilities[ability].label), value: s.abilities[ability].value });
      parts.push({ label: L(CONFIG.CNV.skills[skill]?.label ?? "CNV.Ranks"), value: s.skills[skill]?.ranks ?? 0 });
      if ( skill === "martialArts" && s.armorPenalty ) parts.push({ label: L("CNV.ArmorPenalty"), value: s.armorPenalty });
    } else {
      parts.push({ label: L("CNV.CheckBonus"), value: s.checkBonus });
    }
    if ( sys.attackBonus ) parts.push({ label: weapon.name, value: sys.attackBonus });

    // Requirement: below the weapon's requirement = 1 Disadvantage (and Recoil/Unwieldy notes)
    const notes = [];
    let dis = 0; let adv = 0;
    const req = sys.requirement;
    if ( this.isPC && req?.value && (s.abilities[req.ability]?.value ?? 0) < req.value ) {
      notes.push(L("CNV.Attack.BelowRequirement", { ability: L(CONFIG.CNV.abilities[req.ability].label), value: req.value }));
    }
    const recoil = sys.traitValues?.[opts.doubleBarrel ? "doubleBarrelRecoil" : "recoil"] ?? sys.traitValues?.recoil;
    if ( recoil && this.isPC && s.abilities.might.value < recoil ) {
      notes.push(L("CNV.Attack.RecoilUnwieldy", { value: recoil }));
      if ( s.abilities.might.value <= recoil - 2 ) notes.push(L("CNV.Attack.RecoilVolatile"));
    }
    if ( opts.rangeIncrements ) dis += opts.rangeIncrements;

    // Target conditions
    const targets = [...game.user.targets];
    if ( targets.length === 1 ) {
      const t = targetAdjustments(targets[0].actor);
      adv += t.adv; dis += t.dis;
      if ( t.notes.length ) notes.push(`${L("CNV.Target")}: ${t.notes.join(", ")}`);
    }

    const cfg = this._applyConditions({
      actor: this, kind: "attack", ability, skill, title: L("CNV.Roll.Attack", { weapon: weapon.name }),
      parts, adv, dis, notes, event: opts.event, traits: ["attack"],
      flags: { attack: {
        itemUuid: weapon.uuid, actorUuid: this.uuid, twoHanded: !!opts.twoHanded, doubleBarrel: !!opts.doubleBarrel,
        targets: targets.map(t => t.document.uuid), melee: !sys.isRanged, technique: opts.technique ?? null
      } }
    });

    // Ammunition
    if ( sys.usesAmmo && sys.ammo.max > 0 ) {
      const spend = opts.doubleBarrel ? sys.ammo.value : 1;
      if ( sys.ammo.value < 1 ) return ui.notifications.warn(L("CNV.Attack.NoAmmo", { weapon: weapon.name }));
      await weapon.update({ "system.ammo.value": Math.max(0, sys.ammo.value - spend) });
    }

    const result = await performCheck(cfg);
    if ( !result ) return null;
    await this._postDefenseCard(result, weapon, targets, opts);
    // Bump initiative: the creature attacked goes next
    const combat = game.combat;
    if ( combat?.started && targets.length ) {
      const c = combat.combatants.find(x => x.tokenId === targets[0].id);
      if ( c ) await asGM("setLastTarget", { combatId: combat.id, combatantId: c.id });
    }
    return result;
  }

  /** Post a follow-up card listing targets with Parry / Dodge / Take-it buttons. */
  async _postDefenseCard(result, item, targets, opts = {}) {
    const total = result.roll.total;
    const content = await foundry.applications.handlebars.renderTemplate(`systems/${SYS}/templates/chat/attack-card.hbs`, {
      item, total, natural: result.roll.natural,
      targets: targets.map(t => ({ uuid: t.document.uuid, name: t.name, img: t.document.texture.src })),
      melee: !item.system.isRanged, isSpell: item.type === "spell"
    });
    return ChatMessage.create({
      speaker: ChatMessage.getSpeaker({ actor: this }),
      content,
      flags: { [SYS]: { attackCard: {
        attackTotal: total, attackNatural: result.roll.natural, itemUuid: item.uuid, actorUuid: this.uuid,
        twoHanded: !!opts.twoHanded, doubleBarrel: !!opts.doubleBarrel, melee: !item.system.isRanged
      } } }
    });
  }

  /**
   * Defend against an attack total with Parry (Might save) or Dodge (Reflex save).
   * @returns {Promise<{outcome: "critDefense"|"defended"|"hit"|"critHit", result}>}
   */
  async rollDefense(mode, attackTotal, attackNatural, { melee = true, attackerName = "" } = {}) {
    const ability = mode === "parry" ? "might" : "reflex";
    const s = this.system;
    // Eligibility warnings
    const warns = [];
    if ( mode === "parry" ) {
      const hasWeapon = this.items.some(i => (i.type === "weapon" && i.system.equipped && !i.system.isRanged) || (i.type === "shield" && i.system.equipped));
      if ( !hasWeapon ) warns.push(L("CNV.Defense.ParryNeedsWeapon"));
      if ( !melee && !(this.items.some(i => i.type === "shield" && i.system.equipped) && (s.skills?.shields?.ranks ?? 0) > 0) ) warns.push(L("CNV.Defense.ParryRanged"));
    } else {
      if ( this.statuses.has("grappled") || this.statuses.has("restrained") || this.statuses.has("prone") ) warns.push(L("CNV.Defense.DodgeBlocked"));
      if ( melee && this.isPC && (s.skills?.acrobatics?.ranks ?? 0) < 2 ) warns.push(L("CNV.Defense.DodgeMelee"));
    }
    const parts = this._checkParts(ability, [
      { label: L("CNV.SaveBonus"), value: s.saveBonus ?? 0 },
      { label: L("CNV.Misc"), value: (s.abilities[ability].save ?? 0) + (s.defenses?.[mode] ?? 0) }
    ]);
    // Raised shield bonus applies to the save against attacks
    const shield = this.items.find(i => i.type === "shield" && i.system.equipped && i.system.raised);
    if ( shield ) parts.push({ label: shield.name, value: shield.system.effectiveBonus });
    const cfg = this._applyConditions({
      actor: this, kind: mode, ability, parts, dc: attackTotal, critMargin: CONFIG.CNV.defenseCritMargin,
      title: L(mode === "parry" ? "CNV.Defense.ParryVs" : "CNV.Defense.DodgeVs", { name: attackerName, total: attackTotal }),
      notes: warns
    });
    const result = await performCheck(cfg);
    if ( !result ) return null;
    const r = result.roll;
    let outcome;
    if ( cfg.autoFail || r.isNat1 || (attackTotal - r.total >= CONFIG.CNV.defenseCritMargin) || attackNatural === 20 ) outcome = "critHit";
    else if ( r.isNat20 || (r.total - attackTotal >= CONFIG.CNV.defenseCritMargin) ) outcome = "critDefense";
    else if ( r.total >= attackTotal ) outcome = "defended";
    else outcome = "hit";
    return { outcome, result };
  }

  /* -------------------------------------------- */
  /*  Damage                                       */
  /* -------------------------------------------- */

  /**
   * Build and roll weapon damage.
   * @param {Item} weapon
   * @param {object} opts { crit, twoHanded, doubleBarrel, brutal, targetUuid, bonus }
   */
  async rollWeaponDamage(weapon, opts = {}) {
    const sys = weapon.system;
    let dice = sys.damage.dice;
    if ( opts.twoHanded && sys.damage.versatile ) dice = sys.damage.versatile;
    if ( opts.doubleBarrel && sys.damage.doubleBarrel ) dice = sys.damage.doubleBarrel;
    if ( (sys.category === "natural") && this.isPC ) {
      dice = CONFIG.CNV.bandMin(CONFIG.CNV.martialArtsDamage, this.system.skills.martialArts.ranks)?.dice ?? dice;
      if ( this.system.skills.martialArts.ranks < 1 ) dice = "1";
    }
    if ( this.type === "adversary" && sys.damage.dice === "table" ) dice = this.system.damage;
    const ability = this.isPC ? this.weaponAbility(weapon) : null;
    const abilityValue = ability ? this.system.abilities[ability].value : 0;
    const terms = [dice];
    if ( abilityValue ) terms.push(`${abilityValue}[${L(CONFIG.CNV.abilities[ability].label)}]`);
    if ( sys.traits.includes("deadly") && abilityValue ) terms.push(`${abilityValue}[${L("CNV.WTrait.deadly")}]`);
    if ( opts.brutal && sys.traits.includes("brutal") ) terms.push(`3[${L("CNV.WTrait.brutal")}]`);
    if ( sys.damageBonus ) terms.push(`${sys.damageBonus}`);
    if ( opts.bonus ) terms.push(`(${opts.bonus})`);
    let formula = terms.join(" + ").replace(/\+ -/g, "- ");
    if ( opts.crit ) formula = `(${formula}) * 2`;
    return this.postDamage(formula, {
      type: sys.damage.type, ap: sys.traitValues?.armorPiercing ?? 0, heavy: sys.traits.includes("heavy"),
      subdual: sys.traits.includes("subdual"), crit: !!opts.crit, flavor: `${weapon.name} — ${L("CNV.Damage.Label")}`,
      targetUuid: opts.targetUuid
    });
  }

  /** Roll an arbitrary damage formula and post a damage card with apply buttons. */
  async postDamage(formula, { type = "untyped", ap = 0, heavy = false, subdual = false, crit = false, flavor, targetUuid, persistent = false } = {}) {
    const roll = await new Roll(formula, this.getRollData()).evaluate();
    const typeLabel = L(CONFIG.CNV.damageTypes[type]?.label ?? type);
    const content = await foundry.applications.handlebars.renderTemplate(`systems/${SYS}/templates/chat/damage-card.hbs`, {
      total: roll.total, formula: roll.formula, tooltip: await roll.getTooltip(), typeLabel, ap, heavy, crit, subdual,
      target: targetUuid ? fromUuidSync(targetUuid)?.name : null
    });
    return ChatMessage.create({
      speaker: ChatMessage.getSpeaker({ actor: this }),
      flavor, content, rolls: [roll],
      flags: { [SYS]: { damage: { total: roll.total, type, ap, heavy, subdual, crit, targetUuid, persistent } } }
    });
  }

  /**
   * Apply damage after Soak, Armor Piercing, resistances, THP. Prompts for Wounds and 0 HP.
   * @param {number} amount
   * @param {object} opts { type, ap, heavy, crit, ignoreSoak, multiplier, silent }
   */
  async applyDamage(amount, opts = {}) {
    const s = this.system;
    if ( !s.hp ) return;
    const type = opts.type ?? "untyped";
    const dt = CONFIG.CNV.damageTypes[type] ?? {};
    const lines = [];
    let dmg = Math.floor(amount * (opts.multiplier ?? 1));
    lines.push(`${L("CNV.Damage.Rolled")}: ${dmg}`);

    // Gaping Wound
    if ( (type === "piercing" || type === "slashing") && this.statuses.has("gapingWound") ) { dmg += 2; lines.push(`${L("CNV.Cond.gapingWound")}: +2`); }

    // Soak
    if ( !opts.ignoreSoak && type !== "untyped" ) {
      let soak = s.soak?.value ?? 0;
      if ( !dt.physical ) soak = Math.floor(soak / 2);
      soak = Math.max(0, soak - (opts.ap ?? 0));
      if ( soak ) { dmg = Math.max(0, dmg - soak); lines.push(`${L("CNV.Soak")}: -${soak}`); }
    }

    // Minion rule: any damage beyond Soak kills
    if ( this.type === "adversary" && s.rank === "minion" && dmg > 0 ) {
      await this.update({ "system.hp.value": 0 });
      await this.toggleStatusEffect("dead", { active: true, overlay: true });
      return this._damageReport(lines.concat(L("CNV.Damage.MinionDies")), 0);
    }

    // Resistance / Vulnerability / Immunity (and Fortified/Heavy)
    const tr = s.traits ?? { resist: new Set(), vuln: new Set(), immune: new Set() };
    const has = (set, key) => set?.has?.(key) || set?.has?.("all") || (dt.physical && set?.has?.("physical")) || (!dt.physical && set?.has?.("energy"));
    if ( has(tr.immune, type) || (tr.immune?.has?.("nonheavy") && !opts.heavy) ) { dmg = 0; lines.push(L("CNV.Damage.Immune")); }
    else {
      let resist = has(tr.resist, type) || (tr.resist?.has?.("nonheavy") && !opts.heavy) || (tr.resist?.has?.("heavy") && opts.heavy);
      let vuln = has(tr.vuln, type) || (tr.vuln?.has?.("heavy") && opts.heavy);
      if ( resist && !vuln ) { dmg = Math.floor(dmg / 2); lines.push(L("CNV.Damage.Resisted")); }
      else if ( vuln && !resist ) { dmg *= 2; lines.push(L("CNV.Damage.Vulnerable")); }
    }

    // Temporary HP
    let thp = s.hp.temp ?? 0;
    if ( thp && dmg ) {
      const absorbed = Math.min(thp, dmg);
      thp -= absorbed; dmg -= absorbed;
      lines.push(`${L("CNV.TempHP")}: -${absorbed}`);
    }

    const before = s.hp.value;
    const after = Math.max(0, before - dmg);
    const updates = { "system.hp.value": after, "system.hp.temp": thp };
    await this.update(updates);
    if ( dmg > 0 && this.statuses.has("stable") ) await this.toggleStatusEffect("stable", { active: false });
    lines.push(`<strong>${L("CNV.Damage.Taken")}: ${dmg}</strong> (${before} → ${after})`);

    // Dying: damage ticks the Death Timer
    if ( this.isPC && before === 0 && dmg > 0 && s.dying ) {
      const tick = opts.crit ? 2 : 1;
      await this.update({ "system.deathTimer.value": Math.max(0, s.deathTimer.value - tick) });
      lines.push(L("CNV.Death.TimerTick", { n: tick }));
      if ( s.deathTimer.value - tick <= 0 ) await this._die();
    }

    await this._damageReport(lines, dmg);

    // Wounds
    if ( dmg > 0 && after > 0 && s.hp.lightThreshold && game.settings.get(SYS, "useWounds") ) {
      if ( dmg >= s.hp.heavyThreshold ) await this._woundCheck("heavy");
      else if ( dmg >= s.hp.lightThreshold ) await this._woundCheck("light");
    }
    // Massive damage & 0 HP
    if ( after === 0 && before > 0 ) {
      const overkill = dmg - before;
      if ( this.isPC ) await this._onZeroHP(overkill > s.hp.max);
      else if ( this.type === "adversary" ) await this.toggleStatusEffect("dead", { active: true, overlay: true });
    }
    return dmg;
  }

  async _damageReport(lines, dmg) {
    if ( game.settings.get(SYS, "damageReports") === "none" ) return;
    const whisper = game.settings.get(SYS, "damageReports") === "gm" ? ChatMessage.getWhisperRecipients("GM") : undefined;
    return ChatMessage.create({
      speaker: ChatMessage.getSpeaker({ actor: this }),
      whisper,
      content: `<div class="cnv-card cnv-damage-report"><h4>${this.name}</h4><p>${lines.join("<br>")}</p></div>`
    });
  }

  async applyHealing(amount) {
    if ( this.statuses.has("withered") ) return ui.notifications.warn(L("CNV.Cond.WitheredBlocks", { name: this.name }));
    const s = this.system;
    const hp = Math.min(s.hp.max, s.hp.value + amount);
    const updates = { "system.hp.value": hp };
    if ( hp > 0 && s.dying ) Object.assign(updates, { "system.dying": false });
    await this.update(updates);
    if ( hp > 0 ) {
      for ( const id of ["dying", "stable", "unconscious", "gapingWound"] ) if ( this.statuses.has(id) ) await this.toggleStatusEffect(id, { active: false });
    }
    return hp;
  }

  async setTempHP(amount) {
    if ( this.statuses.has("withered") ) return;
    // THP don't stack — keep the higher
    if ( amount > (this.system.hp.temp ?? 0) ) await this.update({ "system.hp.temp": amount });
  }

  /** Light/Heavy wound flat check with location prompt. */
  async _woundCheck(severity) {
    const dc = severity === "heavy" ? 15 : 10;
    const res = await flatCheck(dc, { actor: this, title: L(severity === "heavy" ? "CNV.Wound.HeavyCheck" : "CNV.Wound.LightCheck", { dc }) });
    if ( !res || res.degree === "success" || res.degree === "criticalSuccess" ) return;
    const locations = CONFIG.CNV.woundLocations;
    const choice = await foundry.applications.api.DialogV2.wait({
      window: { title: L("CNV.Wound.Location", { name: this.name }) },
      content: `<p>${L("CNV.Wound.LocationHint")}</p>`,
      buttons: Object.entries(locations).map(([k, v]) => ({ action: k, label: L(v.label) })),
      rejectClose: false
    });
    if ( !choice ) return;
    const loc = locations[choice];
    const id = severity === "heavy" ? loc.heavy : loc.light;
    const value = severity === "heavy" ? loc.heavyValue : loc.lightValue;
    await setCondition(this, id, value ?? null);
    await this.update({ [`system.wounds.${severity}`]: (this.system.wounds?.[severity] ?? 0) + 1 }).catch(() => {});
    ChatMessage.create({ speaker: ChatMessage.getSpeaker({ actor: this }),
      content: `<div class="cnv-card"><p>${L("CNV.Wound.Suffered", { name: this.name, severity: L(`CNV.Wound.${severity}`), location: L(loc.label), condition: CONFIG.CNV.conditions[id].name + (value ? ` ${value}` : "") })}</p></div>` });
  }

  /* -------------------------------------------- */
  /*  Death                                        */
  /* -------------------------------------------- */

  async _onZeroHP(massive = false) {
    const options = massive ? ["vengeance"] : ["heroic", "vengeance", "mostlyDead"];
    const choice = await foundry.applications.api.DialogV2.wait({
      window: { title: L("CNV.Death.Title", { name: this.name }) },
      content: `<p>${L(massive ? "CNV.Death.Massive" : "CNV.Death.Choose")}</p><ul>${options.map(o => `<li><strong>${L(`CNV.Death.${o}`)}:</strong> ${L(`CNV.Death.${o}Text`)}</li>`).join("")}</ul>`,
      buttons: options.map(o => ({ action: o, label: L(`CNV.Death.${o}`) })),
      rejectClose: false
    });
    if ( choice === "mostlyDead" ) return this.onlyMostlyDead();
    const text = choice ? L(`CNV.Death.${choice}Chat`, { name: this.name }) : L("CNV.Death.Pending", { name: this.name });
    ChatMessage.create({ speaker: ChatMessage.getSpeaker({ actor: this }), content: `<div class="cnv-card cnv-death"><p>${text}</p></div>` });
    if ( choice === "vengeance" ) await this._die();
  }

  async onlyMostlyDead() {
    const ex = Math.min(4, this.system.exhaustion + 1);
    const roll = await new Roll(`1d4 + ${this.system.abilities.fortitude.value} - ${ex}`).evaluate();
    const timer = Math.max(0, roll.total);
    await this.update({ "system.exhaustion": ex, "system.deathTimer.value": timer, "system.deathTimer.max": timer, "system.dying": true });
    await this.toggleStatusEffect("dying", { active: true });
    await this.toggleStatusEffect("unconscious", { active: true });
    await roll.toMessage({ speaker: ChatMessage.getSpeaker({ actor: this }), flavor: L("CNV.Death.TimerSet", { name: this.name }) });
    if ( timer <= 0 || ex >= 4 ) await this._die();
  }

  /** Start-of-turn dying roll. */
  async rollDying() {
    if ( !this.system.dying ) return;
    const roll = await new Roll("1d20").evaluate();
    let text;
    if ( roll.total === 20 ) {
      await this.applyHealing(1);
      await this.update({ "system.dying": false });
      text = L("CNV.Death.Nat20", { name: this.name });
    } else if ( this.statuses.has("stable") ) {
      text = L("CNV.Death.StableHolds", { name: this.name });
    } else {
      const t = Math.max(0, this.system.deathTimer.value - 1);
      await this.update({ "system.deathTimer.value": t });
      text = L("CNV.Death.Tick", { name: this.name, n: t });
      if ( t <= 0 ) await this._die();
    }
    return roll.toMessage({ speaker: ChatMessage.getSpeaker({ actor: this }), flavor: text });
  }

  async _die() {
    await this.update({ "system.dying": false });
    await this.toggleStatusEffect("dying", { active: false });
    await this.toggleStatusEffect("dead", { active: true, overlay: true });
    ChatMessage.create({ speaker: ChatMessage.getSpeaker({ actor: this }), content: `<div class="cnv-card cnv-death"><p>${L("CNV.Death.Died", { name: this.name })}</p></div>` });
  }

  /* -------------------------------------------- */
  /*  Strain & Exhaustion                          */
  /* -------------------------------------------- */

  /**
   * Take Strain. Anything beyond the limit converts to Exhaustion via the Excess Strain table.
   */
  async spendStrain(n, { reason } = {}) {
    const s = this.system;
    if ( !s.strain || !n ) return;
    // Chest Trauma adds X to every action's Strain
    const total = s.strain.value + n;
    const updates = {};
    let excess = total - s.strain.max;
    if ( excess > 0 ) {
      const levels = CONFIG.CNV.bandMax(CONFIG.CNV.excessStrain, excess).levels;
      const ex = Math.min(4, s.exhaustion + levels);
      updates["system.strain.value"] = s.strain.max;
      updates["system.exhaustion"] = ex;
      ChatMessage.create({ speaker: ChatMessage.getSpeaker({ actor: this }),
        content: `<div class="cnv-card"><p>${L("CNV.Strain.Overflow", { name: this.name, excess, levels, ex })}</p></div>` });
      if ( ex >= 4 ) await this._die();
    } else updates["system.strain.value"] = Math.max(0, total);
    await this.update(updates);
    if ( reason ) ui.notifications.info(L("CNV.Strain.Spent", { name: this.name, n, reason }));
  }

  /** Strain from Chest Trauma, applied when an action is used. */
  get chestTrauma() {
    const e = this.effects.find(e => e.statuses.has("chestTrauma"));
    return e ? (e.getFlag(SYS, "value") ?? 1) : 0;
  }

  /* -------------------------------------------- */
  /*  Rests & Resources                            */
  /* -------------------------------------------- */

  async takeABreak() {
    const roll = await new Roll(this.system.breakDie ?? "1d4").evaluate();
    const v = Math.max(0, this.system.strain.value - roll.total);
    await this.update({ "system.strain.value": v });
    return roll.toMessage({ speaker: ChatMessage.getSpeaker({ actor: this }), flavor: L("CNV.Rest.BreakResult", { name: this.name, n: roll.total }) });
  }

  async shortRest() {
    const s = this.system;
    const hp = Math.min(s.hp.max, s.hp.value + Math.floor(s.hp.max / 4));
    const strain = Math.max(0, s.strain.value - Math.floor(s.strain.max / 2));
    const ex = Math.max(0, s.exhaustion - 1);
    await this.update({ "system.hp.value": hp, "system.hp.temp": 0, "system.strain.value": strain, "system.exhaustion": ex });
    await this._rechargeItems("short");
    return ChatMessage.create({ speaker: ChatMessage.getSpeaker({ actor: this }),
      content: `<div class="cnv-card"><h4>${L("CNV.Rest.Short")}</h4><p>${L("CNV.Rest.ShortResult", { name: this.name, hp, strain, ex })}</p></div>` });
  }

  async longRest({ rough = false } = {}) {
    const s = this.system;
    const hp = rough ? Math.min(s.hp.max, s.hp.value + Math.floor((s.hp.max - s.hp.value) / 2)) : s.hp.max;
    const ex = Math.max(0, s.exhaustion - (rough ? 1 : 2));
    await this.update({ "system.hp.value": hp, "system.hp.temp": 0, "system.strain.value": 0, "system.exhaustion": ex });
    await this._rechargeItems("long");
    return ChatMessage.create({ speaker: ChatMessage.getSpeaker({ actor: this }),
      content: `<div class="cnv-card"><h4>${L("CNV.Rest.Long")}</h4><p>${L("CNV.Rest.LongResult", { name: this.name, hp, ex })}</p></div>` });
  }

  async _rechargeItems(kind) {
    const updates = [];
    for ( const i of this.items ) {
      const u = i.system.uses;
      if ( !u?.max ) continue;
      const per = (u.per ?? "").toLowerCase();
      if ( (kind === "long" && ["short", "long", "day", "rest"].includes(per)) || (kind === "short" && per === "short") ) {
        updates.push({ _id: i.id, "system.uses.value": u.max });
      }
    }
    if ( updates.length ) await this.updateEmbeddedDocuments("Item", updates);
  }

  /** Supply check: flat DC 10 + half item level; success spends nothing, failure spends 1 SUP. */
  async supplyCheck(itemLevel = 0) {
    const dc = 10 + Math.floor(itemLevel / 2);
    const res = await flatCheck(dc, { actor: this, title: L("CNV.Supplies.Check", { dc }) });
    if ( res && (res.degree === "failure" || res.degree === "criticalFailure") ) {
      await this.update({ "system.sup.value": Math.max(0, this.system.sup.value - 1) });
    }
    return res;
  }

  /** Spend a Fate Die: reroll the last failed check or add/subtract the die to an effect. */
  async spendFate() {
    const f = this.system.fate;
    if ( f.value < 1 ) return ui.notifications.warn(L("CNV.Fate.None"));
    await this.update({ "system.fate.value": f.value - 1 });
    return true;
  }

  async rollFateDie() {
    if ( !(await this.spendFate()) ) return;
    const roll = await new Roll(this.system.fateDie).evaluate();
    return roll.toMessage({ speaker: ChatMessage.getSpeaker({ actor: this }), flavor: L("CNV.Fate.EffectRoll", { name: this.name }) });
  }

  /** Start-of-session fate pool: minimum, or carried (max double the minimum). */
  async startSession() {
    const s = this.system;
    const value = Math.clamp(Math.max(s.fateMin, s.fate.value), s.fateMin, s.fateMax);
    return this.update({ "system.fate.value": value });
  }

  /* -------------------------------------------- */
  /*  Adversary helpers                            */
  /* -------------------------------------------- */

  /** Roll the recharge die for an adversary maneuver. */
  async rollRecharge(item) {
    const target = this.system.rechargeTarget ?? 9;
    const roll = await new Roll("1d12").evaluate();
    const ok = roll.total >= target;
    await item.update({ "system.recharge.charged": ok });
    return roll.toMessage({ speaker: ChatMessage.getSpeaker({ actor: this }),
      flavor: L(ok ? "CNV.Recharge.Success" : "CNV.Recharge.Fail", { item: item.name, target }) });
  }

  /**
   * Morale check: 1d20 + Morale Edge vs DC 10. On a failure the crack margin
   * (10 - total) sets how many Elements break.
   */
  async rollMorale({ dc = 10, fortune = false, misfortune = false } = {}) {
    const me = this.system.morale?.value ?? 0;
    const roll = CNVRoll.build({ parts: [{ label: L("CNV.Morale.Edge"), value: me }], fortune, misfortune, dc, kind: "morale" });
    await roll.evaluate();
    const margin = dc - roll.total;
    let outcome;
    if ( margin <= 0 ) outcome = L("CNV.Morale.Holds");
    else if ( margin <= 3 ) outcome = L("CNV.Morale.Break", { n: 1 });
    else if ( margin <= 6 ) outcome = L("CNV.Morale.Break", { n: 2 });
    else outcome = L("CNV.Morale.Rout");
    const broken = margin > 0 ? `<p><em>${L("CNV.Morale.OutcomesHint")}</em></p>` : "";
    return roll.toMessage({ speaker: ChatMessage.getSpeaker({ actor: this }),
      flavor: `${L("CNV.Morale.Check")} — ${outcome}${broken}`,
      flags: { [SYS]: { morale: { margin } } } });
  }
}
