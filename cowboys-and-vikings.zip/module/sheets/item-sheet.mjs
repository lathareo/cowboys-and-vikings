const SYS = "cowboys-and-vikings";
const L = (k, d) => d ? game.i18n.format(k, d) : game.i18n.localize(k);
const { HandlebarsApplicationMixin } = foundry.applications.api;

export class CNVItemSheet extends HandlebarsApplicationMixin(foundry.applications.sheets.ItemSheetV2) {
  static DEFAULT_OPTIONS = {
    classes: ["cnv", "sheet", "item"],
    position: { width: 560, height: 640 },
    window: { resizable: true },
    form: { submitOnChange: true },
    actions: {
      listAdd: CNVItemSheet.#onListAdd,
      listRemove: CNVItemSheet.#onListRemove,
      effectCreate: CNVItemSheet.#onEffectCreate,
      effectEdit: CNVItemSheet.#onEffectEdit,
      effectDelete: CNVItemSheet.#onEffectDelete,
      effectToggle: CNVItemSheet.#onEffectToggle,
      toChat: CNVItemSheet.#onToChat
    }
  };

  static PARTS = {
    header: { template: `systems/${SYS}/templates/item/item-header.hbs` },
    tabs: { template: "templates/generic/tab-navigation.hbs" },
    description: { template: `systems/${SYS}/templates/item/item-description.hbs`, scrollable: [""] },
    details: { template: `systems/${SYS}/templates/item/item-details.hbs`, scrollable: [""] },
    effects: { template: `systems/${SYS}/templates/item/item-effects.hbs`, scrollable: [""] }
  };

  static TABS = {
    primary: {
      tabs: [
        { id: "description", icon: "fa-solid fa-book", label: "CNV.Tab.Description" },
        { id: "details", icon: "fa-solid fa-sliders", label: "CNV.Tab.Details" },
        { id: "effects", icon: "fa-solid fa-bolt", label: "CNV.Tab.Effects" }
      ],
      initial: "description"
    }
  };

  get item() { return this.document; }

  async _prepareContext(options) {
    const ctx = await super._prepareContext(options);
    const item = this.item;
    const s = item.system;
    const C = CONFIG.CNV;
    const loc = obj => Object.fromEntries(Object.entries(obj).map(([k, v]) => [k, L(typeof v === "string" ? v : v.label)]));
    const TE = foundry.applications.ux.TextEditor.implementation;
    Object.assign(ctx, {
      item, system: s, source: item._source.system, C, fields: s.schema.fields, editable: this.isEditable,
      tabs: this._prepareTabs("primary"),
      typeLabel: L(`TYPES.Item.${item.type}`),
      detailsTemplate: `systems/${SYS}/templates/item/details/${item.type}.hbs`,
      enriched: {
        description: await TE.enrichHTML(s.description ?? "", { relativeTo: item, secrets: item.isOwner }),
        critSuccess: s.critSuccess !== undefined ? await TE.enrichHTML(s.critSuccess ?? "", { relativeTo: item }) : "",
        features: s.features !== undefined ? await TE.enrichHTML(s.features ?? "", { relativeTo: item }) : ""
      },
      labels: item.chatLabels(),
      choices: {
        abilities: loc(C.abilities),
        skills: loc(C.skills),
        damageTypes: loc(C.damageTypes),
        weaponCategories: loc(C.weaponCategories),
        armorCategories: loc(C.armorCategories),
        schools: loc(C.spellSchools),
        castingTimes: loc(C.castingTimes),
        actionCosts: loc(C.actionCosts),
        currency: loc(C.currency),
        runeTiers: loc(C.runeTiers),
        runeSlots: loc(C.runeSlots),
        essenceTraits: C.essenceTraits,
        essenceQualities: loc(C.essenceQualities),
        ingredientSources: C.ingredientSources,
        concoctionTypes: C.concoctionTypes,
        afflictionTypes: C.afflictionTypes,
        poisonFamilies: C.poisonFamilies,
        crewTypes: { general: "General", ...C.crewTypes },
        maneuverCategories: loc(C.maneuverCategories),
        roles: loc(C.roles),
        creatureTypes: C.creatureTypes,
        qualities: loc(C.qualities),
        rollTypes: { "": "—", check: L("CNV.RollType.check"), save: L("CNV.RollType.save"), attack: L("CNV.RollType.attack"), damage: L("CNV.RollType.damage"), heal: L("CNV.RollType.heal") },
        geneticKinds: { talent: L("CNV.Genetic.talent"), drawback: L("CNV.Genetic.drawback"), cosmetic: L("CNV.Genetic.cosmetic") },
        techniqueKinds: { melee: L("CNV.Technique.melee"), ranged: L("CNV.Technique.ranged"), shield: L("CNV.Technique.shield") },
        bondCategories: Object.fromEntries(C.bondCategories.map(b => [b, b])),
        talentTrees: Object.fromEntries(C.talentTrees.map(b => [b, b])),
        rarity: { common: L("CNV.Rarity.common"), uncommon: L("CNV.Rarity.uncommon"), rare: L("CNV.Rarity.rare"), legendary: L("CNV.Rarity.legendary") }
      },
      traitChoices: item.type === "weapon" ? Object.entries(C.weaponTraits).map(([k, v]) => ({ key: k, label: L(v), checked: s.traits.includes(k), value: s.traitValues?.[k] ?? "" }))
        : item.type === "armor" ? Object.entries(C.armorTraits).map(([k, v]) => ({ key: k, label: L(v), checked: s.traits.includes(k) })) : [],
      deliveryChoices: item.type === "spell" ? Object.entries(C.deliveries).map(([k, v]) => ({ key: k, label: L(v.label), checked: !s.deliveries.length || s.deliveries.includes(k) })) : [],
      componentChoices: item.type === "spell" ? ["verbal", "somatic", "material"].map(k => ({ key: k, label: L(`CNV.Spell.${k.charAt(0).toUpperCase() + k.slice(1)}`), checked: s.components.includes(k) })) : [],
      effects: item.effects.map(e => ({ id: e.id, name: e.name, img: e.img, disabled: e.disabled, transfer: e.transfer })),
      tagsString: [...(s.tags ?? [])].join(", "),
      actionTraitsString: (s.actionTraits ?? []).join(", "),
      functionsString: (s.functions ?? []).join(", "),
      originSkillsString: item.type === "origin" ? (s.skills ?? []).join(", ") : "",
      originAbilityChoicesString: item.type === "origin" ? (s.abilityChoices ?? []).join(", ") : ""
    });
    return ctx;
  }

  async _preparePartContext(partId, context) {
    context = await super._preparePartContext(partId, context);
    if ( context.tabs?.[partId] ) context.tab = context.tabs[partId];
    return context;
  }

  /** Normalise checkbox groups and comma lists into arrays. */
  _processFormData(event, form, formData) {
    const data = super._processFormData(event, form, formData);
    const s = data.system ?? {};
    const toList = v => typeof v === "string" ? v.split(",").map(x => x.trim()).filter(Boolean) : v;
    for ( const k of ["tags", "actionTraits", "functions", "maneuvers", "spellTraits", "skills", "abilityChoices"] ) if ( typeof s[k] === "string" ) s[k] = toList(s[k]);
    if ( s._traits ) {
      s.traits = Object.entries(s._traits).filter(([, v]) => v).map(([k]) => k);
      delete s._traits;
    }
    if ( s._traitValues ) {
      s.traitValues = Object.fromEntries(Object.entries(s._traitValues).filter(([, v]) => v !== "" && v !== null).map(([k, v]) => [k, Number(v) || v]));
      delete s._traitValues;
    }
    if ( s._deliveries ) {
      const on = Object.entries(s._deliveries).filter(([, v]) => v).map(([k]) => k);
      s.deliveries = on.length === Object.keys(CONFIG.CNV.deliveries).length ? [] : on;
      delete s._deliveries;
    }
    if ( s._components ) {
      s.components = Object.entries(s._components).filter(([, v]) => v).map(([k]) => k);
      delete s._components;
    }
    return data;
  }

  static async #onListAdd(event, target) {
    const path = target.dataset.path;
    const list = foundry.utils.deepClone(foundry.utils.getProperty(this.item._source, path) ?? []);
    list.push(target.dataset.template ? JSON.parse(target.dataset.template) : {});
    return this.item.update({ [path]: list });
  }
  static async #onListRemove(event, target) {
    const path = target.dataset.path;
    const list = foundry.utils.deepClone(foundry.utils.getProperty(this.item._source, path) ?? []);
    list.splice(Number(target.dataset.index), 1);
    return this.item.update({ [path]: list });
  }
  static #onEffectCreate() {
    return this.item.createEmbeddedDocuments("ActiveEffect", [{ name: this.item.name, img: this.item.img, origin: this.item.uuid, transfer: true }]);
  }
  static #onEffectEdit(event, target) { this.item.effects.get(target.closest("[data-effect-id]").dataset.effectId)?.sheet.render(true); }
  static #onEffectDelete(event, target) { return this.item.effects.get(target.closest("[data-effect-id]").dataset.effectId)?.delete(); }
  static #onEffectToggle(event, target) {
    const e = this.item.effects.get(target.closest("[data-effect-id]").dataset.effectId);
    return e?.update({ disabled: !e.disabled });
  }
  static #onToChat() { return this.item.toChat(); }
}
