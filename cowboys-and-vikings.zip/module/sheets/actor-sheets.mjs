import { setCondition } from "../helpers/conditions.mjs";
import * as builder from "../helpers/character-builder.mjs";

const SYS = "cowboys-and-vikings";
const L = (k, d) => d ? game.i18n.format(k, d) : game.i18n.localize(k);
const { HandlebarsApplicationMixin } = foundry.applications.api;
const TextEditor = () => foundry.applications.ux.TextEditor.implementation;

/**
 * Shared behaviour for every Cowboys & Vikings actor sheet.
 */
export class CNVActorSheet extends HandlebarsApplicationMixin(foundry.applications.sheets.ActorSheetV2) {
  static DEFAULT_OPTIONS = {
    classes: ["cnv", "sheet", "actor"],
    position: { width: 760, height: 820 },
    window: { resizable: true },
    form: { submitOnChange: true },
    actions: {
      rollAbility: CNVActorSheet.#onRollAbility,
      rollSkill: CNVActorSheet.#onRollSkill,
      rollLore: CNVActorSheet.#onRollLore,
      rollSave: CNVActorSheet.#onRollSave,
      rollInitiative: CNVActorSheet.#onRollInitiative,
      itemCreate: CNVActorSheet.#onItemCreate,
      itemEdit: CNVActorSheet.#onItemEdit,
      itemDelete: CNVActorSheet.#onItemDelete,
      itemUse: CNVActorSheet.#onItemUse,
      itemChat: CNVActorSheet.#onItemChat,
      itemToggle: CNVActorSheet.#onItemToggle,
      itemQuantity: CNVActorSheet.#onItemQuantity,
      itemRecharge: CNVActorSheet.#onItemRecharge,
      reload: CNVActorSheet.#onReload,
      effectToggle: CNVActorSheet.#onEffectToggle,
      effectEdit: CNVActorSheet.#onEffectEdit,
      effectDelete: CNVActorSheet.#onEffectDelete,
      effectCreate: CNVActorSheet.#onEffectCreate,
      conditionToggle: CNVActorSheet.#onConditionToggle,
      conditionStep: CNVActorSheet.#onConditionStep,
      listAdd: CNVActorSheet.#onListAdd,
      listRemove: CNVActorSheet.#onListRemove,
      toggleEdit: CNVActorSheet.#onToggleEdit
    }
  };

  /** Edit mode lock (unlocked shows raw inputs). */
  _editMode = false;

  get actor() { return this.document; }

  async _prepareContext(options) {
    const ctx = await super._prepareContext(options);
    const actor = this.actor;
    const system = actor.system;
    const C = CONFIG.CNV;
    Object.assign(ctx, {
      actor, system, source: actor.system._source ?? actor._source.system, C,
      systemFields: system.schema.fields,
      editable: this.isEditable, owner: actor.isOwner, isGM: game.user.isGM, editMode: this._editMode,
      config: C,
      abilities: Object.entries(system.abilities ?? {}).map(([k, v]) => ({
        key: k, label: L(C.abilities[k].label), abbr: L(C.abilities[k].abbr), value: v.value, bonus: v.bonus, saveMisc: v.save,
        save: system.saves?.[k], tier: system.saveTier?.[k], quality: system.abilityQuality?.[k],
        desc: C.abilityDescriptions[k]?.[String(Math.clamp(v.value, -2, 5))] ?? ""
      })),
      conditions: this._conditionContext(),
      effects: actor.effects.filter(e => !e.statuses.size || !CONFIG.CNV.conditions[[...e.statuses][0]]).map(e => ({ id: e.id, name: e.name, img: e.img, disabled: e.disabled, source: e.sourceName })),
      itemEffects: actor.items.contents.flatMap(i => i.effects.map(e => ({ id: e.id, itemId: i.id, name: e.name, img: e.img, disabled: e.disabled, source: i.name })))
    });
    return ctx;
  }

  _conditionContext() {
    const actor = this.actor;
    return Object.values(CONFIG.CNV.conditions).filter(c => !["dead", "dying", "stable", "bloodied"].includes(c.id) || game.user.isGM).map(c => {
      const eff = actor.effects.find(e => e.statuses.has(c.id));
      return { ...c, active: !!eff, value: eff?.getFlag(SYS, "value") ?? (eff ? 1 : 0) };
    });
  }

  /** Group items by type and sort. */
  _items(types) {
    const list = this.actor.items.filter(i => types.includes(i.type)).sort((a, b) => (a.sort || 0) - (b.sort || 0));
    return list.map(i => ({ id: i.id, uuid: i.uuid, name: i.name, img: i.img, type: i.type, system: i.system, labels: i.chatLabels?.() ?? [] }));
  }

  async _enrich(html) {
    return TextEditor().enrichHTML(html ?? "", { relativeTo: this.actor, secrets: this.actor.isOwner, rollData: this.actor.getRollData() });
  }

  _onRender(context, options) {
    super._onRender(context, options);
    // Item rows can be dragged to hotbar / other sheets
    this.element.querySelectorAll("[data-item-id].item-row").forEach(el => el.setAttribute("draggable", "true"));
    this.element.querySelectorAll("[data-item-id].item-row").forEach(el => el.classList.add("draggable"));
    // Inline editing of embedded item fields: <input data-item-field="system.quantity">
    this.element.querySelectorAll("[data-item-field]").forEach(input => input.addEventListener("change", ev => {
      ev.stopPropagation();
      const id = ev.currentTarget.closest("[data-item-id]").dataset.itemId;
      const value = ev.currentTarget.type === "checkbox" ? ev.currentTarget.checked : (ev.currentTarget.dataset.dtype === "Number" ? Number(ev.currentTarget.value) : ev.currentTarget.value);
      this.actor.items.get(id)?.update({ [ev.currentTarget.dataset.itemField]: value });
    }));
  }

  /* ---------- Actions ---------- */
  static #onRollAbility(event, target) { return this.actor.rollAbility(target.dataset.ability, { event }); }
  static #onRollSkill(event, target) { return this.actor.rollSkill(target.dataset.skill, { event }); }
  static #onRollLore(event, target) { return this.actor.rollLore(Number(target.dataset.index), { event }); }
  static #onRollSave(event, target) { return this.actor.rollSave(target.dataset.ability, { event }); }
  static async #onRollInitiative() {
    const combat = game.combat;
    if ( !combat ) return ui.notifications.warn(L("CNV.Combat.NoCombat"));
    return this.actor.rollInitiative({ createCombatants: true });
  }
  static async #onItemCreate(event, target) {
    const type = target.dataset.type;
    const data = { name: L("CNV.NewItem", { type: L(`TYPES.Item.${type}`) }), type, system: {} };
    if ( target.dataset.category ) data.system.category = target.dataset.category;
    if ( target.dataset.kind ) data.system.kind = target.dataset.kind;
    const [item] = await this.actor.createEmbeddedDocuments("Item", [data]);
    item?.sheet.render(true);
  }
  static #onItemEdit(event, target) { this.actor.items.get(target.closest("[data-item-id]").dataset.itemId)?.sheet.render(true); }
  static async #onItemDelete(event, target) {
    const item = this.actor.items.get(target.closest("[data-item-id]").dataset.itemId);
    if ( !item ) return;
    const ok = event.shiftKey || await foundry.applications.api.DialogV2.confirm({ window: { title: L("CNV.DeleteTitle", { name: item.name }) }, content: `<p>${L("CNV.DeleteConfirm")}</p>` });
    if ( ok ) return item.delete();
  }
  static #onItemUse(event, target) { return this.actor.items.get(target.closest("[data-item-id]").dataset.itemId)?.use({ event }); }
  static #onItemChat(event, target) { return this.actor.items.get(target.closest("[data-item-id]").dataset.itemId)?.toChat(); }
  static #onItemToggle(event, target) {
    const item = this.actor.items.get(target.closest("[data-item-id]").dataset.itemId);
    const field = target.dataset.field ?? "system.equipped";
    return item?.update({ [field]: !foundry.utils.getProperty(item, field) });
  }
  static #onItemQuantity(event, target) {
    const item = this.actor.items.get(target.closest("[data-item-id]").dataset.itemId);
    const q = Math.max(0, (item.system.quantity ?? 0) + Number(target.dataset.delta));
    return item.update({ "system.quantity": q });
  }
  static #onItemRecharge(event, target) {
    const item = this.actor.items.get(target.closest("[data-item-id]").dataset.itemId);
    if ( item.system.recharge?.charged ) return item.update({ "system.recharge.charged": false });
    return this.actor.rollRecharge(item);
  }
  static async #onReload(event, target) {
    const item = this.actor.items.get(target.closest("[data-item-id]").dataset.itemId);
    await item.update({ "system.ammo.value": item.system.ammo.max });
    ChatMessage.create({ speaker: ChatMessage.getSpeaker({ actor: this.actor }), content: `<div class="cnv-card"><p>${L("CNV.Attack.Reloaded", { name: this.actor.name, weapon: item.name, ap: item.system.traitValues?.reload ?? 1 })}</p></div>` });
  }
  static #getEffect(target) {
    const row = target.closest("[data-effect-id]");
    const parent = row.dataset.itemId ? this.actor.items.get(row.dataset.itemId) : this.actor;
    return parent?.effects.get(row.dataset.effectId);
  }
  static #onEffectToggle(event, target) { const e = CNVActorSheet.#getEffect.call(this, target); return e?.update({ disabled: !e.disabled }); }
  static #onEffectEdit(event, target) { CNVActorSheet.#getEffect.call(this, target)?.sheet.render(true); }
  static #onEffectDelete(event, target) { return CNVActorSheet.#getEffect.call(this, target)?.delete(); }
  static #onEffectCreate() {
    return this.actor.createEmbeddedDocuments("ActiveEffect", [{ name: L("CNV.NewEffect"), img: "icons/svg/aura.svg", origin: this.actor.uuid }]);
  }
  static async #onConditionToggle(event, target) {
    const id = target.dataset.condition;
    const c = CONFIG.CNV.conditions[id];
    const existing = this.actor.effects.find(e => e.statuses.has(id));
    if ( existing ) return existing.delete();
    if ( id === "persistentDamage" ) return promptPersistent(this.actor);
    return setCondition(this.actor, id, c.valued ? 1 : null);
  }
  static async #onConditionStep(event, target) {
    const id = target.dataset.condition;
    const existing = this.actor.effects.find(e => e.statuses.has(id));
    const v = (existing?.getFlag(SYS, "value") ?? 0) + Number(target.dataset.delta);
    return setCondition(this.actor, id, Math.max(0, v));
  }
  static async #onListAdd(event, target) {
    const path = target.dataset.path;
    const list = foundry.utils.deepClone(foundry.utils.getProperty(this.actor._source, path) ?? []);
    const tpl = target.dataset.template ? JSON.parse(target.dataset.template) : {};
    list.push(tpl);
    return this.actor.update({ [path]: list });
  }
  static async #onListRemove(event, target) {
    const path = target.dataset.path;
    const index = Number(target.dataset.index);
    const list = foundry.utils.deepClone(foundry.utils.getProperty(this.actor._source, path) ?? []);
    list.splice(index, 1);
    return this.actor.update({ [path]: list });
  }
  static #onToggleEdit() { this._editMode = !this._editMode; this.render(); }
}

/** Ask for the persistent damage formula and type. */
export async function promptPersistent(actor) {
  const types = Object.entries(CONFIG.CNV.damageTypes).map(([k, v]) => `<option value="${k}">${L(v.label)}</option>`).join("");
  const r = await foundry.applications.api.DialogV2.prompt({
    window: { title: L("CNV.Cond.persistentDamage") },
    content: `<div class="form-group"><label>${L("CNV.Formula")}</label><input name="formula" value="1d4"></div>
      <div class="form-group"><label>${L("CNV.Damage.Type")}</label><select name="type">${types}</select></div>`,
    ok: { callback: (e, b) => new foundry.applications.ux.FormDataExtended(b.form).object }, rejectClose: false
  });
  if ( !r ) return;
  const eff = await setCondition(actor, "persistentDamage", 1);
  const e = actor.effects.find(x => x.statuses.has("persistentDamage"));
  return e?.update({ name: `${L("CNV.Cond.persistentDamage")} ${r.formula} (${L(CONFIG.CNV.damageTypes[r.type].label)})`,
    [`flags.${SYS}.formula`]: r.formula, [`flags.${SYS}.damageType`]: r.type });
}

/* -------------------------------------------- */
/*  Character                                    */
/* -------------------------------------------- */

export class CharacterSheet extends CNVActorSheet {
  static DEFAULT_OPTIONS = {
    classes: ["character"],
    actions: {
      shortRest: CharacterSheet.#onShortRest,
      longRest: CharacterSheet.#onLongRest,
      takeBreak: CharacterSheet.#onTakeBreak,
      fateRoll: CharacterSheet.#onFateRoll,
      supplyCheck: CharacterSheet.#onSupplyCheck,
      strain: CharacterSheet.#onStrain,
      deathTimer: CharacterSheet.#onDeathTimer,
      bondTier: CharacterSheet.#onBondTier,
      rollTableField: CharacterSheet.#onRollTableField,
      chooseTableField: CharacterSheet.#onChooseTableField,
      rollGeneticMods: CharacterSheet.#onRollGeneticMods,
      rollGeneticItem: CharacterSheet.#onRollGeneticItem,
      crewTraining: CharacterSheet.#onCrewTraining
    }
  };

  static PARTS = {
    header: { template: `systems/${SYS}/templates/actor/character-header.hbs` },
    tabs: { template: "templates/generic/tab-navigation.hbs" },
    main: { template: `systems/${SYS}/templates/actor/character-main.hbs`, scrollable: [""] },
    combat: { template: `systems/${SYS}/templates/actor/character-combat.hbs`, scrollable: [""] },
    talents: { template: `systems/${SYS}/templates/actor/character-talents.hbs`, scrollable: [""] },
    magic: { template: `systems/${SYS}/templates/actor/character-magic.hbs`, scrollable: [""] },
    inventory: { template: `systems/${SYS}/templates/actor/character-inventory.hbs`, scrollable: [""] },
    bio: { template: `systems/${SYS}/templates/actor/character-bio.hbs`, scrollable: [""] },
    effects: { template: `systems/${SYS}/templates/actor/actor-effects.hbs`, scrollable: [""] }
  };

  static TABS = {
    primary: {
      tabs: [
        { id: "main", icon: "fa-solid fa-dice-d20", label: "CNV.Tab.Main" },
        { id: "combat", icon: "fa-solid fa-gun", label: "CNV.Tab.Combat" },
        { id: "talents", icon: "fa-solid fa-star", label: "CNV.Tab.Talents" },
        { id: "magic", icon: "fa-solid fa-hand-sparkles", label: "CNV.Tab.Magic" },
        { id: "inventory", icon: "fa-solid fa-sack", label: "CNV.Tab.Inventory" },
        { id: "bio", icon: "fa-solid fa-feather", label: "CNV.Tab.Bio" },
        { id: "effects", icon: "fa-solid fa-bolt", label: "CNV.Tab.Effects" }
      ],
      initial: "main"
    }
  };

  async _prepareContext(options) {
    const ctx = await super._prepareContext(options);
    const s = this.actor.system;
    const C = CONFIG.CNV;
    ctx.tabs = this._prepareTabs("primary");
    const src = this.actor.system._source;
    const grants = this._grantSources();
    const training = builder.crewTrainings(this.actor);
    // Ability rows: points (creation/advancement choice) + genetic + granted (effects)
    for ( const a of ctx.abilities ) {
      const v = s.abilities[a.key];
      Object.assign(a, { points: src.abilities[a.key].value, genetic: v.genetic, granted: v.granted,
        grantedTip: (grants[`abilities.${a.key}`] ?? []).join("<br>") });
    }
    ctx.abilityPoints = s.abilityPoints;
    ctx.abilityPointsOver = s.abilityPoints && s.abilityPoints.spent > s.abilityPoints.max;
    ctx.skills = Object.entries(s.skills).map(([k, v]) => ({
      key: k, label: L(C.skills[k].label), ranks: v.ranks, purchased: src.skills[k].ranks, granted: v.granted,
      grantedTip: (grants[`skills.${k}`] ?? []).join("<br>"),
      training: training[k] ? L("CNV.Crew.TrainingTip", { crew: training[k].join(", ") }) : null,
      bonus: v.bonus, mod: v.mod, ability: v.abilityKey,
      abilityAbbr: L(C.abilities[v.abilityKey]?.abbr ?? ""), alt: C.skills[k].alt, combat: C.skills[k].combat, overCap: v.overCap,
      abilityChoices: C.skills[k].alt ? { [C.skills[k].ability]: L(C.abilities[C.skills[k].ability].abbr), [C.skills[k].alt]: L(C.abilities[C.skills[k].alt].abbr) } : null
    }));
    ctx.lores = s.lores.map((l, i) => ({ ...l, index: i }));
    ctx.weapons = this._items(["weapon"]);
    ctx.armor = this._items(["armor"]);
    ctx.shields = this._items(["shield"]);
    ctx.techniques = this._items(["technique"]);
    ctx.talents = this._items(["talent"]);
    ctx.origin = this._items(["origin"]);
    ctx.genetics = this._items(["genetic"]);
    ctx.bonds = this._items(["bond"]).map(b => ({ ...b, tiers: (b.system.tiers ?? []).map((t, i) => ({ ...t, index: i, unlocked: i < b.system.unlocked })) }));
    ctx.crewAbilities = this._items(["crewAbility"]);
    ctx.spells = this._items(["spell"]);
    ctx.spellsBySchool = Object.entries(C.spellSchools).map(([k, label]) => ({ key: k, label: L(label), spells: ctx.spells.filter(sp => sp.system.school === k) })).filter(g => g.spells.length);
    ctx.metamagic = this._items(["metamagic"]);
    ctx.gear = this._items(["gear"]);
    ctx.concoctions = this._items(["concoction"]);
    ctx.materials = this._items(["material", "essence", "ingredient", "rune"]);
    ctx.afflictions = this._items(["affliction"]);
    ctx.inventorySections = [
      { key: "gear", label: "CNV.Gear", items: ctx.gear },
      { key: "concoction", label: "CNV.Concoctions", items: ctx.concoctions },
      { key: "ingredient", label: "CNV.CraftingMaterials", items: ctx.materials },
      { key: "affliction", label: "CNV.Afflictions", items: ctx.afflictions }
    ];
    ctx.fatePips = Array.from({ length: s.fateMax }, (_, i) => ({ filled: i < s.fate.value, min: i < s.fateMin }));
    ctx.exhaustionChoices = { 0: "0", 1: "1", 2: "2", 3: "3", 4: "4" };
    ctx.exhaustionPips = [1, 2, 3, 4].map(i => ({ level: i, active: i <= s.exhaustion }));
    ctx.strainPct = Math.round((s.strain.value / Math.max(1, s.strain.max)) * 100);
    ctx.hpPct = Math.round((s.hp.value / Math.max(1, s.hp.max)) * 100);
    ctx.bulkPct = Math.min(100, Math.round((s.bulk.value / Math.max(1, s.bulk.max)) * 100));
    ctx.channelDC = null;
    ctx.enriched = { biography: await this._enrich(s.biography), notes: await this._enrich(s.notes) };
    ctx.hpFormulaHint = game.settings.get(SYS, "hpFormula") === "encounters" ? "(Fort + 5) × Level + 10" : "(Fort + 5) × (Level + 2)";
    ctx.abilityChoices = Object.fromEntries(Object.entries(C.abilities).map(([k, v]) => [k, L(v.label)]));
    ctx.virtues = C.virtues; ctx.vices = C.vices;
    // Personality: origin aspects paired with Virtues/Vices, and the personality prompts
    const d = s.details;
    const pc = builder.pairingCounts(this.actor);
    ctx.aspects = Object.entries(C.aspects).map(([k, label]) => ({ key: k, label: L(label), ...d.aspects[k],
      kindChoices: { "": "—", virtue: L("CNV.Virtue"), vice: L("CNV.Vice") } }));
    ctx.pairing = { ...pc, ok: pc.virtue === 2 && pc.vice === 2, over: pc.virtue > 2 || pc.vice > 2 };
    ctx.promptGroups = Object.entries(C.personalityPrompts).map(([gk, g]) => ({ key: gk, label: L(g.label),
      prompts: Object.entries(g.prompts).map(([k, [label, table]]) => ({ key: k, label: L(label), table, value: d.prompts?.[k] ?? "" })) }));
    ctx.originName = builder.originName(this.actor);
    return ctx;
  }

  /** Names of the effects that grant ability points or skill ranks, keyed "abilities.might" / "skills.medicine". */
  _grantSources() {
    const out = {};
    for ( const e of this.actor.allApplicableEffects() ) {
      if ( e.disabled || e.isSuppressed ) continue;
      for ( const c of e.changes ) {
        const m = c.key.match(/^system\.(abilities|skills)\.(\w+)\.granted$/);
        if ( !m ) continue;
        const src = e.parent instanceof Item ? `${e.parent.name}` : e.name;
        (out[`${m[1]}.${m[2]}`] ??= []).push(`${src}${e.parent instanceof Item && e.name !== e.parent.name ? ` (${e.name})` : ""}: ${Number(c.value) >= 0 ? "+" : ""}${c.value}`);
      }
    }
    return out;
  }

  async _preparePartContext(partId, context) {
    context = await super._preparePartContext(partId, context);
    if ( context.tabs?.[partId] ) context.tab = context.tabs[partId];
    return context;
  }

  static #onShortRest() { return this.actor.shortRest(); }
  static async #onLongRest() {
    const rough = await foundry.applications.api.DialogV2.wait({
      window: { title: L("CNV.Rest.Long") }, content: `<p>${L("CNV.Rest.ShelterQuestion")}</p>`,
      buttons: [{ action: "no", label: L("CNV.Rest.Sheltered"), default: true }, { action: "yes", label: L("CNV.Rest.Rough") }], rejectClose: false
    });
    if ( !rough ) return;
    return this.actor.longRest({ rough: rough === "yes" });
  }
  static #onTakeBreak() { return this.actor.takeABreak(); }
  static #onFateRoll() { return this.actor.rollFateDie(); }
  static async #onSupplyCheck() {
    const r = await foundry.applications.api.DialogV2.prompt({ window: { title: L("CNV.Supplies.Check", { dc: "?" }) },
      content: `<div class="form-group"><label>${L("CNV.Level")}</label><input type="number" name="level" value="0"></div>`,
      ok: { callback: (e, b) => Number(b.form.elements.level.value) || 0 }, rejectClose: false });
    if ( r === null || r === undefined ) return;
    return this.actor.supplyCheck(r);
  }
  static async #onStrain(event, target) {
    const delta = Number(target.dataset.delta);
    if ( delta > 0 ) return this.actor.spendStrain(delta);
    return this.actor.update({ "system.strain.value": Math.max(0, this.actor.system.strain.value + delta) });
  }
  static #onDeathTimer() { return this.actor.onlyMostlyDead(); }

  /** Resolve which table and which field a roll/choose button targets. */
  async _tableTarget(target) {
    const { field, table, aspect } = target.dataset;
    if ( aspect ) return { table: await builder.aspectTableName(this.actor, aspect), path: aspect === "specialty" ? "system.details.specialty" : `system.details.aspects.${aspect}.text` };
    return { table, path: field };
  }
  static async #onRollTableField(event, target) {
    if ( target.dataset.trait ) return builder.drawTrait(this.actor, target.dataset.trait);
    const t = await this._tableTarget(target);
    if ( !t.table ) return;
    const text = await builder.drawFromTable(t.table, { actor: this.actor });
    if ( text ) return this.actor.update({ [t.path]: text });
  }
  static async #onChooseTableField(event, target) {
    if ( target.dataset.trait ) return builder.drawTrait(this.actor, target.dataset.trait, { choose: true });
    const t = await this._tableTarget(target);
    if ( !t.table ) return;
    const text = await builder.drawFromTable(t.table, { choose: true, actor: this.actor });
    if ( text ) return this.actor.update({ [t.path]: text });
  }
  static #onRollGeneticMods() { return builder.rollGeneticModifiers(this.actor); }
  static #onRollGeneticItem(event, target) {
    return builder.addGeneticFromTable(this.actor, target.dataset.kind, { choose: target.dataset.choose === "true" });
  }
  static #onCrewTraining(event, target) { return builder.useCrewTraining(this.actor, target.dataset.skill); }
  static #onBondTier(event, target) {
    const item = this.actor.items.get(target.closest("[data-item-id]").dataset.itemId);
    const n = Number(target.dataset.tier) + 1;
    return item.update({ "system.unlocked": item.system.unlocked === n ? n - 1 : n });
  }
}

/* -------------------------------------------- */
/*  Adversary                                    */
/* -------------------------------------------- */

export class AdversarySheet extends CNVActorSheet {
  static DEFAULT_OPTIONS = {
    classes: ["adversary"],
    position: { width: 700, height: 820 },
    actions: {
      baselineAttack: AdversarySheet.#onBaseline,
      morale: AdversarySheet.#onMorale,
      rollAdvSkill: AdversarySheet.#onAdvSkill,
      resetHP: AdversarySheet.#onResetHP
    }
  };

  static PARTS = {
    header: { template: `systems/${SYS}/templates/actor/adversary-header.hbs` },
    tabs: { template: "templates/generic/tab-navigation.hbs" },
    stats: { template: `systems/${SYS}/templates/actor/adversary-stats.hbs`, scrollable: [""] },
    build: { template: `systems/${SYS}/templates/actor/adversary-build.hbs`, scrollable: [""] },
    notes: { template: `systems/${SYS}/templates/actor/adversary-notes.hbs`, scrollable: [""] },
    effects: { template: `systems/${SYS}/templates/actor/actor-effects.hbs`, scrollable: [""] }
  };

  static TABS = {
    primary: {
      tabs: [
        { id: "stats", icon: "fa-solid fa-skull", label: "CNV.Tab.StatBlock" },
        { id: "build", icon: "fa-solid fa-sliders", label: "CNV.Tab.Build" },
        { id: "notes", icon: "fa-solid fa-feather", label: "CNV.Tab.Notes" },
        { id: "effects", icon: "fa-solid fa-bolt", label: "CNV.Tab.Effects" }
      ],
      initial: "stats"
    }
  };

  async _prepareContext(options) {
    const ctx = await super._prepareContext(options);
    const s = this.actor.system;
    const C = CONFIG.CNV;
    ctx.tabs = this._prepareTabs("primary");
    ctx.maneuvers = this._items(["maneuver"]);
    ctx.actions = ctx.maneuvers.filter(m => !["passive", "reaction", "free"].includes(m.system.cost) && m.system.category !== "morale");
    ctx.reactions = ctx.maneuvers.filter(m => m.system.cost === "reaction");
    ctx.traits = ctx.maneuvers.filter(m => ["passive", "free"].includes(m.system.cost) && m.system.category !== "morale");
    ctx.moraleTraits = ctx.maneuvers.filter(m => m.system.category === "morale");
    ctx.weapons = this._items(["weapon", "shield"]);
    ctx.other = this._items(["gear", "concoction", "affliction", "essence", "ingredient", "armor", "talent", "spell"]);
    ctx.baseline = s.baseline.map((b, i) => ({ ...b, index: i, dice: b.dice }));
    ctx.ranks = Object.fromEntries(Object.entries(C.ranks).map(([k, v]) => [k, L(v.label)]));
    ctx.roles = Object.fromEntries(Object.entries(C.roles).map(([k, v]) => [k, L(v.label)]));
    ctx.qualities = Object.fromEntries(Object.entries(C.qualities).map(([k, v]) => [k, L(v)]));
    ctx.creatureTypes = C.creatureTypes;
    ctx.damageTypes = Object.fromEntries(Object.entries(C.damageTypes).map(([k, v]) => [k, L(v.label)]));
    ctx.sizes = Object.fromEntries(Object.entries(C.sizes).map(([k, v]) => [k, L(v)]));
    ctx.rankData = s.rankData; ctx.roleData = s.roleData;
    ctx.roleStrong = (s.roleData?.strong ?? []).join(", ");
    ctx.roleWeak = (s.roleData?.weak ?? []).join(", ");
    ctx.isMinion = s.rank === "minion";
    ctx.enriched = { description: await this._enrich(s.description), notes: await this._enrich(s.notes) };
    ctx.rvi = ["resist", "vuln", "immune"].map(k => ({ key: k, label: L(`CNV.RVI.${k}`), value: [...(s.traits[k] ?? [])].join(", ") }));
    return ctx;
  }

  async _preparePartContext(partId, context) {
    context = await super._preparePartContext(partId, context);
    if ( context.tabs?.[partId] ) context.tab = context.tabs[partId];
    return context;
  }

  /** Convert comma lists for RVI into sets. */
  _processFormData(event, form, formData) {
    const data = super._processFormData(event, form, formData);
    for ( const k of ["resist", "vuln", "immune"] ) {
      const v = foundry.utils.getProperty(data, `system.traits.${k}`);
      if ( typeof v === "string" ) foundry.utils.setProperty(data, `system.traits.${k}`, v.split(",").map(x => x.trim().toLowerCase()).filter(Boolean));
    }
    return data;
  }

  static async #onBaseline(event, target) {
    const b = this.actor.system.baseline[Number(target.dataset.index)];
    if ( !b ) return;
    const pseudo = {
      name: b.name, uuid: this.actor.uuid, type: "maneuver",
      system: { isRanged: !!b.range, skill: "", category: "natural", traits: [], traitValues: {}, requirement: {}, attackBonus: 0,
        usesAmmo: false, ammo: {}, damage: { dice: b.dice, type: b.type } }
    };
    return this.actor.rollAttack(pseudo, { event });
  }
  static #onMorale() { return this.actor.rollMorale(); }
  static #onAdvSkill(event, target) { return this.actor.rollSkill(target.dataset.skill, { event }); }
  static #onResetHP() {
    const s = this.actor.system;
    return this.actor.update({ "system.hp.value": s.hp.max, "system.morale.value": s.startingMorale, "system.strain.value": 0 });
  }
}

/* -------------------------------------------- */
/*  Hazard                                       */
/* -------------------------------------------- */

export class HazardSheet extends CNVActorSheet {
  static DEFAULT_OPTIONS = {
    classes: ["hazard"],
    position: { width: 640, height: 760 },
    actions: {
      hazardDetect: HazardSheet.#onDetect,
      hazardTrigger: HazardSheet.#onTrigger,
      hazardDamage: HazardSheet.#onDamage,
      hazardDisable: HazardSheet.#onDisable
    }
  };
  static PARTS = { main: { template: `systems/${SYS}/templates/actor/hazard-sheet.hbs`, scrollable: [".cnv-body"] } };

  async _prepareContext(options) {
    const ctx = await super._prepareContext(options);
    const s = this.actor.system;
    ctx.enriched = { description: await this._enrich(s.description), effect: await this._enrich(s.effect), notes: await this._enrich(s.notes) };
    ctx.natures = Object.fromEntries(Object.entries(CONFIG.CNV.hazardNatures).map(([k, v]) => [k, L(v)]));
    ctx.saveChoices = Object.fromEntries(Object.entries(CONFIG.CNV.abilities).map(([k, v]) => [k, L(v.label)]));
    ctx.damageTypes = Object.fromEntries(Object.entries(CONFIG.CNV.damageTypes).map(([k, v]) => [k, L(v.label)]));
    ctx.rungs = CONFIG.CNV.passiveRungs.map((r, i) => ({ rung: r, index: i + 1 }));
    return ctx;
  }

  /** Passive Awareness: each PC compares Perception-based passive (d20-free: 10 + skill) against the detection DC. */
  static async #onDetect() {
    const s = this.actor.system;
    const dc = s.detectDC;
    const pcs = game.actors.filter(a => a.type === "character" && a.hasPlayerOwner);
    const rows = pcs.map(a => {
      const skill = a.system.skills?.[s.stealth.skill || "investigation"] ?? a.system.skills?.investigation;
      const passive = 10 + (a.system.abilities.perception.value) + (skill?.ranks ?? 0);
      // Rungs: beat by 0..4 -> rung 1, 5..9 -> rung 2, 10..14 -> 3, 15+ -> 4 (Passive Awareness ladder)
      const margin = passive - dc;
      const rung = margin < -5 ? 0 : margin < 0 ? 1 : margin < 5 ? 2 : margin < 10 ? 3 : 4;
      return `<tr><td>${a.name}</td><td>${passive}</td><td>${rung ? L("CNV.Hazard.Rung", { n: rung }) : "—"}</td></tr>`;
    }).join("");
    ChatMessage.create({ whisper: ChatMessage.getWhisperRecipients("GM"),
      content: `<div class="cnv-card"><h4>${this.actor.name} — ${L("CNV.Hazard.PassiveAwareness")} (DC ${dc})</h4><table class="cnv-table"><tr><th>${L("CNV.Name")}</th><th>${L("CNV.Passive")}</th><th>${L("CNV.Hazard.Rungs")}</th></tr>${rows}</table></div>` });
  }
  static async #onTrigger() {
    const s = this.actor.system;
    const content = await foundry.applications.handlebars.renderTemplate(`systems/${SYS}/templates/chat/hazard-card.hbs`, {
      actor: this.actor, system: s, saveLabel: L(CONFIG.CNV.abilities[s.save.ability]?.label ?? ""), effect: await this._enrich(s.effect)
    });
    return ChatMessage.create({ speaker: ChatMessage.getSpeaker({ actor: this.actor }), content });
  }
  static #onDamage() {
    const s = this.actor.system;
    return this.actor.postDamage(s.damageFormula, { type: s.damageType || "untyped", flavor: `${this.actor.name} — ${L("CNV.Damage.Label")}` });
  }
  static #onDisable() {
    const s = this.actor.system;
    ChatMessage.create({ speaker: ChatMessage.getSpeaker({ actor: this.actor }),
      content: `<div class="cnv-card"><h4>${L("CNV.Hazard.Disable")}: ${this.actor.name}</h4><p>${s.disable || ""}</p>
      <div class="cnv-card-buttons"><button data-cnv-action="rollSkill" data-skill="${s.stealth.skill || "thievery"}" data-dc="${s.disableDCValue}">${L("CNV.Hazard.DisableCheck", { dc: s.disableDCValue })}</button></div></div>` });
  }
}

/* -------------------------------------------- */
/*  Crew                                         */
/* -------------------------------------------- */

export class CrewSheet extends CNVActorSheet {
  static DEFAULT_OPTIONS = {
    classes: ["crew"],
    position: { width: 720, height: 780 },
    actions: { cohortCheck: CrewSheet.#onCohortCheck, openMember: CrewSheet.#onOpenMember, removeMember: CrewSheet.#onRemoveMember }
  };
  static PARTS = {
    header: { template: `systems/${SYS}/templates/actor/crew-header.hbs` },
    tabs: { template: "templates/generic/tab-navigation.hbs" },
    crew: { template: `systems/${SYS}/templates/actor/crew-main.hbs`, scrollable: [""] },
    cohorts: { template: `systems/${SYS}/templates/actor/crew-cohorts.hbs`, scrollable: [""] },
    notes: { template: `systems/${SYS}/templates/actor/crew-notes.hbs`, scrollable: [""] }
  };
  static TABS = {
    primary: {
      tabs: [
        { id: "crew", icon: "fa-solid fa-people-group", label: "CNV.Tab.Crew" },
        { id: "cohorts", icon: "fa-solid fa-user-group", label: "CNV.Tab.Cohorts" },
        { id: "notes", icon: "fa-solid fa-feather", label: "CNV.Tab.Notes" }
      ],
      initial: "crew"
    }
  };

  async _prepareContext(options) {
    const ctx = await super._prepareContext(options);
    const s = this.actor.system;
    ctx.tabs = this._prepareTabs("primary");
    ctx.crewTypes = CONFIG.CNV.crewTypes;
    ctx.cohortTypes = Object.fromEntries(Object.entries(CONFIG.CNV.cohortTypes).map(([k, v]) => [k, v.label]));
    ctx.members = s.members.map(uuid => fromUuidSync(uuid)).filter(Boolean).map(a => ({ uuid: a.uuid, name: a.name, img: a.img, level: a.system.level }));
    ctx.abilities = this._items(["crewAbility"]);
    ctx.upgrades = this._items(["crewUpgrade"]);
    ctx.cohorts = s.cohorts.map((c, i) => ({ ...c, index: i }));
    ctx.skills = Object.fromEntries(Object.entries(CONFIG.CNV.skills).map(([k, v]) => [k, L(v.label)]));
    ctx.enriched = { description: await this._enrich(s.description), notes: await this._enrich(s.notes) };
    return ctx;
  }

  async _preparePartContext(partId, context) {
    context = await super._preparePartContext(partId, context);
    if ( context.tabs?.[partId] ) context.tab = context.tabs[partId];
    return context;
  }

  /** Dropping a character actor adds it as a member. */
  async _onDropActor(event, actor) {
    if ( actor.type !== "character" ) return;
    const members = new Set(this.actor.system.members);
    members.add(actor.uuid);
    await this.actor.update({ "system.members": [...members] });
    // Crew advances as one: sync the member's level
    if ( actor.isOwner && actor.system.level !== this.actor.system.level ) {
      ui.notifications.info(L("CNV.Crew.LevelNote", { name: actor.name, level: this.actor.system.level }));
    }
  }

  static async #onCohortCheck(event, target) {
    const c = this.actor.system.cohorts[Number(target.dataset.index)];
    if ( !c ) return;
    const quality = target.dataset.quality;
    const { performCheck } = await import("../dice/cnv-roll.mjs");
    return performCheck({ actor: this.actor, title: `${c.name || c.typeLabel} — ${L(`CNV.Quality.${quality}`)}`,
      parts: [{ label: L("CNV.CheckBonus"), value: c.check[quality] }], event });
  }
  static #onOpenMember(event, target) { fromUuidSync(target.dataset.uuid)?.sheet.render(true); }
  static #onRemoveMember(event, target) {
    return this.actor.update({ "system.members": this.actor.system.members.filter(u => u !== target.dataset.uuid) });
  }
}
